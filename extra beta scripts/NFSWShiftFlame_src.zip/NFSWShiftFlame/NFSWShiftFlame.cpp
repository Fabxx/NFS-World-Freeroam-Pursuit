#if __has_include(<windows.h>)
#include <windows.h>
#else
typedef int BOOL; typedef unsigned long DWORD; typedef void* HANDLE; typedef void* HMODULE; typedef void* LPVOID;
#define WINAPI __stdcall
#define DLL_PROCESS_ATTACH 1
#define PAGE_EXECUTE_READWRITE 0x40
#define GENERIC_WRITE 0x40000000
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
extern "C" {
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, unsigned long, DWORD, DWORD*);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, const void*, unsigned long);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess();
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(const char*);
__declspec(dllimport) HANDLE WINAPI CreateFileA(const char*, DWORD, DWORD, void*, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE, const void*, DWORD, DWORD*, void*);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
}
#endif

namespace {

struct Patch { unsigned addr; unsigned char len; const unsigned char* orig; const unsigned char* repl; };

const unsigned char kOrig1[] = { 0x83,0x8E,0x98,0x01,0x00,0x00,0x04 };
const unsigned char kNew1[]  = { 0x83,0x8E,0x98,0x01,0x00,0x00,0x14 };

const unsigned char kOrig2[] = { 0x83,0xA6,0x98,0x01,0x00,0x00,0xFB, 0x5F,0x5E,0x8B,0xE5,0x5D,0x8B,0xE3,0x5B,0xC2,0x0C,0x00,
                                 0xCC,0xCC,0xCC,0xCC,0xCC,0xCC,0xCC };
const unsigned char kNew2[]  = { 0x83,0xA6,0x98,0x01,0x00,0x00,0xFB, 0x83,0x8E,0x98,0x01,0x00,0x00,0x10,
                                 0x5F,0x5E,0x8B,0xE5,0x5D,0x8B,0xE3,0x5B,0xC2,0x0C,0x00 };

const Patch kPatches[] = {
    { 0x733DF5, sizeof(kOrig1), kOrig1, kNew1 },
    { 0x733E07, sizeof(kOrig2), kOrig2, kNew2 },
};

unsigned g_base = 0x400000;
unsigned VA(unsigned a) { return a - 0x400000 + g_base; }

#ifdef _DEBUG
HANDLE g_log = INVALID_HANDLE_VALUE;
void LogOpen() { g_log = CreateFileA("NFSWShiftFlame.log", GENERIC_WRITE, 1, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0); }
void LogClose() { if (g_log != INVALID_HANDLE_VALUE) { CloseHandle(g_log); g_log = INVALID_HANDLE_VALUE; } }
void Log(const char* s) {
    if (g_log == INVALID_HANDLE_VALUE) return;
    DWORD n = 0, len = 0; while (s[len]) ++len;
    WriteFile(g_log, s, len, &n, 0);
}
void LogHex(unsigned v) {
    char b[11] = "0x00000000";
    for (int i = 0; i < 8; ++i) { unsigned d = (v >> (28 - 4 * i)) & 15; b[2 + i] = (char)(d < 10 ? '0' + d : 'A' + d - 10); }
    Log(b);
}
#else
inline void LogOpen() {}
inline void LogClose() {}
inline void Log(const char*) {}
inline void LogHex(unsigned) {}
#endif

bool Same(const unsigned char* a, const unsigned char* b, unsigned n) {
    for (unsigned i = 0; i < n; ++i) if (a[i] != b[i]) return false;
    return true;
}

void Apply() {
    g_base = (unsigned)(unsigned long)GetModuleHandleA(0);
    Log("NFSWShiftFlame: base exe "); LogHex(g_base); Log("\r\n");
    for (const Patch& p : kPatches) {
        const unsigned char* at = (const unsigned char*)(unsigned long)VA(p.addr);
        if (Same(at, p.repl, p.len)) { Log("gia' applicata a "); LogHex(p.addr); Log("\r\n"); continue; }
        if (!Same(at, p.orig, p.len)) { Log("byte inattesi a "); LogHex(p.addr); Log(" - versione exe diversa, nessuna modifica\r\n"); return; }
    }
    for (const Patch& p : kPatches) {
        unsigned char* at = (unsigned char*)(unsigned long)VA(p.addr);
        DWORD old = 0;
        if (!VirtualProtect(at, p.len, PAGE_EXECUTE_READWRITE, &old)) { Log("VirtualProtect fallita a "); LogHex(p.addr); Log("\r\n"); continue; }
        for (unsigned i = 0; i < p.len; ++i) at[i] = p.repl[i];
        VirtualProtect(at, p.len, old, &old);
        FlushInstructionCache(GetCurrentProcess(), at, p.len);
        Log("patch ok a "); LogHex(p.addr); Log("\r\n");
    }
    Log("fiammata al cambio marcia attiva\r\n");
}

}

extern "C" BOOL WINAPI DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        LogOpen();
        Apply();
        LogClose();
    }
    return 1;
}
