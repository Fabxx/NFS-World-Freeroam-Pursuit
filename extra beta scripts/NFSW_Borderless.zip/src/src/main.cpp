// NFSWBorderless.asi - finestra a schermo intero senza bordi per Need for Speed World (build 2015)
//
// Come funziona
//  - legge VideoConfig dal gioco (GetInt, vtable delle impostazioni 0xB2BCE0 slot 5 = 0x4713E0) e
//    forza "screenwindowed" = 1; in Mode 0 forza anche screenwidth/screenheight = risoluzione del monitor
//  - CreateWindowExA/W ("GameFrame"), SetWindowLongA/W, SetWindowPos, MoveWindow (IAT di nfsw.exe):
//    stile WS_POPUP|WS_VISIBLE e finestra grande quanto il monitor (o centrata, Mode 2)
//  - Direct3DCreate9 -> IDirect3D9::CreateDevice e IDirect3DDevice9::Reset: Windowed = TRUE sempre
//  - Mode 1 (stretch): il gioco resta alla sua risoluzione e l'immagine viene allargata al monitor;
//    GetClientRect / ScreenToClient / ClientToScreen e i messaggi del mouse vengono riscalati
//  - BlockFullscreenToggle: disattiva il passaggio a schermo intero esclusivo (0x6610C0)
#include "common.h"

#define WS_POPUP   0x80000000UL
#define WS_VISIBLE 0x10000000UL
#define WS_MINIMIZE 0x20000000UL
#define WS_EX_TOPMOST 0x00000008UL
#define SWP_NOSIZE 0x0001
#define SWP_NOMOVE 0x0002
#define SWP_NOZORDER 0x0004
#define SWP_FRAMECHANGED 0x0020
#define SWP_NOACTIVATE 0x0010
#define MONITOR_DEFAULTTOPRIMARY 1
#define MONITOR_DEFAULTTONEAREST 2

extern "C" {
__declspec(dllimport) HMONITOR WINAPI MonitorFromPoint(POINT, DWORD);
__declspec(dllimport) HMONITOR WINAPI MonitorFromWindow(HWND, DWORD);
__declspec(dllimport) BOOL WINAPI GetMonitorInfoA(HMONITOR, MONITORINFO*);
__declspec(dllimport) BOOL WINAPI EnumDisplayMonitors(HDC, const RECT*, MONITORENUMPROC, LPARAM);
__declspec(dllimport) BOOL WINAPI GetWindowRect(HWND, RECT*);
__declspec(dllimport) LONG WINAPI GetWindowLongW(HWND, int);
}

// ---------------------------------------------------------------- impostazioni
static int  g_mode = 0;          // 0 = risoluzione del desktop, 1 = stretch, 2 = centrata
static int  g_monitor = 0;       // 0 = principale, N = N-esimo monitor
static bool g_topMost = false, g_blockToggle = true, g_fixMouse = true, g_enabled = true;

// ---------------------------------------------------------------- stato
static HWND g_hwnd = 0;
static RECT g_mon = { 0, 0, 0, 0 };
static int  g_gameW = 0, g_gameH = 0;      // risoluzione del gioco (back buffer)

static int MonW() { return g_mon.right - g_mon.left; }
static int MonH() { return g_mon.bottom - g_mon.top; }

static int g_enumIdx;
static BOOL WINAPI EnumMon(HMONITOR m, HDC, RECT*, LPARAM)
{
    if (++g_enumIdx == g_monitor) { MONITORINFO mi; mi.cbSize = sizeof(mi); if (GetMonitorInfoA(m, &mi)) g_mon = mi.rcMonitor; return FALSE; }
    return TRUE;
}
static void UpdateMonitor()
{
    RECT old = g_mon;
    g_mon.left = g_mon.top = g_mon.right = g_mon.bottom = 0;
    if (g_monitor > 0) { g_enumIdx = 0; EnumDisplayMonitors(0, 0, EnumMon, 0); }
    if (MonW() <= 0) {
        HMONITOR m = (g_hwnd && g_monitor > 0) ? MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTONEAREST) : 0;
        if (!m) { POINT p = { 0, 0 }; m = MonitorFromPoint(p, MONITOR_DEFAULTTOPRIMARY); }
        MONITORINFO mi; mi.cbSize = sizeof(mi);
        if (GetMonitorInfoA(m, &mi)) g_mon = mi.rcMonitor;
    }
    if (old.right - old.left != MonW() || old.bottom - old.top != MonH()) {
        char a[16], b[16], c[16], d[16]; IntToStr(MonW(), a); IntToStr(MonH(), b); IntToStr(g_mon.left, c); IntToStr(g_mon.top, d);
        Log("monitor: ", a, "x", b, " @ ", c);
    }
}
// rettangolo della finestra del gioco
static RECT TargetRect()
{
    RECT r = g_mon;
    if (g_mode == 2 && g_gameW > 0 && g_gameH > 0 && g_gameW <= MonW() && g_gameH <= MonH()) {
        r.left = g_mon.left + (MonW() - g_gameW) / 2; r.top = g_mon.top + (MonH() - g_gameH) / 2;
        r.right = r.left + g_gameW; r.bottom = r.top + g_gameH;
    }
    return r;
}
static bool Stretching() { return g_mode == 1 && g_fixMouse && g_hwnd && g_gameW > 0 && g_gameH > 0 && MonW() > 0 && (g_gameW != MonW() || g_gameH != MonH()); }

// ---------------------------------------------------------------- impostazioni del gioco (VideoConfig)
static const DWORD kVtSettings = 0x00B2BCE0, kGetInt = 0x004713E0;
typedef int (__thiscall* GetInt_t)(void*, const char*, const char*, int);
static GetInt_t g_getInt;
static int __fastcall HookGetInt(void* self, void*, const char* sec, const char* key, int def)
{
    int v = g_getInt(self, sec, key, def);
    if (sec && key && Readable(sec, 1) && Readable(key, 1) && StrIEq(sec, "VideoConfig")) {
        int nv = v;
        if (StrIEq(key, "screenwindowed")) nv = 1;
        else if (g_mode == 0 && StrIEq(key, "screenwidth"))  { UpdateMonitor(); nv = MonW(); }
        else if (g_mode == 0 && StrIEq(key, "screenheight")) { UpdateMonitor(); nv = MonH(); }
        else if (StrIEq(key, "screenleft")) nv = g_mon.left;
        else if (StrIEq(key, "screentop"))  nv = g_mon.top;
        if (StrIEq(key, "screenwidth"))  g_gameW = nv;
        if (StrIEq(key, "screenheight")) g_gameH = nv;
        if (nv != v) { char a[16], b[16]; IntToStr(v, a); IntToStr(nv, b); Log("VideoConfig ", key, ": ", a, " -> ", b); }
        v = nv;
    }
    return v;
}

// ---------------------------------------------------------------- finestra
typedef HWND (WINAPI* CreateWindowExA_t)(DWORD, LPCSTR, LPCSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
typedef HWND (WINAPI* CreateWindowExW_t)(DWORD, LPCWSTR, LPCWSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
typedef LONG (WINAPI* SetWindowLong_t)(HWND, int, LONG);
typedef BOOL (WINAPI* SetWindowPos_t)(HWND, HWND, int, int, int, int, UINT);
typedef BOOL (WINAPI* MoveWindow_t)(HWND, int, int, int, int, BOOL);
typedef BOOL (WINAPI* GetClientRect_t)(HWND, RECT*);
typedef BOOL (WINAPI* PointConv_t)(HWND, POINT*);
typedef WORD (WINAPI* RegisterClassEx_t)(const void*);
static CreateWindowExA_t g_cwA; static CreateWindowExW_t g_cwW;
static SetWindowLong_t g_swlA, g_swlW; static SetWindowPos_t g_swp; static MoveWindow_t g_mw;
static GetClientRect_t g_gcr; static PointConv_t g_s2c, g_c2s;
static RegisterClassEx_t g_rcA, g_rcW;
static WNDPROC g_gameProc;

static DWORD FixStyle(DWORD s) { return WS_POPUP | WS_VISIBLE | (s & WS_MINIMIZE); }
static void PlaceWindow()
{
    if (!g_hwnd || !g_swp) return;
    UpdateMonitor();
    RECT r = TargetRect(), cur;
    if (GetWindowRect(g_hwnd, &cur) && cur.left == r.left && cur.top == r.top && cur.right == r.right && cur.bottom == r.bottom
        && ((DWORD)GetWindowLongW(g_hwnd, -16) & ~WS_MINIMIZE) == (WS_POPUP | WS_VISIBLE)) return;
    g_swp(g_hwnd, g_topMost ? (HWND)-1 : (HWND)0, r.left, r.top, r.right - r.left, r.bottom - r.top,
          SWP_FRAMECHANGED | SWP_NOACTIVATE | (g_topMost ? 0 : SWP_NOZORDER));
}
static bool IsGameClassA(LPCSTR c) { return c && ((DWORD)c >> 16) && StrIEq(c, "GameFrame"); }
static bool IsGameClassW(LPCWSTR c) { return c && ((DWORD)c >> 16) && WStrIEqA(c, "GameFrame"); }
static void OnCreate(HWND h, DWORD style)
{
    char hs[12]; HexStr(style, hs);
    g_hwnd = h;
    Log("finestra del gioco creata (stile originale ", hs, ")");
}
static HWND WINAPI HookCreateWindowExA(DWORD ex, LPCSTR cls, LPCSTR name, DWORD style, int x, int y, int w, int h, HWND p, HMENU m, HINSTANCE i, LPVOID l)
{
    if (!IsGameClassA(cls)) return g_cwA(ex, cls, name, style, x, y, w, h, p, m, i, l);
    UpdateMonitor(); RECT r = TargetRect();
    HWND hw = g_cwA(g_topMost ? (ex | WS_EX_TOPMOST) : ex, cls, name, FixStyle(style), r.left, r.top, r.right - r.left, r.bottom - r.top, p, m, i, l);
    if (hw) OnCreate(hw, style);
    return hw;
}
static HWND WINAPI HookCreateWindowExW(DWORD ex, LPCWSTR cls, LPCWSTR name, DWORD style, int x, int y, int w, int h, HWND p, HMENU m, HINSTANCE i, LPVOID l)
{
    if (!IsGameClassW(cls)) return g_cwW(ex, cls, name, style, x, y, w, h, p, m, i, l);
    UpdateMonitor(); RECT r = TargetRect();
    HWND hw = g_cwW(g_topMost ? (ex | WS_EX_TOPMOST) : ex, cls, name, FixStyle(style), r.left, r.top, r.right - r.left, r.bottom - r.top, p, m, i, l);
    if (hw) OnCreate(hw, style);
    return hw;
}
static LONG WINAPI HookSetWindowLongW(HWND h, int idx, LONG v)
{
    if (h == g_hwnd && idx == -16) v = (LONG)FixStyle((DWORD)v);
    return g_swlW(h, idx, v);
}
static LONG WINAPI HookSetWindowLongA(HWND h, int idx, LONG v)
{
    if (h == g_hwnd && idx == -16) v = (LONG)FixStyle((DWORD)v);
    return g_swlA(h, idx, v);
}
static BOOL WINAPI HookSetWindowPos(HWND h, HWND after, int x, int y, int cx, int cy, UINT fl)
{
    if (h == g_hwnd && (fl & (SWP_NOSIZE | SWP_NOMOVE)) != (SWP_NOSIZE | SWP_NOMOVE)) {
        UpdateMonitor(); RECT r = TargetRect();
        x = r.left; y = r.top; cx = r.right - r.left; cy = r.bottom - r.top;
        fl = (fl & ~(SWP_NOSIZE | SWP_NOMOVE)) | SWP_FRAMECHANGED;
        if (g_topMost) { after = (HWND)-1; fl &= ~SWP_NOZORDER; }
        else if (after == (HWND)-1) after = (HWND)-2;
    }
    return g_swp(h, after, x, y, cx, cy, fl);
}
static BOOL WINAPI HookMoveWindow(HWND h, int x, int y, int cx, int cy, BOOL rep)
{
    if (h == g_hwnd) { UpdateMonitor(); RECT r = TargetRect(); x = r.left; y = r.top; cx = r.right - r.left; cy = r.bottom - r.top; }
    return g_mw(h, x, y, cx, cy, rep);
}

// ---------------------------------------------------------------- Mode 1: coordinate riscalate
static BOOL WINAPI HookGetClientRect(HWND h, RECT* r)
{
    BOOL ok = g_gcr(h, r);
    if (ok && r && h == g_hwnd && Stretching()) { r->left = r->top = 0; r->right = g_gameW; r->bottom = g_gameH; }
    return ok;
}
static void RealClient(int& w, int& h)
{
    RECT r; w = MonW(); h = MonH();
    if (g_gcr(g_hwnd, &r) && r.right > 0 && r.bottom > 0) { w = r.right; h = r.bottom; }
}
static BOOL WINAPI HookScreenToClient(HWND h, POINT* p)
{
    BOOL ok = g_s2c(h, p);
    if (ok && p && h == g_hwnd && Stretching()) { int w, hh; RealClient(w, hh); p->x = p->x * g_gameW / w; p->y = p->y * g_gameH / hh; }
    return ok;
}
static BOOL WINAPI HookClientToScreen(HWND h, POINT* p)
{
    if (p && h == g_hwnd && Stretching()) { int w, hh; RealClient(w, hh); p->x = p->x * w / g_gameW; p->y = p->y * hh / g_gameH; }
    return g_c2s(h, p);
}
static LRESULT WINAPI GameProc(HWND h, UINT msg, WPARAM wp, LPARAM lp)
{
    if (h == g_hwnd && Stretching() && msg >= 0x200 && msg <= 0x20D && msg != 0x20A && msg != 0x20E) {
        int w, hh; RealClient(w, hh);
        int x = (short)(lp & 0xFFFF), y = (short)((lp >> 16) & 0xFFFF);
        x = x * g_gameW / w; y = y * g_gameH / hh;
        lp = (LPARAM)((x & 0xFFFF) | ((y & 0xFFFF) << 16));
    }
    if (h == g_hwnd && msg == 0x7E /*WM_DISPLAYCHANGE*/) PlaceWindow();
    return g_gameProc(h, msg, wp, lp);
}
struct WNDCLASSEX_ { UINT cbSize, style; WNDPROC proc; int a, b; HINSTANCE inst; void* icon; void* cur; void* br; const void* menu; const void* cls; void* sm; };
static WORD WINAPI HookRegisterClassExA(const void* wc)
{
    WNDCLASSEX_* c = (WNDCLASSEX_*)wc;
    if (c && IsGameClassA((LPCSTR)c->cls) && c->proc != GameProc) { WNDCLASSEX_ copy = *c; g_gameProc = c->proc; copy.proc = GameProc; return g_rcA(&copy); }
    return g_rcA(wc);
}
static WORD WINAPI HookRegisterClassExW(const void* wc)
{
    WNDCLASSEX_* c = (WNDCLASSEX_*)wc;
    if (c && IsGameClassW((LPCWSTR)c->cls) && c->proc != GameProc) { WNDCLASSEX_ copy = *c; g_gameProc = c->proc; copy.proc = GameProc; return g_rcW(&copy); }
    return g_rcW(wc);
}

// ---------------------------------------------------------------- Direct3D 9
// D3DPRESENT_PARAMETERS: +0 BackBufferWidth, +4 BackBufferHeight, +0x20 Windowed, +0x30 FullScreen_RefreshRateInHz
typedef void* (WINAPI* Direct3DCreate9_t)(UINT);
typedef HRESULT (__stdcall* CreateDevice_t)(void*, UINT, int, HWND, DWORD, DWORD*, void**);
typedef HRESULT (__stdcall* Reset_t)(void*, DWORD*);
static Direct3DCreate9_t g_d3dCreate; static CreateDevice_t g_createDevice; static Reset_t g_reset;

static void FixPresent(DWORD* pp, const char* who)
{
    if (!Readable(pp, 0x38)) return;
    bool wasFull = pp[8] == 0;
    pp[8] = 1;          // Windowed
    pp[12] = 0;         // FullScreen_RefreshRateInHz
    if (pp[0] && pp[1]) { g_gameW = (int)pp[0]; g_gameH = (int)pp[1]; }
    char a[16], b[16]; IntToStr((int)pp[0], a); IntToStr((int)pp[1], b);
    Log(who, ": back buffer ", a, "x", b, wasFull ? " (schermo intero esclusivo -> finestra senza bordi)" : " (finestra)");
}
static HRESULT __stdcall HookReset(void* dev, DWORD* pp)
{
    FixPresent(pp, "Reset");
    HRESULT hr = g_reset(dev, pp);
    PlaceWindow();
    return hr;
}
static HRESULT __stdcall HookCreateDevice(void* d3d, UINT ad, int type, HWND focus, DWORD flags, DWORD* pp, void** dev)
{
    FixPresent(pp, "CreateDevice");
    HRESULT hr = g_createDevice(d3d, ad, type, focus, flags, pp, dev);
    if (hr >= 0 && dev && *dev && !g_reset) {
        void** vt = *(void***)*dev;
        if (WritePtr(&vt[16], (void*)HookReset, (void**)&g_reset)) Log("IDirect3DDevice9::Reset agganciato");
    }
    if (hr < 0) { char h[12]; HexStr((DWORD)hr, h); Log("ATTENZIONE: CreateDevice ha restituito ", h); }
    PlaceWindow();
    return hr;
}
static void* WINAPI HookDirect3DCreate9(UINT sdk)
{
    void* d3d = g_d3dCreate(sdk);
    if (d3d && !g_createDevice) {
        void** vt = *(void***)d3d;
        if (WritePtr(&vt[16], (void*)HookCreateDevice, (void**)&g_createDevice)) Log("IDirect3D9::CreateDevice agganciato");
    }
    return d3d;
}

// ---------------------------------------------------------------- avvio
static void Hook(const char* dll, const char* fn, void* hook, void** orig)
{
    if (HookIAT(dll, fn, hook, orig)) Log("  agganciato ", fn);
    else Log("  ATTENZIONE: import non trovato: ", fn);
}
static void Init(HINSTANCE self)
{
    InitPaths(self);
    DeleteFileA(g_log);
    g_logOn = GetPrivateProfileIntA("General", "Log", 1, g_ini) != 0;
    Log("NFSWBorderless 1.0");
    g_enabled     = GetPrivateProfileIntA("General", "Enabled", 1, g_ini) != 0;
    g_mode        = (int)GetPrivateProfileIntA("Borderless", "Mode", 0, g_ini);
    g_monitor     = (int)GetPrivateProfileIntA("Borderless", "Monitor", 0, g_ini);
    g_topMost     = GetPrivateProfileIntA("Borderless", "TopMost", 0, g_ini) != 0;
    g_blockToggle = GetPrivateProfileIntA("Borderless", "BlockFullscreenToggle", 1, g_ini) != 0;
    g_fixMouse    = GetPrivateProfileIntA("Borderless", "FixMouse", 1, g_ini) != 0;
    if (g_mode < 0 || g_mode > 2) g_mode = 0;
    if (!g_enabled) { Log("disattivato ([General] Enabled=0)"); return; }
    static const char* modes[3] = { "0 (risoluzione del desktop)", "1 (stretch)", "2 (centrata)" };
    Log("Mode = ", modes[g_mode]);
    UpdateMonitor();

    DWORD* slot = (DWORD*)(kVtSettings + 5 * 4 + g_delta);
    if (Readable(slot, 4) && *slot == kGetInt + g_delta && WritePtr(slot, (void*)HookGetInt, (void**)&g_getInt))
        Log("impostazioni VideoConfig agganciate");
    else Log("ATTENZIONE: vtable delle impostazioni non riconosciuta (nfsw.exe diverso?)");

    Hook("user32.dll", "CreateWindowExA", (void*)HookCreateWindowExA, (void**)&g_cwA);
    Hook("user32.dll", "CreateWindowExW", (void*)HookCreateWindowExW, (void**)&g_cwW);
    Hook("user32.dll", "SetWindowLongW", (void*)HookSetWindowLongW, (void**)&g_swlW);
    HookIAT("user32.dll", "SetWindowLongA", (void*)HookSetWindowLongA, (void**)&g_swlA);
    Hook("user32.dll", "SetWindowPos", (void*)HookSetWindowPos, (void**)&g_swp);
    Hook("user32.dll", "MoveWindow", (void*)HookMoveWindow, (void**)&g_mw);
    if (g_mode == 1) {
        Hook("user32.dll", "GetClientRect", (void*)HookGetClientRect, (void**)&g_gcr);
        Hook("user32.dll", "ScreenToClient", (void*)HookScreenToClient, (void**)&g_s2c);
        Hook("user32.dll", "ClientToScreen", (void*)HookClientToScreen, (void**)&g_c2s);
        Hook("user32.dll", "RegisterClassExA", (void*)HookRegisterClassExA, (void**)&g_rcA);
        Hook("user32.dll", "RegisterClassExW", (void*)HookRegisterClassExW, (void**)&g_rcW);
    }
    Hook("d3d9.dll", "Direct3DCreate9", (void*)HookDirect3DCreate9, (void**)&g_d3dCreate);

    if (g_blockToggle) {
        BYTE* fn = (BYTE*)(0x006610C0 + g_delta);
        static const BYTE expect[] = { 0x55, 0x8B, 0xEC, 0x83, 0x3D };
        static const BYTE patch[]  = { 0x33, 0xC0, 0xC2, 0x04, 0x00 };   // xor eax,eax ; ret 4
        bool same = Readable(fn, 5); for (int i = 0; same && i < 5; ++i) same = fn[i] == expect[i];
        if (same && WriteBytes(fn, patch, 5)) Log("passaggio a schermo intero esclusivo disattivato");
        else Log("ATTENZIONE: funzione finestra/schermo intero non riconosciuta, BlockFullscreenToggle ignorato");
    }
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); Init(h); }
    return TRUE;
}
