NFSWUIScale 1.22 - UI scaling for Need for Speed World (2015 build, offline)

Install: copy NFSWUIScale.asi and NFSWUIScale.ini to gamedata\Scripts (ASI loader required).

What it does
- Hooks GFxMovieRoot::SetViewport and sets GViewport::Scale = 1/s (s = screen height / BaseHeight),
  so every Scaleform movie is drawn s times larger; partial movies (gadgets/windows) are enlarged and
  anchored (edge, top-left, center or in place, see the ini).
- Mouse fixes for enlarged windows listed in FixMouseMovies (powerup console, world map):
  close button, hover, window drag (position remembered in NFSWUIScale.sav), native map
  zoom/arrow controls (0x4ADB30 handler), resize grip (area test 0x6516E0 and window manager
  mouse handler 0x65C370 get the cursor in the window's original units). Map size is remembered too.

Build
- Visual Studio: open NFSWUIScale.vcxproj, configuration Release|Win32 (output bin\NFSWUIScale.asi).
- Linux: build.sh (clang-cl + lld-link, no CRT; shim\ provides minimal headers/import libs).
