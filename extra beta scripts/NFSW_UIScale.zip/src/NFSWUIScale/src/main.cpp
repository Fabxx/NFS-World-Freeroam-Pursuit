// NFSWUIScale - scala dell'interfaccia (DPI) per NFS World 2015.
//
// Come funziona
//   Ogni filmato Scaleform (GFx 3.x) ha un viewport impostato dal gioco con GFxMovieRoot::SetViewport
//   (vtable 0xC3CAF0, slot 25 = 0xA1DB40). Il viewport ha un campo Scale che il gioco lascia a 1.0: in
//   modalita' noScale la Stage del filmato e' larga Width*Scale e alta Height*Scale e il disegno viene
//   ingrandito di 1/Scale. L'ASI imposta Scale = 1/s con s = altezza dello schermo / BaseHeight
//   (predefinito 768), limitato a [1, MaxScale].
//   Cosi' a 1920x1080 la Stage dei filmati a tutto schermo diventa 1067x600: i pannelli che si
//   agganciano ai bordi (ResolutionHelper / PanedScreen, Stage.width/height) restano ai bordi e tutto
//   viene disegnato 1.8 volte piu' grande, testo compreso, come fa la VinylShop di luglio 2010
//   (resizePanedScreen: scala = Stage.height / 600 senza limite).
//
//   I filmati che non coprono tutto lo schermo (gadget, tooltip, finestre) hanno un viewport piu'
//   piccolo: l'ASI lo ingrandisce di s e lo sposta tenendolo agganciato al bordo piu' vicino
//   (sinistra/destra/centro, alto/basso/centro), cosi' il contenuto non viene tagliato.
//   Nell'ini si possono escludere filmati o agganciarli al loro angolo in alto a sinistra.
//
//   Il mouse funziona da solo: GFx converte le coordinate con lo stesso viewport.
#include <windows.h>

extern "C" void* __cdecl memset(void* d, int c, size_t n) { unsigned char* p = (unsigned char*)d; while (n--) *p++ = (unsigned char)c; return d; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; while (n--) *a++ = *b++; return d; }
#pragma function(memset, memcpy)

static const DWORD kBase         = 0x00400000;
static const DWORD kVtSetViewport = 0x00C3CB54;   // GFxMovieRoot vtable slot 25
static const DWORD kSetViewport  = 0x00A1DB40;    // void __thiscall GFxMovieRoot::SetViewport(const GViewport&)
static const int   kRootMovieDef = 0x6C;          // GFxMovieRoot -> GFxMovieDefImpl*

struct GViewport {
    int BufferWidth, BufferHeight;
    int Left, Top, Width, Height;
    int ScissorLeft, ScissorTop, ScissorWidth, ScissorHeight;
    float Scale, AspectRatio;
    unsigned Flags;
};
typedef void(__thiscall* SetViewport_t)(void* root, const GViewport* vp);

static DWORD g_delta;
static SetViewport_t g_orig;
static char  g_ini[MAX_PATH], g_log[MAX_PATH];
static bool  g_logOn = true, g_enabled = true, g_partial = true;
static float g_baseHeight = 600.0f, g_maxScale = 1.8f, g_fixed = 0.0f, g_userMul = 1.0f;
static char  g_exclude[1024], g_topLeft[1024], g_center[1024], g_inPlace[1024];
static int   g_logLines = 0;
static int   g_scrW = 0, g_scrH = 0;

// ---------------------------------------------------------------- utilita'
static int  StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); StrCpy(d + n, s, cap - n); }
static char Lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static void IntToStr(int v, char* out) { char t[16]; int n = 0; bool neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (neg) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static void FloatToStr(float f, char* out)
{
    int i = 0; if (f < 0) { out[i++] = '-'; f = -f; }
    int ip = (int)f; int fp = (int)((f - (float)ip) * 1000.0f + 0.5f); if (fp >= 1000) { ++ip; fp -= 1000; }
    IntToStr(ip, out + i); i = StrLen(out); out[i++] = '.';
    out[i++] = (char)('0' + fp / 100); out[i++] = (char)('0' + (fp / 10) % 10); out[i++] = (char)('0' + fp % 10); out[i] = 0;
}
static float ParseFloat(const char* p, float def)
{
    while (*p == ' ' || *p == '\t') ++p;
    bool neg = false; if (*p == '-' || *p == '+') { neg = *p == '-'; ++p; }
    if (!((*p >= '0' && *p <= '9') || *p == '.' || *p == ',')) return def;
    float v = 0; while (*p >= '0' && *p <= '9') { v = v * 10.0f + (float)(*p - '0'); ++p; }
    if (*p == '.' || *p == ',') { ++p; float s = 0.1f; while (*p >= '0' && *p <= '9') { v += s * (float)(*p - '0'); s *= 0.1f; ++p; } }
    return neg ? -v : v;
}
static void Log(const char* a, const char* b = 0, const char* c = 0, const char* d = 0, const char* e = 0, const char* f = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w; const char* parts[6] = { a, b, c, d, e, f };
    for (int i = 0; i < 6; ++i) if (parts[i]) WriteFile(h, parts[i], StrLen(parts[i]), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}
static float IniFloat(const char* sec, const char* key, float def)
{
    char buf[64]; GetPrivateProfileStringA(sec, key, "", buf, sizeof(buf), g_ini);
    return buf[0] ? ParseFloat(buf, def) : def;
}
static void HexStr(DWORD v, char* buf) { const char* hx = "0123456789ABCDEF"; buf[0] = '0'; buf[1] = 'x'; for (int i = 0; i < 8; ++i) buf[2 + i] = hx[(v >> (28 - 4 * i)) & 15]; buf[10] = 0; }
static bool Readable(const void* p, unsigned n) { return p && (DWORD)p > 0x10000 && !IsBadReadPtr(p, n); }

// nome in una lista separata da virgole (senza estensione, maiuscole/minuscole indifferenti)
static bool InList(const char* list, const char* name)
{
    if (!name || !name[0]) return false;
    const char* p = list;
    while (*p) {
        while (*p == ' ' || *p == ',' || *p == ';') ++p;
        const char* s = p; while (*p && *p != ',' && *p != ';') ++p;
        const char* e = p; while (e > s && (e[-1] == ' ' || e[-1] == '\t')) --e;
        int n = (int)(e - s); if (n <= 0) continue;
        int i = 0; for (; i < n; ++i) if (Lower(s[i]) != Lower(name[i])) break;
        if (i == n && (name[n] == 0 || name[n] == '.')) return true;
    }
    return false;
}

// ---------------------------------------------------------------- nome del filmato
// Tutti i filmati vengono caricati da 0x52B4AA -> 0x402610 -> GFxLoader::CreateMovie (0x9A6120, thiscall
// (loader, const char* file, flags, x), ret 0xC) chiamato a 0x402621. L'ASI sostituisce quella chiamata e
// ricorda nome file -> MovieDataDef (MovieDef+0x1C -> +0x0C, lo stesso percorso usato da UpdateViewport
// per la dimensione del filmato), poi per ogni GFxMovieRoot (MovieDef a +0x6C) ritrova il nome.
static const DWORD kCreateMovieCall = 0x00402621;
static const DWORD kCreateMovie     = 0x009A6120;
typedef void*(__thiscall* CreateMovie_t)(void* loader, const char* file, unsigned flags, int x);
static CreateMovie_t g_createMovie;

static const void* DataDefOf(const void* def)
{
    if (!Readable(def, 0x20)) return def;
    const void* a = *(const void* const*)((const char*)def + 0x1C);
    if (!Readable(a, 0x10)) return def;
    const void* b = *(const void* const*)((const char*)a + 0x0C);
    return Readable(b, 4) ? b : def;
}
struct NameCache { const void* key; const void* def; char name[64]; int logged; DWORD seen[16]; };
static NameCache g_names[512];
static int g_nameNext = 0;
static void Remember(const void* def, const char* file)
{
    const void* key = DataDefOf(def);
    NameCache* c = 0;
    for (int i = 0; i < 512; ++i) if (g_names[i].key == key) { c = &g_names[i]; break; }
    if (!c) { c = &g_names[g_nameNext]; g_nameNext = (g_nameNext + 1) % 512; }
    c->key = key; c->def = def; c->logged = 0; memset(c->seen, 0, sizeof(c->seen));
    int n = StrLen(file), st = n; while (st > 0 && file[st - 1] != '/' && file[st - 1] != '\\') --st;
    int e = n; for (int i = n - 1; i > st; --i) if (file[i] == '.') { e = i; break; }
    int k = 0; for (int i = st; i < e && k < 63; ++i) c->name[k++] = file[i];
    c->name[k] = 0;
    char a[12], b[12]; HexStr((DWORD)def, a); HexStr((DWORD)key, b);
    if (g_logLines < 3000) { ++g_logLines; Log("caricato ", c->name, " def=", a, " key=", b); }
}
static void* __fastcall HookCreateMovie(void* loader, void*, const char* file, unsigned flags, int x)
{
    void* def = g_createMovie(loader, file, flags, x);
    if (def && file) Remember(def, file);
    return def;
}
static NameCache g_unknown = { 0, 0, "?", 0, {0} };
static NameCache* MovieInfo(void* root)
{
    const void* def = Readable((char*)root + kRootMovieDef, 4) ? *(const void* const*)((char*)root + kRootMovieDef) : 0;
    for (int i = 0; i < 512; ++i) if (g_names[i].def && g_names[i].def == def) return &g_names[i];
    const void* key = DataDefOf(def);
    for (int i = 0; i < 512; ++i) if (g_names[i].key && g_names[i].key == key) return &g_names[i];
    return &g_unknown;
}

// ---------------------------------------------------------------- scala
static float ScaleFor(int screenH)
{
    float s = g_fixed > 0.0f ? g_fixed : (float)screenH / g_baseHeight;
    if (s < 1.0f) s = 1.0f;
    if (g_fixed <= 0.0f && s > g_maxScale) s = g_maxScale;
    return s * g_userMul;
}
static int Round(float f) { return (int)(f >= 0 ? f + 0.5f : f - 0.5f); }

// un asse: posizione e lunghezza nuove tenendo il bordo piu' vicino (o il centro)
static void MapAxis(int screen, int pos, int len, float s, int mode, int& outPos, int& outLen)
{
    int nl = Round(len * s);
    if (nl > screen && screen > 0) nl = screen;
    int gapA = pos, gapB = screen - (pos + len);
    int tol = screen / 50 > 4 ? screen / 50 : 4;
    int np;
    if (mode == 1) np = pos;                                                   // angolo in alto a sinistra fisso
    else if (mode == 3) np = Round(pos + len * 0.5f - nl * 0.5f);             // ingrandito sul posto (es. nomi sopra le auto)
    else if (mode == 2 || (gapA - gapB <= tol && gapB - gapA <= tol))        // centro
        np = Round(screen * 0.5f + (pos + len * 0.5f - screen * 0.5f) * s - nl * 0.5f);
    else if (gapA < gapB) np = Round(gapA * s);
    else np = screen - Round(gapB * s) - nl;
    if (np + nl > screen) np = screen - nl;
    if (np < 0) np = 0;
    outPos = np; outLen = nl;
}

static void LogDecision(NameCache* c, const GViewport* in, const GViewport* out, float s, const char* what)
{
    // una riga per ogni combinazione diversa di buffer/viewport/decisione (max 16 per filmato)
    DWORD hsh = 2166136261u;
    const int* iv = (const int*)in;
    for (int i = 0; i < 6; ++i) hsh = (hsh ^ (DWORD)iv[i]) * 16777619u;
    hsh = (hsh ^ (DWORD)(s * 1000.0f)) * 16777619u;
    hsh = (hsh ^ (DWORD)what[0] ^ ((DWORD)StrLen(what) << 8)) * 16777619u;
    for (int i = 0; i < c->logged && i < 16; ++i) if (c->seen[i] == hsh) return;
    if (c->logged >= 16 || g_logLines > 3000) return;
    c->seen[c->logged] = hsh;
    ++c->logged; ++g_logLines;
    char a[16], b[16], cc[16], d[16], e[16], f[16], g[16], h[16], sc[16], line[256];
    IntToStr(in->Left, a); IntToStr(in->Top, b); IntToStr(in->Width, cc); IntToStr(in->Height, d);
    IntToStr(out->Left, e); IntToStr(out->Top, f); IntToStr(out->Width, g); IntToStr(out->Height, h); FloatToStr(s, sc);
    StrCpy(line, "[", 256); StrCat(line, c->name, 256); StrCat(line, "] ", 256); StrCat(line, what, 256);
    StrCat(line, " s=", 256); StrCat(line, sc, 256);
    StrCat(line, "  ", 256); StrCat(line, a, 256); StrCat(line, ",", 256); StrCat(line, b, 256); StrCat(line, " ", 256);
    StrCat(line, cc, 256); StrCat(line, "x", 256); StrCat(line, d, 256);
    StrCat(line, " -> ", 256); StrCat(line, e, 256); StrCat(line, ",", 256); StrCat(line, f, 256); StrCat(line, " ", 256);
    StrCat(line, g, 256); StrCat(line, "x", 256); StrCat(line, h, 256);
    char bw[16], bh[16]; IntToStr(in->BufferWidth, bw); IntToStr(in->BufferHeight, bh);
    Log(line, "  schermo ", bw, "x", bh);
}

// ultimo viewport passato/impostato per ogni filmato: se il gioco rilegge il viewport (GetViewport) e lo
// reimposta (spostamento, cambio scaleMode/align), arriva gia' ingrandito e non va ingrandito di nuovo
struct RootState { void* root; GViewport in, out; unsigned age; bool moved; };
static RootState g_roots[256];
static unsigned g_clock = 0;
static RootState* State(void* root, bool create)
{
    RootState* oldest = &g_roots[0];
    for (int i = 0; i < 256; ++i) {
        if (g_roots[i].root == root) return &g_roots[i];
        if (g_roots[i].age < oldest->age) oldest = &g_roots[i];
    }
    if (!create) return 0;
    memset(oldest, 0, sizeof(*oldest)); oldest->root = root;
    return oldest;
}
static float Abs(float f) { return f < 0 ? -f : f; }

// ---------------------------------------------------------------- finestre spostate dall'utente
// Quando l'utente trascina una finestra il gioco reimposta il viewport a ogni movimento del mouse con la
// nuova posizione. Prima l'ASI la ricalcolava come una posizione "di progetto" (distanza dal bordo x s):
// la finestra saltava altrove e il trascinamento successivo partiva da li' -> si riposizionava da sola.
// Ora, con il tasto sinistro premuto, la posizione richiesta viene usata cosi' com'e' (solo la
// dimensione resta ingrandita) e viene ricordata per nome del filmato: quando il gioco la ripropone
// (rilascio, riapertura del gadget) resta dove l'utente l'ha lasciata.
struct DragMem { char name[64]; int left, top, w, h; };
static DragMem g_drag[64];
static int g_dragNext = 0;
static bool g_followDrag = true;
static char g_sav[MAX_PATH];
static bool CursorOver(const GViewport& r)
{
    HWND w = GetActiveWindow();
    if (!w) return true;
    POINT p; RECT c;
    if (!GetCursorPos(&p) || !ScreenToClient(w, &p) || !GetClientRect(w, &c)) return true;
    int cw = c.right - c.left, ch = c.bottom - c.top;
    if (cw <= 0 || ch <= 0) return true;
    int bw = r.BufferWidth > 0 ? r.BufferWidth : cw, bh = r.BufferHeight > 0 ? r.BufferHeight : ch;
    int x = p.x * bw / cw, y = p.y * bh / ch, m = 64;
    return x >= r.Left - m && x <= r.Left + r.Width + m && y >= r.Top - m && y <= r.Top + r.Height + m;
}
static bool g_dragDirty = false;
static bool MouseDown() { return (GetAsyncKeyState(0x01) & 0x8000) != 0; }
static bool SameName(const char* a, const char* b) { int i = 0; for (; a[i] && b[i]; ++i) if (Lower(a[i]) != Lower(b[i])) return false; return a[i] == b[i]; }
static DragMem* DragFind(const char* name)
{
    if (!name || !name[0] || name[0] == '?') return 0;
    for (int i = 0; i < 64; ++i) if (g_drag[i].name[0] && SameName(g_drag[i].name, name)) return &g_drag[i];
    return 0;
}
static void DragRemember(const char* name, int l, int t, int w, int h)
{
    if (!name || !name[0] || name[0] == '?') return;
    DragMem* d = DragFind(name);
    if (!d) { d = &g_drag[g_dragNext]; g_dragNext = (g_dragNext + 1) % 64; StrCpy(d->name, name, 64); }
    if (d->left != l || d->top != t || d->w != w || d->h != h) g_dragDirty = true;
    d->left = l; d->top = t; d->w = w; d->h = h;
}
// posizioni salvate in NFSWUIScale.sav ([Positions] nome=left,top,w,h), ricaricate all'avvio
static void DragSave()
{
    g_dragDirty = false;
    for (int i = 0; i < 64; ++i) {
        if (!g_drag[i].name[0]) continue;
        char v[64], n[16];
        IntToStr(g_drag[i].left, v); StrCat(v, ",", 64); IntToStr(g_drag[i].top, n); StrCat(v, n, 64);
        StrCat(v, ",", 64); IntToStr(g_drag[i].w, n); StrCat(v, n, 64); StrCat(v, ",", 64); IntToStr(g_drag[i].h, n); StrCat(v, n, 64);
        WritePrivateProfileStringA("Positions3", g_drag[i].name, v, g_sav);
    }
}
static int ParseIntP(const char*& p) { bool neg = false; while (*p == ' ') ++p; if (*p == '-') { neg = true; ++p; } int v = 0; while (*p >= '0' && *p <= '9') v = v * 10 + (*p++ - '0'); if (*p == ',') ++p; return neg ? -v : v; }
static void DragLoad()
{
    static char keys[4096];
    DWORD n = GetPrivateProfileStringA("Positions3", 0, "", keys, sizeof(keys), g_sav);
    for (const char* k = keys; n && *k && k < keys + n; k += StrLen(k) + 1) {
        char v[64]; GetPrivateProfileStringA("Positions3", k, "", v, sizeof(v), g_sav);
        if (!v[0]) continue;
        const char* p = v;
        int l = ParseIntP(p), t = ParseIntP(p), w = ParseIntP(p), h = ParseIntP(p);
        if (w > 0 && h > 0) { DragRemember(k, l, t, w, h); }
    }
    g_dragDirty = false;
}
// viewport ingrandito con l'angolo in alto a sinistra nella posizione richiesta (tenuto dentro lo schermo)
static void PlaceAt(GViewport& o, const GViewport& src, int nw, int nh, float s, int W, int H)
{
    bool scissorSame = src.ScissorLeft == src.Left && src.ScissorTop == src.Top && src.ScissorWidth == src.Width && src.ScissorHeight == src.Height;
    o = src;
    int l = src.Left, t = src.Top;
    if (nw > W) nw = W; if (nh > H) nh = H;
    // la finestra puo' uscire in parte dal bordo destro/basso (come con la dimensione originale):
    // ne restano visibili almeno 80x40 pixel per poterla riprendere
    int keepW = nw < 80 ? nw : 80, keepH = nh < 40 ? nh : 40;
    if (l > W - keepW) l = W - keepW; if (t > H - keepH) t = H - keepH;
    if (l < 0) l = 0; if (t < 0) t = 0;
    o.Left = l; o.Top = t; o.Width = nw; o.Height = nh;
    if (scissorSame) {
        int r = l + nw > W ? W : l + nw, b = t + nh > H ? H : t + nh;
        o.ScissorLeft = l; o.ScissorTop = t; o.ScissorWidth = r - l; o.ScissorHeight = b - t;
    }
    o.Scale = 1.0f / s;
}

static void __fastcall HookSetViewport(void* root, void* /*edx*/, const GViewport* vp)
{
    if (!g_enabled || !vp) { g_orig(root, vp); return; }
    GViewport v = *vp;
    int W = v.BufferWidth > 0 ? v.BufferWidth : v.Width;
    int H = v.BufferHeight > 0 ? v.BufferHeight : v.Height;
    // dimensione reale dello schermo: il buffer piu' grande visto (finestre e HUD a tutto schermo)
    if (W >= 640 && H >= 480 && W * H > g_scrW * g_scrH) { g_scrW = W; g_scrH = H; }
    // alcuni gadget (es. la console dei powerup) hanno il buffer uguale alla propria dimensione e sono
    // posizionati sullo schermo con Left/Top: per loro lo schermo e' quello reale
    if (g_scrH > 0 && W == v.Width && H == v.Height && (v.Left > 0 || v.Top > 0) && W < g_scrW && H < g_scrH &&
        v.Left + v.Width <= g_scrW && v.Top + v.Height <= g_scrH) {
        W = g_scrW; H = g_scrH;
        v.BufferWidth = W; v.BufferHeight = H;
    }
    float s = ScaleFor(H);
    if (s <= 1.001f || v.Width <= 1 || v.Height <= 1) {
        NameCache* c = MovieInfo(root);
        LogDecision(c, vp, vp, s, "NON scalato (buffer piccolo o viewport vuoto)");
        v = *vp; v.Scale = 1.0f; g_orig(root, &v); return;
    }
    RootState* st = State(root, true);
    st->age = ++g_clock;
    if (g_followDrag && g_partial) {
        NameCache* dc = MovieInfo(root);
        bool eligible = !InList(g_exclude, dc->name) && !InList(g_topLeft, dc->name) && !InList(g_inPlace, dc->name) &&
                        !(v.Width >= W * 95 / 100 && v.Height >= H * 95 / 100);
        bool hadOut  = st->out.Width > 0 && st->out.Scale != 0.0f;
        bool sizeOut = hadOut && v.Width == st->out.Width && v.Height == st->out.Height && v.Scale < 0.999f;
        bool sizeIn  = hadOut && v.Width == st->in.Width && v.Height == st->in.Height;
        bool moved   = hadOut && (v.Left != st->out.Left || v.Top != st->out.Top);
        int rawW = sizeOut ? st->in.Width : v.Width, rawH = sizeOut ? st->in.Height : v.Height;
        DragMem* dm  = DragFind(dc->name);
        bool mouse   = MouseDown();
        if (!mouse && g_dragDirty) DragSave();
        // trascinamento vero: il gioco rilegge il viewport ingrandito (GetViewport) e lo sposta del delta del mouse,
        // quindi arriva con la dimensione gia' ingrandita e il cursore e' sopra la finestra. I riposizionamenti fatti
        // dal gioco mentre il tasto e' premuto (apertura di un gadget, cambio schermata) arrivano con la dimensione
        // originale e non vanno trattati come spostamenti dell'utente.
        // il gioco che rimette il gadget nella sua posizione di progetto (stesse coordinate originali, es. la
        // console dei powerup a 50,650) non e' un trascinamento, anche se il tasto e' premuto
        bool backToDesign = v.Left == st->in.Left && v.Top == st->in.Top;
        int ddx = v.Left - st->out.Left, ddy = v.Top - st->out.Top;
        bool smallStep = ddx < 200 && ddx > -200 && ddy < 200 && ddy > -200;
        if (eligible && moved && sizeOut && mouse && !backToDesign && smallStep && CursorOver(st->out)) {
            // trascinamento: la finestra segue la posizione richiesta dal gioco
            int nw = st->out.Width;
            int nh = st->out.Height;
            GViewport o;
            PlaceAt(o, v, nw, nh, s, W, H);
            DragRemember(dc->name, o.Left, o.Top, rawW, rawH);
            LogDecision(dc, vp, &o, s, "spostato dall'utente");
            st->out = o;
            st->moved = true;
            g_orig(root, &o);
            return;
        }
        if (eligible && !mouse && dm && dm->w == rawW && dm->h == rawH && (!hadOut || sizeIn || (sizeOut && moved))) {
            // finestra gia' spostata dall'utente e riaperta/riposizionata dal gioco: resta dove era stata lasciata
            GViewport src = v;
            if (sizeOut) { src.Width = st->in.Width; src.Height = st->in.Height; }
            else st->in = v;
            src.Left = dm->left; src.Top = dm->top;
            GViewport o;
            PlaceAt(o, src, Round(rawW * s), Round(rawH * s), s, W, H);
            if (!(hadOut && o.Left == st->out.Left && o.Top == st->out.Top && o.Width == st->out.Width)) LogDecision(dc, vp, &o, s, "posizione dell'utente");
            st->out = o;
            st->moved = true;
            g_orig(root, &o);
            return;
        }
    }
    if (st->out.Width == v.Width && st->out.Height == v.Height && st->out.Scale != 0.0f && Abs(st->out.Scale - v.Scale) < 1e-5f && v.Scale < 0.999f) {
        if (v.Left == st->out.Left && v.Top == st->out.Top) {
            g_orig(root, &v);                   // gia' scalato da questo ASI e non spostato
            st->out = v;
            return;
        }
        // il gioco ha riletto il viewport ingrandito (GetViewport) e lo ha spostato calcolando la posizione
        // con la dimensione originale (es. indicatore dell'inseguimento: Top = schermo - 164): si torna alla
        // dimensione originale e si rifa' il calcolo, altrimenti finirebbe in parte fuori dallo schermo
        v.Width = st->in.Width; v.Height = st->in.Height;
        v.BufferWidth = st->in.BufferWidth; v.BufferHeight = st->in.BufferHeight;
        v.ScissorLeft = v.Left; v.ScissorTop = v.Top; v.ScissorWidth = v.Width; v.ScissorHeight = v.Height;
        v.Scale = 1.0f;
    }
    st->in = v;
    NameCache* c = MovieInfo(root);
    if (InList(g_exclude, c->name)) { v = *vp; v.Scale = 1.0f; LogDecision(c, vp, &v, 1.0f, "escluso"); g_orig(root, &v); return; }
    bool full = v.Width >= W * 95 / 100 && v.Height >= H * 95 / 100;
    if (full) {
        v.Scale = 1.0f / s;
        LogDecision(c, vp, &v, s, "schermo intero");
    } else if (g_partial) {
        int mode = InList(g_topLeft, c->name) ? 1 : (InList(g_center, c->name) ? 2 : (InList(g_inPlace, c->name) ? 3 : 0));
        int nx, ny, nw, nh;
        MapAxis(W, v.Left, v.Width, s, mode, nx, nw);
        MapAxis(H, v.Top, v.Height, s, mode, ny, nh);
        bool scissorSame = v.ScissorLeft == v.Left && v.ScissorTop == v.Top && v.ScissorWidth == v.Width && v.ScissorHeight == v.Height;
        v.Left = nx; v.Top = ny; v.Width = nw; v.Height = nh;
        if (scissorSame) { v.ScissorLeft = nx; v.ScissorTop = ny; v.ScissorWidth = nw; v.ScissorHeight = nh; }
        // Stage = viewport / s: uguale all'originale, oppure piu' stretta se il viewport ingrandito non entra
        // nello schermo (barre larghe quanto lo schermo: si adattano come le schermate intere)
        v.Scale = 1.0f / s;
        LogDecision(c, vp, &v, s, mode == 1 ? "parziale (alto-sinistra)" : (mode == 2 ? "parziale (centro)" : (mode == 3 ? "parziale (sul posto)" : "parziale")));
    } else {
        v.Scale = 1.0f;
    }
    st->out = v;
    st->moved = v.Left != st->in.Left || v.Top != st->in.Top || v.Width != st->in.Width || v.Height != st->in.Height;
    g_orig(root, &v);
}

// ---------------------------------------------------------------- avvio
static void LoadSettings()
{
    g_logOn      = GetPrivateProfileIntA("General", "Log", 1, g_ini) != 0;
    g_enabled    = GetPrivateProfileIntA("General", "Enabled", 1, g_ini) != 0;
    g_baseHeight = IniFloat("Scale", "BaseHeight", 768.0f);
    g_maxScale   = IniFloat("Scale", "MaxScale", 1.8f);
    g_fixed      = IniFloat("Scale", "FixedScale", 0.0f);
    g_userMul    = IniFloat("Scale", "Multiplier", 1.0f);
    g_partial    = GetPrivateProfileIntA("Movies", "ScalePartial", 1, g_ini) != 0;
    g_followDrag = GetPrivateProfileIntA("Movies", "FollowDrag", 1, g_ini) != 0;
    GetPrivateProfileStringA("Movies", "Exclude", "", g_exclude, sizeof(g_exclude), g_ini);
    GetPrivateProfileStringA("Movies", "AnchorTopLeft", "", g_topLeft, sizeof(g_topLeft), g_ini);
    GetPrivateProfileStringA("Movies", "AnchorCenter", "", g_center, sizeof(g_center), g_ini);
    GetPrivateProfileStringA("Movies", "AnchorInPlace", "", g_inPlace, sizeof(g_inPlace), g_ini);
    if (g_baseHeight < 200.0f) g_baseHeight = 600.0f;
    if (g_maxScale < 1.0f) g_maxScale = 1.0f;
    if (g_userMul <= 0.1f || g_userMul > 4.0f) g_userMul = 1.0f;
    char a[16], b[16], c[16], d[16];
    FloatToStr(g_baseHeight, a); FloatToStr(g_maxScale, b); FloatToStr(g_fixed, c); FloatToStr(g_userMul, d);
    Log("BaseHeight=", a, " MaxScale=", b, " FixedScale=", c);
    Log("Multiplier=", d, g_partial ? " ScalePartial=1" : " ScalePartial=0");
    Log("Exclude=", g_exclude); Log("AnchorTopLeft=", g_topLeft); Log("AnchorCenter=", g_center); Log("AnchorInPlace=", g_inPlace);
}

// ---------------------------------------------------------------- mouse
// GFx vuole le coordinate del mouse relative all'angolo del viewport (HandleEvent: evento+8/+12;
// NotifyMouseState: x, y). Alcuni filmati (es. WorldMap) ricevono dal gioco coordinate calcolate con la
// posizione originale del riquadro: per i filmati spostati da questo ASI si ricalcolano dalla posizione
// reale del cursore e dal viewport effettivo, cosi' pulsanti e chiusura rispondono dove sono disegnati.
static const DWORD kVtHandleEvent = 0x00C3CB94;   // slot 41
static const DWORD kHandleEvent   = 0x00A14D60;
static const DWORD kVtNotifyMouse = 0x00C3CB9C;   // slot 43
static const DWORD kNotifyMouse   = 0x00A15170;
typedef int(__thiscall* HandleEvent_t)(void* root, void* ev, int a, int b);
typedef void(__thiscall* NotifyMouse_t)(void* root, float x, float y, int buttons, unsigned idx);
static HandleEvent_t g_origHandleEvent;
static NotifyMouse_t g_origNotifyMouse;
static bool g_fixMouse = true;

static bool CursorLocal(void* root, float& x, float& y)
{
    if (!g_fixMouse) return false;
    RootState* st = State(root, false);
    if (!st || !st->moved || st->out.Scale == 0.0f) return false;
    HWND w = GetActiveWindow();
    if (!w) return false;
    POINT p; RECT r;
    if (!GetCursorPos(&p) || !ScreenToClient(w, &p) || !GetClientRect(w, &r)) return false;
    int cw = r.right - r.left, ch = r.bottom - r.top;
    if (cw <= 0 || ch <= 0) return false;
    float bw = (float)(st->out.BufferWidth > 0 ? st->out.BufferWidth : cw);
    float bh = (float)(st->out.BufferHeight > 0 ? st->out.BufferHeight : ch);
    x = (float)p.x * bw / (float)cw - (float)st->out.Left;
    y = (float)p.y * bh / (float)ch - (float)st->out.Top;
    return true;
}
static int __fastcall HookHandleEvent(void* root, void*, void* ev, int a, int b)
{
    if (ev && Readable(ev, 16)) {
        int type = *(int*)ev;
        if (type >= 1 && type <= 4) {
            float x, y;
            if (CursorLocal(root, x, y)) { ((float*)ev)[2] = x; ((float*)ev)[3] = y; }
        }
    }
    return g_origHandleEvent(root, ev, a, b);
}
static void __fastcall HookNotifyMouse(void* root, void*, float x, float y, int buttons, unsigned idx)
{
    float nx, ny;
    if (CursorLocal(root, nx, ny)) { x = nx; y = ny; }
    g_origNotifyMouse(root, x, y, buttons, idx);
}
static bool PatchSlot(DWORD slotVa, DWORD expect, void* fn, void** orig)
{
    DWORD* slot = (DWORD*)(slotVa + g_delta);
    if (!Readable(slot, 4) || *slot != expect + g_delta) return false;
    *orig = (void*)*slot;
    DWORD old;
    if (!VirtualProtect(slot, 4, PAGE_READWRITE, &old)) return false;
    *slot = (DWORD)fn;
    VirtualProtect(slot, 4, old, &old);
    return true;
}

static void Init(HMODULE self)
{
    char path[MAX_PATH]; GetModuleFileNameA(self, path, MAX_PATH);
    int n = StrLen(path); while (n > 0 && path[n - 1] != '.' && path[n - 1] != '\\') --n;
    if (n > 0 && path[n - 1] == '.') path[n - 1] = 0;
    StrCpy(g_ini, path, MAX_PATH); StrCat(g_ini, ".ini", MAX_PATH);
    StrCpy(g_log, path, MAX_PATH); StrCat(g_log, ".log", MAX_PATH);
    StrCpy(g_sav, path, MAX_PATH); StrCat(g_sav, ".sav", MAX_PATH);
    DeleteFileA(g_log);
    Log("NFSWUIScale 1.4");
    LoadSettings();
    if (g_followDrag) DragLoad();
    if (!g_enabled) { Log("disattivato ([General] Enabled=0)"); return; }
    g_delta = (DWORD)GetModuleHandleA(0) - kBase;
    DWORD* slot = (DWORD*)(kVtSetViewport + g_delta);
    if (!Readable(slot, 4) || *slot != kSetViewport + g_delta) { Log("ERRORE: vtable di GFxMovieRoot non riconosciuta (nfsw.exe diverso?)"); return; }
    g_orig = (SetViewport_t)(*slot);
    DWORD old;
    if (!VirtualProtect(slot, 4, PAGE_READWRITE, &old)) { Log("ERRORE: VirtualProtect"); return; }
    *slot = (DWORD)(void*)HookSetViewport;
    VirtualProtect(slot, 4, old, &old);
    Log("GFxMovieRoot::SetViewport agganciato");
    g_fixMouse = GetPrivateProfileIntA("Movies", "FixMouse", 1, g_ini) != 0;
    if (g_fixMouse) {
        bool a = PatchSlot(kVtHandleEvent, kHandleEvent, (void*)HookHandleEvent, (void**)&g_origHandleEvent);
        bool b = PatchSlot(kVtNotifyMouse, kNotifyMouse, (void*)HookNotifyMouse, (void**)&g_origNotifyMouse);
        Log(a && b ? "mouse: correzione attiva (HandleEvent, NotifyMouseState)" : "ATTENZIONE: aggancio del mouse non riuscito");
    }
    unsigned char* call = (unsigned char*)(kCreateMovieCall + g_delta);
    if (Readable(call, 5) && call[0] == 0xE8 && (DWORD)call + 5 + *(int*)(call + 1) == kCreateMovie + g_delta) {
        g_createMovie = (CreateMovie_t)(kCreateMovie + g_delta);
        if (VirtualProtect(call + 1, 4, PAGE_EXECUTE_READWRITE, &old)) {
            *(int*)(call + 1) = (int)((DWORD)(void*)HookCreateMovie - ((DWORD)call + 5));
            VirtualProtect(call + 1, 4, old, &old);
            Log("GFxLoader::CreateMovie agganciato (nomi dei filmati)");
        }
    } else Log("ATTENZIONE: chiamata a CreateMovie non riconosciuta, i nomi dei filmati non saranno disponibili");
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); Init(h); }
    return TRUE;
}
