NFS World - Beta Safehouse (Asian beta, restored)
=================================================

The 2009 Asian beta (World Online) safehouse for NFS World 2015 (offline),
with fixed materials, lighting and background, plus a menu entry to open /
close the safehouse windows (blinds).

Install
-------
Copy the contents of "gamedata" into your game's gamedata folder
(back up the files it replaces first):

  Tracks\L5RA.BUN               section table (safehouse section size)
  Tracks\STREAML5RA_418.BUN     safehouse geometry / scenery
  Tracks\STREAML5RA_18.BUN      safehouse textures
  Scripts\NFSWSafehouseWindows.asi + .ini   windows toggle (needs an ASI loader)
  GFX\SafeHouseHub.gfx          safehouse menu with "OPEN/CLOSE SAFEHOUSE WINDOWS"

If you use the Player Profile safehouse mod, use
optional\PlayerProfile_mod\gamedata\GFX\SafeHouseHub.gfx instead
(same menu, keeps the PLAYER PROFILE entry).

Note: L5RA.BUN is a full track file; it is the one this port was made on.

What was fixed compared with the plain Asian beta conversion
------------------------------------------------------------
- Reflective materials restored (car platform, floor glass, beams, lights,
  skyscraper, construction building): shader ids, vertex buffers split per
  material, tangents, 16-byte chunk alignment.
- Vertex data of the reflective / special materials re-read from the Asian beta
  with the correct layouts (fixes stretched "rainbow" textures on the towers).
- Prelit vertex colours converted from the beta 2x scale (matches July 2010
  brightness).
- Background building / city textures replaced with the July 2010 versions;
  Asian-only highway and dam pieces hidden.

Windows toggle
--------------
The menu entry calls ExternalInterface "SafehouseWindows" ("toggle"/"state").
The ASI answers it by setting / clearing the instance exclude flags (0x18) of
FE_Blinds_01 and FE_Blinds_REF in memory. Settings in NFSWSafehouseWindows.ini
(optional hotkey, object list, log). Built for the 2015 nfsw.exe used by
NFS World Offline (ExternalInterface callback slot 0xB729C4); it chains with
other mods that wrap the same callback.

Source
------
source\asi        ASI source, build with build.sh (Linux, LLVM 18, no Windows SDK)
source\gfx        SafeHouseHub.as (vanilla and Player Profile variants), import into
                  SafeHouseHub.gfx with JPEXS FFDec (-importScript)
source\tools      Python scripts used to rebuild the safehouse files
                  (bun.py chunk tree writer, rebuild.py materials/vertex buffers,
                  asiavtx.py Asian vertex layouts, colorfix.py vertex colours,
                  texfix.py texture replacement, make418.py pipeline).
                  File paths inside make418.py / texfix.py point to the
                  original working folders and must be adjusted.
