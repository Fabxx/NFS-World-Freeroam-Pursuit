import sys,struct,statistics as st; sys.path.insert(0,'/tmp/bsh/tool')
from bun import parse,write
from rebuild import solids,find,sname,STRIDE
def groups_of(s):
    m=find(s.kids,0x80134100)[0]; k=m.kids; E=find(k,0x134b02)[0].data; ns=len(E)//116
    ef=[struct.unpack_from('<I',E,i*116+8)[0] for i in range(ns)]
    g=[]
    for i in range(ns):
        if g and ef[g[-1][-1]]==ef[i]: g[-1].append(i)
        else: g.append([i])
    return [(STRIDE[ef[gg[0]]],vb) for gg,vb in zip(g,find(k,0x134b01))]
def meancol(s):
    cols=[]
    for sd,vb in groups_of(s):
        if sd==28: continue
        for j in range(len(vb.data)//sd): cols.append(vb.data[j*sd+28:j*sd+32])
    if not cols: return None
    return [st.mean(c[i] for c in cols) for i in range(4)]
def apply(tree,ref_tree,default=0.5,log=print):
    R={sname(s):meancol(s) for s in solids(ref_tree)}
    def cs(a,b):
        n=0
        while n<min(len(a),len(b)) and a[-1-n]==b[-1-n]: n+=1
        return n
    def lookup(n):
        best=max(R,key=lambda r: cs(n,r)); l=cs(n,best)
        return R[best] if l>=10 else None
    for s in solids(tree):
        n=sname(s); mc=meancol(s)
        if mc is None: continue
        ref=lookup(n); setalpha=None
        if ref:
            lo=sum(mc[:3]); lr=sum(ref[:3])
            k=max(0.3,min(1.0,lr/lo)) if lo>0 else 1.0
            if ref[3]>=254 and mc[3]<254: setalpha=255
        else: k=default
        for sd,vb in groups_of(s):
            if sd==28: continue
            b=bytearray(vb.data)
            for j in range(len(b)//sd):
                o=j*sd+28
                for c in range(3): b[o+c]=min(255,int(round(b[o+c]*k)))
                if setalpha: b[o+3]=setalpha
            vb.data=bytes(b)
        log('%-28s x%.2f%s'%(n[-28:],k,' alpha->255' if setalpha else ''))
