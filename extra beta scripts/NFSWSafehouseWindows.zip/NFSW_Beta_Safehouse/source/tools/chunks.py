import sys,struct
def walk(d,o,end,depth,out,maxd=3):
    while o+8<=end:
        cid,sz=struct.unpack_from('<II',d,o)
        out.append((depth,o,cid,sz))
        if cid&0x80000000 and depth<maxd: walk(d,o+8,o+8+sz,depth+1,out,maxd)
        o+=8+sz
def chunks(fn,maxd=3):
    d=open(fn,'rb').read(); out=[]; walk(d,0,len(d),0,out,maxd); return d,out
if __name__=='__main__':
    d,out=chunks(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 1)
    import collections
    for dep,o,c,s in out:
        if dep<=int(sys.argv[3]) if len(sys.argv)>3 else dep==0: print('  '*dep+'%08x @%x size %d'%(c,o,s))
