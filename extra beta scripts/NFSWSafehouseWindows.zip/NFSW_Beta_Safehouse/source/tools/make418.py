import sys,struct; sys.path.insert(0,'/tmp/bsh/tool')
from bun import parse,write
import rebuild,colorfix,asiavtx
from scen import scen
CUR='/tmp/bsh/418_orig.BUN'
ASIA='/mnt/user-data/uploads/TRACKS/STREAML5RA_2420.BUN'; JUL='/mnt/user-data/uploads/Data/TRACKS/STREAML5RA_2420.BUN'
HIDE_INFOS=('TRN_Dam','PAN_HWY')   # asian-only background chunks, not in the July 2010 safehouse
def main(out_f):
    tree=parse(open(CUR,'rb').read()); A=rebuild.asian_flags(parse(open(ASIA,'rb').read()))
    for s in rebuild.solids(tree): rebuild.rebuild_solid(s,A.get(rebuild.sname(s)),print)
    asiavtx.apply(tree,parse(open(ASIA,'rb').read()))
    colorfix.apply(tree,parse(open(JUL,'rb').read()))
    # hide the asian-only background chunks (instance exclude flags 0x18)
    for top in tree:
        if top.id==0x80034100:
            info=[n for n in top.kids if n.id==0x34102][0].data; inst=[n for n in top.kids if n.id==0x34103][0]
            b=bytearray(inst.data)
            for j in range(len(b)//96):
                idx=struct.unpack_from('<H',b,j*96+84)[0]; nm=info[idx*72:idx*72+24].split(b'\0')[0].decode()
                if nm.startswith(HIDE_INFOS):
                    f=struct.unpack_from('<I',b,j*96+12)[0]; struct.pack_into('<I',b,j*96+12,f|0x18); print('hide',j,nm)
            inst.data=bytes(b)
    out=write(tree,bytearray()); open(out_f,'wb').write(out); print('size',len(out))
main(sys.argv[1])
