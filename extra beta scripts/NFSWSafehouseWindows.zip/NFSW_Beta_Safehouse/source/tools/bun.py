# generic EA bundle chunk tree with automatic 0x11 alignment padding
import struct
ALIGN={0x134011,0x134900,0x134b02,0x134b03,0x134b01,0x134c05,0x134c06,0x34101,0x34103,0x3410e,0x3410f,0x34c03,0x34105}
class Node:
    __slots__=('id','kids','data','padded')
    def __init__(s,id,kids=None,data=b'',padded=False): s.id=id; s.kids=kids; s.data=data; s.padded=padded
def parse(d,o=0,end=None):
    if end is None: end=len(d)
    res=[]
    while o+8<=end:
        cid,sz=struct.unpack_from('<II',d,o)
        p=o+8; e=p+sz
        if cid&0x80000000:
            res.append(Node(cid,parse(d,p,e)))
        else:
            data=d[p:e]; need=(16-(p%16))%16; padded=False
            if cid in ALIGN:
                if need>0:
                    assert data[:need]==b'\x11'*need, hex(cid)
                    data=data[need:]
                padded=True
            elif cid!=0 and need>0 and len(data)>=need and data[:need]==b'\x11'*need:
                data=data[need:]; padded=True
            res.append(Node(cid,None,data,padded))
        o=e
    return res
def write(nodes,out,top=True):
    for i,n in enumerate(nodes):
        hdr=len(out); out+=b'\0'*8; p=len(out)
        if n.kids is not None:
            write(n.kids,out,False)
        elif top and n.id==0 and n.data.count(0)==len(n.data):
            # alignment filler: make the next chunk start 16-aligned
            nxt=(16-((p)%16))%16
            out+=b'\0'*nxt
        else:
            if n.padded:
                need=(16-(p%16))%16
                out+=b'\x11'*need
            out+=n.data
        struct.pack_into('<II',out,hdr,n.id,len(out)-p)
    return out
def dump(nodes,dep=0):
    for n in nodes:
        print('  '*dep+'%08x'%n.id,len(n.data) if n.kids is None else '')
        if n.kids: dump(n.kids,dep+1)
