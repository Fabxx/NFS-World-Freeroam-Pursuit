import sys,struct; sys.path.insert(0,'/tmp/bsh/tool')
from tpk2 import tpk
OURS="/mnt/user-data/uploads/Need For Speed World Offline/gamedata/Tracks/STREAML5RA_18.BUN"; OTH='/tmp/bsh/x/STREAML5RA_24764.BUN'
REPL=['ARC_HIGHRISEGLASSWINDOWS_02_D','ARC_HIGHRISEGLASSWINDOWS_02_N','ARC_HIGHRISEGLASSWINDOWS_05_D','ARC_HIGHRISEGLASSWINDOWS_05_N','ARC_BUILDINGCONSTRUCTION_01_D','PAN_FECITY_01_D','PAN_FECITYGRID_01_D']
NORM=['ARC_HIGHRISEGLASSWINDOWS_04_D','ARC_HIGHRISEGLASSWINDOWS_04_N']
def base(d,dp):
    b=dp
    while d[b]==0x11: b+=1
    return b
def main(out_f):
    A=tpk(OURS); B=tpk(OTH)
    d=bytearray(A[0]); ents=A[1]; ab=base(A[0],A[2])
    Bd,Be,Bdp=B; bb=base(Bd,Bdp); Bn={e['name']:e for e in Be}
    offs=sorted(set(e['off'] for e in ents))
    datalen=len(d)  # upper bound guard
    for e in ents:
        p=e['pos']
        if e['name'] in REPL:
            o=Bn[e['name']]; nxt=[x for x in offs if x>e['off']]; room=(nxt[0] if nxt else None)
            if room is not None and o['size']>room-e['off']: print('NO ROOM',e['name'],o['size'],room-e['off']); continue
            assert (o['w'],o['hgt'])==(e['w'],e['hgt'])
            d[ab+e['off']:ab+e['off']+o['size']]=Bd[bb+o['off']:bb+o['off']+o['size']]
            # copy the 2010 header (keep our image offset)
            h=bytearray(Bd[o['pos']:o['pos']+0x84]); struct.pack_into('<I',h,0x44,e['off'])
            d[p:p+0x84]=h; print('replaced',e['name'],e['size'],'->',o['size'])
        elif e['name'] in NORM:
            d[p+4:p+8]=bytes.fromhex('cf931a00'); d[p+0x2c]=0; d[p+0x2e]=0; print('normalised',e['name'])
    open(out_f,'wb').write(d)
main(sys.argv[1])
