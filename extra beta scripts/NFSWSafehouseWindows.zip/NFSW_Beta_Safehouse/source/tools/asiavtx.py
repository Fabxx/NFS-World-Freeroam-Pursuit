import sys,struct; sys.path.insert(0,'/tmp/bsh/tool')
from rebuild import solids,find,sname,STRIDE,EFF
ASTR={0:36,10:36,7:52,11:52,4:24}
def asian_subverts(s):
    k=find(s.kids,0x80134100)[0].kids; E=find(k,0x134b02)[0].data; ns=len(E)//144
    fl=[struct.unpack_from('<HH',E,i*144+0x38) for i in range(ns)]; nv=[struct.unpack_from('<I',E,i*144+0x40)[0] for i in range(ns)]
    ef=[EFF(*f) if f[0] in (0x4000,0x4012) else -1 for f in fl]
    g=[]
    for i in range(ns):
        if g and ef[g[-1][-1]]==ef[i]: g[-1].append(i)
        else: g.append([i])
    vbs=find(k,0x134b01)
    if len(g)!=len(vbs): return None
    out={}
    for gg,vb in zip(g,vbs):
        if ef[gg[0]]<0: return None
        sd=ASTR[ef[gg[0]]]
        if len(vb.data)!=sum(nv[i] for i in gg)*sd: return None
        b=0
        for i in gg: out[i]=(sd,[vb.data[(b+j)*sd:(b+j+1)*sd] for j in range(nv[i])],ef[i]); b+=nv[i]
    return out
def pk(x):
    if x!=x: return 0
    return max(-32767,min(32767,int(round(x*32767))))
def apply(tree,asia_tree,log=print):
    A={}
    for s in solids(asia_tree): A.setdefault(sname(s),s)
    for s in solids(tree):
        a=A.get(sname(s))
        if not a: continue
        av=asian_subverts(a)
        if av is None: log('asian layout not understood',sname(s)); continue
        k=find(s.kids,0x80134100)[0].kids; E=find(k,0x134b02)[0].data; ns=len(E)//116
        ef=[struct.unpack_from('<I',E,i*116+8)[0] for i in range(ns)]; nv=[struct.unpack_from('<I',E,i*116+0x40)[0] for i in range(ns)]
        g=[]
        for i in range(ns):
            if g and ef[g[-1][-1]]==ef[i]: g[-1].append(i)
            else: g.append([i])
        for gg,vb in zip(g,find(k,0x134b01)):
            if ef[gg[0]]==10:
                # asian effect-10 layout (36 bytes): pos, uv, color, normal -> 2015: pos, normal(4h), uv, color, ffffffff
                b=bytearray(vb.data); base=0
                for i in gg:
                    sd,vs,aef=av.get(i,(0,[],0))
                    if sd!=36 or aef!=10 or len(vs)!=nv[i]: log('  no asian effect-10 data',sname(s),i); base+=nv[i]; continue
                    for j,v in enumerate(vs):
                        nx,ny,nz=struct.unpack_from('<3f',v,24); o=(base+j)*36
                        b[o:o+36]=v[0:12]+struct.pack('<4h',pk(nx),pk(ny),pk(nz),32767)+v[12:20]+v[20:24]+b'\xff\xff\xff\xff'
                    base+=nv[i]
                vb.data=bytes(b); log('asian effect-10 vertices restored',sname(s)[-28:]); continue
            if STRIDE[ef[gg[0]]]!=44: continue
            b=bytearray(vb.data); base=0; n=0
            for i in gg:
                sd,vs,aef=av.get(i,(0,[],0))
                if sd!=52 or len(vs)!=nv[i]: log('  no asian 52-byte data for',sname(s),i); base+=nv[i]; continue
                for j,v in enumerate(vs):
                    pos=v[0:12]
                    if aef==11:   # asian layout: pos, uv, color, normal, tangent, w
                        uv=v[12:20]; col=v[20:24]; nx,ny,nz=struct.unpack_from('<3f',v,24); tx,ty,tz,w=struct.unpack_from('<4f',v,36)
                    else:         # asian layout: pos, normal, color, uv, tangent, w
                        nx,ny,nz=struct.unpack_from('<3f',v,12); col=v[24:28]; uv=v[28:36]; tx,ty,tz,w=struct.unpack_from('<4f',v,36)
                    o=(base+j)*44
                    if b[o:o+12]!=pos: n+=1
                    nb=pos+struct.pack('<4h',pk(nx),pk(ny),pk(nz),32767)+uv+col+b'\xff\xff\xff\xff'+struct.pack('<4h',pk(tx),pk(ty),pk(tz),pk(w))
                    b[o:o+44]=nb
                base+=nv[i]
            vb.data=bytes(b); log('asian vertices restored %-28s posdiff %d'%(sname(s)[-28:],n))
