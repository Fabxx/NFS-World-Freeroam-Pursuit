import sys,struct; sys.path.insert(0,'/tmp/bsh/tool')
from chunks import chunks
def scen(fn):
    d,out=chunks(fn,3)
    res=[]; cur=None
    for dep,o,c,s in out:
        if c==0x80034100: cur={'o':o}; res.append(cur)
        if cur is not None and (c&0xffffff00)==0x34100 and dep>0: cur[c]=(o+8,s)
    secs=[]
    for sc in res:
        o,s=sc[0x34102]; infos=[]
        for i in range(s//72):
            b=d[o+i*72:o+i*72+72]; infos.append((b[:24].split(b'\0')[0].decode(),b))
        o,s=sc[0x34103]; ins=[]
        n=(s-4)//96
        for i in range(n):
            b=d[o+4+i*96:o+4+(i+1)*96]
            ins.append(dict(raw=b,flags=struct.unpack_from('<I',b,12)[0],idx=struct.unpack_from('<H',b,28)[0],x2=struct.unpack_from('<H',b,30)[0],pos=struct.unpack_from('<3f',b,32),tail=b[80:].hex()))
        secs.append((infos,ins,sc))
    return d,secs
