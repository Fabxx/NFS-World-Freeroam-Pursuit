import sys,struct; sys.path.insert(0,'/tmp/bsh/tool')
from chunks import chunks
def tpk(fn):
    d,out=chunks(fn,4)
    info=dds=data=None; hashes=None
    for dep,o,c,s in out:
        if c==0x33310004 and info is None: info=(o+8,s)
        if c==0x33310005 and dds is None: dds=(o+8,s)
        if c==0x33310002 and hashes is None: hashes=(o+8,s)
        if c==0x33320002 and data is None: data=(o+8,s)
    o,s=info; p=o; ents=[]
    while p<o+s-0x90:
        while d[p:p+4]==b'\0\0\0\0' and p<o+s-0x90: p+=4
        h=p
        name_len=d[h+0x84]; name=d[h+0x85:h+0x85+name_len].split(b'\0')[0].decode('latin1')
        e=dict(hash=struct.unpack_from('<I',d,h)[0],size=struct.unpack_from('<I',d,h+0xc)[0],off=struct.unpack_from('<I',d,h+0x44)[0],
               w=struct.unpack_from('<I',d,h+0x14)[0],hgt=struct.unpack_from('<I',d,h+0x18)[0],fmt=d[h+0x24:h+0x28].hex(),name=name,pos=h)
        ents.append(e); p=h+0x85+name_len; p=(p+3)&~3
    fo,fs=dds
    for i,e in enumerate(ents): e['fourcc']=d[fo+i*32+12:fo+i*32+16]
    # data offset base: data chunk payload start, skip 0x11? padding
    dp,dsz=data
    return d,ents,dp
if __name__=='__main__':
    d,ents,dp=tpk(sys.argv[1])
    for e in ents: print('%08x %-36s %4dx%-4d %-8s fmt %s size %d off %x'%(e['hash'],e['name'],e['w'],e['hgt'],e['fourcc'],e['fmt'],e['size'],e['off']))
