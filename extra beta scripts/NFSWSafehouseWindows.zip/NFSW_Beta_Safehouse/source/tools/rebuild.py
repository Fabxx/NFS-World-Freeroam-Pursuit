import sys,struct,math; sys.path.insert(0,'/tmp/bsh/tool')
from bun import parse,write
STRIDE={0:36,10:36,7:44,11:44,4:28}
EFF=lambda fa,fb: 11 if fb&0x1000 else 7 if fb&0x4000 else 4 if fb&0x2000 else 10 if fa==0x4012 else 0
def find(nodes,cid): return [n for n in nodes if n.id==cid]
def solids(tree):
    for top in tree:
        if top.id==0x80134000:
            for s in top.kids:
                if s.id==0x80134010: yield s
def sname(s):
    return find(s.kids,0x134011)[0].data.rstrip(b'\0').split(b'\0')[-1].decode('latin1')
def asian_flags(asia_tree):
    A={}
    for s in solids(asia_tree):
        m=find(s.kids,0x80134100)[0]; b=find(m.kids,0x134b02)[0].data
        A.setdefault(sname(s),[struct.unpack_from('<HH',b,i*144+0x38) for i in range(len(b)//144)])
    return A
def tangents(verts,tris):
    # verts: list of (pos,n,uv); returns list of (tx,ty,tz,w)
    n=len(verts); T=[[0.0,0.0,0.0] for _ in range(n)]; B=[[0.0,0.0,0.0] for _ in range(n)]
    for a,b,c in tris:
        p0,p1,p2=verts[a][0],verts[b][0],verts[c][0]; u0,u1,u2=verts[a][2],verts[b][2],verts[c][2]
        e1=[p1[i]-p0[i] for i in range(3)]; e2=[p2[i]-p0[i] for i in range(3)]
        du1,dv1=u1[0]-u0[0],u1[1]-u0[1]; du2,dv2=u2[0]-u0[0],u2[1]-u0[1]
        r=du1*dv2-du2*dv1
        if abs(r)<1e-12: continue
        r=1.0/r
        t=[(e1[i]*dv2-e2[i]*dv1)*r for i in range(3)]; bt=[(e2[i]*du1-e1[i]*du2)*r for i in range(3)]
        for v in (a,b,c):
            for i in range(3): T[v][i]+=t[i]; B[v][i]+=bt[i]
    out=[]
    for k in range(n):
        nn=verts[k][1]; t=T[k]
        d=sum(t[i]*nn[i] for i in range(3)); t=[t[i]-nn[i]*d for i in range(3)]
        L=math.sqrt(sum(x*x for x in t))
        if L<1e-9:
            # any vector orthogonal to the normal
            a=[1,0,0] if abs(nn[0])<0.9 else [0,1,0]
            t=[a[1]*nn[2]-a[2]*nn[1],a[2]*nn[0]-a[0]*nn[2],a[0]*nn[1]-a[1]*nn[0]]; L=math.sqrt(sum(x*x for x in t)) or 1
        t=[x/L for x in t]
        cr=[nn[1]*t[2]-nn[2]*t[1],nn[2]*t[0]-nn[0]*t[2],nn[0]*t[1]-nn[1]*t[0]]
        w=-1 if sum(cr[i]*B[k][i] for i in range(3))<0 else 1
        out.append(t+[w])
    return out
def rebuild_solid(s,af,log):
    m=find(s.kids,0x80134100)[0]; k=m.kids
    n900=find(k,0x134900)[0]; nb02=find(k,0x134b02)[0]; nb03=find(k,0x134b03)[0]; vbs=find(k,0x134b01)
    E=bytearray(nb02.data); ns=len(E)//116
    if af is None or len(af)!=ns: log('skip (no asian match)',sname(s)); return False
    ce=[struct.unpack_from('<I',E,i*116+8)[0] for i in range(ns)]
    nv=[struct.unpack_from('<I',E,i*116+0x40)[0] for i in range(ns)]
    ni=[struct.unpack_from('<I',E,i*116+0x44)[0] for i in range(ns)]
    st=[struct.unpack_from('<I',E,i*116+0x4c)[0] for i in range(ns)]
    idx=list(struct.unpack_from('<%dH'%(len(nb03.data)//2),nb03.data))
    # old groups
    groups=[]; 
    for i in range(ns):
        if groups and ce[groups[-1][-1]]==ce[i]: groups[-1].append(i)
        else: groups.append([i])
    if len(groups)!=len(vbs): log('vb/group mismatch',sname(s),len(groups),len(vbs)); return False
    sub_v={}  # submesh -> list of raw vertex bytes
    for g,vb in zip(groups,vbs):
        stv=STRIDE[ce[g[0]]]; base=0
        if len(vb.data)!=sum(nv[i] for i in g)*stv: log('vb size mismatch',sname(s),len(vb.data),stv); return False
        for i in g:
            seg=idx[st[i]:st[i]+ni[i]]
            if seg and (min(seg)<base or max(seg)>=base+nv[i]): log('index range mismatch',sname(s),i); return False
            sub_v[i]=(base,[vb.data[(base+j)*stv:(base+j+1)*stv] for j in range(nv[i])]); base+=nv[i]
    # new effects / flags
    ne=[]; nf=[]
    for i in range(ns):
        fa,fb=af[i]
        if ce[i]==4 or fa not in (0x4000,0x4012): e=ce[i]; f=struct.unpack_from('<HH',E,i*116)
        else: e=EFF(fa,fb); f=(fa,fb)
        if e==4 and ce[i]!=4: e=ce[i]; f=struct.unpack_from('<HH',E,i*116)   # never convert to the glow format
        ne.append(e); nf.append(f)
    if ne==ce and all(nf[i]==struct.unpack_from('<HH',E,i*116) for i in range(ns)): return False
    ngroups=[]
    for i in range(ns):
        if ngroups and ne[ngroups[-1][-1]]==ne[i]: ngroups[-1].append(i)
        else: ngroups.append([i])
    newvbs=[]; newidx=list(idx)
    for g in ngroups:
        out=bytearray(); base=0; ts=STRIDE[ne[g[0]]]
        for i in g:
            ob,vs=sub_v[i]
            seg=[x-ob for x in idx[st[i]:st[i]+ni[i]]]
            if STRIDE[ce[i]]==ts:
                for v in vs: out+=v
            elif STRIDE[ce[i]]==36 and ts==44:
                dec=[(struct.unpack_from('<3f',v,0),[c/32767.0 for c in struct.unpack_from('<3h',v,12)],struct.unpack_from('<2f',v,20)) for v in vs]
                tris=[(seg[j],seg[j+1],seg[j+2]) for j in range(0,len(seg)-2,3)]
                tg=tangents(dec,tris)
                for v,t in zip(vs,tg):
                    out+=v+struct.pack('<4h',*[max(-32767,min(32767,int(round(x*32767)))) for x in t[:3]],32767 if t[3]>0 else -32767)
            else: log('unsupported stride change',sname(s),ce[i],ne[i]); return False
            for j,x in enumerate(seg): newidx[st[i]+j]=x+base
            base+=nv[i]
        newvbs.append(out)
    # write back entries
    orf=0
    for i in range(ns):
        struct.pack_into('<HH',E,i*116,*nf[i]); struct.pack_into('<I',E,i*116+8,ne[i]); orf|=nf[i][0]|(nf[i][1]<<16)
    nb02.data=bytes(E)
    nb03.data=struct.pack('<%dH'%len(newidx),*newidx)+nb03.data[len(newidx)*2:]
    d9=bytearray(n900.data); struct.pack_into('<I',d9,12,orf); struct.pack_into('<I',d9,24,len(newvbs)); n900.data=bytes(d9)
    # replace vb nodes in place (keep order: first vb position)
    first=k.index(vbs[0]); 
    for vb in vbs: k.remove(vb)
    from bun import Node
    for j,vbd in enumerate(newvbs): k.insert(first+j,Node(0x134b01,None,bytes(vbd),True))
    # solid header: reflective flag
    h=find(s.kids,0x134011)[0]; hd=bytearray(h.data)
    if any(e in (7,10,11) for e in ne): hd[14]|=0x40
    h.data=bytes(hd)
    log('rebuilt %-28s eff %s -> %s  vbs %d -> %d'%(sname(s)[-28:],ce,ne,len(vbs),len(newvbs)))
    return True
def main(cur_f,asia_f,out_f,log=print):
    d=open(cur_f,'rb').read(); tree=parse(d); at=parse(open(asia_f,'rb').read()); A=asian_flags(at)
    n=0
    for s in solids(tree): n+=rebuild_solid(s,A.get(sname(s)),log)
    out=write(tree,bytearray()); open(out_f,'wb').write(out); return n,len(out)
if __name__=='__main__': print(main(*sys.argv[1:4]))
