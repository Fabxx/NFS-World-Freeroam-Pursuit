// NFSWSafehouseWindows.asi - opens/closes the safehouse windows (hides the blinds).
//
//  1. At startup the scenery section of the safehouse (gamedata\Tracks\STREAML5RA_418.BUN)
//     is read from disk and a signature of every instance of the objects listed in the
//     ini (FE_Blinds_01, FE_Blinds_REF) is kept (scenery.cpp).
//  2. The SafeHouseHub menu entry (menuhook.cpp) or the optional key flips the state;
//     the worker thread locates the instances in game memory and sets/clears their
//     exclude flags (blinds.cpp).
//  3. While the windows are open the state is re-applied if the section is streamed again.
#include "common.h"

volatile LONG g_request = 0;

static bool IsForeground()
{
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

static DWORD WINAPI Worker(LPVOID hooked)
{
    // the hook is normally installed in DllMain; retry here for executables that
    // are unpacked/patched after the ASI loader runs
    bool menu = hooked != 0;
    for (int i = 0; !menu && i < 120; ++i) { Sleep(500); menu = InstallMenuHook(i == 119); }

    Sleep(3000);
    if (!LoadSignatures()) return 0;

    bool keyWasDown = false;
    DWORD lastCheck = 0;
    for (;;) {
        Sleep(30);
        if (g_cfg.key) {
            bool down = (GetAsyncKeyState(g_cfg.key) & 0x8000) != 0;
            if (down && !keyWasDown && IsForeground()) {
                g_hidden = !g_hidden;
                Log(g_hidden ? "key: windows open" : "key: windows closed");
                g_request = 2;
            }
            keyWasDown = down;
        }
        if (g_request) {
            LONG r = InterlockedExchange(&g_request, 0);
            // user request: full speed; the periodic check below runs at low priority
            SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
            BlindsUpdate(r == 2);
            SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
            lastCheck = GetTickCount();
        }
        // keep the state if the section gets streamed out and back in (to a new address: the old copy can stay
        // in freed memory and still look valid, so a full scan is done)
        // the check also runs with the windows closed, so the addresses are already known when they are opened
        if (GetTickCount() - lastCheck > 15000) {
            lastCheck = GetTickCount();
            BlindsUpdate(true);
        }
    }
}

extern "C" BOOL WINAPI DllMain(HINSTANCE self, DWORD reason, LPVOID)
{
    if (reason != DLL_PROCESS_ATTACH) return TRUE;
    DisableThreadLibraryCalls(self);
    LoadConfig(self);
    Log("NFSWSafehouseWindows 1.3");
    g_hidden = 0;
    bool hooked = InstallMenuHook(true);
    HANDLE t = CreateThread(0, 0, Worker, (LPVOID)(ULONG_PTR)(hooked ? 1 : 0), 0, 0);
    if (t) { SetThreadPriority(t, THREAD_PRIORITY_BELOW_NORMAL); CloseHandle(t); }
    return TRUE;
}
