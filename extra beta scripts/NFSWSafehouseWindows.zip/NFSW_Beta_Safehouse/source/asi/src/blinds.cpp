// NFSWSafehouseWindows - finds the blind instances in game memory and sets/clears
// their exclude flags. Memory is read with ReadProcessMemory, so a page freed by
// the game during the scan cannot crash the game.
#include "common.h"
#include "signatures.h"

volatile LONG g_hidden = 0;

static const int kMaxAddr = 1024;   // stale copies of the section can stay in freed memory: keep room for all of them
static BYTE* s_addr[kMaxAddr];
static int   s_nAddr = 0;
static BYTE* s_buf = 0;
static const DWORD kChunk = 0x100000;   // 1 MB read chunks

static bool MatchAt(const BYTE* p, const Signature& s)
{
    return util::SameBytes(p, s.bboxMin, 12) && util::SameBytes(p + 16, s.rest, 60);
}

static void ScanMemory()
{
    s_nAddr = 0;
    if (!s_buf) s_buf = (BYTE*)HeapAlloc(GetProcessHeap(), 0, kChunk + 128);
    if (!s_buf) return;
    DWORD t0 = GetTickCount();
    static bool lead[4096];
    for (int k = 0; k < g_nSig; ++k) { DWORD w = *(DWORD*)g_sig[k].bboxMin; lead[(w ^ (w >> 13)) & 4095] = true; }
    MEMORY_BASIC_INFORMATION mi;
    BYTE* a = (BYTE*)0x10000;
    while ((ULONG_PTR)a < 0xFFFE0000u && VirtualQuery(a, &mi, sizeof(mi))) {
        BYTE* base = (BYTE*)mi.BaseAddress; SIZE_T rs = mi.RegionSize;
        DWORD pr = mi.Protect & 0xFF;
        // the scenery lives in writable heap/mapped memory: skip images (exe/dll) and read-only pages
        bool rw = pr == PAGE_READWRITE || pr == PAGE_WRITECOPY || pr == PAGE_EXECUTE_READWRITE || pr == PAGE_EXECUTE_WRITECOPY;
        if (mi.State == MEM_COMMIT && mi.Type != MEM_IMAGE && !(mi.Protect & PAGE_GUARD) && rw && rs >= 96) {
            for (SIZE_T off = 0; off < rs; off += kChunk) {
                DWORD n = (DWORD)((rs - off) < kChunk + 96 ? (rs - off) : kChunk + 96);
                if (n < 96 || !util::SafeRead(base + off, s_buf, n)) continue;
                for (DWORD p = 0; p + 96 <= n && p < kChunk; p += 4) {
                    DWORD w = *(DWORD*)(s_buf + p);
                    if (!lead[(w ^ (w >> 13)) & 4095]) continue;   // fast reject: not the start of any signature
                    for (int k = 0; k < g_nSig; ++k)
                        if (w == *(DWORD*)g_sig[k].bboxMin && MatchAt(s_buf + p, g_sig[k]) && s_nAddr < kMaxAddr)
                            s_addr[s_nAddr++] = base + off + p;
                }
            }
        }
        BYTE* next = base + rs; if (next <= a) break; a = next;
    }
    // drop matches inside our own tables
    int j = 0;
    for (int i = 0; i < s_nAddr; ++i) {
        BYTE* p = s_addr[i];
        if (p >= (BYTE*)g_sig && p < (BYTE*)(g_sig + kMaxSig)) continue;
        if (p >= s_buf && p < s_buf + kChunk + 128) continue;
        s_addr[j++] = p;
    }
    s_nAddr = j;
    LogNum("memory scan matches: ", (DWORD)s_nAddr);
    LogNum("  scan ms: ", GetTickCount() - t0);
}

static bool CacheValid()
{
    BYTE tmp[96];
    for (int i = 0; i < s_nAddr; ++i) {
        if (!util::SafeRead(s_addr[i], tmp, 96)) return false;
        bool ok = false;
        for (int k = 0; k < g_nSig; ++k) if (MatchAt(tmp, g_sig[k])) ok = true;
        if (!ok) return false;
    }
    return s_nAddr > 0;
}

static void Apply()
{
    for (int i = 0; i < s_nAddr; ++i) {
        DWORD f;
        if (!util::SafeRead(s_addr[i] + 12, &f, 4)) continue;
        f = g_hidden ? (f | g_cfg.hideFlags) : (f & ~g_cfg.hideFlags);
        util::SafeWrite(s_addr[i] + 12, &f, 4);
    }
}

void BlindsUpdate(bool forceScan)
{
    if (!g_nSig) return;
    bool valid = CacheValid();
    if (valid) Apply();                       // immediate result with the known addresses
    if (!forceScan && valid) return;
    ScanMemory();                             // the section may also live at a new address
    Apply();
}
