// NFSWSafehouseWindows - instance signatures shared by scenery.cpp and blinds.cpp
#pragma once
#include "common.h"

struct Signature {
    BYTE bboxMin[12];   // instance +0
    BYTE rest[60];      // instance +16 .. +76 (bbox max, position, rotation); flags at +12 are excluded
};
const int kMaxSig = 32;
extern Signature g_sig[kMaxSig];
extern int g_nSig;
