// NFSWSafehouseWindows - shared declarations
#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// ---- small string / memory helpers (no CRT dependency) -------------------
namespace util {
    int  Len(const char* s);
    void Cat(char* dst, const char* src, int cap);
    void Copy(char* dst, const char* src, int cap);
    bool Equal(const char* a, const char* b);
    bool InList(const char* commaList, const char* name);   // case-insensitive
    void UIntToStr(DWORD v, char* out);
    void HexToStr(DWORD v, char* out);                       // 8 hex digits
    bool SameBytes(const BYTE* a, const BYTE* b, int n);
    void CopyBytes(BYTE* dst, const BYTE* src, int n);
    bool SafeRead(const void* addr, void* buf, SIZE_T n);   // ReadProcessMemory on our own process
    bool SafeWrite(void* addr, const void* buf, SIZE_T n);
}

// ---- configuration (NFSWSafehouseWindows.ini, [Main]) ----------------------
struct Config {
    char  iniPath[MAX_PATH];
    char  logPath[MAX_PATH];
    char  gameDir[MAX_PATH];     // folder of the game exe (gamedata\), with trailing backslash
    int   log;                   // Log=1 writes NFSWSafehouseWindows.log
    int   key;                   // optional virtual-key code, 0 = none
    DWORD hideFlags;             // instance exclude flags set while the windows are open
    char  section[64];           // scenery section file in gamedata\Tracks
    char  objects[512];          // scenery object names to toggle
};
extern Config g_cfg;
void LoadConfig(HMODULE self);

// ---- log -------------------------------------------------------------------
void Log(const char* a, const char* b = 0, const char* c = 0);
void LogNum(const char* a, DWORD v);
void LogHex(const char* a, DWORD v);

// ---- scenery section on disk -> instance signatures (scenery.cpp) ----------
int  LoadSignatures();           // returns the number of signatures

// ---- blinds in game memory (blinds.cpp) -------------------------------------
extern volatile LONG g_hidden;  // 1 = windows open (blinds hidden)
extern volatile LONG g_request; // 1 = apply the state in the worker thread (dllmain.cpp)
void BlindsUpdate(bool forceScan);   // locate (if needed) and apply g_hidden

// ---- executable image helpers (pattern.cpp) ---------------------------------
BYTE*  FindCode(const char* pattern);              // "55 8B EC ?? 45" style (?? = any byte); first match in executable sections of the game exe
int    FindPointer(DWORD value, DWORD** out, int max);   // aligned DWORDs equal to value in non-executable sections
DWORD  ImageBase();

// ---- SafeHouseHub menu hook (menuhook.cpp) ----------------------------------
bool InstallMenuHook(bool verbose);   // true when the ExternalInterface handler is hooked
