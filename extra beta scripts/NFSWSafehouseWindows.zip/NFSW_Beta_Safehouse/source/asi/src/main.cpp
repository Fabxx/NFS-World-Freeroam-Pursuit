// NFSWSafehouseWindows.asi - toggle the safehouse window objects (blinds) with a key.
//
// How it works:
//  1. At startup the ASI reads the safehouse scenery section from disk
//     (gamedata\Tracks\STREAML5RA_418.BUN by default), finds the SceneryInfo names
//     (chunk 0x34102) and the SceneryInstances (chunk 0x34103), and keeps a byte
//     signature (bounding box + position + rotation) of every instance whose
//     object name is listed in the ini ("Objects=").
//  2. When the Safehouse menu entry (or the optional key) is used it flips the hidden
//     state, searches the game memory for those instances and sets / clears the
//     instance exclude flags (HideFlags, default 0x18 - the same bits used by the
//     July 2010 safehouse port to remove FE_Blinds_01).
//  3. While the window objects are hidden it re-checks the cached addresses and,
//     if the section was reloaded, searches again so they stay hidden.
#include <windows.h>

static char gIni[300], gLog[300], gGame[300];
static int gLogOn = 0, gKey = 0; static volatile int gHidden = 0;
static DWORD gHideFlags = 0x18;

struct Sig { BYTE bbmin[12]; BYTE rest[60]; /* +16..+28 bbox max, +28..+32 info idx, +32..+80 pos/rot */ DWORD flags; };
static Sig gSig[32]; static int gNSig = 0;
static BYTE* gAddr[64]; static int gNAddr = 0;

static int slen(const char* s){int n=0;while(s[n])n++;return n;}
static void scat(char* d,const char* s){d+=slen(d);while((*d++=*s++));}
static char lc(char c){return (c>='A'&&c<='Z')?c+32:c;}
static int mcmp(const BYTE* a,const BYTE* b,int n){for(int i=0;i<n;i++) if(a[i]!=b[i]) return 1; return 0;}
static void mcpy(BYTE* d,const BYTE* s,int n){for(int i=0;i<n;i++) d[i]=s[i];}
static void utoa_(DWORD v,char* o){char t[12];int i=0;do{t[i++]=(char)('0'+v%10);v/=10;}while(v);while(i)*o++=t[--i];*o=0;}
static void hex_(DWORD v,char* o){const char* h="0123456789abcdef";for(int i=7;i>=0;i--){o[7-i]=h[(v>>(i*4))&15];}o[8]=0;}
static void logs(const char* m){
    if(!gLogOn) return;
    HANDLE h=CreateFileA(gLog,4,1,0,4,0x80,0); if(h==INVALID_HANDLE_VALUE) return;
    DWORD w; WriteFile(h,m,slen(m),&w,0); WriteFile(h,"\r\n",2,&w,0); CloseHandle(h);
}
static void logn(const char* a,DWORD v){char m[200];m[0]=0;scat(m,a);char n[16];utoa_(v,n);scat(m,n);logs(m);}

// case-insensitive: is 'name' one of the comma separated entries of 'list'?
static int inList(const char* list,const char* name){
    const char* p=list;
    while(*p){
        while(*p==','||*p==' ') p++;
        const char* q=p; while(*q&&*q!=',') q++;
        int n=(int)(q-p); while(n>0&&p[n-1]==' ') n--;
        if(n>0){ int i=0; while(i<n&&name[i]&&lc(p[i])==lc(name[i])) i++; if(i==n&&name[i]==0) return 1; }
        p=q;
    }
    return 0;
}

// collect the instances of one scenery section (0x80034100): the info names
// (0x34102) come after the instances (0x34103) in the file, so look them up first
static void scenery(BYTE* d,DWORD o,DWORD end,const char* objs){
    BYTE* infos=0; DWORD ninfo=0;
    for(DWORD p=o;p+8<=end;){ DWORD id=*(DWORD*)(d+p), sz=*(DWORD*)(d+p+4); if(p+8+sz>end) break;
        if(id==0x00034102){ infos=d+p+8; ninfo=sz/72; } p+=8+sz; }        // SceneryInfo: 72 bytes, name in the first 24
    if(!infos) return;
    while(ninfo && *infos==0x11){ infos++; }                                // (no padding expected, just in case)
    for(DWORD p=o;p+8<=end;){ DWORD id=*(DWORD*)(d+p), sz=*(DWORD*)(d+p+4); if(p+8+sz>end) break;
        if(id==0x00034103){                                                 // SceneryInstance: 96 bytes after 0x11 padding
            BYTE* q=d+p+8; DWORD n=sz; while(n&&*q==0x11){q++;n--;}
            for(DWORD i=0;i<n/96 && gNSig<32;i++){
                BYTE* e=q+i*96; DWORD idx=*(WORD*)(e+84);
                if(idx>=ninfo) continue;
                char nm[25]; mcpy((BYTE*)nm,infos+idx*72,24); nm[24]=0;
                if(!inList(objs,nm)) continue;
                Sig& s=gSig[gNSig++]; mcpy(s.bbmin,e,12); mcpy(s.rest,e+16,60); s.flags=*(DWORD*)(e+12);
                char m[80]="instance found: "; scat(m,nm); logs(m);
            }
        }
        p+=8+sz; }
}
// walk the bundle chunks (id,size); container chunks have bit 31 set
static void walk(BYTE* d,DWORD o,DWORD end,const char* objs){
    while(o+8<=end){
        DWORD id=*(DWORD*)(d+o), sz=*(DWORD*)(d+o+4);
        if(o+8+sz>end) break;
        if(id==0x80034100) scenery(d,o+8,o+8+sz,objs);
        else if(id&0x80000000) walk(d,o+8,o+8+sz,objs);
        o+=8+sz;
    }
}
static void loadSignatures(){
    char sec[64], objs[512], path[400];
    GetPrivateProfileStringA("Main","Section","STREAML5RA_418.BUN",sec,64,gIni);
    GetPrivateProfileStringA("Main","Objects","FE_Blinds_01,FE_Blinds_REF",objs,512,gIni);
    path[0]=0; scat(path,gGame); scat(path,"Tracks\\"); scat(path,sec);
    HANDLE f=CreateFileA(path,0x80000000,1,0,3,0x80,0);
    if(f==INVALID_HANDLE_VALUE){ char m[460]="cannot open "; scat(m,path); logs(m); return; }
    DWORD sz=GetFileSize(f,0), rd=0; BYTE* d=(BYTE*)HeapAlloc(GetProcessHeap(),0,sz);
    if(d && ReadFile(f,d,sz,&rd,0) && rd==sz) walk(d,0,sz,objs);
    CloseHandle(f); if(d) HeapFree(GetProcessHeap(),0,d);
    logn("signatures: ",gNSig);
}

static int matchAt(BYTE* p,const Sig& s){ return !mcmp(p,s.bbmin,12) && !mcmp(p+16,s.rest,60); }
// search all readable committed memory for the instances; memory is copied with
// ReadProcessMemory so a page freed by the game in the meantime cannot crash us
static BYTE* gBuf=0;
static int safeRead(const void* a,void* b,DWORD n){ SIZE_T r=0; return ReadProcessMemory(GetCurrentProcess(),a,b,n,&r) && r==n; }
static void scanMemory(){
    gNAddr=0; MEMORY_BASIC_INFORMATION mi; BYTE* a=(BYTE*)0x10000; DWORD t0=GetTickCount();
    const DWORD CH=0x100000;
    if(!gBuf) gBuf=(BYTE*)HeapAlloc(GetProcessHeap(),0,CH+128);
    if(!gBuf) return;
    while((unsigned long)a<0xFFFE0000u && VirtualQuery(a,&mi,sizeof(mi))){
        BYTE* base=(BYTE*)mi.BaseAddress; SIZE_T rs=mi.RegionSize;
        DWORD pr=mi.Protect&0xff;
        // game data lives in writable private/mapped memory: skip images (exe/dll) and read-only pages
        if(mi.State==MEM_COMMIT && mi.Type!=0x1000000 && !(mi.Protect&PAGE_GUARD) && (pr==0x04||pr==0x08||pr==0x40||pr==0x80) && rs>=96){
            for(SIZE_T off=0;off<rs;off+=CH){
                DWORD n=(DWORD)((rs-off)<CH+96?(rs-off):CH+96);
                if(n<96 || !safeRead(base+off,gBuf,n)) continue;
                for(DWORD p=0;p+96<=n && p<CH;p+=4){
                    DWORD w=*(DWORD*)(gBuf+p);
                    for(int k=0;k<gNSig;k++)
                        if(w==*(DWORD*)gSig[k].bbmin && matchAt(gBuf+p,gSig[k]) && gNAddr<64) gAddr[gNAddr++]=base+off+p;
                }
            }
        }
        BYTE* nx=base+rs; if(nx<=a) break; a=nx;
    }
    // drop matches inside our own signature table / scan buffer
    int j=0; for(int i=0;i<gNAddr;i++){ BYTE* p=gAddr[i];
        if(p>=(BYTE*)gSig && p<(BYTE*)(gSig+32)) continue;
        if(p>=gBuf && p<gBuf+CH+128) continue;
        gAddr[j++]=p; } gNAddr=j;
    logn("memory scan matches: ",gNAddr); logn("  scan ms: ",GetTickCount()-t0);
}
static void apply(){
    for(int i=0;i<gNAddr;i++){
        DWORD f; if(!safeRead(gAddr[i]+12,&f,4)) continue;
        f = gHidden ? (f|gHideFlags) : (f&~gHideFlags);
        SIZE_T w=0; WriteProcessMemory(GetCurrentProcess(),gAddr[i]+12,&f,4,&w);
    }
}
static int cacheValid(){
    BYTE tmp[96];
    for(int i=0;i<gNAddr;i++){ if(!safeRead(gAddr[i],tmp,96)) return 0; int ok=0; for(int k=0;k<gNSig;k++) if(matchAt(tmp,gSig[k])) ok=1; if(!ok) return 0; }
    return gNAddr>0;
}
static int isForeground(){ DWORD pid=0; GetWindowThreadProcessId(GetForegroundWindow(),&pid); return pid==GetCurrentProcessId(); }

// ---- SafeHouseHub button -------------------------------------------------
// The menu calls ExternalInterface.call("SafehouseWindows","toggle"|"state").
// We wrap the game's GFx ExternalInterface handler (vtable slot of the
// front-end ExternalInterface object, Callback at 0x4ABBB0): our method is
// answered here with a Boolean return value (true = windows open / blinds
// hidden), every other call goes to the original handler.
struct GVal { void* pObj; DWORD type; union { const char* s; const char** ps; double d; int b; } v; DWORD pad; };
typedef void (__fastcall *CB)(void*, void*, void*, const char*, GVal*, unsigned);
static CB oCallback = 0;
static volatile LONG gRequest = 0;      // 1 = apply the new state in the worker
static int streq(const char* a,const char* b){ while(*a&&*a==*b){a++;b++;} return *a==*b; }
static const char* argStr(GVal* a){ if((a->type&0x8f)!=4) return 0; return (a->type&0x40) ? *a->v.ps : a->v.s; }
static void __fastcall hkCallback(void* self, void* edx, void* movie, const char* name, GVal* args, unsigned argc){
    if(name && streq(name,"SafehouseWindows")){
        const char* cmd = argc>0 ? argStr(&args[0]) : 0;
        if(cmd && streq(cmd,"toggle")){ gHidden=!gHidden; logs(gHidden?"menu: windows open (blinds hidden)":"menu: windows closed"); }
        else logs("menu: state query");
        gRequest=1;   // also used to pre-locate the blinds as soon as the safehouse menu opens
        // movie->SetExternalInterfaceRetVal(Boolean) - vtable +0xB4, as used by the game's own handlers
        GVal r; r.pObj=0; r.type=2; r.v.d=0; r.v.b=gHidden?1:0; r.pad=0;
        typedef void (__fastcall *SRV)(void*, void*, GVal*);
        if(movie){ SRV f=(SRV)((*(void***)movie)[0xB4/4]); f(movie,0,&r); }
        return;
    }
    oCallback(self,edx,movie,name,args,argc);
}
static void hookCallback(){
    void** slot=(void**)0x00B729C4;
    MEMORY_BASIC_INFORMATION mi;
    if(!VirtualQuery(slot,&mi,sizeof(mi)) || mi.State!=MEM_COMMIT){ logs("callback slot not found"); return; }
    void* cur=*slot;
    if(cur!=(void*)0x004ABBB0){
        // another mod may already wrap this callback: chain to it if it points to executable code
        MEMORY_BASIC_INFORMATION ci;
        if(!cur || !VirtualQuery(cur,&ci,sizeof(ci)) || ci.State!=MEM_COMMIT || !(ci.Protect&0xF0)){ logs("unexpected nfsw.exe build: menu button disabled"); return; }
        char m[64]="callback already wrapped by another mod at 0x"; char hx[12]; hex_((DWORD)cur,hx); scat(m,hx); logs(m);
    }
    DWORD o; VirtualProtect(slot,4,0x04,&o); oCallback=(CB)*slot; *slot=(void*)hkCallback; VirtualProtect(slot,4,o,&o);
    logs("menu callback hooked");
}

static DWORD WINAPI worker(LPVOID){
    Sleep(3000);
    loadSignatures();
    if(!gNSig) return 0;
    int was=0; DWORD lastCheck=0;
    for(;;){
        Sleep(30);
        if(gKey){
            int down=(GetAsyncKeyState(gKey)&0x8000)!=0;
            if(down && !was && isForeground()){ gHidden=!gHidden; logs(gHidden?"key: windows open":"key: windows closed"); gRequest=1; }
            was=down;
        }
        if(gRequest){
            gRequest=0;
            if(!cacheValid()) scanMemory();
            apply(); lastCheck=GetTickCount();
        }
        // keep the state if the section gets streamed out and back in
        if(gHidden && GetTickCount()-lastCheck>10000){
            lastCheck=GetTickCount();
            if(!cacheValid()) scanMemory();
            apply();
        }
    }
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID){
    if(r!=DLL_PROCESS_ATTACH) return 1;
    DisableThreadLibraryCalls(h);
    char p[300]; GetModuleFileNameA(h,p,260);
    int n=slen(p); while(n>0&&p[n-1]!='.') n--; p[n]=0;
    for(int i=0;i<=n;i++){gIni[i]=p[i];gLog[i]=p[i];}
    scat(gIni,"ini"); scat(gLog,"log");
    GetModuleFileNameA(0,gGame,260); int m=slen(gGame); while(m>0&&gGame[m-1]!='\\') m--; gGame[m]=0;
    gLogOn=GetPrivateProfileIntA("Main","Log",0,gIni);
    gKey=GetPrivateProfileIntA("Main","Key",0,gIni);
    gHideFlags=GetPrivateProfileIntA("Main","HideFlags",0x18,gIni);
    gHidden=0;
    if(gLogOn){ HANDLE f=CreateFileA(gLog,0x40000000,1,0,2,0x80,0); if(f!=INVALID_HANDLE_VALUE) CloseHandle(f); }
    hookCallback();
    CreateThread(0,0,worker,0,0,0);
    return 1;
}
