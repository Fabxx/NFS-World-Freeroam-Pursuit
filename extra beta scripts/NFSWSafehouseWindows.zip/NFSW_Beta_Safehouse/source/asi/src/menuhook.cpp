// NFSWSafehouseWindows - SafeHouseHub menu entry.
//
// SafeHouseHub.gfx calls ExternalInterface.call("SafehouseWindows", "toggle" | "state").
// The game routes every ExternalInterface call of the front end through one virtual
// method (the GFxExternalInterface::Callback of the front-end handler). We replace
// that vtable slot: our method is answered here with a Boolean (true = windows open),
// every other call goes to the previous handler (the game, or another mod that
// wrapped it before us).
//
// No fixed addresses: the handler and its vtable slot are located at runtime with
// byte patterns, so the hook works with any nfsw.exe build (original, Soapbox Race
// World, patched/ASLR executables) as long as the front-end code is the 2015 one.
#include "common.h"

// GFxValue (Scaleform GFx 3.x): 16 bytes, value at +8
struct GfxValue { void* obj; DWORD type; union { const char* s; const char** ps; double d; int b; } v; };
static_assert(sizeof(GfxValue) == 16, "GFxValue layout");
const DWORD kGfxBool = 2, kGfxString = 4, kGfxManaged = 0x40, kGfxTypeMask = 0x8F;
const int kSetRetValVtblOffset = 0xB4;   // GFxMovieView::SetExternalInterfaceRetVal

typedef void (__fastcall* Callback_t)(void* self, void* edx, void* movie, const char* name, GfxValue* args, unsigned argc);
static Callback_t s_prev = 0;

// front-end ExternalInterface handler (Callback), 2015 code
static const char* kSigCallback = "55 8B EC 8B 45 0C 53 8B 5D 10 56 57 8B 7D 14 57 53 8B F1 8B 4D 08 50 51 8B 8E D0 00 00 00 E8";
// the two methods that follow it in the same vtable (used when another mod already replaced the slot)
static const char* kSigNext1 = "55 8B EC 83 EC 10 53 56 8B 75 08 8B 86 D8 00 00 00 57 33 FF 3B C7 0F 84";
static const char* kSigNext2 = "B8 02 00 00 00 C2 14 00 CC CC CC CC CC CC CC CC 55 8B EC 83 7D 0C 01 75";

static const char* ArgString(const GfxValue* a)
{
    if ((a->type & kGfxTypeMask) != kGfxString) return 0;
    return (a->type & kGfxManaged) ? *a->v.ps : a->v.s;
}

static void __fastcall HookCallback(void* self, void* edx, void* movie, const char* name, GfxValue* args, unsigned argc)
{
    if (name && util::Equal(name, "SafehouseWindows")) {
        const char* cmd = argc > 0 ? ArgString(&args[0]) : 0;
        if (cmd && util::Equal(cmd, "toggle")) {
            g_hidden = !g_hidden;
            Log(g_hidden ? "menu: windows open (blinds hidden)" : "menu: windows closed");
        } else Log("menu: state query");
        g_request = 1;   // also pre-locates the blinds when the menu opens
        GfxValue r; r.obj = 0; r.type = kGfxBool; r.v.d = 0; r.v.b = g_hidden ? 1 : 0;
        typedef void (__fastcall* SetRetVal_t)(void*, void*, GfxValue*);
        if (movie) { SetRetVal_t f = (SetRetVal_t)((*(void***)movie)[kSetRetValVtblOffset / 4]); f(movie, 0, &r); }
        return;
    }
    s_prev(self, edx, movie, name, args, argc);
}

static bool IsCode(void* p)
{
    MEMORY_BASIC_INFORMATION mi;
    if (!p || !VirtualQuery(p, &mi, sizeof(mi)) || mi.State != MEM_COMMIT) return false;
    return (mi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
}

static DWORD* FindSlot(bool verbose)
{
    BYTE* cb = FindCode(kSigCallback);
    BYTE* n1 = FindCode(kSigNext1);
    BYTE* n2 = FindCode(kSigNext2);
    if (verbose) {
        LogHex("exe base ", ImageBase());
        if (cb) LogHex("handler found at ", (DWORD)(ULONG_PTR)cb); else Log("handler pattern not found");
    }
    DWORD* hits[8]; int n;
    if (cb) {   // normal case: the slot still points to the game's handler
        n = FindPointer((DWORD)(ULONG_PTR)cb, hits, 8);
        for (int i = 0; i < n && i < 8; ++i)
            if (!n1 || hits[i][1] == (DWORD)(ULONG_PTR)n1) return hits[i];
    }
    if (n1) {   // slot already replaced by another mod: locate it from the following entries
        n = FindPointer((DWORD)(ULONG_PTR)n1, hits, 8);
        for (int i = 0; i < n && i < 8; ++i) {
            DWORD* slot = hits[i] - 1;
            if (n2 && hits[i][1] != (DWORD)(ULONG_PTR)n2) continue;
            if (IsCode((void*)(ULONG_PTR)*slot)) return slot;
        }
    }
    return 0;
}

bool InstallMenuHook(bool verbose)
{
    DWORD* slot = FindSlot(verbose);
    if (!slot) { if (verbose) Log("ExternalInterface vtable slot not found: menu button disabled (key still works)"); return false; }
    void* cur = (void*)(ULONG_PTR)*slot;
    if (!IsCode(cur)) { Log("unexpected vtable content: menu button disabled"); return false; }
    LogHex("vtable slot at ", (DWORD)(ULONG_PTR)slot);
    LogHex("  previous handler ", (DWORD)(ULONG_PTR)cur);
    DWORD old;
    if (!VirtualProtect(slot, 4, PAGE_READWRITE, &old)) { Log("VirtualProtect failed"); return false; }
    s_prev = (Callback_t)cur;
    *slot = (DWORD)(ULONG_PTR)&HookCallback;
    VirtualProtect(slot, 4, old, &old);
    Log("menu callback hooked");
    return true;
}
