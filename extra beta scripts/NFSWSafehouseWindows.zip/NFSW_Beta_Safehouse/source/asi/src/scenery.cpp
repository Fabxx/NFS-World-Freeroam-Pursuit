// NFSWSafehouseWindows - reads the safehouse scenery section from disk and keeps a
// byte signature of every instance of the window objects (blinds).
//
// Bundle chunks: DWORD id, DWORD size; container chunks have bit 31 set.
//   0x80034100  scenery section
//     0x00034102  SceneryInfo     72 bytes each, object name in the first 24 bytes
//     0x00034103  SceneryInstance 96 bytes each (after 0x11 alignment padding):
//                 +0 bbox min, +12 flags, +16 bbox max, +32 position, +44 rotation 3x3,
//                 +84 WORD SceneryInfo index
#include "common.h"
#include "signatures.h"

Signature g_sig[kMaxSig];
int g_nSig = 0;

// the SceneryInfo chunk comes after the instances in the file: find it first
static void ReadSection(BYTE* d, DWORD o, DWORD end)
{
    BYTE* infos = 0; DWORD nInfo = 0;
    for (DWORD p = o; p + 8 <= end; ) {
        DWORD id = *(DWORD*)(d + p), sz = *(DWORD*)(d + p + 4);
        if (p + 8 + sz > end) break;
        if (id == 0x00034102) { infos = d + p + 8; nInfo = sz / 72; }
        p += 8 + sz;
    }
    if (!infos) return;
    for (DWORD p = o; p + 8 <= end; ) {
        DWORD id = *(DWORD*)(d + p), sz = *(DWORD*)(d + p + 4);
        if (p + 8 + sz > end) break;
        if (id == 0x00034103) {
            BYTE* q = d + p + 8; DWORD n = sz;
            while (n && *q == 0x11) { ++q; --n; }                       // alignment padding
            for (DWORD i = 0; i < n / 96 && g_nSig < kMaxSig; ++i) {
                BYTE* e = q + i * 96;
                DWORD idx = *(WORD*)(e + 84);
                if (idx >= nInfo) continue;
                char name[25]; util::CopyBytes((BYTE*)name, infos + idx * 72, 24); name[24] = 0;
                if (!util::InList(g_cfg.objects, name)) continue;
                Signature& s = g_sig[g_nSig++];
                util::CopyBytes(s.bboxMin, e, 12);
                util::CopyBytes(s.rest, e + 16, 60);
                Log("instance found: ", name);
            }
        }
        p += 8 + sz;
    }
}

static void Walk(BYTE* d, DWORD o, DWORD end)
{
    while (o + 8 <= end) {
        DWORD id = *(DWORD*)(d + o), sz = *(DWORD*)(d + o + 4);
        if (o + 8 + sz > end) break;
        if (id == 0x80034100) ReadSection(d, o + 8, o + 8 + sz);
        else if (id & 0x80000000) Walk(d, o + 8, o + 8 + sz);
        o += 8 + sz;
    }
}

int LoadSignatures()
{
    char path[MAX_PATH * 2]; path[0] = 0;
    util::Cat(path, g_cfg.gameDir, sizeof(path)); util::Cat(path, "Tracks\\", sizeof(path)); util::Cat(path, g_cfg.section, sizeof(path));
    HANDLE f = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (f == INVALID_HANDLE_VALUE) { Log("cannot open ", path); return 0; }
    DWORD size = GetFileSize(f, 0), rd = 0;
    BYTE* d = (size && size != INVALID_FILE_SIZE) ? (BYTE*)HeapAlloc(GetProcessHeap(), 0, size) : 0;
    if (d && ReadFile(f, d, size, &rd, 0) && rd == size) Walk(d, 0, size);
    CloseHandle(f);
    if (d) HeapFree(GetProcessHeap(), 0, d);
    LogNum("signatures: ", (DWORD)g_nSig);
    return g_nSig;
}
