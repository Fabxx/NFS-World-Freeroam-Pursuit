// NFSWSafehouseWindows - byte pattern search in the game executable image.
// Works on any nfsw.exe build and with ASLR (the image base is read at runtime).
#include "common.h"

static BYTE* Base() { return (BYTE*)GetModuleHandleA(0); }
DWORD ImageBase() { return (DWORD)(ULONG_PTR)Base(); }

static IMAGE_SECTION_HEADER* Sections(int* count)
{
    BYTE* b = Base();
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)b;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) { *count = 0; return 0; }
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(b + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) { *count = 0; return 0; }
    *count = nt->FileHeader.NumberOfSections;
    return IMAGE_FIRST_SECTION(nt);
}

static int Hex(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

// "55 8B EC ?? 45" -> bytes + mask
static int Parse(const char* t, BYTE* bytes, BYTE* mask, int cap)
{
    int n = 0;
    while (*t && n < cap) {
        if (*t == ' ') { ++t; continue; }
        if (t[0] == '?') { bytes[n] = 0; mask[n] = 0; ++n; t += (t[1] == '?') ? 2 : 1; continue; }
        int h = Hex(t[0]), l = Hex(t[1]);
        if (h < 0 || l < 0) break;
        bytes[n] = (BYTE)(h * 16 + l); mask[n] = 1; ++n; t += 2;
    }
    return n;
}

static bool Readable(const MEMORY_BASIC_INFORMATION& mi)
{
    if (mi.State != MEM_COMMIT || (mi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) return false;
    return true;
}

BYTE* FindCode(const char* pattern)
{
    BYTE bytes[128], mask[128];
    int n = Parse(pattern, bytes, mask, 128);
    if (n <= 0) return 0;
    int cnt; IMAGE_SECTION_HEADER* s = Sections(&cnt);
    for (int i = 0; i < cnt; ++i) {
        if (!(s[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        BYTE* p = Base() + s[i].VirtualAddress;
        DWORD size = s[i].Misc.VirtualSize;
        MEMORY_BASIC_INFORMATION mi;
        if (!VirtualQuery(p, &mi, sizeof(mi)) || !Readable(mi)) continue;
        for (DWORD o = 0; o + n <= size; ++o) {
            int k = 0;
            while (k < n && (!mask[k] || p[o + k] == bytes[k])) ++k;
            if (k == n) return p + o;
        }
    }
    return 0;
}

int FindPointer(DWORD value, DWORD** out, int max)
{
    int found = 0, cnt;
    IMAGE_SECTION_HEADER* s = Sections(&cnt);
    for (int i = 0; i < cnt; ++i) {
        if (s[i].Characteristics & IMAGE_SCN_MEM_EXECUTE) continue;          // vtables live in .rdata/.data
        if (!(s[i].Characteristics & IMAGE_SCN_MEM_READ)) continue;
        DWORD* p = (DWORD*)(Base() + s[i].VirtualAddress);
        DWORD n = s[i].Misc.VirtualSize / 4;
        MEMORY_BASIC_INFORMATION mi;
        if (!VirtualQuery(p, &mi, sizeof(mi)) || !Readable(mi)) continue;
        for (DWORD k = 0; k < n; ++k)
            if (p[k] == value) { if (found < max) out[found] = p + k; ++found; }
    }
    return found;
}
