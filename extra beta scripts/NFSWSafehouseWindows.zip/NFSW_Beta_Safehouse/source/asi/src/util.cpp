// NFSWSafehouseWindows - helpers, configuration and log
#include "common.h"

namespace util {
int Len(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
void Copy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
void Cat(char* d, const char* s, int cap) { int n = Len(d); if (n < cap) Copy(d + n, s, cap - n); }
static char Low(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
bool Equal(const char* a, const char* b) { while (*a && *a == *b) { ++a; ++b; } return *a == *b; }
bool InList(const char* list, const char* name)
{
    const char* p = list;
    while (*p) {
        while (*p == ',' || *p == ' ') ++p;
        const char* q = p; while (*q && *q != ',') ++q;
        int n = (int)(q - p); while (n > 0 && p[n - 1] == ' ') --n;
        if (n > 0) { int i = 0; while (i < n && name[i] && Low(p[i]) == Low(name[i])) ++i; if (i == n && name[i] == 0) return true; }
        p = q;
    }
    return false;
}
void UIntToStr(DWORD v, char* o) { char t[12]; int i = 0; do { t[i++] = (char)('0' + v % 10); v /= 10; } while (v); while (i) *o++ = t[--i]; *o = 0; }
void HexToStr(DWORD v, char* o) { const char* h = "0123456789ABCDEF"; for (int i = 0; i < 8; ++i) o[i] = h[(v >> (28 - 4 * i)) & 15]; o[8] = 0; }
bool SameBytes(const BYTE* a, const BYTE* b, int n) { for (int i = 0; i < n; ++i) if (a[i] != b[i]) return false; return true; }
void CopyBytes(BYTE* d, const BYTE* s, int n) { for (int i = 0; i < n; ++i) d[i] = s[i]; }
bool SafeRead(const void* a, void* b, SIZE_T n) { SIZE_T r = 0; return ReadProcessMemory(GetCurrentProcess(), a, b, n, &r) && r == n; }
bool SafeWrite(void* a, const void* b, SIZE_T n) { SIZE_T r = 0; return WriteProcessMemory(GetCurrentProcess(), a, b, n, &r) && r == n; }
}

Config g_cfg;

void LoadConfig(HMODULE self)
{
    char p[MAX_PATH];
    DWORD n = GetModuleFileNameA(self, p, MAX_PATH);
    if (!n || n >= MAX_PATH) p[0] = 0;
    int dot = util::Len(p); while (dot > 0 && p[dot - 1] != '.') --dot;       // "...\NFSWSafehouseWindows."
    p[dot] = 0;
    util::Copy(g_cfg.iniPath, p, MAX_PATH); util::Cat(g_cfg.iniPath, "ini", MAX_PATH);
    util::Copy(g_cfg.logPath, p, MAX_PATH); util::Cat(g_cfg.logPath, "log", MAX_PATH);

    n = GetModuleFileNameA(0, g_cfg.gameDir, MAX_PATH);
    if (!n || n >= MAX_PATH) g_cfg.gameDir[0] = 0;
    int m = util::Len(g_cfg.gameDir); while (m > 0 && g_cfg.gameDir[m - 1] != '\\' && g_cfg.gameDir[m - 1] != '/') --m;
    g_cfg.gameDir[m] = 0;

    const char* ini = g_cfg.iniPath;
    g_cfg.log = GetPrivateProfileIntA("Main", "Log", 0, ini);
    g_cfg.key = GetPrivateProfileIntA("Main", "Key", 0, ini);
    g_cfg.hideFlags = GetPrivateProfileIntA("Main", "HideFlags", 0x18, ini);
    GetPrivateProfileStringA("Main", "Section", "STREAML5RA_418.BUN", g_cfg.section, sizeof(g_cfg.section), ini);
    GetPrivateProfileStringA("Main", "Objects", "FE_Blinds_01,FE_Blinds_REF", g_cfg.objects, sizeof(g_cfg.objects), ini);

    if (g_cfg.log) { HANDLE f = CreateFileA(g_cfg.logPath, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0); if (f != INVALID_HANDLE_VALUE) CloseHandle(f); }
}

void Log(const char* a, const char* b, const char* c)
{
    if (!g_cfg.log) return;
    char m[600]; m[0] = 0;
    util::Cat(m, a, sizeof(m)); if (b) util::Cat(m, b, sizeof(m)); if (c) util::Cat(m, c, sizeof(m));
    util::Cat(m, "\r\n", sizeof(m));
    HANDLE h = CreateFileA(g_cfg.logPath, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w; WriteFile(h, m, (DWORD)util::Len(m), &w, 0); CloseHandle(h);
}
void LogNum(const char* a, DWORD v) { char n[16]; util::UIntToStr(v, n); Log(a, n); }
void LogHex(const char* a, DWORD v) { char n[16] = "0x"; util::HexToStr(v, n + 2); Log(a, n); }
