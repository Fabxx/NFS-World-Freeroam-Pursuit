#!/bin/sh
# Alternative build without Visual Studio (Linux, LLVM 18 + MinGW-w64 headers, no C runtime).
# Usage: MINGW_INCLUDE=/path/to/mingw-w64/include sh tools/linux/build.sh   (run from the source root)
set -e
INC=${MINGW_INCLUDE:-/usr/i686-w64-mingw32/include}
CLANGINC=$(clang++-18 -print-resource-dir)/include
OUT=build/linux; mkdir -p $OUT
llvm-dlltool -m i386 -k -d tools/linux/kernel32.def -l $OUT/libkernel32.a
llvm-dlltool -m i386 -k -d tools/linux/user32.def -l $OUT/libuser32.a
FLAGS="--target=i686-w64-mingw32 -nostdinc -isystem $CLANGINC -isystem $INC -O2 -Wall -Wextra -fno-exceptions -fno-rtti -fno-builtin -ffreestanding -fno-stack-protector"
for f in src/*.cpp; do clang++-18 $FLAGS -c $f -o $OUT/$(basename $f .cpp).o; done
clang-18 --target=i686-w64-mingw32 -O2 -ffreestanding -fno-builtin -c tools/linux/mem.c -o $OUT/mem.o
ld.lld-18 -m i386pe --shared -e _DllMain@12 --subsystem windows --image-base 0x10000000 --build-id=none \
  -o $OUT/NFSWSafehouseWindows.asi $OUT/*.o $OUT/libkernel32.a $OUT/libuser32.a
echo built $OUT/NFSWSafehouseWindows.asi
