/* only for the Linux build without a C runtime: compiler-generated memcpy/memset */
void* memcpy(void* d, const void* s, unsigned int n) { char* a = (char*)d; const char* b = (const char*)s; while (n--) *a++ = *b++; return d; }
void* memset(void* d, int v, unsigned int n) { char* a = (char*)d; while (n--) *a++ = (char)v; return d; }
