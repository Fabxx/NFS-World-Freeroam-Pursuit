int _fltused = 0;
#pragma function(memcpy)
#pragma function(memset)
void* __cdecl memcpy(void* d,const void* s,unsigned int n){char*a=(char*)d;const char*b=(const char*)s;while(n--)*a++=*b++;return d;}
void* __cdecl memset(void* d,int v,unsigned int n){char*a=(char*)d;while(n--)*a++=(char)v;return d;}
