class com.ea.SafeHouse.SafeHouseHub extends com.ea.screens.PanedScreen
{
   var m_Delegates;
   var m_ExitButtonListeners;
   var m_PowerupManagementButtonListeners;
   var m_SelectCarButtonListeners;
   var m_ChangeDriverButtonListeners;
   var m_VisualButtonListeners;
   var m_PerformanceButtonListeners;
   var m_CarDealerButtonListeners;
   var m_CardPacksButtonListeners;
   var m_PlayerProfileButtonListeners;
   var m_HelpButtonListener;
   var m_IsWaitingForDurabilityFix;
   var mcRepairsCallout1;
   var m_Screen;
   var mcRepairsCallout2;
   var m_btn_exit;
   var m_btn_exit2;
   var m_btn_powerupManagement;
   var m_btn_PlayerProfile;
   var m_btn_help;
   var m_btn_selectCar;
   var m_btn_changeDriver;
   var m_btn_visual;
   var m_btn_performance;
   var m_btn_carDealer;
   var m_btn_cardPacks;
   var m_btn_windows;
   var m_WindowsButtonListeners;
   var m_WindowsOpen;
   var m_Wallet;
   var m_RentalIndicator;
   var m_CascadeMenuHelper;
   var m_fixButton;
   var mProgAmpInsurance;
   var m_DurabilityIcon;
   var m_DurabilityWarning;
   var m_DurabilityInsuranceText;
   var mFixCost;
   var mFixButtonEventDispatcher;
   var targetNextTransition;
   var mOrigStartFadeBack;
   var animation_target_scale;
   var mBaseScale;
   var mOrigStartReturnToNormal;
   var mbPlayerProfileOpen;
   var mPlayerProfileHolder;
   var mPlayerProfileLoader;
   var mPlayerProfileTimer;
   var mPanes;
   var dispatchEvent;
   var m_GamePersona;
   var DATA_SOURCE = "GBE";
   static var ON_FIX_BUTTON_PRESS = "ON_FIX_BUTTON_PRESS";
   static var LABEL_DURABILITY_INFO_SHOW = "show";
   static var LABEL_DURABILITY_INFO_HIDE = "hide";
   var SCREEN_TAG = "[SafeHouseHub]";
   static var USE_NATIVE_PLAYER_PROFILE = false;
   static var PLAYER_PROFILE_SWF = "PlayerProfile.swf";
   static var PLAYER_PROFILE_ICON = "mc-icon_hub_profile";
   static var PLAYER_PROFILE_DEPTH = 30000;
   static var HUB_BUTTON_SCALE = 86;
   static var HUB_BUTTON_ORDER = ["m_btn_selectCar","m_btn_visual","m_btn_changeDriver","m_btn_carDealer","m_btn_powerupManagement","m_btn_cardPacks","m_btn_windows","m_btn_exit"];
   static var WINDOWS_LABEL_OPEN = "OPEN SAFEHOUSE WINDOWS";
   static var WINDOWS_LABEL_CLOSE = "CLOSE SAFEHOUSE WINDOWS";
   function SafeHouseHub(screen)
   {
      super(screen);
      com.ea.gameapi.command.Command.EndGadget(com.ea.gameapi.enum.GadgetName.WebHelp.value);
      gfx.events.EventDispatcher.initialize(this);
      _global.RootClass = this;
      this.m_Delegates = new Object();
      this.m_Delegates.exit = mx.utils.Delegate.create(this,this.ExitPressEventHandler);
      this.m_Delegates.powerupManagement = mx.utils.Delegate.create(this,this.PowerupManagementPressEventHandler);
      this.m_Delegates.PlayerProfile = mx.utils.Delegate.create(this,this.PlayerProfilePressEventHandler);
      this.m_Delegates.selectCar = mx.utils.Delegate.create(this,this.SelectCarPressEventHandler);
      this.m_Delegates.changeDriver = mx.utils.Delegate.create(this,this.ChangeDriverPressEventHandler);
      this.m_Delegates.visual = mx.utils.Delegate.create(this,this.VisualPressEventHandler);
      this.m_Delegates.performance = mx.utils.Delegate.create(this,this.PerformancePressEventHandler);
      this.m_Delegates.carDealer = mx.utils.Delegate.create(this,this.CarDealerPressEventHandler);
      this.m_Delegates.cardPacks = mx.utils.Delegate.create(this,this.CardPacksPressEventHandler);
      this.m_Delegates.HelpButton = mx.utils.Delegate.create(this,this.HelpPressEventHandler);
      this.m_Delegates.DurabilityChange = mx.utils.Delegate.create(this,this.DurabilityChangeEventHandler);
      this.m_Delegates.OnProgAmpPurchased = mx.utils.Delegate.create(this,this.OnInsurancePurchased);
      this.m_Delegates.windows = mx.utils.Delegate.create(this,this.WindowsPressEventHandler);
      this.m_WindowsButtonListeners = new Object();
      this.m_WindowsButtonListeners.onRelease = this.m_Delegates.windows;
      this.m_ExitButtonListeners = new Object();
      this.m_PowerupManagementButtonListeners = new Object();
      this.m_SelectCarButtonListeners = new Object();
      this.m_ChangeDriverButtonListeners = new Object();
      this.m_VisualButtonListeners = new Object();
      this.m_PerformanceButtonListeners = new Object();
      this.m_CarDealerButtonListeners = new Object();
      this.m_CardPacksButtonListeners = new Object();
      this.m_PlayerProfileButtonListeners = new Object();
      this.m_HelpButtonListener = new Object();
      this.m_ExitButtonListeners.onRelease = this.m_Delegates.exit;
      this.m_PowerupManagementButtonListeners.onRelease = this.m_Delegates.powerupManagement;
      this.m_PlayerProfileButtonListeners.onRelease = this.m_Delegates.PlayerProfile;
      this.m_SelectCarButtonListeners.onRelease = this.m_Delegates.selectCar;
      this.m_ChangeDriverButtonListeners.onRelease = this.m_Delegates.changeDriver;
      this.m_VisualButtonListeners.onRelease = this.m_Delegates.visual;
      this.m_PerformanceButtonListeners.onRelease = this.m_Delegates.performance;
      this.m_CarDealerButtonListeners.onRelease = this.m_Delegates.carDealer;
      this.m_CardPacksButtonListeners.onRelease = this.m_Delegates.cardPacks;
      this.m_HelpButtonListener.onRelease = this.m_Delegates.HelpButton;
      this.m_IsWaitingForDurabilityFix = false;
      com.ea.SafeHouse.SafeHouse_Util.CursorManager.Get();
      com.ea.util.KeyboardNavigation.Set(Key.ESCAPE,this,this.ExitPressEventHandler);
      com.ea.util.SFX.PlaySound(com.ea.util.SFX.GADGET_SHOW_SFX);
   }
   function OnIntroComplete()
   {
      this.Initialize();
      this.mcRepairsCallout1 = this.m_Screen.pane_BL.callouts.callout1;
      this.mcRepairsCallout2 = this.m_Screen.pane_BL.callouts.callout2;
      this.HideCallouts();
      this.RequestCallouts();
   }
   function OnPush()
   {
      com.ea.gameapi.command.Command.GadgetListenToResolutionChange();
   }
   function Initialize()
   {
      this.CreatePlayerProfileButton();
      this.m_btn_exit = this.m_Screen.pane_MR.m_content.m_btn_exit;
      this.m_btn_exit2 = this.m_Screen.pane_UL.m_btn_exit;
      this.m_btn_powerupManagement = this.m_Screen.pane_MR.m_content.m_btn_powerupManagement;
      this.m_btn_PlayerProfile = this.m_Screen.pane_MR.m_content.m_btn_PlayerProfile;
      this.m_btn_help = this.m_Screen.pane_MR.m_content.m_btn_help;
      this.m_btn_help.setTooltip("TXT_CMN_TOOLTIP_VIEW_HELP");
      this.m_btn_selectCar = this.m_Screen.pane_MR.m_content.m_btn_selectCar;
      this.m_btn_changeDriver = this.m_Screen.pane_MR.m_content.m_btn_changeDriver;
      this.m_btn_visual = this.m_Screen.pane_MR.m_content.m_btn_visual;
      this.m_btn_visual.hasNewFlag = true;
      this.m_btn_performance = this.m_Screen.pane_MR.m_content.m_btn_performance;
      this.m_btn_carDealer = this.m_Screen.pane_MR.m_content.m_btn_carDealer;
      this.m_btn_carDealer.hasNewFlag = true;
      this.m_btn_cardPacks = this.m_Screen.pane_MR.m_content.m_btn_cardPacks;
      this.m_btn_windows = this.m_Screen.pane_MR.m_content.m_btn_windows;
      this.m_btn_windows.addListener(this.m_WindowsButtonListeners);
      this.UpdateWindowsButton(flash.external.ExternalInterface.call("SafehouseWindows","state"));
      this.m_Wallet = this.m_Screen.pane_UR.m_Wallet;
      this.m_RentalIndicator = this.m_Screen.pane_BL.mRentalIndicator;
      this.m_RentalIndicator.InitTimeRemaining();
      this.m_btn_exit2.setLabel("CMN_LEAVE_SAFEHOUSE");
      this.m_btn_exit.setLabel("CMN_LEAVE_SAFEHOUSE");
      this.m_btn_powerupManagement.setLabel("CMN_POWERUP_MANAGEMENT");
      this.m_btn_PlayerProfile.setLabel("CMN_PLAYER_PROFILE");
      this.m_btn_selectCar.setLabel("CMN_CHANGE_CAR");
      this.m_btn_changeDriver.setLabel("CMN_CHANGE_DRIVER");
      this.m_btn_visual.setLabel("CMN_CUSTOMIZATION_SHOP");
      this.m_btn_performance.setLabel("CMN_PERFORMANCE_CUSTOMIZATION_SHOP");
      this.m_btn_exit.addListener(this.m_ExitButtonListeners);
      this.m_btn_exit2.addListener(this.m_ExitButtonListeners);
      this.m_btn_powerupManagement.addListener(this.m_PowerupManagementButtonListeners);
      this.m_btn_PlayerProfile.addListener(this.m_PlayerProfileButtonListeners);
      this.m_btn_selectCar.addListener(this.m_SelectCarButtonListeners);
      this.m_btn_changeDriver.addListener(this.m_ChangeDriverButtonListeners);
      this.m_btn_visual.addListener(this.m_VisualButtonListeners);
      this.m_btn_performance.addListener(this.m_PerformanceButtonListeners);
      this.m_btn_carDealer.addListener(this.m_CarDealerButtonListeners);
      this.m_btn_cardPacks.addListener(this.m_CardPacksButtonListeners);
      this.m_btn_help.addListener(this.m_HelpButtonListener);
      this.m_CascadeMenuHelper = this.m_Screen.pane_MR.m_content.buttonHelper;
      this.m_CascadeMenuHelper.initialize();
      this.m_fixButton = this.m_Screen.pane_BL.m_DurabilityBar.m_fixButton;
      this.mProgAmpInsurance = this.m_Screen.pane_BL.m_DurabilityBar.mProgAmpInsurance;
      this.m_DurabilityIcon = this.m_Screen.pane_BL.m_DurabilityIcon;
      this.m_DurabilityWarning = this.m_Screen.pane_BL.m_DurabilityBar.m_warningText;
      this.m_DurabilityInsuranceText = this.m_Screen.pane_BL.m_DurabilityBar.m_insuranceText;
      this.mFixCost = this.m_Screen.pane_BL.m_DurabilityBar.repairCost.txtCost;
      this.WaitAnim = this.m_Screen.pane_BL.m_waitAnimation;
      this.UpdateFixPrice();
      this.m_DurabilityIcon.addEventListener(com.ea.components.DurabilityView.DURABILITY_CHANGED,this.m_Delegates.DurabilityChange);
      this.UpdateDurabilityState();
      this.mFixButtonEventDispatcher = com.ea.common.buttons.ButtonEventDispatcher.AddActionToButton(this.m_fixButton,this,this.FixEventHandler);
      this.mProgAmpInsurance.Init(com.ea.common.components.PurchaseBox.PurchaseBox.CONTEXT_PROGRESSION_AMP_INSURANCE);
      this.mProgAmpInsurance.removeEventListener(com.ea.common.components.PurchaseBox.ProgressionAmplifier.ON_PROGRESSION_AMPLIFIER_PURCHASED,this.m_Delegates.OnProgAmpPurchased);
      this.mProgAmpInsurance.addEventListener(com.ea.common.components.PurchaseBox.ProgressionAmplifier.ON_PROGRESSION_AMPLIFIER_PURCHASED,this.m_Delegates.OnProgAmpPurchased);
      this.m_fixButton.setTooltip("TOOL_TIP_FIX_DURABILITY_BUTTON");
      _global.mSafeHouseActiveCar = com.ea.Requests.Request_SafeHouseActiveCar.SyncRequest();
      var _loc3_ = _global.mSafeHouseActiveCar;
      this.ViewDurabilityInfo(_loc3_.ActiveCar.Owned);
      this.RequestPersonaInfo();
      this.StoreLastState();
      this.m_Wallet.EnableBoostButton(true);
      com.ea.gameapi.command.Command.FeatureCheckFirstClick(com.ea.gameapi.enum.GadgetName.SafeHouseHub.value);
   }
   function OnFeatureFirstClickReceived()
   {
      var _loc2_ = _global.mFeatureFirstClick;
      if(_loc2_.gadgetName == com.ea.gameapi.enum.GadgetName.SafeHouseHub.value)
      {
         com.ea.common.Generic.Utils.TriggerTransition("SafeHouseRoadBlock");
      }
   }
   function UpdateDurabilityState(setting)
   {
      this.OnDurabilityEmpty(this.m_DurabilityIcon.state == com.ea.components.DurabilityView.STATE_DURABILITY_EMPTY);
      this.OnDurabilityInsured(this.m_DurabilityIcon.state == com.ea.components.DurabilityView.STATE_DURABILITY_INSURED);
      this.m_fixButton.setEnable(this.m_DurabilityIcon.IsFixAvailable());
   }
   function ViewDurabilityInfo(setting)
   {
      this.m_Screen.pane_BL.m_DurabilityBar._visible = setting;
      this.m_DurabilityIcon._visible = setting;
   }
   function triggerTransition(transition, closeAnimationNeeded)
   {
      this.removeListeners();
      if(closeAnimationNeeded == undefined)
      {
         closeAnimationNeeded = true;
      }
      if(closeAnimationNeeded)
      {
         this.targetNextTransition = transition;
         this.executeCloseAnimation();
      }
      else
      {
         com.ea.common.Generic.Utils.TriggerTransition(transition);
      }
   }
   function executeCloseAnimation()
   {
      this.m_RentalIndicator.AnimateOut();
      this.m_Screen.gotoAndPlay("Leave");
      com.ea.util.SFX.PlaySound(com.ea.util.SFX.GADGET_HIDE_SFX);
   }
   function onHidden()
   {
      com.ea.SafeHouse.SafeHouse_Util.CursorManager.Get().Reset();
      com.ea.common.Generic.Utils.TriggerTransition(this.targetNextTransition);
      if(this.targetNextTransition == "ExitSafeHouse")
      {
         com.ea.gameapi.command.Command.SafeHouseExit();
      }
      else if(this.targetNextTransition == "EnterChangeDriver")
      {
         com.ea.gameapi.command.Command.GameGoToSelectDriver();
      }
   }
   function removeListeners()
   {
      com.ea.util.KeyboardNavigation.Enable = false;
      this.mFixButtonEventDispatcher.ShutDown();
      delete this.mFixButtonEventDispatcher;
      this.m_btn_exit.removeListener(this.m_ExitButtonListeners);
      this.m_btn_exit2.removeListener(this.m_ExitButtonListeners);
      this.m_btn_selectCar.removeListener(this.m_SelectCarButtonListeners);
      this.m_btn_powerupManagement.removeListener(this.m_PowerupManagementButtonListeners);
      this.m_btn_PlayerProfile.removeListener(this.m_PlayerProfileButtonListeners);
      this.m_btn_changeDriver.removeListener(this.m_ChangeDriverButtonListeners);
      this.m_btn_visual.removeListener(this.m_VisualButtonListeners);
      this.m_btn_performance.removeListener(this.m_PerformanceButtonListeners);
      this.m_btn_carDealer.removeListener(this.m_CarDealerButtonListeners);
      this.m_btn_help.removeListener(this.m_HelpButtonListener);
      this.m_btn_windows.removeListener(this.m_WindowsButtonListeners);
      this.m_Wallet.EnableBoostButton(false);
   }
   function ExitPressEventHandler(evtObj)
   {
      this.removeListeners();
      flash.external.ExternalInterface.call("Request","SafeHouseIsActiveCarExpired");
   }
   function OnSafeHouseActiveCarExpiredReceived()
   {
      var _loc3_ = _global.mSafeHouseActiveCarExpired;
      if(_loc3_.expired)
      {
         com.ea.common.Generic.Utils.TriggerTransition("CurrentCarExpired");
      }
      else
      {
         this.triggerTransition("ExitSafeHouse");
      }
   }
   function OnPopupClosed(command)
   {
      switch(command)
      {
         case "GoChangeCar":
            com.ea.common.Generic.Utils.TriggerTransition("EnterSelectCar");
            break;
         case "GoBuyCar":
            com.ea.common.Generic.Utils.TriggerTransition("EnterBuyCar");
            break;
         case "BoostErrorStore":
            com.ea.Store.Store.GoToTopUp();
         case "SpeedBoostTutorialOk":
         case "BoostErrorOK":
         default:
            return undefined;
      }
   }
   function PowerupManagementPressEventHandler(evtObj)
   {
      this.triggerTransition("EnterPowerupManagement");
   }
   function PlayerProfilePressEventHandler(evtObj)
   {
      if(com.ea.SafeHouse.SafeHouseHub.USE_NATIVE_PLAYER_PROFILE)
      {
         this.triggerTransition("EnterPlayerProfile");
         return undefined;
      }
      this.OpenPlayerProfile();
   }
   function CreatePlayerProfileButton()
   {
      var _loc2_ = this.m_Screen.pane_MR.m_content;
      if(_loc2_ == undefined || _loc2_.m_btn_windows != undefined)
      {
         return undefined;
      }
      var _loc3_ = _loc2_[com.ea.SafeHouse.SafeHouseHub.HUB_BUTTON_ORDER[0]];
      var _loc4_ = _loc2_.m_btn_exit;
      var _loc5_ = _loc3_._y;
      var _loc6_ = _loc4_._y;
      var _loc7_ = new Object();
      _loc7_.iconMovieClipId = com.ea.SafeHouse.SafeHouseHub.PLAYER_PROFILE_ICON;
      _loc7_.label = "CMN_PLAYER_PROFILE";
      _loc7_.sfxMouseOff = "";
      _loc7_.sfxMouseOver = "SAFEHOUSE_MOUSE_OVER";
      _loc7_.sfxPress = "OK_BUTTON";
      this.CreateWindowsButton(_loc2_);
      var _loc9_ = com.ea.SafeHouse.SafeHouseHub.HUB_BUTTON_ORDER;
      var _loc10_ = (_loc6_ - _loc5_) / (_loc9_.length - 1);
      var _loc11_ = 0;
      var _loc12_;
      while(_loc11_ < _loc9_.length)
      {
         _loc12_ = _loc2_[_loc9_[_loc11_]];
         if(_loc12_ != undefined)
         {
            _loc12_._y = _loc5_ + _loc10_ * _loc11_;
            this.ScaleCascadeButton(_loc12_,com.ea.SafeHouse.SafeHouseHub.HUB_BUTTON_SCALE);
         }
         _loc11_ += 1;
      }
   }
   function CreateWindowsButton(content)
   {
      if(content.m_btn_windows != undefined)
      {
         return undefined;
      }
      var _loc3_ = new Object();
      _loc3_.label = com.ea.SafeHouse.SafeHouseHub.WINDOWS_LABEL_OPEN;
      _loc3_.sfxMouseOff = "";
      _loc3_.sfxMouseOver = "SAFEHOUSE_MOUSE_OVER";
      _loc3_.sfxPress = "OK_BUTTON";
      var _loc4_ = content.attachMovie("CascadeButton","m_btn_windows",content.getNextHighestDepth(),_loc3_);
      if(_loc4_ == undefined)
      {
         return undefined;
      }
      _loc4_._x = content.m_btn_cardPacks._x;
      this.DrawWindowsIcon(_loc4_.icon,content.m_btn_cardPacks.icon);
   }
   function DrawWindowsIcon(target, reference)
   {
      if(target == undefined)
      {
         return undefined;
      }
      var _loc4_ = reference.getBounds(reference);
      var _loc5_ = _loc4_.xMax - _loc4_.xMin;
      var _loc6_ = _loc4_.yMax - _loc4_.yMin;
      if(!(_loc5_ > 4) || !(_loc6_ > 4))
      {
         _loc4_ = {xMin:0,yMin:0};
         _loc5_ = 64;
         _loc6_ = 64;
      }
      var _loc7_ = target.createEmptyMovieClip("windowsIcon",target.getNextHighestDepth());
      var _loc8_ = Math.min(_loc5_,_loc6_) * 0.52;
      var _loc9_ = _loc4_.xMin + (_loc5_ - _loc8_) / 2;
      var _loc10_ = _loc4_.yMin + (_loc6_ - _loc8_) / 2;
      var _loc11_ = Math.max(2,_loc8_ * 0.09);
      var _loc12_ = 6150399;
      _loc7_.beginFill(_loc12_,18);
      _loc7_.moveTo(_loc9_,_loc10_);
      _loc7_.lineTo(_loc9_ + _loc8_,_loc10_);
      _loc7_.lineTo(_loc9_ + _loc8_,_loc10_ + _loc8_);
      _loc7_.lineTo(_loc9_,_loc10_ + _loc8_);
      _loc7_.lineTo(_loc9_,_loc10_);
      _loc7_.endFill();
      _loc7_.lineStyle(_loc11_,_loc12_,100);
      _loc7_.moveTo(_loc9_,_loc10_);
      _loc7_.lineTo(_loc9_ + _loc8_,_loc10_);
      _loc7_.lineTo(_loc9_ + _loc8_,_loc10_ + _loc8_);
      _loc7_.lineTo(_loc9_,_loc10_ + _loc8_);
      _loc7_.lineTo(_loc9_,_loc10_);
      _loc7_.moveTo(_loc9_ + _loc8_ / 2,_loc10_);
      _loc7_.lineTo(_loc9_ + _loc8_ / 2,_loc10_ + _loc8_);
      _loc7_.moveTo(_loc9_,_loc10_ + _loc8_ / 2);
      _loc7_.lineTo(_loc9_ + _loc8_,_loc10_ + _loc8_ / 2);
      _loc7_.lineStyle(Math.max(1,_loc11_ * 0.5),16777215,55);
      _loc7_.moveTo(_loc9_ + _loc8_ * 0.12,_loc10_ + _loc8_ * 0.38);
      _loc7_.lineTo(_loc9_ + _loc8_ * 0.38,_loc10_ + _loc8_ * 0.12);
      _loc7_.moveTo(_loc9_ + _loc8_ * 0.62,_loc10_ + _loc8_ * 0.88);
      _loc7_.lineTo(_loc9_ + _loc8_ * 0.88,_loc10_ + _loc8_ * 0.62);
   }
   function UpdateWindowsButton(state)
   {
      if(state != undefined)
      {
         this.m_WindowsOpen = state == true || state == "true";
      }
      if(this.m_btn_windows != undefined)
      {
         this.m_btn_windows.setLabel(!this.m_WindowsOpen ? com.ea.SafeHouse.SafeHouseHub.WINDOWS_LABEL_OPEN : com.ea.SafeHouse.SafeHouseHub.WINDOWS_LABEL_CLOSE);
      }
   }
   function WindowsPressEventHandler(evtObj)
   {
      var _loc3_ = flash.external.ExternalInterface.call("SafehouseWindows","toggle");
      if(_loc3_ == undefined)
      {
         _loc3_ = !this.m_WindowsOpen;
      }
      this.UpdateWindowsButton(_loc3_);
   }
   function ScaleCascadeButton(b, scale)
   {
      b.mBaseScale = scale;
      b._xscale = scale;
      b._yscale = scale;
      if(b.mOrigStartFadeBack == undefined)
      {
         b.mOrigStartFadeBack = b.startFadeBack;
         b.mOrigStartReturnToNormal = b.startReturnToNormal;
      }
      b.startFadeBack = function(absIndex)
      {
         this.mOrigStartFadeBack(absIndex);
         this.animation_target_scale = this.animation_target_scale * this.mBaseScale / 100;
      };
      b.startReturnToNormal = function()
      {
         this.mOrigStartReturnToNormal();
         this.animation_target_scale = this.mBaseScale;
      };
   }
   function OpenPlayerProfile()
   {
      if(this.mbPlayerProfileOpen)
      {
         return undefined;
      }
      this.mbPlayerProfileOpen = true;
      this.SetInputEnabled(false);
      com.ea.util.KeyboardNavigation.Enable = true;
      com.ea.util.KeyboardNavigation.UnSet(Key.ESCAPE);
      com.ea.util.SFX.PlaySound(com.ea.util.SFX.GADGET_HIDE_SFX);
      this.SetHubVisible(false);
      _global.PlayerProfileHost = this;
      this.mPlayerProfileHolder = this.m_Screen.createEmptyMovieClip("mPlayerProfileHolder",com.ea.SafeHouse.SafeHouseHub.PLAYER_PROFILE_DEPTH);
      this.mPlayerProfileHolder._lockroot = true;
      this.mPlayerProfileLoader = new MovieClipLoader();
      var _loc3_ = new Object();
      _loc3_.onLoadInit = mx.utils.Delegate.create(this,this.OnPlayerProfileLoaded);
      _loc3_.onLoadError = mx.utils.Delegate.create(this,this.OnPlayerProfileLoadError);
      this.mPlayerProfileLoader.addListener(_loc3_);
      this.mPlayerProfileLoader.loadClip(com.ea.SafeHouse.SafeHouseHub.PLAYER_PROFILE_SWF,this.mPlayerProfileHolder);
   }
   function OnPlayerProfileLoaded(target)
   {
      var _loc3_ = this.mPlayerProfileHolder.Screen;
      if(_loc3_ != undefined && _loc3_.onResize != undefined)
      {
         _loc3_.onResize();
      }
   }
   function OnPlayerProfileLoadError(target, errorCode)
   {
      this.FinishClosePlayerProfile();
   }
   function ClosePlayerProfile(transition)
   {
      if(this.mPlayerProfileTimer == undefined)
      {
         this.mPlayerProfileTimer = new com.ea.util.Intervalista();
      }
      this.mPlayerProfileTimer.stop();
      this.mPlayerProfileTimer.start(this,"FinishClosePlayerProfile",30);
   }
   function FinishClosePlayerProfile()
   {
      if(this.mPlayerProfileTimer != undefined)
      {
         this.mPlayerProfileTimer.stop();
      }
      var _loc3_ = this.mPlayerProfileHolder.Screen;
      if(_loc3_ != undefined)
      {
         Stage.removeListener(_loc3_);
      }
      com.ea.util.KeyboardNavigation.UnSet(Key.ESCAPE);
      if(this.mPlayerProfileLoader != undefined && this.mPlayerProfileHolder != undefined)
      {
         this.mPlayerProfileLoader.unloadClip(this.mPlayerProfileHolder);
      }
      this.mPlayerProfileHolder.removeMovieClip();
      this.mPlayerProfileHolder = undefined;
      this.mPlayerProfileLoader = undefined;
      _global.PlayerProfileHost = undefined;
      _global.RootClass = this;
      this.mbPlayerProfileOpen = false;
      this.SetHubVisible(true);
      this.onResize();
      com.ea.util.KeyboardNavigation.Set(Key.ESCAPE,this,this.ExitPressEventHandler);
      this.SetInputEnabled(true);
      flash.external.ExternalInterface.call("Request","SafeHouseSetMouseWheelZoom",true);
      com.ea.gameapi.command.Command.GadgetListenToResolutionChange();
      com.ea.util.SFX.PlaySound(com.ea.util.SFX.GADGET_SHOW_SFX);
      this.RequestPersonaInfo();
   }
   function SetHubVisible(setting)
   {
      for(var _loc3_ in this.mPanes)
      {
         this.mPanes[_loc3_]._visible = setting;
      }
   }
   function SelectCarPressEventHandler(evtObj)
   {
      this.triggerTransition("EnterSelectCar");
   }
   function ChangeDriverPressEventHandler(evtObj)
   {
      this.triggerTransition("EnterChangeDriver");
   }
   function VisualPressEventHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterCustomization();
   }
   function PerformancePressEventHandler(evtObj)
   {
   }
   function CarDealerPressEventHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterCarDealer();
   }
   function CardPacksPressEventHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterBoosterPack();
   }
   function HelpPressEventHandler()
   {
      com.ea.common.Generic.Utils.TriggerTransition("SafeHouseRoadBlock");
   }
   function OnDurabilityEmpty(setting)
   {
      this.m_DurabilityWarning._visible = setting;
      this.m_DurabilityInsuranceText._visible = !setting;
      this.m_DurabilityWarning.gotoAndPlay(!setting ? com.ea.SafeHouse.SafeHouseHub.LABEL_DURABILITY_INFO_HIDE : com.ea.SafeHouse.SafeHouseHub.LABEL_DURABILITY_INFO_SHOW);
   }
   function OnDurabilityInsured(setting)
   {
      this.m_DurabilityWarning._visible = !setting;
      this.m_DurabilityInsuranceText._visible = setting;
      this.m_DurabilityInsuranceText.gotoAndPlay(!setting ? com.ea.SafeHouse.SafeHouseHub.LABEL_DURABILITY_INFO_HIDE : com.ea.SafeHouse.SafeHouseHub.LABEL_DURABILITY_INFO_SHOW);
   }
   function DurabilityChangeEventHandler(eventObj)
   {
      this.UpdateDurabilityState();
   }
   function StoreLastState()
   {
      com.ea.gameapi.command.Command.SetSessionValue("lastState","Global",com.ea.gameapi.enum.GadgetName.SafeHouseHub.value);
   }
   function EnableWaitAnimation(lbSetting)
   {
      this.WaitAnim._visible = !lbSetting ? false : true;
      this.WaitAnim.gotoAndPlay(!lbSetting ? "outro" : "intro");
   }
   function SetInputEnabled(setting)
   {
      this.m_btn_exit.setEnable(setting);
      this.m_btn_selectCar.setEnable(setting);
      this.m_btn_exit2.setEnable(setting);
      this.m_btn_powerupManagement.setEnable(setting);
      this.m_btn_PlayerProfile.setEnable(setting);
      this.m_btn_changeDriver.setEnable(setting);
      this.m_btn_visual.setEnable(setting);
      this.m_btn_performance.setEnable(setting);
      this.m_btn_carDealer.setEnable(setting);
      this.m_btn_help.setEnable(setting);
      this.m_btn_cardPacks.setEnable(setting);
      this.m_btn_windows.setEnable(setting);
      this.m_Wallet.EnableBoostButton(setting);
      this.m_fixButton.setEnable(setting && this.m_DurabilityIcon.IsFixAvailable());
      this.mProgAmpInsurance.EnableInput(setting);
      com.ea.util.KeyboardNavigation.Enable = setting;
   }
   function FixEventHandler(evtObj)
   {
      this.SetInputEnabled(false);
      this.EnableWaitAnimation(true);
      this.dispatchEvent({type:com.ea.SafeHouse.SafeHouseHub.ON_FIX_BUTTON_PRESS,object:this});
      if(undefined == com.ea.gameapi.command.Command.ShoppingCartFixDurability)
      {
         flash.external.ExternalInterface.call("Request","ShoppingCartFixDurability");
      }
      else
      {
         com.ea.gameapi.command.Command.ShoppingCartFixDurability();
      }
   }
   function OnFixInProgressReceived(Void)
   {
      this.m_IsWaitingForDurabilityFix = true;
      this.SetInputEnabled(false);
      this.EnableWaitAnimation(true);
   }
   function OnFixCompleteReceived(Void)
   {
      this.m_IsWaitingForDurabilityFix = false;
      this.SetInputEnabled(true);
      this.EnableWaitAnimation(false);
      this.m_DurabilityIcon.Update();
      this.UpdateFixPrice();
      this.UpdateDurabilityState();
   }
   function UpdateFixPrice(Void)
   {
      com.ea.gameapi.command.Command.CarsGetFixPrice();
      this.mFixCost.text = _global.mCarsFixPrice.fixPrice;
   }
   function OnBoostShopCompleteReceived()
   {
      com.ea.gameapi.command.Command.GetPersonaInfo(0,false);
   }
   function RequestPersonaInfo()
   {
      com.ea.gameapi.command.Command.GetPersonaInfo(0,false);
   }
   function OnGamePersonaReceived()
   {
      if(!_global.mGamePersona.isSelf)
      {
         return undefined;
      }
      this.m_GamePersona = _global.mGamePersona;
      this.m_Wallet.SetValuesFromPersona(this.m_GamePersona);
      if(this.m_IsWaitingForDurabilityFix)
      {
         this.m_DurabilityIcon.Update();
         this.OnFixCompleteReceived();
      }
   }
   function GetPersonaInfoFailed()
   {
      if(this.m_IsWaitingForDurabilityFix)
      {
         this.m_DurabilityIcon.Update();
         this.OnFixCompleteReceived();
      }
   }
   function RequestExitSafeHouse()
   {
      com.ea.gameapi.command.Command.SafeHouseExit();
   }
   function OnInsurancePurchased(_event)
   {
      var _loc2_ = _event.purchaseResult;
      if(_loc2_.result == false)
      {
         com.ea.common.Generic.Utils.TriggerTransition("BoostErrorGoToStore");
      }
   }
   function OnFocus()
   {
      this.mProgAmpInsurance.Reset();
   }
   function get WaitAnim()
   {
      return this.m_Screen.pane_BL.m_waitAnimation;
   }
   function OnDisplayTutorialReceived()
   {
      if(_global.mDisplayTutorial.value)
      {
         this.SetupCallouts();
         this.ShowCallouts();
      }
   }
   function SetupCallouts()
   {
      this.mcRepairsCallout1.titleMc.titleFld.text = "TTRL_REPAIRS_3_HDR";
      this.mcRepairsCallout1.contentMc.contentFld.text = "TTRL_REPAIRS_3";
      this.mcRepairsCallout1.gotoAndPlay("down");
      this.mcRepairsCallout2.titleMc.titleFld.text = "TTRL_REPAIRS_4_HDR";
      this.mcRepairsCallout2.contentMc.contentFld.text = "TTRL_REPAIRS_4";
      this.mcRepairsCallout2.gotoAndPlay("bottomleft_down");
   }
   function ShowCallouts()
   {
      this.m_Screen.pane_BL.callouts.play();
   }
   function HideCallouts()
   {
      this.m_Screen.pane_BL.callouts.stop();
   }
   function RequestCallouts()
   {
      flash.external.ExternalInterface.call("Request","HandleTutorial","RepairsCallout","");
   }
}
