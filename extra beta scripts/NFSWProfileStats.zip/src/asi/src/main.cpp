// NFSWProfileStats.asi - NFS World 2015 (offline)
//
// Statistiche reali per il profilo (PlayerProfile.gfx, pagina Statistiche) e per il gadget del profilo.
//
// Le due schermate chiedono le statistiche con ExternalInterface.call("Request","NFSWGetProfileStats",personaId)
// (classe com.ea.util.FakeProfileStats modificata: se nessuno risponde usano ancora i valori generati).
// Questo ASI registra il comando nel registro "Request" del gioco e risponde in modo sincrono con il file
// drivers\driverN\ProfileStats.txt del server offline, scritto dal modulo del server src\routes\ProfileStats.js
// a ogni gara, pursuit e Team Escape concluso:
//   found=1            il pilota esiste sul server (anche se non ha ancora statistiche: tutto a zero)
//   S.<campo>=valore   ProfileStatistics   (gare: complessive, single player, multiplayer)
//   P.<campo>=valore   ProfilePursuitStats (inseguimenti)
//   R.<campo>=valore   ProfileRecordStats  (record)
// Pilota non trovato (es. i rivali finti del profilo): risposta vuota, la schermata usa i valori generati.
//
// Cartella del server: come NFSWLevelUpRewards.asi (ricerca automatica, oppure ServerFolder nell'ini).
// Gli hook (RegisterAll e i due slot ExternalInterface) sono concatenati a quelli degli altri ASI.

#include <windows.h>

// ---------------------------------------------------------------- indirizzi (nfsw.exe 2015)
static const DWORD kBase              = 0x00400000;
static const DWORD kRegistryGlobal    = 0x00CEA7A4; // registro dei comandi "Request"
static const DWORD kRegisterCmd       = 0x00524410; // void __thiscall (registry, const char*, handler)
static const DWORD kRegisterAllSite   = 0x00522B9F; // call RegisterAll(registry)
static const DWORD kRegisterAll       = 0x004C4C50; // void __cdecl (registry)
static const DWORD kScreenEISlot      = 0x00B729C4; // ExternalInterface::Callback delle schermate FE
static const DWORD kScreenEIOrig      = 0x004ABBB0;
static const DWORD kGadgetEISlot      = 0x00B2D030; // ExternalInterface::Callback dei gadget
static const DWORD kGadgetEIOrig      = 0x004867E0;
static const DWORD kCurrentPersonaId  = 0x0043FDD0; // unsigned __int64 __cdecl (), id della persona in uso
static const int   kMovieSetRetVal    = 0xB4;       // GFxMovieView vtable: SetExternalInterfaceRetVal

// ---------------------------------------------------------------- valore GFx
struct GVal { void* obj; unsigned type; union { double n; const char* s; const char** ms; unsigned char b; } v; };
typedef void (__cdecl *ReqHandler)(void* ctx, const GVal* args, unsigned argc);
typedef void (__fastcall *EICallback)(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc);

// ---------------------------------------------------------------- stato
static DWORD g_delta;
static char  g_dir[MAX_PATH];        // cartella dell'ASI (Data\Scripts\)
static char  g_ini[MAX_PATH];
static char  g_log[MAX_PATH];
static char  g_server[MAX_PATH];     // cartella del server offline
static bool  g_logOn = true;
static DWORD g_prevRegisterAll, g_prevScreenEI, g_prevGadgetEI;
static void* g_movie;                // movie della chiamata ExternalInterface in corso
static bool  g_registered;

static char  g_file[64 * 1024];      // ProfileStats.txt
static char  g_out[64 * 1024];       // risposta per Flash

// ---------------------------------------------------------------- mini libc
extern "C" void* __cdecl memset(void* d, int c, size_t n) { unsigned char* p = (unsigned char*)d; while (n--) *p++ = (unsigned char)c; return d; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; while (n--) *a++ = *b++; return d; }
static int  StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); if (n < cap) StrCpy(d + n, s, cap - n); }
static bool StartsWith(const char* s, const char* p) { while (*p) if (*s++ != *p++) return false; return true; }
static void IntToStr(int v, char* out) { char t[16]; int n = 0; bool neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (neg) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static void UIntToStr(unsigned u, char* out) { char t[16]; int n = 0; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; while (n) out[i++] = t[--n]; out[i] = 0; }
static int  ParseInt(const char* p) { while (*p == ' ' || *p == '\t') ++p; bool neg = *p == '-'; if (neg) ++p; int v = 0; while (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); ++p; } return neg ? -v : v; }
static const char* Find(const char* s, const char* end, const char* what)
{
    int n = StrLen(what);
    for (; s + n <= end; ++s) { int i = 0; while (i < n && s[i] == what[i]) ++i; if (i == n) return s; }
    return 0;
}

static void Log(const char* a, const char* b = 0, const char* c = 0, const char* d = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME t; GetLocalTime(&t);
    char ts[16]; ts[0] = '[';
    int v[3] = { t.wHour, t.wMinute, t.wSecond };
    for (int i = 0; i < 3; ++i) { ts[1 + i * 3] = (char)('0' + v[i] / 10); ts[2 + i * 3] = (char)('0' + v[i] % 10); ts[3 + i * 3] = i < 2 ? ':' : ']'; }
    ts[10] = ' '; ts[11] = 0;
    DWORD w; const char* parts[5] = { ts, a, b, c, d };
    for (int i = 0; i < 5; ++i) if (parts[i]) WriteFile(h, parts[i], StrLen(parts[i]), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}
static void LogHex(const char* what, DWORD v)
{
    char buf[16]; const char* hx = "0123456789ABCDEF"; buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 8; ++i) buf[2 + i] = hx[(v >> (28 - 4 * i)) & 15];
    buf[10] = 0; Log(what, buf);
}

static inline DWORD A(DWORD va) { return va + g_delta; }
static bool Readable(const void* p, unsigned n) { return p && !IsBadReadPtr(p, n); }

// ---------------------------------------------------------------- patch concatenate
// Sostituisce la destinazione di una call rel32 e restituisce quella precedente (originale o hook di un altro ASI).
static bool ChainCall(DWORD site, DWORD* prev, void* fn, DWORD orig, const char* what)
{
    unsigned char* p = (unsigned char*)A(site);
    if (!Readable(p, 5) || p[0] != 0xE8) { Log("[init] ", what, ": istruzione inattesa, hook non installato"); return false; }
    DWORD target = (DWORD)p + 5 + *(int*)(p + 1);
    if (target == (DWORD)fn) return true;
    DWORD old;
    if (!VirtualProtect(p + 1, 4, PAGE_EXECUTE_READWRITE, &old)) return false;
    *prev = target;
    *(int*)(p + 1) = (int)((DWORD)fn - ((DWORD)p + 5));
    VirtualProtect(p + 1, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    Log("[init] ", what, target == A(orig) ? ": hook installato" : ": hook concatenato a quello di un altro ASI");
    return true;
}
static bool ChainPtr(DWORD addr, DWORD* prev, void* fn, DWORD orig, const char* what)
{
    DWORD* p = (DWORD*)A(addr);
    if (!Readable(p, 4) || !*p) { Log("[init] ", what, ": slot non valido, hook non installato"); return false; }
    if (*p == (DWORD)fn) return true;
    DWORD old;
    if (!VirtualProtect(p, 4, PAGE_READWRITE, &old)) return false;
    *prev = *p;
    *p = (DWORD)fn;
    VirtualProtect(p, 4, old, &old);
    Log("[init] ", what, *prev == A(orig) ? ": hook installato" : ": hook concatenato a quello di un altro ASI");
    return true;
}

// ---------------------------------------------------------------- file
static int ReadWholeFile(const char* path, char* buf, int cap, FILETIME* mtime)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return -1;
    if (mtime) { mtime->dwLowDateTime = mtime->dwHighDateTime = 0; GetFileTime(h, 0, 0, mtime); }
    DWORD size = GetFileSize(h, 0), got = 0;
    if (size == 0xFFFFFFFF || (int)size >= cap) { CloseHandle(h); return -1; }
    BOOL ok = ReadFile(h, buf, size, &got, 0);
    CloseHandle(h);
    if (!ok) return -1;
    buf[got] = 0;
    return (int)got;
}
static bool Newer(const FILETIME& a, const FILETIME& b)
{
    return a.dwHighDateTime != b.dwHighDateTime ? a.dwHighDateTime > b.dwHighDateTime : a.dwLowDateTime > b.dwLowDateTime;
}
// percorso relativo alla cartella dell'ASI, oppure assoluto
static void ResolvePath(char* out, const char* p)
{
    if (p[0] && (p[1] == ':' || (p[0] == '\\' && p[1] == '\\'))) { StrCpy(out, p, MAX_PATH); return; }
    StrCpy(out, g_dir, MAX_PATH); StrCat(out, p, MAX_PATH);
}

// ---------------------------------------------------------------- ricerca della cartella del server
// Nessun nome fisso: viene cercata, tra le sottocartelle della cartella del gioco (quella che contiene Data)
// e della cartella dell'eseguibile, quella che ha la struttura del server offline (drivers\DefaultPersonaIdx.xml
// e data\). Se piu' cartelle sono valide vince quella il cui config\config.json punta a questo nfsw.exe.
static bool FileExists(const char* path)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return false;
    CloseHandle(h);
    return true;
}
static bool DirExists(const char* path)
{
    WIN32_FIND_DATAA fd; char m[MAX_PATH]; StrCpy(m, path, MAX_PATH); StrCat(m, "*", MAX_PATH);
    HANDLE f = FindFirstFileA(m, &fd);
    if (f == INVALID_HANDLE_VALUE) return false;
    FindClose(f);
    return true;
}
static char LowerSlash(char c) { if (c == '/') return '\\'; return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
// config\config.json del server: "nfswFilePath" coincide con l'eseguibile in uso?
static bool ConfigPointsToExe(const char* server, const char* exe)
{
    static char buf[8 * 1024];
    char path[MAX_PATH]; StrCpy(path, server, MAX_PATH); StrCat(path, "config\\config.json", MAX_PATH);
    int n = ReadWholeFile(path, buf, sizeof(buf), 0);
    if (n <= 0) return false;
    const char* p = Find(buf, buf + n, "\"nfswFilePath\"");
    if (!p) return false;
    p = Find(p + 14, buf + n, "\"");
    if (!p) return false;
    ++p;
    const char* e = exe;
    while (p < buf + n && *p != '"') {
        char c = *p++;
        if (c == '\\' && p < buf + n && (*p == '\\' || *p == '/')) c = *p++;
        if (!*e || LowerSlash(c) != LowerSlash(*e)) return false;
        ++e;
    }
    return *e == 0;
}
static int ScanForServer(const char* root, const char* exe, char* best, int bestScore)
{
    char mask[MAX_PATH]; StrCpy(mask, root, MAX_PATH); StrCat(mask, "*", MAX_PATH);
    WIN32_FIND_DATAA fd;
    HANDLE f = FindFirstFileA(mask, &fd);
    if (f == INVALID_HANDLE_VALUE) return bestScore;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == '.') continue;
        char dir[MAX_PATH]; StrCpy(dir, root, MAX_PATH); StrCat(dir, fd.cFileName, MAX_PATH); StrCat(dir, "\\", MAX_PATH);
        char t[MAX_PATH]; StrCpy(t, dir, MAX_PATH); StrCat(t, "drivers\\DefaultPersonaIdx.xml", MAX_PATH);
        if (!FileExists(t)) continue;
        StrCpy(t, dir, MAX_PATH); StrCat(t, "data\\", MAX_PATH);
        if (!DirExists(t)) continue;
        int score = 1;
        StrCpy(t, dir, MAX_PATH); StrCat(t, "src\\routes\\ProfileStats.js", MAX_PATH);
        if (FileExists(t)) score += 1;
        if (ConfigPointsToExe(dir, exe)) score += 2;
        Log("[server] trovato: ", dir, score >= 3 ? " (configurato per questo nfsw.exe)" : "");
        if (score > bestScore) { bestScore = score; StrCpy(best, dir, MAX_PATH); }
    } while (FindNextFileA(f, &fd));
    FindClose(f);
    return bestScore;
}
static bool FindServerFolder(char* out)
{
    char exe[MAX_PATH], exeDir[MAX_PATH], root[MAX_PATH];
    DWORD n = GetModuleFileNameA(0, exe, MAX_PATH);
    if (!n || n >= MAX_PATH) return false;
    StrCpy(exeDir, exe, MAX_PATH);
    int cut = -1;
    for (int i = (int)n - 1; i >= 0; --i) if (exeDir[i] == '\\' || exeDir[i] == '/') { cut = i; break; }
    if (cut < 0) return false;
    exeDir[cut + 1] = 0;                                   // ...\Data\  .
    StrCpy(root, exeDir, MAX_PATH); root[cut] = 0;
    int up = -1;
    for (int i = cut - 1; i >= 0; --i) if (root[i] == '\\' || root[i] == '/') { up = i; break; }
    root[up + 1] = 0;                                      // cartella del gioco
    int score = 0;
    if (up >= 0) score = ScanForServer(root, exe, out, score);
    score = ScanForServer(exeDir, exe, out, score);
    return score > 0;
}
static void ResolveServer()
{
    char tmp[MAX_PATH];
    GetPrivateProfileStringA("ProfileStats", "ServerFolder", "", tmp, MAX_PATH, g_ini);
    if (tmp[0]) ResolvePath(g_server, tmp);
    else if (!FindServerFolder(g_server)) { g_server[0] = 0; Log("[server] cartella del server offline non trovata (indicarla con ServerFolder nell'ini)"); }
    int n = StrLen(g_server);
    if (n && g_server[n - 1] != '\\' && g_server[n - 1] != '/') StrCat(g_server, "\\", MAX_PATH);
    Log("[init] server: ", g_server[0] ? g_server : "(non trovato)");
    if (g_server[0]) {
        char js[MAX_PATH]; StrCpy(js, g_server, MAX_PATH); StrCat(js, "src\\routes\\ProfileStats.js", MAX_PATH);
        if (!FileExists(js)) Log("[init] ATTENZIONE: manca ", js, " (il server non registra le statistiche)");
    }
}

// ---------------------------------------------------------------- statistiche (file del server)
static int TagInt(const char* xml, const char* tag)
{
    const char* end = xml + StrLen(xml);
    const char* p = Find(xml, end, tag);
    if (!p) return -1;
    return ParseInt(p + StrLen(tag));
}

static unsigned CurrentPersonaId()
{
    const unsigned char* f = (const unsigned char*)A(kCurrentPersonaId);
    if (!Readable(f, 5) || f[0] != 0xB8) return 0;
    unsigned long long id = ((unsigned long long (__cdecl*)())f)();
    if (id == 0 || id > 0x7FFFFFFFULL) return 0;
    return (unsigned)id;
}

// Cartella drivers\driverN\ del pilota indicato (false se non esiste sul server).
static bool FindDriverDir(unsigned wantId, char* out)
{
    if (!g_server[0] || !wantId) return false;
    char mask[MAX_PATH]; StrCpy(mask, g_server, MAX_PATH); StrCat(mask, "drivers\\driver*", MAX_PATH);
    WIN32_FIND_DATAA fd;
    HANDLE f = FindFirstFileA(mask, &fd);
    if (f == INVALID_HANDLE_VALUE) return false;
    static char buf[16 * 1024];
    bool found = false;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        char dir[MAX_PATH]; StrCpy(dir, g_server, MAX_PATH); StrCat(dir, "drivers\\", MAX_PATH);
        StrCat(dir, fd.cFileName, MAX_PATH); StrCat(dir, "\\", MAX_PATH);
        char path[MAX_PATH]; StrCpy(path, dir, MAX_PATH); StrCat(path, "GetPersonaInfo.xml", MAX_PATH);
        if (ReadWholeFile(path, buf, sizeof(buf), 0) <= 0) continue;
        if (TagInt(buf, "<PersonaId>") == (int)wantId) { StrCpy(out, dir, MAX_PATH); found = true; break; }
    } while (FindNextFileA(f, &fd));
    FindClose(f);
    return found;
}

static bool g_full;
static void OutN(const char* s, int m)
{
    int n = StrLen(g_out);
    if (n + m + 1 >= (int)sizeof(g_out) - 1) { g_full = true; return; }
    memcpy(g_out + n, s, m); g_out[n + m] = '\n'; g_out[n + m + 1] = 0;
}

// ---------------------------------------------------------------- risposta a Flash
static void SetReturnString(const char* value)
{
    void* movie = g_movie;
    if (!Readable(movie, 4)) { Log("[flash] movie non disponibile, nessun valore di ritorno"); return; }
    void** vt = *(void***)movie;
    if (!Readable(vt + kMovieSetRetVal / 4, 4)) return;
    GVal v; memset(&v, 0, sizeof(v));
    v.type = 4; v.v.s = value;
    typedef void (__fastcall *SetRet)(void*, void*, const GVal*);
    ((SetRet)vt[kMovieSetRetVal / 4])(movie, 0, &v);
}

static int ArgInt(const GVal* a)
{
    if (!a) return 0;
    unsigned t = a->type & 0x8F;
    if (t == 3) return (int)a->v.n;
    if (t == 4) { const char* s = (a->type & 0x40) ? (a->v.ms ? *a->v.ms : 0) : a->v.s; return s ? ParseInt(s) : 0; }
    return 0;
}

static void __cdecl Req_ProfileStats(void*, const GVal* args, unsigned argc)
{
    g_out[0] = 0; g_full = false;
    if (!g_server[0]) ResolveServer();                         // il server potrebbe essere stato aggiunto dopo l'avvio
    int arg = argc > 0 ? ArgInt(&args[0]) : 0;
    unsigned id = arg > 0 ? (unsigned)arg : CurrentPersonaId();
    char num[16]; UIntToStr(id, num);
    char dir[MAX_PATH];
    if (!FindDriverDir(id, dir)) { Log("[richiesta] pilota ", num, " non presente sul server: valori generati"); SetReturnString(""); return; }
    StrCpy(g_out, "found=1\n", sizeof(g_out));
    char path[MAX_PATH]; StrCpy(path, dir, MAX_PATH); StrCat(path, "ProfileStats.txt", MAX_PATH);
    int n = ReadWholeFile(path, g_file, sizeof(g_file), 0);
    int lines = 0;
    if (n > 0) {
        const char* p = g_file; const char* end = g_file + n;
        while (p < end) {
            const char* e = p; while (e < end && *e != '\n' && *e != '\r') ++e;
            if (e - p > 2 && (p[0] == 'S' || p[0] == 'P' || p[0] == 'R') && p[1] == '.') { OutN(p, (int)(e - p)); ++lines; }
            p = e; while (p < end && (*p == '\n' || *p == '\r')) ++p;
        }
    }
    SetReturnString(g_out);
    char c[16]; IntToStr(lines, c);
    Log("[richiesta] statistiche del pilota ", num, n > 0 ? ": voci " : ": nessuna gara registrata, valori a zero", n > 0 ? c : 0);
    if (g_full) Log("[richiesta] risposta troncata");
}

// ---------------------------------------------------------------- hook
static void __fastcall Hook_ScreenEI(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc)
{
    void* prev = g_movie; g_movie = movie;
    ((EICallback)g_prevScreenEI)(self, edx, movie, method, args, argc);
    g_movie = prev;
}
static void __fastcall Hook_GadgetEI(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc)
{
    void* prev = g_movie; g_movie = movie;
    ((EICallback)g_prevGadgetEI)(self, edx, movie, method, args, argc);
    g_movie = prev;
}

static void RegisterCommands(void* registry)
{
    if (!registry) return;
    typedef void (__fastcall *RegFn)(void*, void*, const char*, void*);
    ((RegFn)A(kRegisterCmd))(registry, 0, "NFSWGetProfileStats", (void*)Req_ProfileStats);
    g_registered = true;
    LogHex("[init] comando NFSWGetProfileStats registrato in ", (DWORD)registry);
}
static void __cdecl Hook_RegisterAll(void* registry)
{
    ((void (__cdecl*)(void*))g_prevRegisterAll)(registry);
    RegisterCommands(registry);
}

// ---------------------------------------------------------------- init
static void Init(HMODULE self)
{
    g_delta = (DWORD)GetModuleHandleA(0) - kBase;
    DWORD n = GetModuleFileNameA(self, g_dir, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    for (int i = (int)n - 1; i >= 0; --i) if (g_dir[i] == '\\' || g_dir[i] == '/') { g_dir[i + 1] = 0; break; }
    StrCpy(g_ini, g_dir, MAX_PATH); StrCat(g_ini, "NFSWProfileStats.ini", MAX_PATH);
    StrCpy(g_log, g_dir, MAX_PATH); StrCat(g_log, "NFSWProfileStats.log", MAX_PATH);
    if (!GetPrivateProfileIntA("ProfileStats", "Enabled", 1, g_ini)) return;
    g_logOn = GetPrivateProfileIntA("ProfileStats", "Log", 1, g_ini) != 0;
    if (g_logOn) DeleteFileA(g_log);

    ResolveServer();

    const unsigned char* site = (const unsigned char*)A(kRegisterAllSite);
    const unsigned char* pid = (const unsigned char*)A(kCurrentPersonaId);
    if (!Readable(site, 5) || site[0] != 0xE8 || !Readable(pid, 5) || pid[0] != 0xB8) { Log("[init] nfsw.exe sconosciuto, ASI disattivato"); return; }

    ChainCall(kRegisterAllSite, &g_prevRegisterAll, (void*)Hook_RegisterAll, kRegisterAll, "RegisterAll");
    ChainPtr(kScreenEISlot, &g_prevScreenEI, (void*)Hook_ScreenEI, kScreenEIOrig, "ExternalInterface schermate");
    ChainPtr(kGadgetEISlot, &g_prevGadgetEI, (void*)Hook_GadgetEI, kGadgetEIOrig, "ExternalInterface gadget");
    void* reg = Readable((void*)A(kRegistryGlobal), 4) ? *(void**)A(kRegistryGlobal) : 0;
    if (reg) RegisterCommands(reg);
}

extern "C" BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hinst);
        Init(hinst);
    }
    return TRUE;
}
