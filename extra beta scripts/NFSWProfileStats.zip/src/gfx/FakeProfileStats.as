class com.ea.util.FakeProfileStats
{
   static var mSeed = 1;
   function FakeProfileStats()
   {
   }
   static function Seed(personaId, salt)
   {
      var _loc3_ = Math.abs(Math.floor(Number(personaId)));
      if(isNaN(_loc3_))
      {
         _loc3_ = 0;
      }
      com.ea.util.FakeProfileStats.mSeed = (_loc3_ + salt * 7919) % 2147483646 + 1;
      com.ea.util.FakeProfileStats.Next();
      com.ea.util.FakeProfileStats.Next();
   }
   static function Next()
   {
      com.ea.util.FakeProfileStats.mSeed = com.ea.util.FakeProfileStats.mSeed * 16807 % 2147483647;
      return com.ea.util.FakeProfileStats.mSeed / 2147483647;
   }
   static function Range(minV, maxV)
   {
      return Math.floor(minV + com.ea.util.FakeProfileStats.Next() * (maxV - minV + 1));
   }
   static function FixLevel(level)
   {
      var _loc2_ = Number(level);
      if(isNaN(_loc2_) || _loc2_ < 1)
      {
         _loc2_ = 10;
      }
      return _loc2_;
   }
   static function Time(totalSeconds)
   {
      var _loc2_ = Math.floor(totalSeconds / 60);
      var _loc3_ = Math.floor(totalSeconds % 60);
      var _loc4_ = Math.floor((totalSeconds - Math.floor(totalSeconds)) * 100);
      return _loc2_ + ":" + (_loc3_ >= 10 ? "" : "0") + _loc3_ + "." + (_loc4_ >= 10 ? "" : "0") + _loc4_;
   }
   static function Speed(kmh)
   {
      return Math.floor(kmh) + " KM/H";
   }
   static function GetReal(personaId)
   {
      var _loc2_ = flash.external.ExternalInterface.call("Request","NFSWGetProfileStats",Number(personaId));
      if(_loc2_ == undefined || _loc2_ == null)
      {
         return null;
      }
      var _loc3_ = String(_loc2_);
      if(_loc3_.length == 0)
      {
         return null;
      }
      var _loc4_ = {found:false,S:new Object(),P:new Object(),R:new Object()};
      var _loc5_ = _loc3_.split("\n");
      var _loc6_ = 0;
      var _loc7_;
      var _loc8_;
      var _loc9_;
      while(_loc6_ < _loc5_.length)
      {
         _loc7_ = _loc5_[_loc6_];
         if(_loc7_.charAt(_loc7_.length - 1) == "\r")
         {
            _loc7_ = _loc7_.substr(0,_loc7_.length - 1);
         }
         if(_loc7_ == "found=1")
         {
            _loc4_.found = true;
         }
         else
         {
            _loc8_ = _loc7_.indexOf("=");
            if(_loc8_ > 2 && _loc7_.charAt(1) == ".")
            {
               _loc9_ = _loc4_[_loc7_.charAt(0)];
               if(_loc9_ != undefined)
               {
                  _loc9_[_loc7_.substring(2,_loc8_)] = _loc7_.substring(_loc8_ + 1);
               }
            }
         }
         _loc6_ += 1;
      }
      if(!_loc4_.found)
      {
         return null;
      }
      return _loc4_;
   }
   static function Fill(target, values, personaId)
   {
      var _loc5_;
      var _loc6_;
      for(var _loc4_ in values)
      {
         _loc5_ = values[_loc4_];
         _loc6_ = Number(_loc5_);
         if(_loc5_ != "" && !isNaN(_loc6_))
         {
            target[_loc4_] = _loc6_;
         }
         else
         {
            target[_loc4_] = _loc5_;
         }
      }
      target.personaId = personaId;
      return target;
   }
   static function MakeStatistics(personaId, level)
   {
      var _loc8_ = com.ea.util.FakeProfileStats.GetReal(personaId);
      if(_loc8_ != null)
      {
         return com.ea.util.FakeProfileStats.Fill(new com.ea.gameapi.data.ProfileStatistics(),_loc8_.S,personaId);
      }
      var _loc3_ = com.ea.util.FakeProfileStats;
      var _loc4_ = _loc3_.FixLevel(level);
      _loc3_.Seed(personaId,1);
      var _loc5_ = new com.ea.gameapi.data.ProfileStatistics();
      _loc5_.personaId = personaId;
      _loc5_.singlePlayerTotalRaces = 15 + _loc4_ * 8 + _loc3_.Range(0,_loc4_ * 4);
      _loc5_.singlePlayerEventsWon = Math.floor(_loc5_.singlePlayerTotalRaces * _loc3_.Range(40,75) / 100);
      _loc5_.singlePlayerEventsLost = _loc5_.singlePlayerTotalRaces - _loc5_.singlePlayerEventsWon;
      _loc5_.singlePlayerEventWinPercentage = Math.round(_loc5_.singlePlayerEventsWon * 100 / _loc5_.singlePlayerTotalRaces);
      _loc5_.singlePlayerEventWinStreak = _loc3_.Range(3,12);
      _loc5_.singlePlayerAvgPlacing = 1 + _loc3_.Range(30,180) / 100;
      _loc5_.singlePlayerMoneyWon = _loc5_.singlePlayerTotalRaces * _loc3_.Range(900,2600);
      _loc5_.rankedTotalRaces = 5 + _loc4_ * 4 + _loc3_.Range(0,_loc4_ * 3);
      _loc5_.totalRankedEvents = _loc5_.rankedTotalRaces;
      _loc5_.rankedWins = Math.floor(_loc5_.rankedTotalRaces * _loc3_.Range(20,60) / 100);
      _loc5_.rankedDNFCount = _loc3_.Range(0,Math.floor(_loc5_.rankedTotalRaces / 15) + 1);
      _loc5_.rankedLosses = _loc5_.rankedTotalRaces - _loc5_.rankedWins - _loc5_.rankedDNFCount;
      if(_loc5_.rankedLosses < 0)
      {
         _loc5_.rankedLosses = 0;
      }
      _loc5_.rankedWinPercentage = Math.round(_loc5_.rankedWins * 100 / _loc5_.rankedTotalRaces);
      _loc5_.rankedAvgPlacing = 1 + _loc3_.Range(80,300) / 100;
      _loc5_.rankedBestWinStreak = _loc3_.Range(2,9);
      _loc5_.rankedWinStreak = _loc3_.Range(0,_loc5_.rankedBestWinStreak);
      _loc5_.rankedMoneyWon = _loc5_.rankedTotalRaces * _loc3_.Range(1500,4000);
      _loc5_.overallTotalRaces = _loc5_.singlePlayerTotalRaces + _loc5_.rankedTotalRaces;
      _loc5_.totalRacesWon = _loc5_.singlePlayerEventsWon + _loc5_.rankedWins;
      _loc5_.totalRacesLost = _loc5_.overallTotalRaces - _loc5_.totalRacesWon;
      _loc5_.totalWinPercentage = Math.round(_loc5_.totalRacesWon * 100 / _loc5_.overallTotalRaces);
      _loc5_.bestWinStreak = Math.max(_loc5_.singlePlayerEventWinStreak,_loc5_.rankedBestWinStreak);
      _loc5_.overallWinningStreak = _loc5_.bestWinStreak;
      _loc5_.overallDNFCount = _loc5_.rankedDNFCount;
      _loc5_.averagePlacing = Math.round((_loc5_.singlePlayerAvgPlacing * _loc5_.singlePlayerTotalRaces + _loc5_.rankedAvgPlacing * _loc5_.rankedTotalRaces) / _loc5_.overallTotalRaces * 100) / 100;
      _loc5_.totalMoneyWon = _loc5_.singlePlayerMoneyWon + _loc5_.rankedMoneyWon;
      _loc5_.totalCarsOwned = _loc3_.Range(2,6) + Math.floor(_loc4_ / 10);
      _loc5_.disconnectPercentage = _loc3_.Range(0,3);
      _loc5_.DNFPercentage = Math.round(_loc5_.overallDNFCount * 100 / _loc5_.overallTotalRaces);
      _loc5_.numberOfPlayerCarCollisions = _loc5_.overallTotalRaces * _loc3_.Range(2,9);
      _loc5_.numberOfPowerupsUsed = _loc5_.overallTotalRaces * _loc3_.Range(1,4);
      _loc5_.perfectStartNumSuccess = Math.floor(_loc5_.overallTotalRaces * _loc3_.Range(30,70) / 100);
      _loc5_.perfectStartNumFail = _loc5_.overallTotalRaces - _loc5_.perfectStartNumSuccess;
      _loc5_.numberOfDuels = _loc3_.Range(5,20) + _loc4_;
      _loc5_.numberOfHonorChallenges = _loc3_.Range(0,Math.floor(_loc5_.numberOfDuels / 3));
      _loc5_.numberOfHonorWins = _loc3_.Range(0,_loc5_.numberOfHonorChallenges);
      return _loc5_;
   }
   static function MakePursuit(personaId, level)
   {
      var _loc8_ = com.ea.util.FakeProfileStats.GetReal(personaId);
      if(_loc8_ != null)
      {
         return com.ea.util.FakeProfileStats.Fill(new com.ea.gameapi.data.ProfilePursuitStats(),_loc8_.P,personaId);
      }
      var _loc3_ = com.ea.util.FakeProfileStats;
      var _loc4_ = _loc3_.FixLevel(level);
      _loc3_.Seed(personaId,2);
      var _loc5_ = new com.ea.gameapi.data.ProfilePursuitStats();
      _loc5_.personaId = personaId;
      _loc5_.singlePursuitCount = 10 + _loc4_ * 3 + _loc3_.Range(0,_loc4_ * 2);
      _loc5_.coopPursuitCount = _loc3_.Range(2,8) + Math.floor(_loc4_ / 2);
      _loc5_.PursuitCount = _loc5_.singlePursuitCount;
      _loc5_.overallPursuitCount = _loc5_.singlePursuitCount + _loc5_.coopPursuitCount;
      _loc5_.singlePursuitEvadeCount = Math.floor(_loc5_.singlePursuitCount * _loc3_.Range(50,85) / 100);
      _loc5_.coopPursuitEvadeCount = Math.floor(_loc5_.coopPursuitCount * _loc3_.Range(40,80) / 100);
      _loc5_.pursuitEvadeCount = _loc5_.singlePursuitEvadeCount + _loc5_.coopPursuitEvadeCount;
      _loc5_.bustedCount = _loc5_.overallPursuitCount - _loc5_.pursuitEvadeCount;
      _loc5_.pursuitAverageEvaded = Math.round(_loc5_.pursuitEvadeCount * 100 / _loc5_.overallPursuitCount);
      var _loc6_ = _loc3_.Range(420,1500) + _loc3_.Range(0,99) / 100;
      var _loc7_ = _loc3_.Range(25,90) + _loc3_.Range(0,99) / 100;
      _loc5_.longestPursuit = _loc3_.Time(_loc6_);
      _loc5_.shortestPursuit = _loc3_.Time(_loc7_);
      _loc5_.cooplongestPursuit = _loc3_.Time(_loc3_.Range(300,1100) + _loc3_.Range(0,99) / 100);
      _loc5_.overallLongestPursuit = _loc5_.longestPursuit;
      _loc5_.overallShortestPursuit = _loc5_.shortestPursuit;
      _loc5_.copsDisabledSingle = _loc3_.Range(4,25);
      _loc5_.copsDisabledTotal = _loc5_.copsDisabledSingle * _loc3_.Range(8,20);
      _loc5_.copsRammedSingle = _loc3_.Range(10,60);
      _loc5_.copsRammedTotal = _loc5_.copsRammedSingle * _loc3_.Range(8,20);
      _loc5_.spikeStripDodgedSingle = _loc3_.Range(1,8);
      _loc5_.spikeStripDodgedTotal = _loc5_.spikeStripDodgedSingle * _loc3_.Range(5,15);
      _loc5_.roadBlocksDodgedSingle = _loc3_.Range(1,10);
      _loc5_.roadBlocksDodgedTotal = _loc5_.roadBlocksDodgedSingle * _loc3_.Range(5,15);
      _loc5_.infractionsSingle = _loc3_.Range(3,9);
      _loc5_.infractionsTotal = _loc5_.infractionsSingle * _loc5_.overallPursuitCount;
      _loc5_.costToStateSingle = _loc3_.Range(80,600) * 1000;
      _loc5_.costToStateTotal = _loc5_.costToStateSingle * _loc3_.Range(10,40);
      _loc5_.coopCostToStateTotal = Math.floor(_loc5_.costToStateTotal / _loc3_.Range(3,6));
      _loc5_.overallCostToStateTotal = _loc5_.costToStateTotal + _loc5_.coopCostToStateTotal;
      _loc5_.bountySingle = _loc3_.Range(50,400) * 1000;
      _loc5_.bountyTotal = _loc5_.bountySingle * _loc3_.Range(10,40);
      _loc5_.coopBountyTotal = Math.floor(_loc5_.bountyTotal / _loc3_.Range(3,6));
      _loc5_.overallBountySingle = _loc5_.bountySingle;
      _loc5_.overallBountyTotal = _loc5_.bountyTotal + _loc5_.coopBountyTotal;
      _loc5_.highestClockedSpeed = _loc3_.Range(260,340);
      _loc5_.totalClockedSpeed = _loc5_.highestClockedSpeed * _loc3_.Range(20,60);
      _loc5_.highestHeat = String(_loc3_.Range(3,5));
      _loc5_.singleCopsDeployed = _loc3_.Range(15,70);
      _loc5_.coopCopsDeployed = _loc3_.Range(10,50);
      _loc5_.overallCopsDeployed = _loc5_.singleCopsDeployed + _loc5_.coopCopsDeployed;
      _loc5_.singleCopsEvaded = _loc3_.Range(10,60);
      _loc5_.coopCopsEvaded = _loc3_.Range(5,40);
      _loc5_.overallCopsEvaded = _loc5_.singleCopsEvaded + _loc5_.coopCopsEvaded;
      _loc5_.singleSpikesDodged = _loc5_.spikeStripDodgedSingle;
      _loc5_.coopSpikesDodged = _loc3_.Range(1,6);
      _loc5_.overallSpikesDodged = _loc5_.singleSpikesDodged + _loc5_.coopSpikesDodged;
      _loc5_.singleRoadBlocksDodged = _loc5_.roadBlocksDodgedSingle;
      _loc5_.coopRoadBlocksDodged = _loc3_.Range(1,6);
      _loc5_.overallRoadBlocksDodged = _loc5_.singleRoadBlocksDodged + _loc5_.coopRoadBlocksDodged;
      _loc5_.coopFavoritePartner = "-";
      return _loc5_;
   }
   static function MakeRecords(personaId, level)
   {
      var _loc8_ = com.ea.util.FakeProfileStats.GetReal(personaId);
      if(_loc8_ != null)
      {
         return com.ea.util.FakeProfileStats.Fill(new com.ea.gameapi.data.ProfileRecordStats(),_loc8_.R,personaId);
      }
      var _loc3_ = com.ea.util.FakeProfileStats;
      var _loc4_ = _loc3_.FixLevel(level);
      _loc3_.Seed(personaId,3);
      var _loc5_ = new com.ea.gameapi.data.ProfileRecordStats();
      _loc5_.personaId = personaId;
      var _loc6_ = _loc3_.Range(230,260) + Math.floor(_loc4_ * 1.2);
      _loc5_.bestOverallTopSpeed = _loc3_.Speed(_loc6_);
      _loc5_.bestSinglePlayerTopSpeed = _loc3_.Speed(_loc6_ - _loc3_.Range(0,15));
      _loc5_.bestRankedTopSpeed = _loc3_.Speed(_loc6_ - _loc3_.Range(0,20));
      _loc5_.bestOverallTime = _loc3_.Time(_loc3_.Range(70,140) + _loc3_.Range(0,99) / 100);
      _loc5_.bestOverallLapTime = _loc3_.Time(_loc3_.Range(40,80) + _loc3_.Range(0,99) / 100);
      _loc5_.bestSprintEventTime = _loc5_.bestOverallTime;
      _loc5_.bestSprintEventTopSpeed = _loc6_ - _loc3_.Range(0,10);
      _loc5_.bestSprintEventPlayCount = _loc3_.Range(3,30);
      _loc5_.bestCircuitEventTime = _loc3_.Time(_loc3_.Range(150,300) + _loc3_.Range(0,99) / 100);
      _loc5_.bestCircuitEventLapTime = _loc5_.bestOverallLapTime;
      _loc5_.bestCircuitEventTopSpeed = _loc6_ - _loc3_.Range(0,15);
      _loc5_.bestCircuitEventPlayCount = _loc3_.Range(3,30);
      _loc5_.bestSpeedTrapEventTopSpeed = _loc6_ - _loc3_.Range(0,5);
      _loc5_.bestSpeedTrapEventCumulativeSpeed = _loc5_.bestSpeedTrapEventTopSpeed * _loc3_.Range(3,6);
      _loc5_.bestSpeedTrapEventScore = _loc5_.bestSpeedTrapEventCumulativeSpeed;
      _loc5_.bestSpeedTrapEventPlayCount = _loc3_.Range(1,15);
      _loc5_.bestCheckpointEventTime = _loc3_.Time(_loc3_.Range(90,200) + _loc3_.Range(0,99) / 100);
      _loc5_.bestCheckpointEventTopSpeed = _loc6_ - _loc3_.Range(0,15);
      _loc5_.bestCheckpointEventPlayCount = _loc3_.Range(1,15);
      _loc5_.bestDriftEventScore = _loc3_.Range(20000,120000);
      _loc5_.bestDriftEventLapScore = Math.floor(_loc5_.bestDriftEventScore / _loc3_.Range(2,4));
      _loc5_.bestDriftEventChainScore = Math.floor(_loc5_.bestDriftEventLapScore / _loc3_.Range(2,4));
      _loc5_.bestDriftEventLength = _loc3_.Range(200,1500);
      _loc5_.bestDriftEventTopSpeed = _loc3_.Range(120,190);
      _loc5_.bestDriftEventPlayCount = _loc3_.Range(0,10);
      _loc5_.bestCanyonEventScore = _loc3_.Range(10000,90000);
      _loc5_.bestCanyonEventLapTime = _loc3_.Time(_loc3_.Range(60,120) + _loc3_.Range(0,99) / 100);
      _loc5_.bestCanyonEventKOWins = _loc3_.Range(0,5);
      _loc5_.bestCanyonEventWins = _loc3_.Range(0,10);
      _loc5_.bestCanyonEventPlayCount = _loc3_.Range(0,15);
      return _loc5_;
   }
}
