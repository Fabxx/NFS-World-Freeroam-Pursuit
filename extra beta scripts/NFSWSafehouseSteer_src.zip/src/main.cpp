// NFSWSafehouseSteer.asi
// Steers the front wheels of the safehouse car (like the Asian beta).
//
// NFS World 2015 (nfsw.exe): the new safehouse class (0x656E40) builds the
// wheel matrices in 0x655A10 and reads the steering angle from the global
// float 0xD10CCC, which the game never writes (it is always 0.0, so the
// wheels stay straight).
// This ASI redirects that single read (movss xmm0,[0xD10CCC] at 0x655C00)
// to a float owned by the ASI, so the angle can be set from the .ini file.

#include <windows.h>

static float g_steerAngle = 20.6723f;   // degrees, same value as the Asian beta

static const DWORD kPreferredBase  = 0x00400000;
static const DWORD kInstrVA        = 0x00655C00;   // movss xmm0, dword ptr [imm32]
static const DWORD kOrigGlobalVA   = 0x00D10CCC;   // unused global (always 0)
static const DWORD kRdataConstVA   = 0x00BB5B10;   // 20.6723f (old exe patch)

// --- minimal float parser (no CRT) ------------------------------------------
static float ParseFloat(const char* s, float def)
{
    while (*s == ' ' || *s == '\t') ++s;
    bool neg = false;
    if (*s == '-' || *s == '+') { neg = (*s == '-'); ++s; }
    if ((*s < '0' || *s > '9') && *s != '.' && *s != ',') return def;
    double v = 0.0;
    while (*s >= '0' && *s <= '9') { v = v * 10.0 + (*s - '0'); ++s; }
    if (*s == '.' || *s == ',') {
        ++s;
        double f = 0.1;
        while (*s >= '0' && *s <= '9') { v += (*s - '0') * f; f *= 0.1; ++s; }
    }
    return (float)(neg ? -v : v);
}

static void LoadConfig(HMODULE self, bool& enabled)
{
    char path[MAX_PATH];
    DWORD n = GetModuleFileNameA(self, path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return;
    // replace extension .asi -> .ini
    char* dot = 0;
    for (char* p = path; *p; ++p) if (*p == '.') dot = p;
    if (!dot || (dot - path) + 4 >= MAX_PATH) return;
    dot[1] = 'i'; dot[2] = 'n'; dot[3] = 'i'; dot[4] = 0;

    enabled = GetPrivateProfileIntA("SafehouseSteer", "Enabled", 1, path) != 0;
    char buf[64];
    GetPrivateProfileStringA("SafehouseSteer", "SteerAngle", "20.6723", buf, sizeof(buf), path);
    g_steerAngle = ParseFloat(buf, 20.6723f);
}

static bool Apply()
{
    BYTE* base  = (BYTE*)GetModuleHandleA(NULL);
    DWORD delta = (DWORD)base - kPreferredBase;
    BYTE* instr = (BYTE*)(kInstrVA + delta);

    // check that this is the expected exe: F3 0F 10 05 <imm32>
    if (instr[0] != 0xF3 || instr[1] != 0x0F || instr[2] != 0x10 || instr[3] != 0x05)
        return false;
    DWORD cur = *(DWORD*)(instr + 4);
    if (cur != kOrigGlobalVA + delta && cur != kRdataConstVA + delta)
        return false;   // unknown version: do nothing

    DWORD newAddr = (DWORD)&g_steerAngle;
    DWORD oldProt;
    if (!VirtualProtect(instr + 4, 4, PAGE_EXECUTE_READWRITE, &oldProt))
        return false;
    *(DWORD*)(instr + 4) = newAddr;
    VirtualProtect(instr + 4, 4, oldProt, &oldProt);
    FlushInstructionCache(GetCurrentProcess(), instr, 8);
    return true;
}

extern "C" BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hinst);
        bool enabled = true;
        LoadConfig(hinst, enabled);
        if (enabled) Apply();
    }
    return TRUE;
}
