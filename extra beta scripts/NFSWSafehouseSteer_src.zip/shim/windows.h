// minimal shim for building without the Windows SDK (clang-cl + lld-link)
#pragma once
typedef unsigned long DWORD; typedef int BOOL; typedef unsigned char BYTE; typedef unsigned int UINT;
typedef void* LPVOID; typedef void* HANDLE; typedef struct HINSTANCE__* HINSTANCE; typedef HINSTANCE HMODULE;
typedef const char* LPCSTR; typedef char* LPSTR; typedef unsigned long SIZE_T; typedef DWORD* PDWORD; typedef int INT;
#define WINAPI __stdcall
#define NULL 0
#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define DLL_PROCESS_ATTACH 1
#define PAGE_EXECUTE_READWRITE 0x40
extern "C" {
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(LPCSTR);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HMODULE, LPSTR, DWORD);
__declspec(dllimport) UINT WINAPI GetPrivateProfileIntA(LPCSTR, LPCSTR, INT, LPCSTR);
__declspec(dllimport) DWORD WINAPI GetPrivateProfileStringA(LPCSTR, LPCSTR, LPCSTR, LPSTR, DWORD, LPCSTR);
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, SIZE_T, DWORD, PDWORD);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, const void*, SIZE_T);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess(void);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
}
