NFSWSafehouseSteer.asi - NFS World 2015 (offline)
Front wheels of the safehouse car steered like in the Asian beta.

Installation: copy NFSWSafehouseSteer.asi and NFSWSafehouseSteer.ini into Data\Scripts.
Requires the original (unpatched) nfsw.exe; it also works on the exe that was already patched.

Technical details: the 0x655A10 function (safehouse class 0x656E40) reads the steering angle from
the global float 0xD10CCC, which the game never writes (= 0, straight wheels). The ASI
redirects the movss operand at 0x655C04 to its own float (SteerAngle in the ini).
The exe version is checked before writing.

Build: Visual Studio -> NFSWSafehouseSteer.vcxproj (Release|Win32), or build.sh (LLVM).
