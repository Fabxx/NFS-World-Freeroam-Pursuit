# Converts an MP3 (MPEG-1 Layer III, 44.1 kHz, encoded with -reservoir 0) into an EA SNR/SNS
# stream (codec 6, EALayer3 v2): every MP3 granule is repacked as one EALayer3 v2 frame,
# one MP3 frame (1152 samples) per SNS block. Usage: python3 mp3sns.py in.mp3 out_basename [--noloop]
import sys,struct
BR=[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320]
SRT=[44100,48000,32000]
class BW:
    def __init__(s): s.b=bytearray(); s.acc=0; s.n=0
    def w(s,v,n):
        for i in range(n-1,-1,-1):
            s.acc=(s.acc<<1)|((v>>i)&1); s.n+=1
            if s.n==8: s.b.append(s.acc); s.acc=0; s.n=0
    def align(s):
        while s.n: s.w(0,1)
class BR_:
    def __init__(s,b,pos=0): s.b=b; s.p=pos
    def r(s,n):
        v=0
        for _ in range(n):
            v=(v<<1)|((s.b[s.p>>3]>>(7-(s.p&7)))&1); s.p+=1
        return v
d=open(sys.argv[1],'rb').read()
p=0; frames=[]
while p+4<=len(d):
    h=struct.unpack('>I',d[p:p+4])[0]
    if (h>>21)&0x7ff!=0x7ff: p+=1; continue
    ver=(h>>19)&3; lay=(h>>17)&3; crc=not((h>>16)&1); bri=(h>>12)&15; sri=(h>>10)&3; pad=(h>>9)&1; mode=(h>>6)&3; mext=(h>>4)&3
    assert ver==3 and lay==1 and sri==0
    fl=144000*BR[bri]//SRT[sri]+pad
    ch=1 if mode==3 else 2
    q=p+4+(2 if crc else 0)
    sil=32 if ch==2 else 17
    side=d[q:q+sil]; main=d[q+sil:p+fl]
    frames.append((ver,sri,mode,mext,ch,side,main)); p+=fl
# reservoir
stream=bytearray(); out=[]
for (ver,sri,mode,mext,ch,side,main) in frames:
    r=BR_(side); mdb=r.r(9); r.r(3 if ch==2 else 5)
    scfsi=[r.r(4) for c in range(ch)]
    gi=[[None]*ch for g in range(2)]
    for g in range(2):
        for c in range(ch):
            l=r.r(12); rest_hi=r.r(32); rest_lo=r.r(15)
            gi[g][c]=(l,rest_hi,rest_lo)
    start=len(stream)-mdb; assert start>=0
    stream+=main
    mr=BR_(stream,start*8)
    frs=[]
    for g in range(2):
        bw=BW()
        tot=sum(gi[g][c][0] for c in range(ch))
        # common header
        cw=BW()
        cw.w(3,2); cw.w(sri,2); cw.w(mode,2); cw.w(mext,2); cw.w(g,1)
        if g==1:
            for c in range(ch): cw.w(scfsi[c],4)
        for c in range(ch):
            l,hi,lo=gi[g][c]; cw.w(l,12); cw.w(hi,32); cw.w(lo,15)
        for _ in range(tot): cw.w(mr.r(1),1)
        cw.align()
        size=2+len(cw.b)
        assert size<4096
        bw.w(0,1); bw.w(1 if ch==2 else 0,1); bw.w(0,2); bw.w(size,12)
        frs.append(bytes(bw.b)+bytes(cw.b))
    out.append(b''.join(frs))
    # trim stream memory
    if len(stream)>8192: 
        cut=len(stream)-4096; stream=stream[cut:]
sns=bytearray()
for i,f in enumerate(out):
    flag=0x80 if i==len(out)-1 else 0
    sz=8+len(f)
    sns+=bytes([flag])+sz.to_bytes(3,'big')+struct.pack('>I',1152)+f
ns=len(out)*1152
open(sys.argv[2]+'.sns','wb').write(sns)
loop='--noloop' not in sys.argv
if loop:
    snr=bytes([0x06,0x04])+struct.pack('>H',44100)+struct.pack('>I',(0x60<<24)|ns)+struct.pack('>I',0)+struct.pack('>I',0)
else:
    snr=bytes([0x06,0x04])+struct.pack('>H',44100)+struct.pack('>I',(0x40<<24)|ns)
open(sys.argv[2]+'.snr','wb').write(snr)
print(len(out),'frames',ns,'samples',ns/44100,'s',len(sns),'bytes')
