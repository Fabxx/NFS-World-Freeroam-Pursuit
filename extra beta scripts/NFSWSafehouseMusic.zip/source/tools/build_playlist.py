# Builds the playlist WAV: World safehouse original + Carbon menu themes A, D (muscle), C,
# each ending with an 8 s fade-out and 1.5 s of silence; the whole cycle is written twice
# so the ASI can start the stream at any track and still read a full cycle forward.
import numpy as np, wave, json
from scipy.signal import resample_poly
SR=44100; FADE=8.0; GAP=1.5
def rdw(f):
    w=wave.open(f); return np.frombuffer(w.readframes(w.getnframes()),'<i2').reshape(-1,2).astype(np.float32)/32768
def fin(x):
    n=int(FADE*SR); t=np.linspace(0,1,n,dtype=np.float32); x=x.copy(); x[-n:]*=(np.cos(t*np.pi)*0.5+0.5)[:,None]
    m=int(0.03*SR); x[:m]*=np.linspace(0,1,m,dtype=np.float32)[:,None]; return x
T={'O':fin(rdw('orig.wav'))}
for k,reps in (('A',1.5),('D',2.5),('C',1.5)):
    intro,body=np.load(k+'_intro.npy'),np.load(k+'_body.npy')
    parts=[intro]+[body]*int(reps)+([body[:len(body)//2]] if reps%1 else [])
    x=resample_poly(np.concatenate(parts),49,40,axis=0).astype(np.float32)
    x*=0.19/np.sqrt((x**2).mean()); T[k]=fin(x)
gap=np.zeros((int(GAP*SR),2),np.float32)
seq=[];starts=[];pos=0
for k in 'OADC':
    seq.append(gap if k!='O' else np.zeros((0,2),np.float32))
    pos+=len(seq[-1]); starts.append(pos); seq.append(T[k]); pos+=len(T[k])
seq.append(gap); S=np.concatenate(seq)
pad=(-len(S))%1152; S=np.concatenate([S,np.zeros((pad,2),np.float32)])
y=np.concatenate([S,S])
th=0.89; a=np.abs(y); ov=a>th; y[ov]=np.sign(y[ov])*(th+(1-th)*np.tanh((a[ov]-th)/(1-th))); y=np.clip(y,-0.999,0.999)
w=wave.open('cyc.wav','wb');w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((y*32767).astype('<i2').tobytes());w.close()
json.dump(dict(starts=starts,L=len(S),durs={k:len(T[k])/SR for k in T}),open('cyc.json','w'))
print(starts,len(S)/SR,{k:round(len(T[k])/SR,1) for k in T})
