// NFSWSafehouseMusic.asi - random track every time the safehouse music starts.
// Sound\Music\Carbon_SH.sns holds the playlist (World original + 3 Carbon themes)
// written twice in a row. The game opens the stream only once per session and, on
// every safehouse entry / loop, seeks back to offset 0: this ASI remaps that offset 0
// to the start of a random track (offset table in NFSWSafehouseMusic.ini); all later
// reads simply continue forward from there.
#include <windows.h>
typedef HANDLE (WINAPI *CFA)(LPCSTR, DWORD, DWORD, LPVOID, DWORD, DWORD, HANDLE);
typedef HANDLE (WINAPI *CFW)(LPCWSTR, DWORD, DWORD, LPVOID, DWORD, DWORD, HANDLE);
typedef BOOL (WINAPI *RF)(HANDLE, LPVOID, DWORD, LPDWORD, LPOVERLAPPED);
typedef DWORD (WINAPI *SFP)(HANDLE, long, long*, DWORD);
typedef BOOL (WINAPI *SFPX)(HANDLE, long long, long long*, DWORD);
typedef BOOL (WINAPI *CH)(HANDLE);
static CFA oCFA; static CFW oCFW; static RF oRF; static SFP oSFP; static SFPX oSFPX; static CH oCH;
static HANDLE gH=0; static long long gP[16]; static int gCount=0, gK=0, gLast=-1, gLog=0, gForce=-1;
static DWORD gPickT=0; static unsigned gRng=1;
static char gLogPath[300], gIni[300], gWin[300]; static int gWinLen=0;

static int slen(const char* s){int n=0;while(s[n])n++;return n;}
static int wlen(const wchar_t* s){int n=0;while(s[n])n++;return n;}
static char lc(char c){return (c>='A'&&c<='Z')?c+32:c;}
static void scat(char* d,const char* s){d+=slen(d);while((*d++=*s++));}
static void itoa_(long long vv,char* o){char t[24];int i=0;if(vv<0){*o++='-';vv=-vv;}unsigned long v=(unsigned long)vv;do{t[i++]=(char)('0'+v%10);v/=10;}while(v);while(i)*o++=t[--i];*o=0;}
static long long atoll_(const char* s){long long v=0;while(*s>='0'&&*s<='9')v=v*10+(*s++-'0');return v;}
static void logs(const char* m){
    if(!gLog) return;
    HANDLE h=CreateFileA(gLogPath,4,1,0,4,0x80,0); if(h==INVALID_HANDLE_VALUE)return;
    DWORD w; WriteFile(h,m,slen(m),&w,0); WriteFile(h,"\r\n",2,&w,0); CloseHandle(h);
}
static void log2(const char* a,long long v){char m[200];m[0]=0;scat(m,a);char n[24];itoa_(v,n);scat(m,n);logs(m);}
static unsigned rnd(){ gRng^=gRng<<13; gRng^=gRng>>17; gRng^=gRng<<5; return gRng; }
static void pick(const char* why){
    DWORD now=GetTickCount();
    if(gPickT && now-gPickT<2000) return;   // ignore repeated picks within 2 s
    gPickT=now;
    int k=(int)(rnd()%gCount);
    if(gCount>1 && k==gLast) k=(k+1+(int)(rnd()%(gCount-1)))%gCount;
    if(gForce>=0 && gForce<gCount) k=gForce;
    gK=k; gLast=k;
    char v[4]={(char)('0'+k),0}; WritePrivateProfileStringA("Main","Last",v,gIni);
    char m[80]="picked track "; char n[4]={(char)('0'+k),0}; scat(m,n); scat(m," ("); scat(m,why); scat(m,")"); logs(m);
}
// true if the path ends with Carbon_SH.sns (case-insensitive)
template<class C> static int isSns(const C* p){
    int n=0; while(p[n]) n++;
    const char* key="carbon_sh.sns"; if(n<13) return 0;
    const C* t=p+n-13; if(n>13){ C b=t[-1]; if(b!='\\'&&b!='/'&&b!=':') return 0; }
    for(int i=0;i<13;i++) if(lc((char)t[i])!=key[i]) return 0;
    return 1;
}
// called when the game opens Carbon_SH.sns: pick a track and position the file there
static void opened(HANDLE h){
    if(h==INVALID_HANDLE_VALUE||!gCount) return;
    gH=h; gPickT=0; pick("open");
    long hi=(long)(gP[gK]>>32); oSFP(h,(long)(gP[gK]&0xffffffff),&hi,0);
}
static HANDLE WINAPI hCFA(LPCSTR f, DWORD a, DWORD s, LPVOID sa, DWORD c, DWORD fl, HANDLE t){
    HANDLE h=oCFA(f,a,s,sa,c,fl,t); if(f&&isSns(f)){ logs("opened Carbon_SH.sns (A)"); opened(h);} return h; }
static HANDLE WINAPI hCFW(LPCWSTR f, DWORD a, DWORD s, LPVOID sa, DWORD c, DWORD fl, HANDLE t){
    HANDLE h=oCFW(f,a,s,sa,c,fl,t); if(f&&isSns(f)){ logs("opened Carbon_SH.sns (W)"); opened(h);} return h; }
static int gRdLog=0;
// ReadFile: overlapped reads carry their own offset, translate it (virtual -> physical)
static BOOL WINAPI hRF(HANDLE h, LPVOID b, DWORD n, LPDWORD r, LPOVERLAPPED ov){
    if(h && h==gH && ov){
        long long off=((long long)ov->OffsetHigh<<32)|ov->Offset;
        if(off==0) pick("read at offset 0");
        if(gRdLog<6){ gRdLog++; log2("ReadFile overlapped offset=",off); }
        long long ph=off+gP[gK]; DWORD o0=ov->Offset,o1=ov->OffsetHigh;
        ov->Offset=(DWORD)ph; ov->OffsetHigh=(DWORD)(ph>>32);
        BOOL ok=oRF(h,b,n,r,ov); ov->Offset=o0; ov->OffsetHigh=o1; return ok;
    }
    if(h && h==gH && gRdLog<6){ gRdLog++; logs("ReadFile synchronous"); }
    return oRF(h,b,n,r,ov);
}
// SetFilePointer: a seek to 0 means "music (re)starts" -> new random track
static DWORD WINAPI hSFP(HANDLE h, long d, long* hi, DWORD m){
    if(h && h==gH){
        long long v=((long long)(hi?*hi:(d<0?-1:0))<<32)|(DWORD)d;
        long long ph;
        if(m==0){ if(v==0) pick("seek to 0"); ph=v+gP[gK]; long H=(long)(ph>>32); DWORD L=oSFP(h,(long)(DWORD)ph,&H,0);
            ph=((long long)H<<32)|L; }
        else { long H=hi?*hi:0; DWORD L=oSFP(h,d,hi?&H:0,m); ph=((long long)(hi?H:0)<<32)|L; if(!hi){ long H2=0; DWORD L2=oSFP(h,0,&H2,1); ph=((long long)H2<<32)|L2; } }
        long long vv=ph-gP[gK]; if(hi) *hi=(long)(vv>>32);
        if(gRdLog<6){ gRdLog++; log2("SetFilePointer virtual=",vv); }
        return (DWORD)vv;
    }
    return oSFP(h,d,hi,m);
}
static BOOL WINAPI hSFPX(HANDLE h, long long d, long long* np, DWORD m){
    if(h && h==gH){
        long long ph; BOOL ok;
        if(m==0){ if(d==0) pick("seek to 0"); ok=oSFPX(h,d+gP[gK],&ph,0); }
        else ok=oSFPX(h,d,&ph,m);
        if(np) *np=ph-gP[gK];
        if(gRdLog<6){ gRdLog++; log2("SetFilePointerEx virtual=",ph-gP[gK]); }
        return ok;
    }
    return oSFPX(h,d,np,m);
}
static BOOL WINAPI hCH(HANDLE h){ if(h && h==gH){ gH=0; logs("closed Carbon_SH.sns"); } return oCH(h); }

static int eqn(const char* a,const char* b){ while(*b){ if(*a!=*b) return 0; a++; b++; } return *a==0; }
// redirect the kernel32 file functions in a module's import table to our hooks
static void patchIAT(BYTE* base){
    if(!base || *(WORD*)base!=0x5A4D) return;
    DWORD pe=*(DWORD*)(base+0x3c);
    DWORD irva=*(DWORD*)(base+pe+0x80); if(!irva) return;
    for(DWORD* d=(DWORD*)(base+irva); d[3]; d+=5){
        void** iat=(void**)(base+d[4]);
        DWORD* nt=d[0]?(DWORD*)(base+d[0]):0; if(!nt) continue;
        for(int i=0;iat[i];i++){
            if(nt[i]&0x80000000) continue;
            const char* nm=(const char*)(base+nt[i]+2);
            void* hk=0;
            if(eqn(nm,"CreateFileA")) hk=(void*)hCFA; else if(eqn(nm,"CreateFileW")) hk=(void*)hCFW;
            else if(eqn(nm,"ReadFile")) hk=(void*)hRF; else if(eqn(nm,"SetFilePointer")) hk=(void*)hSFP;
            else if(eqn(nm,"SetFilePointerEx")) hk=(void*)hSFPX; else if(eqn(nm,"CloseHandle")) hk=(void*)hCH;
            if(!hk || iat[i]==hk) continue;
            DWORD o; VirtualProtect(&iat[i],4,PAGE_READWRITE,&o); iat[i]=hk; VirtualProtect(&iat[i],4,o,&o);
        }
    }
}
extern "C" unsigned long __readfsdword(unsigned long);
extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID){
    if(r!=DLL_PROCESS_ATTACH) return 1;
    DisableThreadLibraryCalls(h);
    HMODULE k32=GetModuleHandleA("kernel32.dll");
    oCFA=(CFA)GetProcAddress(k32,"CreateFileA"); oCFW=(CFW)GetProcAddress(k32,"CreateFileW");
    oRF=(RF)GetProcAddress(k32,"ReadFile"); oSFP=(SFP)GetProcAddress(k32,"SetFilePointer");
    oSFPX=(SFPX)GetProcAddress(k32,"SetFilePointerEx"); oCH=(CH)GetProcAddress(k32,"CloseHandle");
    char p[300]; GetModuleFileNameA(h,p,260);
    int n=slen(p); while(n>0&&p[n-1]!='.') n--; p[n]=0;
    for(int i=0;i<=n;i++){gIni[i]=p[i];gLogPath[i]=p[i];}
    scat(gIni,"ini"); scat(gLogPath,"log");
    gLog=GetPrivateProfileIntA("Main","Log",0,gIni);
    gForce=(int)GetPrivateProfileIntA("Main","Track",-1,gIni);
    gLast=(int)GetPrivateProfileIntA("Main","Last",-1,gIni);
    if(gLog){ HANDLE f=oCFA(gLogPath,0x40000000,1,0,2,0x80,0); if(f!=INVALID_HANDLE_VALUE) oCH(f); }
    gCount=(int)GetPrivateProfileIntA("Tracks","Count",0,gIni); if(gCount>16) gCount=16;
    for(int i=0;i<gCount;i++){ char key[4]={'P',(char)('0'+i),0}; if(i>=10){key[1]='1';key[2]=(char)('0'+i-10);key[3]=0;}
        char v[32]; GetPrivateProfileStringA("Tracks",key,"0",v,32,gIni); gP[i]=atoll_(v); }
    long long c=0; QueryPerformanceCounter(&c); gRng=(unsigned)c^GetTickCount()^0x9e3779b9u; if(!gRng) gRng=1;
    log2("tracks: ",gCount);
    gWinLen=(int)GetWindowsDirectoryA(gWin,260); if(gWinLen>0 && gWin[gWinLen-1]=='\\') gWinLen--;
    // walk every loaded module (PEB loader list) except system DLLs under the Windows folder
    BYTE* peb=(BYTE*)__readfsdword(0x30);
    BYTE* ldr=*(BYTE**)(peb+0x0C);
    BYTE* head=ldr+0x0C; BYTE* e=*(BYTE**)head; int nmod=0, nh=0;
    while(e && e!=head && nmod<512){
        BYTE* base=*(BYTE**)(e+0x18);
        const wchar_t* fn=*(const wchar_t**)(e+0x28); int sys=0;
        if(fn && gWinLen>0){ int j=0; while(j<gWinLen && fn[j] && lc((char)fn[j])==lc(gWin[j])) j++; if(j==gWinLen && (fn[j]=='\\'||fn[j]=='/')) sys=1; }
        if(base && base!=(BYTE*)h && !sys){ patchIAT(base); nh++; }
        e=*(BYTE**)e; nmod++;
    }
    log2("hooked modules: ",nh);
    return 1;
}
