NFSWSafehouseMusic - random safehouse music for NFS World Offline
=================================================================

Install
-------
- Scripts\NFSWSafehouseMusic.asi + .ini  -> gamedata\Scripts\
- Sound\Music\Carbon_SH.snr / Carbon_SH.sns (playlist) -> gamedata\Sound\Music\
- GLOBAL\attributes.bin -> gamedata\GLOBAL\ (back up yours first): the "safehouse"
  rwac_music entry points to "Carbon_SH.snr" instead of "Safehouse.snr"
  (the original safehouse.snr/.sns files are not modified)
Copy the contents of release\ into gamedata\.

How it works
------------
The game opens the safehouse music stream once per session and seeks back to
offset 0 every time the music (re)starts. The ASI hooks CreateFile / ReadFile /
SetFilePointer(Ex) / CloseHandle in the import tables of every non-system module,
and when Carbon_SH.sns is read or seeked at offset 0 it picks a random track
(never the same as the previous one) and shifts all offsets by the start of that
track ([Tracks] P0..Pn in the ini). Carbon_SH.sns contains the playlist twice, so
a full cycle can always be read forward from any starting track.

Build (Linux, LLVM 18, no Windows SDK)
--------------------------------------
  sh build.sh     -> build/NFSWSafehouseMusic.asi

Audio tools (tools/)
--------------------
  build_playlist.py  builds the playlist WAV (cyc.wav) from the decoded tracks
  mp3sns.py          converts MP3 (libmp3lame, -reservoir 0) to EA SNR/SNS EALayer3 v2
  The track offsets (P1..P3) are the SNS byte offsets of the first block inside the
  silence before each track.
