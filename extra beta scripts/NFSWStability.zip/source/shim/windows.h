// dichiarazioni Windows minime (build senza Windows SDK: clang-cl + lld-link)
#pragma once
typedef unsigned long DWORD; typedef int BOOL; typedef unsigned char BYTE; typedef unsigned short WORD; typedef unsigned int UINT;
typedef int INT; typedef long LONG; typedef void* LPVOID; typedef void* HANDLE; typedef struct HINSTANCE__* HINSTANCE;
typedef HINSTANCE HMODULE; typedef const char* LPCSTR; typedef char* LPSTR; typedef unsigned long SIZE_T; typedef unsigned int size_t;
typedef DWORD* PDWORD; typedef DWORD* LPDWORD; typedef const void* LPCVOID; typedef unsigned int UINT_PTR; typedef unsigned short wchar16;
#define WINAPI __stdcall
#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define DLL_PROCESS_ATTACH 1
#define PAGE_READWRITE 0x04
#define GENERIC_WRITE 0x40000000
#define FILE_SHARE_READ 1
#define FILE_SHARE_WRITE 2
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
#define MOVEFILE_REPLACE_EXISTING 1
struct EXCEPTION_RECORD { DWORD ExceptionCode, ExceptionFlags; EXCEPTION_RECORD* ExceptionRecord; void* ExceptionAddress; DWORD NumberParameters; UINT_PTR ExceptionInformation[15]; };
struct CONTEXT { DWORD ContextFlags; DWORD Dr[6]; BYTE FloatSave[112]; DWORD SegGs, SegFs, SegEs, SegDs, Edi, Esi, Ebx, Edx, Ecx, Eax, Ebp, Eip, SegCs, EFlags, Esp, SegSs; BYTE Ext[512]; };
struct EXCEPTION_POINTERS { EXCEPTION_RECORD* ExceptionRecord; CONTEXT* ContextRecord; };
typedef LONG (WINAPI* PVECTORED_EXCEPTION_HANDLER)(EXCEPTION_POINTERS*);
typedef LONG (WINAPI* LPTOP_LEVEL_EXCEPTION_FILTER)(EXCEPTION_POINTERS*);
typedef DWORD (WINAPI* LPTHREAD_START_ROUTINE)(LPVOID);
struct THREADENTRY32 { DWORD dwSize, cntUsage, th32ThreadID, th32OwnerProcessID; LONG tpBasePri, tpDeltaPri; DWORD dwFlags; };
struct MODULEINFO { LPVOID lpBaseOfDll; DWORD SizeOfImage; LPVOID EntryPoint; };
struct SYSTEMTIME { WORD wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds; };
#define CONTEXT_FULL_X86 0x10007
extern "C" {
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(LPCSTR);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HMODULE, LPSTR, DWORD);
__declspec(dllimport) UINT WINAPI GetPrivateProfileIntA(LPCSTR, LPCSTR, INT, LPCSTR);
__declspec(dllimport) HANDLE WINAPI CreateFileA(LPCSTR, DWORD, DWORD, LPVOID, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE, LPCVOID, DWORD, LPDWORD, LPVOID);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI MoveFileExA(LPCSTR, LPCSTR, DWORD);
__declspec(dllimport) DWORD WINAPI GetTickCount(void);
__declspec(dllimport) DWORD WINAPI GetCurrentThreadId(void);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess(void);
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, SIZE_T, DWORD, PDWORD);
__declspec(dllimport) BOOL WINAPI IsBadReadPtr(const void*, UINT_PTR);
__declspec(dllimport) HANDLE WINAPI CreateThread(LPVOID, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD);
__declspec(dllimport) void WINAPI Sleep(DWORD);
__declspec(dllimport) HANDLE WINAPI OpenThread(DWORD, BOOL, DWORD);
__declspec(dllimport) DWORD WINAPI SuspendThread(HANDLE);
__declspec(dllimport) DWORD WINAPI ResumeThread(HANDLE);
__declspec(dllimport) BOOL WINAPI GetThreadContext(HANDLE, CONTEXT*);
__declspec(dllimport) LPVOID WINAPI AddVectoredExceptionHandler(DWORD, PVECTORED_EXCEPTION_HANDLER);
__declspec(dllimport) LPTOP_LEVEL_EXCEPTION_FILTER WINAPI SetUnhandledExceptionFilter(LPTOP_LEVEL_EXCEPTION_FILTER);
__declspec(dllimport) HMODULE WINAPI LoadLibraryA(LPCSTR);
__declspec(dllimport) void* WINAPI GetProcAddress(HMODULE, LPCSTR);
__declspec(dllimport) HANDLE WINAPI CreateToolhelp32Snapshot(DWORD, DWORD);
__declspec(dllimport) BOOL WINAPI Thread32First(HANDLE, THREADENTRY32*);
__declspec(dllimport) BOOL WINAPI Thread32Next(HANDLE, THREADENTRY32*);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
__declspec(dllimport) BOOL WINAPI K32EnumProcessModules(HANDLE, HMODULE*, DWORD, LPDWORD);
__declspec(dllimport) BOOL WINAPI K32GetModuleInformation(HANDLE, HMODULE, MODULEINFO*, DWORD);
__declspec(dllimport) DWORD WINAPI K32GetModuleBaseNameA(HANDLE, HMODULE, LPSTR, DWORD);
__declspec(dllimport) void WINAPI GetLocalTime(SYSTEMTIME*);
__declspec(dllimport) BOOL WINAPI FlushFileBuffers(HANDLE);
__declspec(dllimport) DWORD WINAPI GetLastError(void);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, LPCVOID, SIZE_T);
__declspec(dllimport) void WINAPI SetLastError(DWORD);
}
