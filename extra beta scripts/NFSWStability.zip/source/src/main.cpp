// NFSWStability.asi - correzioni di stabilita' per NFS World 2015 (offline)
//
// 1) Crash alla disconnessione della chat (ChatDisconnectMsg)
//    Quando la connessione XMPP della chat con il server cade, il gioco riceve ChatDisconnectMsg e il suo gestore
//    (nfsw.exe 0x46AE10 -> 0x469C20) chiama un metodo C# (EASharp, gameplay.native.dll) sull'oggetto della
//    schermata corrente. Se in quel momento la schermata sta cambiando (caricamento di una gara, uscita dal
//    safehouse...) l'oggetto C# non e' piu' valido: il runtime EASharp lo verifica (0x984010) e si ferma con
//    int3 -> crash (NFSCrashDump con eccezione 80000003 a nfsw 0x984048).
//    Nel gioco offline la chat e' solo locale: il gestore viene sostituito e la disconnessione viene solo
//    registrata nel log. Il resto del gioco (chat compresa) funziona come prima.
//
// 2) Crash del suono dell'auto all'avvio di una gara (AV in nfsw 0x983EC6 / 0x98416B, stack 0x8638C0 <- 0x863D10)
//    La "connessione audio" di ogni auto (CarSoundConn, 0x861420) legge alla creazione i puntatori alle
//    interfacce ITransmission / IEngine / ISuspension dell'auto (+0x118/+0x11C/+0x120) e li riusa ad ogni
//    aggiornamento. Quando parte un evento il gioco ricrea alcuni componenti C# dell'auto: la connessione
//    audio continua a chiamare il componente vecchio, gia' liberato, e il gioco crasha (la memoria
//    dell'oggetto C# e' gia' stata riusata per altro). Ad ogni aggiornamento le tre interfacce vengono
//    rilette dall'auto (stessa QueryInterface della creazione); se una manca, quel fotogramma del suono
//    viene saltato.
#include <windows.h>

static const DWORD kBase              = 0x00400000;
static const DWORD kChatDisconnectFn  = 0x0046AE10; // void __thiscall (this, a2, a3), ret 8
static const DWORD kFsm               = 0x00CE62CC;
static const DWORD kSoundUpdateSite   = 0x00863D1B; // call CarSoundConn::Update (sub_8638C0) in sub_863D10
static const DWORD kSoundUpdateFn     = 0x008638C0; // void __thiscall (this, a2), ret 4
static const DWORD kQueryInterface    = 0x007536B0; // void* __thiscall (list, keyFn), ret 4
static const DWORD kKeyTransmission   = 0x0065D2D0; // "ITransmission"
static const DWORD kKeyEngine         = 0x0065D2F0; // "IEngine"
static const DWORD kKeySuspension     = 0x00684110; // "ISuspension"
static const unsigned char kChatDisconnectBytes[] = { 0x80, 0x79, 0x0C, 0x00, 0x75, 0x1F, 0xC6, 0x41, 0x0C, 0x01 };

static DWORD g_delta;
static char g_log[MAX_PATH];
static bool g_logOn = true;

static int StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); if (n < cap) StrCpy(d + n, s, cap - n); }
static void UToStr(unsigned v, char* out, int width) { char t[16]; int n = 0; do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v); while (n < width) t[n++] = '0'; int i = 0; while (n) out[i++] = t[--n]; out[i] = 0; }
static DWORD A(DWORD va) { return va + g_delta; }

static void Log(const char* a, const char* b = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, 0x0004 /*FILE_APPEND_DATA*/, FILE_SHARE_READ, 0, 4 /*OPEN_ALWAYS*/, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME t; GetLocalTime(&t);
    char ts[32] = "["; char n[8];
    UToStr(t.wHour, n, 2); StrCat(ts, n, 32); StrCat(ts, ":", 32); UToStr(t.wMinute, n, 2); StrCat(ts, n, 32); StrCat(ts, ":", 32); UToStr(t.wSecond, n, 2); StrCat(ts, n, 32); StrCat(ts, "] ", 32);
    DWORD w; WriteFile(h, ts, StrLen(ts), &w, 0);
    WriteFile(h, a, StrLen(a), &w, 0);
    if (b) WriteFile(h, b, StrLen(b), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}

// sostituto del gestore di ChatDisconnectMsg (stessa convenzione: thiscall, 2 argomenti sullo stack)
static void __fastcall ChatDisconnect(void* self, void*, int, int)
{
    char num[16]; unsigned fsm = IsBadReadPtr((void*)A(kFsm), 4) ? 0xFFFFFFFF : *(unsigned*)A(kFsm);
    UToStr(fsm, num, 1);
    Log("ChatDisconnectMsg ricevuto (connessione chat caduta), ignorato per evitare il crash EASharp. FSM ", num);
}


// ---------------------------------------------------------------- suono dell'auto
typedef void (__fastcall* SoundUpdate_t)(DWORD* self, void* edx, int a2);
typedef DWORD (__fastcall* QI_t)(void* list, void* edx, DWORD key);
static unsigned g_soundRefresh = 0, g_soundSkip = 0;
static void __fastcall SoundUpdate(DWORD* self, void*, int a2)
{
    DWORD veh = self[11];
    if (!veh || IsBadReadPtr((void*)(veh + 4), 4)) return;
    void* list = *(void**)(veh + 4);
    if (!list || IsBadReadPtr(list, 8)) return;
    QI_t qi = (QI_t)A(kQueryInterface);
    DWORD t = qi(list, 0, A(kKeyTransmission)), e = qi(list, 0, A(kKeyEngine)), s = qi(list, 0, A(kKeySuspension));
    if (t != self[70] || e != self[71] || s != self[72]) {
        if (++g_soundRefresh <= 20) {
            char n[16]; UToStr(g_soundRefresh, n, 1);
            Log("suono auto: interfacce dell'auto cambiate, aggiornate (evitato componente liberato) n. ", n);
        }
        self[70] = t; self[71] = e; self[72] = s;
    }
    if (!t || !e || !s) {
        if (++g_soundSkip <= 5) Log("suono auto: interfaccia mancante, aggiornamento saltato");
        return;
    }
    ((SoundUpdate_t)A(kSoundUpdateFn))(self, 0, a2);
}

static bool PatchCall(DWORD siteVa, DWORD expectVa, void* fn)
{
    unsigned char* p = (unsigned char*)A(siteVa);
    if (IsBadReadPtr(p, 5) || p[0] != 0xE8) return false;
    if ((DWORD)p + 5 + *(int*)(p + 1) != A(expectVa)) return false;
    DWORD old;
    if (!VirtualProtect(p + 1, 4, 0x40, &old)) return false;
    *(int*)(p + 1) = (int)((DWORD)fn - ((DWORD)p + 5));
    VirtualProtect(p + 1, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    return true;
}

static bool PatchJmp(DWORD va, const unsigned char* expect, int n, void* to)
{
    unsigned char* p = (unsigned char*)A(va);
    if (IsBadReadPtr(p, n)) return false;
    for (int i = 0; i < n; ++i) if (p[i] != expect[i]) return false;
    DWORD old;
    if (!VirtualProtect(p, 5, 0x40 /*PAGE_EXECUTE_READWRITE*/, &old)) return false;
    p[0] = 0xE9; *(int*)(p + 1) = (int)((DWORD)to - ((DWORD)p + 5));
    VirtualProtect(p, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    return true;
}

static void Init(HMODULE self)
{
    g_delta = (DWORD)GetModuleHandleA(0) - kBase;
    char dir[MAX_PATH]; DWORD n = GetModuleFileNameA(self, dir, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    for (int i = (int)n - 1; i >= 0; --i) if (dir[i] == '\\' || dir[i] == '/') { dir[i + 1] = 0; break; }
    char ini[MAX_PATH]; StrCpy(ini, dir, MAX_PATH); StrCat(ini, "NFSWStability.ini", MAX_PATH);
    StrCpy(g_log, dir, MAX_PATH); StrCat(g_log, "NFSWStability.log", MAX_PATH);
    g_logOn = GetPrivateProfileIntA("General", "Log", 1, ini) != 0;
    if (GetPrivateProfileIntA("Fixes", "ChatDisconnectCrash", 1, ini)) {
        if (PatchJmp(kChatDisconnectFn, kChatDisconnectBytes, sizeof(kChatDisconnectBytes), (void*)ChatDisconnect)) Log("[init] fix ChatDisconnectMsg attivo");
        else Log("[init] fix ChatDisconnectMsg NON applicato (nfsw.exe diverso?)");
    }
    if (GetPrivateProfileIntA("Fixes", "CarSoundCrash", 1, ini)) {
        if (PatchCall(kSoundUpdateSite, kSoundUpdateFn, (void*)SoundUpdate)) Log("[init] fix suono auto attivo");
        else Log("[init] fix suono auto NON applicato (nfsw.exe diverso?)");
    }
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); Init(h); }
    return TRUE;
}
