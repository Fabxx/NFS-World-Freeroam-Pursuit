class com.ea.PostRace.PostRace
{
   var _eventModeId;
   var _flowButton;
   var _movie;
   var _state;
   var mBusy;
   var mEventTitle;
   var mPurchaseBox;
   var mSubPageLoader;
   var m_GoBackButton;
   var m_StreakPurchaseBox;
   var mcDurabilityCallout;
   var DATA_SOURCE = "GBE";
   var mLeveledUp = false;
   static var MINIMUM_HEIGHT_FOR_BACKGROUND = 650;
   var GADGET_SHOW_SFX = "RESULTS_SCREEN_SHOW";
   var GADGET_HIDE_SFX = "RESULTS_SCREEN_HIDE";
   var GADGET_WAIT_SFX = "GADGET_WAIT";
   var STATE_SHOW = {label:"show",swfFile:""};
   var STATE_RESULTS = {label:"results",swfFile:"circuit.swf"};
   var STATE_RESULTS_PURSUIT_COOP = {label:"results",swfFile:"PursuitCoopStandings.swf"};
   var STATE_PURSUIT_INTRO = {label:"hidden",swfFile:"PostPursuitIntro.swf"};
   var STATE_PURSUIT_SHOW = {label:"show",swfFile:""};
   var STATE_PURSUIT = {label:"results",swfFile:"pursuit.swf"};
   var STATE_REWARDS = {label:"rewards",swfFile:"RewardsView.swf"};
   var STATE_TREASURE_STREAK = {label:"treasureStreak",swfFile:"TreasureStreak.swf"};
   var STATE_LUCKY_DRAW = {label:"rewards",swfFile:"LuckyBox.swf"};
   var STATE_HIDE = {label:"hide",swfFile:""};
   var STATE_LEVEL_UP = {label:"rewards",swfFile:"UnlocksView.gfx"};
   var delegates = new Object();
   var mPendingSkills = false;
   var mDSWindow;
   var mDSClosed = false;
   function ShowSkillsWindow()
   {
      var self = this;
      var _loc3_ = _level0.createEmptyMovieClip("dsSkillWindow",16000);
      this.mDSWindow = _loc3_;
      _loc3_._x = 0;
      _loc3_._y = 0;
      _global.DSOnSkillWindowClosed = function()
      {
         self.CloseSkillsWindow();
      };
      _global.DSPrevSubPageLoader = _global.SubPageLoader;
      var _loc10_ = new Object();
      _loc10_.onLoadInit = function(screen)
      {
      };
      _global.SubPageLoader = _loc10_;
      var _loc11_ = new MovieClipLoader();
      var _loc12_ = new Object();
      _loc12_.onLoadError = function()
      {
         self.CloseSkillsWindow();
      };
      _loc11_.addListener(_loc12_);
      _loc11_.loadClip("SkillSelection.swf",_loc3_);
   }
   function OnDriverSkillPointsChanged(unused)
   {
      if(this.mDSWindow == undefined)
      {
         return undefined;
      }
      var _loc3_ = "";
      if(unused == 1)
      {
         _loc3_ = "1 UNUSED SKILL POINT";
      }
      else if(unused > 1)
      {
         _loc3_ = unused + " UNUSED SKILL POINTS";
      }
      this.mDSWindow.pointsTxt.text = _loc3_;
   }
   function CloseSkillsWindow()
   {
      if(this.mDSClosed)
      {
         return undefined;
      }
      this.mDSClosed = true;
      if(_global.DSPrevSubPageLoader != undefined)
      {
         _global.SubPageLoader = _global.DSPrevSubPageLoader;
      }
      if(this.mDSWindow != undefined)
      {
         this.mDSWindow.removeMovieClip();
      }
      this.mDSWindow = undefined;
      _global.DSOnSkillWindowClosed = undefined;
      flash.external.ExternalInterface.call("Request","PostEventComplete");
      com.ea.common.Generic.Utils.TriggerTransition("Exit");
   }
   function PostRace(screen)
   {
      this._movie = screen;
      _global.RootClass = this;
      gfx.events.EventDispatcher.initialize(this);
      this._eventModeId = com.ea.interop.enums.GameCore_EventMode.kEventMode_Unknown.Value;
      this.mBusy = 1;
      Stage.addListener(this);
   }
   function set state(value)
   {
      this._state = value;
      if(this._state.label != "")
      {
         this._movie.gotoAndPlay(this._state.label);
      }
      if(this._state.swfFile != "")
      {
         this.mSubPageLoader.LoadPage(this._state.swfFile);
         flash.external.ExternalInterface.call("Request","Debug_NotifyState",this._state.swfFile);
      }
   }
   function onIntroComplete()
   {
      com.ea.gameapi.command.Command.GetEventMode();
      com.ea.gameapi.command.Command.PostEventStart();
      this.StoreWasJustInPostRace();
      if(this.DATA_SOURCE == "local")
      {
         _global.mEventMode = new Object();
         _global.mEventMode.mode = com.ea.interop.enums.GameCore_EventMode.kEventMode_Circuit.Value;
      }
      if(_global.mEventMode.mode == com.ea.interop.enums.GameCore_EventMode.kEventMode_Unknown.Value)
      {
         _global.mEventMode.mode = com.ea.interop.enums.GameCore_EventMode.kEventMode_TreasureHunt.Value;
      }
      this._eventModeId = Number(_global.mEventMode.mode);
      this.initialize();
      this.mPurchaseBox = this._movie.mRecommendation;
      this.InitSuggestSale(this._eventModeId);
      switch(this._eventModeId)
      {
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_Pursuit.Value:
            this.GoToPursuitIntro();
            break;
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_TeamEscape.Value:
            this.GoToPursuitIntro();
            break;
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_Sprint.Value:
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_Circuit.Value:
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_TreasureHunt.Value:
         default:
            this.GoToShow();
      }
      this.mcDurabilityCallout = _level0.DurabilityCallout;
   }
   function onShow()
   {
      this.gotoNextState();
   }
   function GetNavButton()
   {
      return this._flowButton;
   }
   function GetStreakPurchaseBox()
   {
      return this.m_StreakPurchaseBox;
   }
   function GetGoBackButton()
   {
      return this.m_GoBackButton;
   }
   function GetTitle()
   {
      return this.mEventTitle;
   }
   function SetBackingColour(colour)
   {
      this._movie.mc_glowFrame.mc_glowFrameGroup.gotoAndPlay(colour);
   }
   function onResize()
   {
      this.handleResize();
   }
   function OnPush()
   {
      this.handleResize();
   }
   function StoreWasJustInPostRace()
   {
      com.ea.gameapi.command.Command.SetSessionValue("WasJustInPostRace","Global","true");
   }
   function handleResize()
   {
      var _loc2_ = Stage.height < com.ea.PostRace.PostRace.MINIMUM_HEIGHT_FOR_BACKGROUND;
      var _loc3_;
      if(_loc2_)
      {
         _loc3_ = 0.1;
         this._movie._x = this._movie._width * _loc3_ / 2;
         this._movie._y = this._movie._height * _loc3_ / 2;
         this._movie._xscale = (1 - _loc3_) * 100;
         this._movie._yscale = (1 - _loc3_) * 100;
      }
   }
   function initialize()
   {
      this._flowButton = this._movie.nextBtn;
      this.m_GoBackButton = this._movie.m_GoBackBtn;
      this.m_StreakPurchaseBox = this._movie.m_StreakPurchaseBox;
      this.flowButtonChangeToNext();
      this._flowButton.setAttract(false);
      this._flowButton.setEnable(false);
      this.m_GoBackButton.setAttract(false);
      this.m_GoBackButton.setEnable(false);
      this.m_GoBackButton._visible = false;
      this.m_StreakPurchaseBox._visible = false;
      this.mEventTitle = this._movie.mTitle;
      this._movie.mcRenderTarget._visible = false;
      this.mSubPageLoader = this._movie.mSubPageHolder;
      this.mSubPageLoader.removeAllEventListeners();
      this.delegates.EH_onPageLoaded = mx.utils.Delegate.create(this,this.onPageLoaded);
      this.mSubPageLoader.addEventListener(com.ea.components.SubPageLoader.ON_SCREEN_INIT,this.delegates.EH_onPageLoaded);
      this.delegates.PageBusy = mx.utils.Delegate.create(this,this.onPageBusy);
      this.delegates.PageIdle = mx.utils.Delegate.create(this,this.onPageIdle);
   }
   function onHide()
   {
      this.mPurchaseBox.ShutDown();
      this.mSubPageLoader.unloadMovie(this._state.swfFile);
      if(this.mPendingSkills)
      {
         this.mPendingSkills = false;
         this.ShowSkillsWindow();
         return undefined;
      }
      flash.external.ExternalInterface.call("Request","PostEventComplete");
      com.ea.common.Generic.Utils.TriggerTransition("Exit");
   }
   function enableNextButton()
   {
      this._flowButton.setAttract(true);
      this._flowButton.setEnable(true);
   }
   function gotoNextState()
   {
      var _loc2_;
      var _loc3_;
      var _loc4_;
      switch(this._state)
      {
         case this.STATE_SHOW:
            if((_loc2_ = this._eventModeId) !== com.ea.interop.enums.GameCore_EventMode.kEventMode_TreasureHunt.Value)
            {
               this.GoToResults();
               return undefined;
            }
            com.ea.util.SFX.PlaySound(this.GADGET_SHOW_SFX);
            this.GoToTreasureStreak();
            return undefined;
            break;
         case this.STATE_RESULTS:
            this.GoToRewards();
            return undefined;
         case this.STATE_PURSUIT_INTRO:
            this.GoToPursuitShow();
            return undefined;
         case this.STATE_PURSUIT_SHOW:
            if((_loc2_ = this._eventModeId) === com.ea.interop.enums.GameCore_EventMode.kEventMode_Pursuit.Value)
            {
               this.GoToPursuit();
               return undefined;
            }
            return undefined;
            break;
         case this.STATE_PURSUIT:
         case this.STATE_RESULTS_PURSUIT_COOP:
            this.GoToRewards();
            return undefined;
         case this.STATE_TREASURE_STREAK:
            if(com.ea.interop.enums.GameCore_EventMode.kEventMode_TreasureHunt.Value != this._eventModeId)
            {
               return undefined;
            }
            this.GoToRewards();
            return undefined;
            break;
         case this.STATE_REWARDS:
            _loc3_ = com.ea.interop.enums.GameCore_EventMode.kEventMode_TreasureHunt.Value == this._eventModeId;
            _loc4_ = com.ea.PostRace.components.RewardsView(this.mSubPageLoader.GetCurrentScreen());
            if(_loc4_ != undefined)
            {
               this.mLeveledUp = _loc4_.leveledUp == true;
            }
            else
            {
               this.mLeveledUp = false;
            }
            if(_loc4_ != undefined && _loc4_.GetRewards() != undefined && _loc4_.GetRewards().LuckyDraw != undefined && _loc4_.GetRewards().LuckyDraw.HasLuckyDraw && !_loc3_)
            {
               this.GoToLuckyBox();
               return undefined;
            }
            if(this.mLeveledUp)
            {
               this.UpdateCommandHUD();
               this.GoToLevelUpFlasher();
               return undefined;
            }
            this.UpdateCommandHUD();
            this.GoToHide();
            return undefined;
            break;
         case this.STATE_LUCKY_DRAW:
            this.UpdateCommandHUD();
            if(this.mLeveledUp)
            {
               this.GoToLevelUpFlasher();
               return undefined;
            }
            this.GoToHide();
            return undefined;
            break;
         default:
            return undefined;
      }
   }
   function GoToLevelUpFlasher()
   {
      this.LoadExternalLevelUp();
   }
   function LoadExternalLevelUp()
   {
      this.mSubPageLoader.removeEventListener(com.ea.components.SubPageLoader.ON_SCREEN_INIT,this.delegates.EH_onPageLoaded);
      this.delegates.EH_onLevelUpLoaded = mx.utils.Delegate.create(this,this.onLevelUpLoaded);
      this.mSubPageLoader.addEventListener(com.ea.components.SubPageLoader.ON_SCREEN_INIT,this.delegates.EH_onLevelUpLoaded);
      this.state = this.STATE_LEVEL_UP;
   }
   function onLevelUpLoaded()
   {
      var _loc2_ = this.mSubPageLoader.GetCurrentScreen();
      if(_loc2_ != undefined)
      {
         if(_loc2_.navButton != undefined)
         {
            _loc2_.navButton.enabled = false;
         }
      }
      this._flowButton._visible = false;
   }
   function onPageLoaded(evtObj)
   {
      var _loc3_ = this.mSubPageLoader.GetCurrentScreen();
      _loc3_.OnCompleted = mx.utils.Delegate.create(this,this.gotoNextState);
   }
   function GoToShow()
   {
      this._movie.backgroundMc._visible = false;
      this.state = this.STATE_SHOW;
   }
   function GoToResults()
   {
      this._movie.backgroundMc._visible = false;
      this.state = this.STATE_RESULTS;
      com.ea.gameapi.command.Command.HandleTutorial(com.ea.gameapi.enum.FeatureTutorial.Results.value,com.ea.interop.enums.GameCore_TutorialSource.kTutorialSource_Race.Value);
      this.HideCallouts();
      this.RequestCallouts();
   }
   function GoToPursuitIntro()
   {
      this.state = this.STATE_PURSUIT_INTRO;
   }
   function GoToPursuitShow()
   {
      this.state = this.STATE_PURSUIT_SHOW;
   }
   function GoToPursuit()
   {
      this.state = this.STATE_PURSUIT;
   }
   function GoToPursuitCoop()
   {
      this.state = this.STATE_RESULTS_PURSUIT_COOP;
   }
   function GoToRewards()
   {
      this._movie.backgroundMc._visible = true;
      flash.external.ExternalInterface.call("Request","HideTutorial","IntroPopup",0);
      this.mcDurabilityCallout._visible = false;
      this.state = this.STATE_REWARDS;
   }
   function GoToTreasureStreak()
   {
      this._movie.backgroundMc._visible = true;
      flash.external.ExternalInterface.call("Request","HideTutorial","IntroPopup",0);
      this.mcDurabilityCallout._visible = false;
      this.state = this.STATE_TREASURE_STREAK;
   }
   function GoToLuckyBox()
   {
      this._movie.backgroundMc._visible = true;
      this._movie.titleFld.text = "TXT_TITLE_LUCKY_BOX";
      var _loc2_ = new com.ea.PostRace.components.PostRaceView(this._movie.titleAnimationMc);
      _loc2_.title = "POSTRACE_LUCKYBOX_TITLE";
      this.state = this.STATE_LUCKY_DRAW;
      flash.external.ExternalInterface.call("Request","HandleTutorial",com.ea.gameapi.enum.FeatureTutorial.LuckyDraw.value,com.ea.interop.enums.GameCore_TutorialSource.kTutorialSource_PostRace.Value);
   }
   function GoToHide()
   {
      if(this._state == this.STATE_LEVEL_UP)
      {
         this.mPendingSkills = true;
         this.mSubPageLoader.unloadMovie("UnlocksView.gfx");
      }
      this.state = this.STATE_HIDE;
      com.ea.util.SFX.PlaySound(this.GADGET_HIDE_SFX);
   }
   function UpdateCommandHUD()
   {
      com.ea.gameapi.command.Command.GadgetSendEvent("",com.ea.gameapi.enum.eGadgetEvent.EARNED_TOKENS_COUNT_FINISHED.value);
   }
   function flowButtonChangeToNext()
   {
      this._flowButton.setLabel("CMN_NEXT");
   }
   function clickOnFlowButton()
   {
      if(this._flowButton.enabled)
      {
         this._flowButton.onRelease();
      }
   }
   function InitSuggestSale(gameMode)
   {
      switch(gameMode)
      {
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_TeamEscape.Value:
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_Pursuit.Value:
            this.mPurchaseBox.Init(com.ea.common.components.PurchaseBox.PurchaseBox.CONTEXT_POST_PURSUIT);
            break;
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_Circuit.Value:
         case com.ea.interop.enums.GameCore_EventMode.kEventMode_Sprint.Value:
         default:
            this.mPurchaseBox.Init(com.ea.common.components.PurchaseBox.PurchaseBox.CONTEXT_POST_RACE);
      }
      this.mPurchaseBox.removeAllEventListeners();
      this.mPurchaseBox.addEventListener(com.ea.common.components.PurchaseBox.PurchaseBox.ON_REQUEST_PURCHASE,this.delegates.PageBusy);
      this.mPurchaseBox.addEventListener(com.ea.common.components.PurchaseBox.PurchaseBox.ON_RESULT_RECIEVED,this.delegates.PageIdle);
   }
   function onPageBusy()
   {
      this.SetBusy(true);
   }
   function onPageIdle()
   {
      this.SetBusy(false);
   }
   function IsBusy(Void)
   {
      return this.mBusy > 0;
   }
   function SetBusy(value)
   {
      if(value == undefined || value)
      {
         this.mBusy += 1;
      }
      else
      {
         this.mBusy -= 1;
      }
   }
   function OnDisplayTutorialReceived()
   {
      if(_global.mDisplayTutorial.value)
      {
         this.SetupCallouts();
         this.ShowCallouts();
      }
   }
   function SetupCallouts()
   {
      this.mcDurabilityCallout.titleMc.titleFld.text = "TTRL_DURABILITYLOSS_1_HDR";
      this.mcDurabilityCallout.contentMc.contentFld.text = "TTRL_DURABILITYLOSS_1";
      this.mcDurabilityCallout.gotoAndPlay("top");
   }
   function ShowCallouts()
   {
      this.mcDurabilityCallout._alpha = 100;
   }
   function HideCallouts()
   {
      this.mcDurabilityCallout._alpha = 0;
   }
   function RequestCallouts()
   {
      com.ea.gameapi.command.Command.HandleTutorial(com.ea.gameapi.enum.FeatureTutorial.DurabilityCallout.value,com.ea.interop.enums.GameCore_TutorialSource.kTutorialSource_PostRace.Value);
   }
   function HandlePurchaseResult(lReply)
   {
      if(!lReply.result && lReply.info == com.ea.gameapi.enum.ShoppingCartPurchaseResultInfo.NOT_ENOUGH_FUNDS.ordinal)
      {
         com.ea.common.Generic.Utils.TriggerTransition("BoostErrorGoToStore");
         return true;
      }
      return false;
   }
   function OnPopupClosed()
   {
      var _loc3_ = arguments[0];
      var _loc4_;
      switch(_loc3_)
      {
         case "BoostErrorStore":
         case "BoostFlow_Confirm":
         case "GetRewardsCANCEL":
            _loc4_ = this.mSubPageLoader.GetCurrentScreen();
            _loc4_.EnableNavButton(true);
            this.SetBusy(false);
            return undefined;
         case "GetRewardsOK":
            this.GoToRewards();
      }
      return undefined;
   }
}
