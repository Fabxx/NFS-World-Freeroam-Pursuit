class com.ea.components.SkillSelectionComponent extends MovieClip
{
   var DATA_SOURCE;
   var cmdExploreCategory;
   var cmdPursuitCategory;
   var cmdRaceCategory;
   var dispatchEvent;
   var mBtnExploreCategory;
   var mBtnPursueCategory;
   var mBtnRaceCategory;
   var mEventListener;
   var mLearnButtonListener;
   var mListBox;
   var mListBoxListeners;
   var mListBoxScrollbar;
   var mListBoxScrollbarListeners;
   var mOwner;
   var mPointRequirementBackdrop;
   var mSkillInfoBox;
   var mSkillListHeader;
   var m_ExploreCategoryButtonListener;
   var m_PursueCategoryButtonListener;
   var m_RaceCategoryButtonListener;
   var m_SelectedSkillID;
   var m_SelectedSkillIconRankClip;
   var m_SkillMode;
   var m_skillInfo;
   var onLoad;
   var skillListBox;
   var skillListHeader;
   var skillListScrollBar;
   var RACE_COLOUR_DISABLE = 13158;
   var EXPLORE_COLOUR_DISABLE = 5399808;
   var PURSUE_COLOUR_DISABLE = 7739392;
   var RACE_COLOUR_ENABLE = 3579647;
   var EXPLORE_COLOUR_ENABLE = 13434675;
   var PURSUE_COLOUR_ENABLE = 16728320;
   static var SKILL_CAT_RACE = 0;
   static var SKILL_CAT_EXPLORE = 1;
   static var SKILL_CAT_PURSUE = 2;
   var m_CurrentCategory = 0;
   static var ON_COMPONENT_LOADED = "ON_LOAD_COMPLETE";
   static var STATE_RACE = "race";
   static var STATE_EXPLORE = "explore";
   static var STATE_PURSUE = "pursue";
   var COMPONENT_TAG = "[SkillSelectionComponent]";
   var mbShowMostPointsFirst = false;
   var mbShowUnlockedFirst = false;
   // ------------------------------------------------------------------ NFSW Driver Skills (beta 2010 port)
   // Data lives here, persistence and gameplay effect in NFSWDriverSkills.asi
   static var DS_POINTS_PER_LEVEL = 2;
   static var DS_CAT_NAMES = ["RACE","EXPLORE","PURSUIT"];
   static function DS_DB()
   {
      if(_global.mDSDB == undefined)
      {
         _global.mDSDB = [
         {id:101,cat:0,name:"EXTENDED NITROUS",icon:"SKILL_EXT_NOS",max:5,vals:[13,20,34,46,53],lvl:[4,12,20,28,36],pts:[0,0,0,0,0],txt:"Increases the duration of Nitrous by {v}%."},
         {id:102,cat:0,name:"PERFECT START",icon:"SKILL_PERFECT_START",max:5,vals:[1.5,2.5,4,4.5,5],lvl:[3,10,17,24,31],pts:[0,2,4,6,8],txt:"Instant {v} second Nitrous shot at race start if engine RPMs are within the target range."},
         {id:103,cat:0,name:"CATCH UP",icon:"SKILL_CATCH_UP",max:3,vals:[4,6,11],lvl:[3,13,23],pts:[0,0,0],txt:"Boosts car performance by {v}% when in Third Place or lower in a Race."},
         {id:104,cat:0,name:"DRAGSTER",icon:"SKILL_DRAGSTER",max:3,vals:[20,30,45],lvl:[17,27,37],pts:[2,4,8],txt:"Improves acceleration with optimized gear ratios (+{v}%)."},
         {id:105,cat:0,name:"NEED FOR SPEED",icon:"SKILL_NEED_FOR_SPEED",max:3,vals:[6,9,17],lvl:[20,30,40],pts:[2,4,8],txt:"Increases the speed boost of Slingshot by {v}%."},
         {id:106,cat:0,name:"NERVES OF STEEL",icon:"SKILL_NERVES_OF_STEEL",max:3,vals:[15,22,41],lvl:[15,25,35],pts:[2,4,8],txt:"Improves tire grip at launch by {v}%."},
         {id:107,cat:0,name:"RAPID FIRE",icon:"SKILL_RAPID_FIRE",max:3,vals:[10,15,28],lvl:[2,12,22],pts:[0,2,4],txt:"Decreases the Nitrous cooldown timer by {v}%."},
         {id:108,cat:0,name:"STRONG FINISHER",icon:"SKILL_STRONG_FINISHER",max:2,vals:[7,10],lvl:[6,16],pts:[2,4],txt:"Increases the duration of Slingshot by {v}%."},
         {id:109,cat:0,name:"SUPER SHOT",icon:"SKILL_SUPER_SHOT",max:3,vals:[10,15,27],lvl:[8,21,34],pts:[0,4,8],txt:"Increases Nitrous power by {v}%."},
         {id:110,cat:0,name:"TRAFFIC COP",icon:"SKILL_TRAFFIC_COP",max:3,vals:[7,14,28],lvl:[8,14,23],pts:[0,0,4],txt:"Decreases the Traffic Magnet cooldown timer by {v}%."},
         {id:111,cat:0,name:"JUMPSTART",icon:"SKILL_JUMPSTART",max:2,vals:[2,3],lvl:[5,15],pts:[0,0],txt:"Powerups can be played {v} seconds earlier at the start of a Race."},
         {id:112,cat:0,name:"ROLLING FORTRESS",icon:"SKILL_ROLLING_FORTRESS",max:3,vals:[9,14,28],lvl:[4,14,24],pts:[0,2,4],txt:"Increases the duration of Shield by {v}%."},
         {id:201,cat:1,name:"RADAR",icon:"SKILL_RADAR",max:3,vals:[100,150,275],lvl:[3,11,19],pts:[0,0,0],txt:"Displays all Cops within {v} meters on the Minimap."},
         {id:202,cat:1,name:"MOST WANTED",icon:"SKILL_MOST_WANTED",max:3,vals:[6,8,17],lvl:[9,19,29],pts:[0,2,4],txt:"Increases Cash rewards for Pursuits by {v}%."},
         {id:203,cat:1,name:"SOCIALITE",icon:"SKILL_SOCIALITE",max:2,vals:[10,15],lvl:[5,15],pts:[3,5],txt:"Increases Cash earned while exploring the World by {v}%."},
         {id:204,cat:1,name:"TYCOON",icon:"SKILL_TYCOON",max:5,vals:[6,9,17,19,23],lvl:[2,11,20,29,38],pts:[0,0,0,0,0],txt:"Increases Cash rewards for all Race events by {v}%."},
         {id:205,cat:1,name:"LIGHTNING REFLEX",icon:"SKILL_LIGHTNING_REFLEX",max:3,vals:[13,20,36],lvl:[5,10,15],pts:[0,0,4],txt:"Decreases the Ready! cooldown timer by {v}%."},
         {id:301,cat:2,name:"RAM",icon:"SKILL_RAM",max:5,vals:[10,15,28,34,40],lvl:[3,12,21,30,39],pts:[0,2,4,6,8],txt:"Increases the weight of your car in collisions by {v}%."},
         {id:302,cat:2,name:"COOLDOWN",icon:"SKILL_COOLDOWN",max:3,vals:[10,15,28],lvl:[4,12,20],pts:[0,0,0],txt:"Decreases the time required to escape a pursuit by {v}%."},
         {id:303,cat:2,name:"TERMINATOR",icon:"SKILL_TERMINATOR",max:3,vals:[7,10,18],lvl:[10,18,26],pts:[2,0,0],txt:"Decreases the Juggernaut cooldown timer by {v}%."},
         {id:304,cat:2,name:"DEMOLITION MAN",icon:"SKILL_DEMOLITION_MAN",max:3,vals:[5,8,14],lvl:[5,11,17],pts:[2,4,0],txt:"Increases the damage caused by Juggernaut collisions by {v}%."},
         {id:305,cat:2,name:"EVASION",icon:"SKILL_EVASION",max:3,vals:[10,15,28],lvl:[4,14,27],pts:[0,2,4],txt:"Increases the power of Emergency Evade by {v}%."},
         {id:306,cat:2,name:"UNTOUCHABLE",icon:"SKILL_UNTOUCHABLE",max:5,vals:[15,21,41,49,60],lvl:[2,10,18,26,34],pts:[0,0,0,0,0],txt:"Decreases the Emergency Evade cooldown timer by {v}%."},
         {id:307,cat:2,name:"RAMPAGE",icon:"SKILL_RAMPAGE",max:3,vals:[10,15,28],lvl:[2,17,27],pts:[0,0,3],txt:"Increases the duration of Juggernaut by {v}%."}];
      }
      return _global.mDSDB;
   }
   static function DS_Find(id)
   {
      var _loc2_ = com.ea.components.SkillSelectionComponent.DS_DB();
      var _loc3_ = 0;
      while(_loc3_ < _loc2_.length)
      {
         if(_loc2_[_loc3_].id == id)
         {
            return _loc2_[_loc3_];
         }
         _loc3_ += 1;
      }
      return undefined;
   }
   static function DS_Persona()
   {
      var _loc2_ = new Object();
      _loc2_.id = "default";
      _loc2_.level = 1;
      var _loc3_ = flash.external.ExternalInterface.call("HandleRequest_Interop_GetCurrentPlayerPersona");
      if(_loc3_ != undefined && _loc3_ != null)
      {
         if(_loc3_.PersonaId != undefined)
         {
            _loc2_.id = String(_loc3_.PersonaId);
         }
         if(!isNaN(Number(_loc3_.Level)))
         {
            _loc2_.level = Number(_loc3_.Level);
         }
      }
      else if(_global.mGamePersona != undefined && _global.mGamePersona.isSelf)
      {
         if(_global.mGamePersona.personaId != undefined)
         {
            _loc2_.id = String(_global.mGamePersona.personaId);
         }
         if(!isNaN(Number(_global.mGamePersona.level)))
         {
            _loc2_.level = Number(_global.mGamePersona.level);
         }
      }
      if(_loc2_.level < 1)
      {
         _loc2_.level = 1;
      }
      return _loc2_;
   }
   static function DS_Parse(data)
   {
      var _loc3_ = new Object();
      if(data == undefined || data == null)
      {
         return _loc3_;
      }
      var _loc4_ = String(data).split(",");
      var _loc5_ = 0;
      var _loc6_;
      while(_loc5_ < _loc4_.length)
      {
         _loc6_ = _loc4_[_loc5_].split(":");
         if(_loc6_.length == 2 && !isNaN(Number(_loc6_[0])) && !isNaN(Number(_loc6_[1])))
         {
            _loc3_["s" + Number(_loc6_[0])] = Number(_loc6_[1]);
         }
         _loc5_ += 1;
      }
      return _loc3_;
   }
   static function DS_Serialize()
   {
      var _loc2_ = com.ea.components.SkillSelectionComponent.DS_DB();
      var _loc3_ = "";
      var _loc4_ = 0;
      var _loc5_;
      while(_loc4_ < _loc2_.length)
      {
         _loc5_ = com.ea.components.SkillSelectionComponent.DS_Rank(_loc2_[_loc4_].id);
         if(_loc5_ > 0)
         {
            if(_loc3_ != "")
            {
               _loc3_ += ",";
            }
            _loc3_ += _loc2_[_loc4_].id + ":" + _loc5_;
         }
         _loc4_ += 1;
      }
      return _loc3_;
   }
   static function DS_Load()
   {
      var _loc2_ = com.ea.components.SkillSelectionComponent.DS_Persona();
      _global.mDSPersona = _loc2_;
      var _loc3_ = flash.external.ExternalInterface.call("Request","NFSWSkillsLoad",_loc2_.id);
      if(_loc3_ == undefined || _loc3_ == null)
      {
         com.ea.gameapi.command.Command.GetSessionValue("NFSWSkills","Global","");
         if(_global.mSessionValue != undefined && _global.mSessionValue.value != undefined)
         {
            _loc3_ = _global.mSessionValue.value;
         }
      }
      _global.mDSRanks = com.ea.components.SkillSelectionComponent.DS_Parse(_loc3_);
      return _global.mDSRanks;
   }
   static function DS_Save()
   {
      var _loc2_ = _global.mDSPersona;
      if(_loc2_ == undefined)
      {
         _loc2_ = com.ea.components.SkillSelectionComponent.DS_Persona();
      }
      flash.external.ExternalInterface.call("Request","NFSWSkillsSave",_loc2_.id,com.ea.components.SkillSelectionComponent.DS_Serialize());
   }
   static function DS_Rank(id)
   {
      if(_global.mDSRanks == undefined)
      {
         com.ea.components.SkillSelectionComponent.DS_Load();
      }
      var _loc3_ = _global.mDSRanks["s" + id];
      return !(_loc3_ == undefined || isNaN(_loc3_)) ? _loc3_ : 0;
   }
   static function DS_Stats()
   {
      var _loc2_ = com.ea.components.SkillSelectionComponent.DS_DB();
      var _loc3_ = [0,0,0];
      var _loc4_ = 0;
      while(_loc4_ < _loc2_.length)
      {
         _loc3_[_loc2_[_loc4_].cat] += com.ea.components.SkillSelectionComponent.DS_Rank(_loc2_[_loc4_].id);
         _loc4_ += 1;
      }
      var _loc5_ = new Object();
      _loc5_.race_points = _loc3_[0];
      _loc5_.explore_points = _loc3_[1];
      _loc5_.pursue_points = _loc3_[2];
      var _loc6_ = _global.mDSPersona != undefined ? _global.mDSPersona.level : com.ea.components.SkillSelectionComponent.DS_Persona().level;
      _loc5_.driver_level = _loc6_;
      _loc5_.total_points = Math.max(0,(_loc6_ - 1) * com.ea.components.SkillSelectionComponent.DS_POINTS_PER_LEVEL);
      _loc5_.unused_points = Math.max(0,_loc5_.total_points - _loc3_[0] - _loc3_[1] - _loc3_[2]);
      _global.mSSSkillStats = _loc5_;
      return _loc5_;
   }
   static function DS_SkillList(category)
   {
      var _loc3_ = com.ea.components.SkillSelectionComponent.DS_DB();
      var _loc4_ = new Object();
      _loc4_.skill_list = new Array();
      var _loc5_ = 0;
      while(_loc5_ < _loc3_.length)
      {
         if(_loc3_[_loc5_].cat == category)
         {
            _loc4_.skill_list.push(_loc3_[_loc5_].id);
         }
         _loc5_ += 1;
      }
      _global.mSSSkillList = _loc4_;
      return _loc4_;
   }
   static function DS_RankText(def, rank)
   {
      var _loc4_ = def.txt.split("{v}");
      return _loc4_.join(String(def.vals[rank - 1]));
   }
   static function DS_SkillInfo(id)
   {
      var _loc3_ = com.ea.components.SkillSelectionComponent.DS_Find(id);
      var _loc4_ = new Object();
      _global.mSSSkillInfo = _loc4_;
      if(_loc3_ == undefined)
      {
         _loc4_.status = "unavailable";
         return _loc4_;
      }
      var _loc5_ = com.ea.components.SkillSelectionComponent.DS_Stats();
      var _loc6_ = com.ea.components.SkillSelectionComponent.DS_Rank(id);
      var _loc7_ = [_loc5_.race_points,_loc5_.explore_points,_loc5_.pursue_points][_loc3_.cat];
      var _loc8_ = Math.min(_loc6_,_loc3_.max - 1);
      _loc4_.skillID = _loc3_.id;
      _loc4_.name = _loc3_.name;
      _loc4_.icon = _loc3_.icon;
      _loc4_.rank = _loc6_;
      _loc4_.max_rank = _loc3_.max;
      _loc4_.category = _loc3_.cat;
      _loc4_.req_level = _loc6_ < _loc3_.max ? _loc3_.lvl[_loc8_] : 0;
      _loc4_.req_skillpoints = _loc6_ < _loc3_.max ? _loc3_.pts[_loc8_] : 0;
      if(_loc6_ == 0)
      {
         _loc4_.desc_text = "RANK 1: " + com.ea.components.SkillSelectionComponent.DS_RankText(_loc3_,1);
      }
      else
      {
         _loc4_.desc_text = com.ea.components.SkillSelectionComponent.DS_RankText(_loc3_,_loc6_);
      }
      _loc4_.next_rank_text = _loc6_ < _loc3_.max && _loc6_ > 0 ? com.ea.components.SkillSelectionComponent.DS_RankText(_loc3_,_loc6_ + 1) : "";
      if(_loc6_ >= _loc3_.max)
      {
         _loc4_.status = "maxed";
      }
      else if(_loc4_.req_level > _loc5_.driver_level || _loc4_.req_skillpoints > _loc7_)
      {
         _loc4_.status = "locked";
      }
      else
      {
         _loc4_.status = "available";
      }
      return _loc4_;
   }
   static function DS_Learn(id)
   {
      var _loc3_ = com.ea.components.SkillSelectionComponent.DS_SkillInfo(id);
      var _loc4_ = _global.mSSSkillStats;
      if(_loc3_.status != "available" || _loc4_.unused_points <= 0)
      {
         return false;
      }
      _global.mDSRanks["s" + id] = _loc3_.rank + 1;
      com.ea.components.SkillSelectionComponent.DS_Save();
      com.ea.components.SkillSelectionComponent.DS_Stats();
      return true;
   }
   static function DS_UnusedText(n)
   {
      if(n <= 0)
      {
         return "NO AVAILABLE SKILL POINTS";
      }
      if(n == 1)
      {
         return "1 UNUSED SKILL POINT";
      }
      return n + " UNUSED SKILL POINTS";
   }
   function DS_NotifyOwner()
   {
      var _loc2_ = _global.mSSSkillStats.unused_points;
      if(this.mOwner.OnDriverSkillPointsChanged != undefined)
      {
         this.mOwner.OnDriverSkillPointsChanged(_loc2_);
      }
      else if(this.mOwner.mProfileSubScreenSubTitle != undefined)
      {
         this.mOwner.mProfileSubScreenSubTitle.TxtBox.text = com.ea.components.SkillSelectionComponent.DS_UnusedText(_loc2_);
      }
   }
   function SkillSelectionComponent(Void)
   {
      super();
      gfx.events.EventDispatcher.initialize(this);
      this.mEventListener = new Object();
      this.mEventListener.OnSSLearnSkillResultReceived = mx.utils.Delegate.create(this,this.OnSSLearnSkillResultReceived);
      this.mEventListener.OnSSSkillStatsReceived = mx.utils.Delegate.create(this,this.OnSSSkillStatsReceived);
      this.mEventListener.onLoad = mx.utils.Delegate.create(this,this.onLoadComplete);
      this.mListBoxListeners = new Object();
      this.mListBoxListeners.onUpdateItem = mx.utils.Delegate.create(this,this.OnSkillListUpdateItem);
      this.mListBoxListeners.onItemSelected = mx.utils.Delegate.create(this,this.OnSkillListItemSelected);
      this.mListBoxListeners.onItemUnselected = mx.utils.Delegate.create(this,this.OnSkillListItemUnselected);
      this.mListBoxListeners.onItemRollOver = mx.utils.Delegate.create(this,this.OnSkillListItemRollOver);
      this.mListBoxListeners.onItemRollOut = mx.utils.Delegate.create(this,this.OnSkillListItemRollOut);
      this.mListBoxScrollbarListeners = new Object();
      this.mListBoxScrollbarListeners.onScroll = mx.utils.Delegate.create(this,this.OnScrollbarUpdate);
      this.mLearnButtonListener = new Object();
      this.mLearnButtonListener.onPress = mx.utils.Delegate.create(this,this.OnPressLearnSkillButton);
      this.m_RaceCategoryButtonListener = new Object();
      this.m_RaceCategoryButtonListener.onRelease = mx.utils.Delegate.create(this,this.OnSelectRaceTab);
      this.m_ExploreCategoryButtonListener = new Object();
      this.m_ExploreCategoryButtonListener.onRelease = mx.utils.Delegate.create(this,this.OnSelectExploreTab);
      this.m_PursueCategoryButtonListener = new Object();
      this.m_PursueCategoryButtonListener.onRelease = mx.utils.Delegate.create(this,this.OnSelectPursueTab);
      this.m_CurrentCategory = -1;
      this.onLoad = mx.utils.Delegate.create(this,this.onLoadComplete);
   }
   function onLoadComplete(Void)
   {
      this.mOwner = _global.RootClass;
      this.DATA_SOURCE = "nfsw";
      com.ea.components.SkillSelectionComponent.DS_Load();
      com.ea.components.SkillSelectionComponent.DS_Stats();
      this.mListBox = this.skillListBox;
      this.mListBoxScrollbar = this.skillListScrollBar;
      this.mSkillInfoBox = this.m_skillInfo;
      this.mSkillListHeader = this.skillListHeader;
      this.m_SelectedSkillIconRankClip = this.mSkillInfoBox.selectedIconRankText;
      this.mBtnRaceCategory = this.cmdRaceCategory;
      this.mBtnPursueCategory = this.cmdPursuitCategory;
      this.mBtnExploreCategory = this.cmdExploreCategory;
      this.mPointRequirementBackdrop = this.mSkillInfoBox.mPointRequirementBackdrop;
      this.mBtnExploreCategory.addListener(this.m_ExploreCategoryButtonListener);
      this.mBtnPursueCategory.addListener(this.m_PursueCategoryButtonListener);
      this.mBtnRaceCategory.addListener(this.m_RaceCategoryButtonListener);
      this.mListBoxScrollbar.disabled = false;
      this.mListBox.addListener(this.mListBoxListeners);
      this.mSkillInfoBox.learnSkillBtn.addListener(this.mLearnButtonListener);
      this.mListBoxScrollbar.addEventListener("scroll",this.mListBoxScrollbarListeners.onScroll);
      this.SetSkillInfoVisible(false);
      this.SetLearnBtnVisible(false);
      if(undefined == this.mOwner.dispatchEvent)
      {
         return undefined;
      }
      this.mOwner.addEventListener("OnSSLearnSkillResultReceived",this.mEventListener.OnSSLearnSkillResultReceived);
      this.mOwner.OnSSLearnSkillResultReceived = function()
      {
         this.dispatchEvent({type:"OnSSLearnSkillResultReceived"});
      };
      this.mOwner.addEventListener("OnSSSkillStatsReceived",this.mEventListener.OnSSSkillStatsReceived);
      this.mOwner.OnSSSkillStatsReceived = function()
      {
         this.dispatchEvent({type:"OnSSSkillStatsReceived"});
      };
      Mouse.addListener(this);
      this.dispatchEvent({type:com.ea.components.SkillSelectionComponent.ON_COMPONENT_LOADED,object:this});
   }
   function SetSkillInfoVisible(lbSetting)
   {
      this.mSkillInfoBox._visible = lbSetting;
   }
   function SetLearnBtnVisible(lbSetting)
   {
      this.mSkillInfoBox.learnSkillBtn._visible = lbSetting;
   }
   function OnSkillListUpdateItem(itemIndexX, itemIndexY, mcItem)
   {
      if(itemIndexY >= _global.mSSSkillList.skill_list.length)
      {
         return undefined;
      }
      var _loc7_ = com.ea.components.SkillSelectionComponent.DS_SkillInfo(_global.mSSSkillList.skill_list[itemIndexY]);
      mcItem.skillName = _loc7_.name;
      var _loc5_ = [this.RACE_COLOUR_DISABLE,this.EXPLORE_COLOUR_DISABLE,this.PURSUE_COLOUR_DISABLE];
      var _loc6_ = [this.RACE_COLOUR_ENABLE,this.EXPLORE_COLOUR_ENABLE,this.PURSUE_COLOUR_ENABLE];
      mcItem.skillRankColour = _loc7_.rank == 0 ? _loc5_[this.m_CurrentCategory] : _loc6_[this.m_CurrentCategory];
      mcItem.skillRank = "RANK " + _loc7_.rank + "/" + _loc7_.max_rank;
      mcItem.iconRank = com.ea.util.Numeral.NumberToRomanNumeral(_loc7_.rank);
      mcItem.iconPath = "img://TexPack\\128_" + _loc7_.icon;
      mcItem.locked = _loc7_.status == "locked";
      mcItem.known = _loc7_.rank != 0;
   }
   function OnSkillListItemSelected(itemIndexX, itemIndexY, mcItem)
   {
      if(itemIndexY >= _global.mSSSkillList.skill_list.length)
      {
         return undefined;
      }
      this.m_SelectedSkillID = _global.mSSSkillList.skill_list[itemIndexY];
      this.mSkillInfoBox._visible = true;
      mcItem.selected = true;
      var _loc8_ = com.ea.components.SkillSelectionComponent.DS_SkillInfo(this.m_SelectedSkillID);
      var _loc9_ = _global.mSSSkillStats;
      this.mSkillInfoBox.headerMC.nameText.text = _loc8_.name;
      if(_loc8_.rank == 0)
      {
         this.mSkillInfoBox.headerMC.gotoAndPlay(this.m_SkillMode + "Disable");
      }
      else
      {
         this.mSkillInfoBox.headerMC.gotoAndPlay(this.m_SkillMode);
      }
      this.mSkillInfoBox.headerMC.rankText.text = "RANK " + _loc8_.rank + "/" + _loc8_.max_rank;
      this.m_SelectedSkillIconRankClip.iconRankText.text = com.ea.util.Numeral.NumberToRomanNumeral(_loc8_.rank);
      if(_loc8_.req_level > _loc9_.driver_level)
      {
         this.mSkillInfoBox.levelRequirementText.text = "LEVEL " + _loc8_.req_level + " REQUIRED TO LEARN";
         this.mSkillInfoBox.levelRequirementText._visible = true;
         this.mSkillInfoBox.mcRepLocked._visible = true;
      }
      else
      {
         this.mSkillInfoBox.levelRequirementText._visible = false;
         this.mSkillInfoBox.mcRepLocked._visible = false;
      }
      if(_loc8_.req_skillpoints > this.GetCategoryPointsSpent())
      {
         this.mSkillInfoBox.categoryRequirementText.text = "REQUIRES " + _loc8_.req_skillpoints + " POINTS INVESTED IN " + com.ea.components.SkillSelectionComponent.DS_CAT_NAMES[this.m_CurrentCategory];
         this.mSkillInfoBox.categoryRequirementText._visible = true;
         this.mPointRequirementBackdrop._visible = true;
      }
      else
      {
         this.mSkillInfoBox.categoryRequirementText._visible = false;
         this.mPointRequirementBackdrop._visible = false;
      }
      this.mSkillInfoBox.descriptionText.text = _loc8_.desc_text;
      var _loc11_ = _loc8_.rank >= _loc8_.max_rank;
      var _loc13_ = _loc8_.rank > 0 && !_loc11_;
      this.mSkillInfoBox.nextRankText._visible = _loc13_;
      this.mSkillInfoBox.nextRankDescText._visible = _loc13_;
      this.mSkillInfoBox.nextRankDescText.text = _loc8_.next_rank_text;
      this.SetLearnBtnVisible(!_loc11_ && _loc9_.unused_points > 0 && _loc8_.status == "available");
      this.mSkillInfoBox.learnSkillBtn.setEnable(true);
      this.mSkillInfoBox.learnSkillBtn.setLabel(_loc8_.rank == 0 ? "LEARN SKILL" : "LEARN NEXT RANK");
      var _loc15_ = new com.ea.common.components.ImageHelper(this.mSkillInfoBox.skillIcon);
      _loc15_.LoadImage("img://TexPack\\256_" + _loc8_.icon);
      this.mSkillInfoBox.skillIcon._alpha = _loc8_.rank != 0 ? 100 : 50;
   }
   function OnSkillListItemUnselected(itemIndexX, itemIndexY, mcItem)
   {
      mcItem.selected = false;
   }
   function OnSkillListItemRollOver(itemIndexX, itemIndexY, mcItem)
   {
   }
   function OnSkillListItemRollOut(itemIndexX, itemIndexY, mcItem)
   {
   }
   function SetSkillMode(lsMode)
   {
      this.mSkillListHeader.gotoAndPlay(lsMode);
      this.mSkillInfoBox.headerMC.gotoAndPlay(lsMode);
      this.m_SelectedSkillIconRankClip.gotoAndStop(lsMode);
      this.mPointRequirementBackdrop.gotoAndStop(lsMode);
   }
   function InitListBox(lnNumSkills, lsBoxItemName)
   {
      this.mListBox.Init(lnNumSkills,false,false,lsBoxItemName);
   }
   function OnPressLearnSkillButton()
   {
      this.mSkillInfoBox.learnSkillBtn.setEnable(false);
      if(com.ea.components.SkillSelectionComponent.DS_Learn(this.m_SelectedSkillID))
      {
         this.OnSSLearnSkillResultReceived();
      }
      else
      {
         this.mSkillInfoBox.learnSkillBtn.setEnable(true);
      }
   }
   function OnSSLearnSkillResultReceived()
   {
      this.mSkillInfoBox.learnSkillBtn.setEnable(true);
      this.mSkillInfoBox.gotoAndPlay("newSkillAnim");
      var _loc2_ = this.mListBox.GetSelectedDataIndex();
      var _loc3_;
      if(this.mListBox.IsIndexInView(_loc2_.x,_loc2_.y))
      {
         this.UpdateSkillStats();
         this.mListBox.Refresh();
         _loc3_ = com.ea.components.SkillListBoxItem(this.mListBox.GetSelectedItem());
         this.OnSkillListItemSelected(0,_loc2_.y,_loc3_);
      }
      else
      {
         this.UpdateList(this.m_CurrentCategory);
      }
   }
   function OnSSSkillStatsReceived()
   {
      com.ea.components.SkillSelectionComponent.DS_Stats();
      this.mBtnRaceCategory.numPoints = _global.mSSSkillStats.race_points;
      this.mBtnExploreCategory.numPoints = _global.mSSSkillStats.explore_points;
      this.mBtnPursueCategory.numPoints = _global.mSSSkillStats.pursue_points;
      this.DS_NotifyOwner();
   }
   function GetSkillListItemIDForCategory(category)
   {
      if(this.m_CurrentCategory == com.ea.components.SkillSelectionComponent.SKILL_CAT_RACE)
      {
         return "SkillListBoxItemRace";
      }
      if(this.m_CurrentCategory == com.ea.components.SkillSelectionComponent.SKILL_CAT_EXPLORE)
      {
         return "SkillListBoxItemExplore";
      }
      if(this.m_CurrentCategory == com.ea.components.SkillSelectionComponent.SKILL_CAT_PURSUE)
      {
         return "SkillListBoxItemPursue";
      }
   }
   function UpdateSkillStats()
   {
      com.ea.components.SkillSelectionComponent.DS_Stats();
      var _loc2_ = this.GetCategoryPointsSpent();
      if(_loc2_ == 0)
      {
         this.mSkillListHeader.pointsLearnedTxt.text = "NO SKILL POINTS SPENT";
      }
      else if(_loc2_ == 1)
      {
         this.mSkillListHeader.pointsLearnedTxt.text = "1 SKILL POINT SPENT";
      }
      else
      {
         this.mSkillListHeader.pointsLearnedTxt.text = _loc2_ + " SKILL POINTS SPENT";
      }
      this.OnSSSkillStatsReceived();
   }
   function DS_ListDefaults()
   {
      var _loc2_ = this.mListBox;
      if(isNaN(Number(_loc2_.m_ItemHeight)) || Number(_loc2_.m_ItemHeight) <= 0)
      {
         _loc2_.m_ItemHeight = 75;
      }
      if(isNaN(Number(_loc2_.m_ItemWidth)))
      {
         _loc2_.m_ItemWidth = 0;
      }
      if(isNaN(Number(_loc2_.m_VisibleColumns)) || Number(_loc2_.m_VisibleColumns) <= 0)
      {
         _loc2_.m_VisibleColumns = 1;
      }
      if(isNaN(Number(_loc2_.m_VisibleRows)) || Number(_loc2_.m_VisibleRows) <= 0)
      {
         _loc2_.m_VisibleRows = 3;
      }
   }
   function DS_FixListLayout()
   {
      var _loc2_ = this.mListBox;
      var _loc3_ = Number(_loc2_.m_ItemHeight);
      if(isNaN(_loc3_) || _loc3_ <= 0)
      {
         _loc3_ = 75;
      }
      var _loc4_ = Number(_loc2_.m_VisibleRows);
      if(isNaN(_loc4_) || _loc4_ <= 0)
      {
         _loc4_ = 3;
      }
      var _loc5_ = 0;
      var _loc6_;
      while(_loc5_ < _loc4_)
      {
         _loc6_ = _loc2_.m_mcContainer["item_0" + _loc5_];
         if(_loc6_ != undefined)
         {
            _loc6_._x = 0;
            _loc6_._y = _loc5_ * _loc3_;
            if(_loc6_.__dsListen != true && _loc6_.listeners != undefined && _loc6_.addListener != undefined)
            {
               _loc6_.addListener(_loc6_.listeners);
               _loc6_.__dsListen = true;
            }
            _loc6_.selected = false;
         }
         _loc5_ += 1;
      }
      if(_loc2_.m_mcHitBox != undefined)
      {
         _loc2_.m_mcHitBox._x = 0;
         _loc2_.m_mcHitBox._y = 0;
         _loc2_.m_mcHitBox._height = _loc4_ * _loc3_;
      }
      _loc2_.Refresh();
   }
   function UpdateList(category)
   {
      this.m_CurrentCategory = category;
      var _loc3_;
      this.UpdateSkillStats();
      com.ea.components.SkillSelectionComponent.DS_SkillList(this.m_CurrentCategory);
      var _loc4_;
      var _loc5_;
      var _loc6_;
      var _loc7_;
      var _loc8_;
      if(_global.mSSSkillList.skill_list.length > 0)
      {
         _loc4_ = "SkillListBoxItemRace";
         _loc4_ = this.GetSkillListItemIDForCategory(this.m_CurrentCategory);
         this.DS_ListDefaults();
         this.mListBox.Init(_global.mSSSkillList.skill_list.length,false,false,_loc4_);
         this.DS_FixListLayout();
         this.mListBox._visible = true;
         _loc5_ = 0;
         _loc6_ = 0;
         while(_loc6_ < _global.mSSSkillList.skill_list.length)
         {
            if(_global.mSSSkillList.skill_list[_loc6_] == this.m_SelectedSkillID)
            {
               _loc5_ = _loc6_;
               break;
            }
            _loc6_ = _loc6_ + 1;
         }
         this.mListBox.SelectItem(0,_loc5_);
         _loc7_ = _global.mSSSkillList.skill_list.length > this.mListBox.GetNumVisibleItems();
         this.mListBoxScrollbar.setScrollProperties(1,0,this.mListBox.GetMaxScrollIndex() - 1,1);
         this.mListBoxScrollbar.disabled = !_loc7_;
         _loc8_ = this.mListBox.GetSelectedDataIndex();
         this.mListBoxScrollbar.position = _loc8_.y;
         this.mListBoxScrollbar._visible = true;
      }
      else
      {
         this.mListBox._visible = false;
         this.mListBoxScrollbar._visible = false;
         this.mSkillInfoBox._visible = false;
      }
   }
   function OnScrollbarUpdate(_params)
   {
      this.mListBox.SetIndexByScrollPosition(_params.position);
   }
   function GetCategoryPointsSpent()
   {
      if(this.m_CurrentCategory == com.ea.components.SkillSelectionComponent.SKILL_CAT_RACE)
      {
         return _global.mSSSkillStats.race_points;
      }
      if(this.m_CurrentCategory == com.ea.components.SkillSelectionComponent.SKILL_CAT_EXPLORE)
      {
         return _global.mSSSkillStats.explore_points;
      }
      if(this.m_CurrentCategory == com.ea.components.SkillSelectionComponent.SKILL_CAT_PURSUE)
      {
         return _global.mSSSkillStats.pursue_points;
      }
      return 0;
   }
   function dispose()
   {
      this.mListBox.removeListener(this.mListBoxListeners);
      this.mListBoxScrollbar.removeEventListener("scroll",this.mListBoxScrollbarListeners.onScroll);
      this.mSkillInfoBox.learnSkillBtn.removeListener(this.mLearnButtonListener);
      Mouse.removeListener(this);
   }
   function ShowMostPointsFirst(value)
   {
      this.mbShowMostPointsFirst = value;
   }
   function ShowUnlockedFirst(value)
   {
      this.mbShowUnlockedFirst = value;
   }
   function onMouseWheel(delta, target)
   {
      if(delta < 0)
      {
         if(this.mListBoxScrollbar.position < _global.mSSSkillList.skill_list.length)
         {
            this.mListBoxScrollbar.position += 1;
         }
      }
      else if(delta > 0)
      {
         if(this.mListBoxScrollbar.position > 0)
         {
            this.mListBoxScrollbar.position -= 1;
         }
      }
   }
   function OnSelectRaceTab()
   {
      this.m_SkillMode = com.ea.components.SkillSelectionComponent.STATE_RACE;
      this.mBtnRaceCategory.active = true;
      this.mBtnPursueCategory.active = false;
      this.mBtnExploreCategory.active = false;
      this.SetSkillMode(this.m_SkillMode);
      this.UpdateList(com.ea.components.SkillSelectionComponent.SKILL_CAT_RACE);
   }
   function OnSelectExploreTab()
   {
      this.m_SkillMode = com.ea.components.SkillSelectionComponent.STATE_EXPLORE;
      this.mBtnRaceCategory.active = false;
      this.mBtnPursueCategory.active = false;
      this.mBtnExploreCategory.active = true;
      this.SetSkillMode(this.m_SkillMode);
      this.UpdateList(com.ea.components.SkillSelectionComponent.SKILL_CAT_EXPLORE);
   }
   function OnSelectPursueTab()
   {
      this.m_SkillMode = com.ea.components.SkillSelectionComponent.STATE_PURSUE;
      this.mBtnRaceCategory.active = false;
      this.mBtnPursueCategory.active = true;
      this.mBtnExploreCategory.active = false;
      this.SetSkillMode(this.m_SkillMode);
      this.UpdateList(com.ea.components.SkillSelectionComponent.SKILL_CAT_PURSUE);
   }
}
