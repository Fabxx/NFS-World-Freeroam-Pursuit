class com.ea.SafeHouse.VisualCustomization extends com.ea.screens.PanedScreen
{
   var _toolTip;
   var mActiveCar;
   var mWebHelp;
   var m_CascadeMenuHelper;
   var m_Delegates;
   var m_ExitToHubButtonListeners;
   var m_GamePersona;
   var m_PaintShopButtonListeners;
   var m_PerformancePartsButtonListeners;
   var m_RentalIndicator;
   var m_Screen;
   var m_SkillModShopButtonListeners;
   var m_VanityShopButtonListeners;
   var m_VinylShopButtonListeners;
   var m_Wallet;
   var m_btn_exitToHub;
   var m_btn_paintShop;
   var m_btn_perfParts;
   var m_btn_skillModShop;
   var m_btn_vanityShop;
   var m_btn_vinylShop;
   var m_targetNextTransition;
   static var DRIVER_SKILLS_MODE = true;
   var SCREEN_TAG = "[VisualCustomization]";
   function VisualCustomization(screen)
   {
      super(screen);
      gfx.events.EventDispatcher.initialize(this);
      _global.RootClass = this;
      this.m_Delegates = new Object();
      this.m_Delegates.exitHub = mx.utils.Delegate.create(this,this.ExitHubPressEventHandler);
      this.m_Delegates.paintShop = mx.utils.Delegate.create(this,this.PaintShopPressEventHandler);
      this.m_Delegates.vinylShop = mx.utils.Delegate.create(this,this.VinylShopPressEventHandler);
      this.m_Delegates.performanceParts = mx.utils.Delegate.create(this,this.PerformancePartsOnPressHandler);
      this.m_Delegates.vanityShop = mx.utils.Delegate.create(this,this.VanityShopOnPressHandler);
      this.m_Delegates.skillModShop = mx.utils.Delegate.create(this,this.SkillModShopOnPressHandler);
      this.m_ExitToHubButtonListeners = new Object();
      this.m_PaintShopButtonListeners = new Object();
      this.m_VinylShopButtonListeners = new Object();
      this.m_PerformancePartsButtonListeners = new Object();
      this.m_VanityShopButtonListeners = new Object();
      this.m_SkillModShopButtonListeners = new Object();
      this.m_ExitToHubButtonListeners.onPress = this.m_Delegates.exitHub;
      this.m_PaintShopButtonListeners.onPress = this.m_Delegates.paintShop;
      this.m_VinylShopButtonListeners.onPress = this.m_Delegates.vinylShop;
      this.m_PerformancePartsButtonListeners.onPress = this.m_Delegates.performanceParts;
      this.m_VanityShopButtonListeners.onPress = this.m_Delegates.vanityShop;
      this.m_SkillModShopButtonListeners.onPress = this.m_Delegates.skillModShop;
      com.ea.SafeHouse.SafeHouse_Util.CursorManager.Get();
      com.ea.util.KeyboardNavigation.Set(Key.ESCAPE,this,this.ExitHubPressEventHandler);
   }
   function OnIntroComplete()
   {
      com.ea.common.Generic.Utils.Log(this.SCREEN_TAG + " OnIntroComplete");
      this.Initialize();
   }
   function Initialize()
   {
      this.m_btn_exitToHub = this.m_Screen.pane_UL.m_btn_exitToHub;
      this.m_btn_paintShop = this.m_Screen.pane_MR.m_content.m_btn_paintShop;
      this.m_btn_vinylShop = this.m_Screen.pane_MR.m_content.m_btn_vinylShop;
      this.m_btn_perfParts = this.m_Screen.pane_MR.m_content.m_btn_PerfPartsShop;
      this.m_btn_vanityShop = this.m_Screen.pane_MR.m_content.m_btn_vanityShop;
      this.m_btn_vanityShop.hasNewFlag = true;
      this.mWebHelp = this.m_Screen.pane_MR.webHelp;
      this.mWebHelp.setTooltip("TXT_CMN_TOOLTIP_VIEW_HELP");
      this.m_Wallet = this.m_Screen.pane_UR.m_Wallet;
      this.m_RentalIndicator = this.m_Screen.pane_BL.mRentalIndicator;
      this.m_RentalIndicator.InitTimeRemaining();
      this.m_CascadeMenuHelper = this.m_Screen.pane_MR.m_content.buttonHelper;
      this.m_CascadeMenuHelper.items = ["m_btn_vanityShop","m_btn_PerfPartsShop","m_btn_vinylShop","m_btn_paintShop"];
      this.m_CascadeMenuHelper.initialize();
      this.m_btn_exitToHub.setLabel("CMN_BACK_TO_SAFEHOUSE");
      this.m_btn_paintShop.setLabel("CMN_PAINT_SHOP");
      this.m_btn_vinylShop.setLabel("CMN_VINYL_SHOP");
      this.m_btn_exitToHub.addListener(this.m_ExitToHubButtonListeners);
      this.m_btn_paintShop.addListener(this.m_PaintShopButtonListeners);
      this.m_btn_vinylShop.addListener(this.m_VinylShopButtonListeners);
      this.m_btn_perfParts.addListener(this.m_PerformancePartsButtonListeners);
      this.m_btn_vanityShop.addListener(this.m_VanityShopButtonListeners);
      com.ea.gameapi.command.Command.SafeHouseSetCameraTarget(0);
      com.ea.gameapi.command.Command.GetPersonaInfo(0,false);
      com.ea.util.SFX.PlaySound(com.ea.util.SFX.GADGET_SHOW_SFX);
      if(this.IsActiveCarRented())
      {
         com.ea.gameapi.command.Command.EndGadget(com.ea.gameapi.enum.GadgetName.WebHelp.value);
         com.ea.common.Generic.Utils.TriggerTransition("CannotCustomizeRental");
      }
   }
   function IsActiveCarRented()
   {
      _global.mSafeHouseActiveCar = com.ea.Requests.Request_SafeHouseActiveCar.SyncRequest();
      this.mActiveCar = _global.mSafeHouseActiveCar;
      return !this.mActiveCar.ActiveCar.Owned;
   }
   function ShutDown()
   {
      com.ea.SafeHouse.SafeHouse_Util.CursorManager.Get().Reset();
      this.removeListeners();
   }
   function removeListeners()
   {
      this.m_btn_exitToHub.removeListener(this.m_ExitToHubButtonListeners);
      this.m_btn_paintShop.removeListener(this.m_PaintShopButtonListeners);
      this.m_btn_vinylShop.removeListener(this.m_VinylShopButtonListeners);
      this.m_btn_perfParts.removeListener(this.m_PerformancePartsButtonListeners);
      this.m_btn_vanityShop.removeListener(this.m_VanityShopButtonListeners);
   }
   function ExitHubPressEventHandler(evtObj)
   {
      com.ea.util.KeyboardNavigation.Enable = false;
      this.m_Wallet.EnableBoostButton(false);
      this.ReturnToLastScreen();
   }
   function PaintShopPressEventHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterPaintShop();
   }
   function PerformancePartsOnPressHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterPerformanceShop();
   }
   function VinylShopPressEventHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterVinylShop();
   }
   function VanityShopOnPressHandler(evtObj)
   {
      com.ea.gameapi.command.Command.SafeHouseEnterVanityShop();
   }
   function SkillModShopOnPressHandler()
   {
   }
   function showToolTip(message)
   {
      this._toolTip = new com.ea.components.ToolTip(message,this.m_Screen);
   }
   function destroyToolTip()
   {
      if(this._toolTip)
      {
         this._toolTip.destroy();
         this._toolTip = null;
      }
   }
   function OnPopupClosed()
   {
      arguments = arguments[0];
      var _loc0_;
      if((_loc0_ = arguments) === "CannotCustomize_OK")
      {
         this.ReturnToLastScreen();
      }
   }
   function ReturnToLastScreen(Void)
   {
      this.ShutDown();
      com.ea.gameapi.command.Command.SafeHouseEnterHub();
   }
   function TriggerTransition(transition, closeAnimationNeeded)
   {
      if(closeAnimationNeeded == undefined)
      {
         closeAnimationNeeded = true;
      }
      if(closeAnimationNeeded)
      {
         this.m_targetNextTransition = transition;
         this.executeCloseAnimation();
      }
      else
      {
         com.ea.gameapi.command.Command.EndGadget(com.ea.gameapi.enum.GadgetName.WebHelp.value);
         com.ea.common.Generic.Utils.TriggerTransition(transition);
      }
   }
   function executeCloseAnimation()
   {
      this.m_RentalIndicator.AnimateOut();
      this.m_Screen.gotoAndPlay("leave");
      com.ea.util.SFX.PlaySound(com.ea.util.SFX.GADGET_HIDE_SFX);
   }
   function onHidden()
   {
      com.ea.gameapi.command.Command.EndGadget(com.ea.gameapi.enum.GadgetName.WebHelp.value);
      com.ea.common.Generic.Utils.TriggerTransition(this.m_targetNextTransition);
   }
   function OnBoostShopCompleteReceived()
   {
      com.ea.gameapi.command.Command.GetPersonaInfo(0,false);
   }
   function OnGamePersonaReceived()
   {
      if(_global.mGamePersona.isSelf)
      {
         com.ea.common.Generic.Utils.Log(this.SCREEN_TAG + " Persona Info Received!");
         this.m_GamePersona = _global.mGamePersona;
         this.m_Wallet.SetValuesFromPersona(this.m_GamePersona);
      }
      this.m_Wallet.EnableBoostButton(true);
   }
}
