class com.ea.Progression.SkillSelection
{
   var _screen;
   var addEventListener;
   var dispatchEvent;
   var helpButtonListener;
   var mEventListener;
   var mSkillSelectionComponent;
   var m_FinishButtonListener;
   var m_Help;
   var m_HelpButton;
   var myname;
   var mPrevRoot;
   var mClosing = false;
   static var SHOW_LABEL = "show";
   var DATA_SOURCE = "GBE";
   var SCREEN_TAG = "[SkillSelection]";
   static var MINIMUM_HEIGHT_FOR_BACKGROUND = 640;
   var SELECT_BUTTON_SFX = "SELECT_BUTTON";
   var GADGET_SHOW_SFX = "GADGET_SHOW";
   var GADGET_HIDE_SFX = "GADGET_HIDE";
   var SKILLS_FEATURE = "SKILLS_VIEW";
   function SkillSelection(screen)
   {
      this.mPrevRoot = _global.RootClass;
      _global.RootClass = this;
      gfx.events.EventDispatcher.initialize(this);
      this.myname = "heythere";
      this._screen = screen;
      this._screen.screenTitle.text = "DRIVER SKILLS:";
      this._screen.screenSubTitle.text = "";
      this._screen.unusedPointsText.text = "";
      this.mSkillSelectionComponent = this._screen.m_SkillSelectionComp;
      this.m_FinishButtonListener = new Object();
      this.m_FinishButtonListener.onPress = mx.utils.Delegate.create(this,this.OnPressFinishButton);
      this.mEventListener = new Object();
      this.mEventListener.OnSSSkillStatsReceived = mx.utils.Delegate.create(this,this.HandleSSSkillStatsReceived);
      this.addEventListener("OnSSSkillStatsReceived",this.mEventListener.OnSSSkillStatsReceived);
      this.OnPush();
   }
   function GetDataSource(Void)
   {
      return this.DATA_SOURCE;
   }
   function Initialize()
   {
      this.m_Help = this._screen.mHelp;
      this.m_Help._visible = false;
      this._screen.finishBtn.addListener(this.m_FinishButtonListener);
      if(this._screen.finishBtn.setLabel != undefined)
      {
         this._screen.finishBtn.setLabel("FINISHED");
      }
      this.mSkillSelectionComponent.OnSelectRaceTab();
      this.m_HelpButton = this._screen.mHelpButton;
      this.m_HelpButton.setEnable(true);
      this.m_HelpButton.setTooltip("TXT_TLTP_CMN_HELP");
      this.helpButtonListener = new Object();
      this.helpButtonListener.onRelease = mx.utils.Delegate.create(this,this.handleHelpButtonRelease);
      this.m_HelpButton.addListener(this.helpButtonListener);
      this.HandleSSSkillStatsReceived();
   }
   function OnPush()
   {
      this._screen.gotoAndPlay(com.ea.Progression.SkillSelection.SHOW_LABEL);
      com.ea.util.SFX.PlaySound(this.GADGET_SHOW_SFX);
   }
   function close()
   {
      if(this.mClosing)
      {
         return undefined;
      }
      this.mClosing = true;
      this._screen.finishBtn.removeListener(this.m_FinishButtonListener);
      this.mSkillSelectionComponent.dispose();
      this._screen.gotoAndPlay("hide");
      com.ea.util.SFX.PlaySound(this.GADGET_HIDE_SFX);
   }
   function onShow()
   {
      this.Initialize();
   }
   function onHidden()
   {
      if(this.mPrevRoot != undefined)
      {
         _global.RootClass = this.mPrevRoot;
      }
      if(_global.DSOnSkillWindowClosed != undefined)
      {
         _global.DSOnSkillWindowClosed();
      }
      else
      {
         flash.external.ExternalInterface.call("Request","PostEventComplete");
         com.ea.common.Generic.Utils.TriggerTransition("Exit");
      }
   }
   function OnIsInPostRaceReplyReceived()
   {
   }
   function OnPressFinishButton()
   {
      this.close();
   }
   function onResize()
   {
   }
   function OnSSSkillStatsReceived()
   {
      this.dispatchEvent({type:"OnSSSkillStatsReceived"});
   }
   function OnDriverSkillPointsChanged(unused)
   {
      var _loc3_ = Number(unused);
      if(isNaN(_loc3_) || _loc3_ <= 0)
      {
         this._screen.screenSubTitle.text = "NO AVAILABLE SKILL POINTS";
         this._screen.unusedPointsText.text = "NO UNUSED SKILL POINTS";
      }
      else if(_loc3_ == 1)
      {
         this._screen.screenSubTitle.text = "CHOOSE 1 NEW SKILL";
         this._screen.unusedPointsText.text = "1 UNUSED SKILL POINT";
      }
      else
      {
         this._screen.screenSubTitle.text = "CHOOSE " + _loc3_ + " NEW SKILLS";
         this._screen.unusedPointsText.text = _loc3_ + " UNUSED SKILL POINTS";
      }
   }
   function HandleSSSkillStatsReceived()
   {
      this.OnDriverSkillPointsChanged(_global.mSSSkillStats.unused_points);
   }
   function OnFeatureFirstClickReceived()
   {
   }
   function handleHelpButtonRelease()
   {
      this.m_Help._visible = !this.m_Help._visible;
   }
}
