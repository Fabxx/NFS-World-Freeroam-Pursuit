class com.ea.PostRace.PostRace
{
   var _chat;
   var _flowButton;
   var _movie;
   var _state;
   var dispatchEvent;
   var mBusy;
   var mEventTitle;
   var mPurchaseBox;
   var mSubPageLoader;
   var mcDurabilityCallout;
   var DATA_SOURCE = "GBE";
   static var MINIMUM_HEIGHT_FOR_BACKGROUND = 650;
   var GADGET_HIDE_SFX = "RESULTS_SCREEN_HIDE";
   var GADGET_WAIT_SFX = "GADGET_WAIT";
   var STATE_SHOW = {label:"show",swfFile:""};
   var STATE_RESULTS = {label:"results",swfFile:"circuit.swf"};
   var STATE_RESULTS_PURSUIT_COOP = {label:"results",swfFile:"PursuitCoopStandings.swf"};
   var STATE_PURSUIT_INTRO = {label:"hidden",swfFile:"PostPursuitIntro.swf"};
   var STATE_PURSUIT_SHOW = {label:"show",swfFile:""};
   var STATE_PURSUIT = {label:"results",swfFile:"pursuit.swf"};
   var STATE_TEAM_ESCAPE = {label:"results",swfFile:"TeamEscape.swf"};
   var STATE_REWARDS = {label:"rewards",swfFile:"RewardsView.swf"};
   var STATE_LUCKY_DRAW = {label:"rewards",swfFile:"LuckyBox.swf"};
   var STATE_UNLOCKS = {label:"rewards",swfFile:"UnlocksView.swf"};
   var STATE_GETSKILLS = {label:"wait",swfFile:""};
   var STATE_HIDE = {label:"hide",swfFile:""};
   var STATE_LEVEL_UP = {label:"rewards",swfFile:"UnlocksView.gfx"};
   var delegates = new Object();
   var _gameModeId = 0;
   var mPendingSkills = false;
   var mDSWindow;
   var mDSClosed = false;
   function ShowSkillsWindow()
   {
      var self = this;
      var _loc3_ = _level0.createEmptyMovieClip("dsSkillWindow",16000);
      this.mDSWindow = _loc3_;
      _loc3_._x = 0;
      _loc3_._y = 0;
      _global.DSOnSkillWindowClosed = function()
      {
         self.CloseSkillsWindow();
      };
      _global.DSPrevSubPageLoader = _global.SubPageLoader;
      var _loc10_ = new Object();
      _loc10_.onLoadInit = function(screen)
      {
      };
      _global.SubPageLoader = _loc10_;
      var _loc11_ = new MovieClipLoader();
      var _loc12_ = new Object();
      _loc12_.onLoadError = function()
      {
         self.CloseSkillsWindow();
      };
      _loc11_.addListener(_loc12_);
      _loc11_.loadClip("SkillSelection.swf",_loc3_);
   }
   function OnDriverSkillPointsChanged(unused)
   {
      if(this.mDSWindow == undefined)
      {
         return undefined;
      }
      var _loc3_ = "";
      if(unused == 1)
      {
         _loc3_ = "1 UNUSED SKILL POINT";
      }
      else if(unused > 1)
      {
         _loc3_ = unused + " UNUSED SKILL POINTS";
      }
      this.mDSWindow.pointsTxt.text = _loc3_;
   }
   function CloseSkillsWindow()
   {
      if(this.mDSClosed)
      {
         return undefined;
      }
      this.mDSClosed = true;
      if(_global.DSPrevSubPageLoader != undefined)
      {
         _global.SubPageLoader = _global.DSPrevSubPageLoader;
      }
      if(this.mDSWindow != undefined)
      {
         this.mDSWindow.removeMovieClip();
      }
      this.mDSWindow = undefined;
      _global.DSOnSkillWindowClosed = undefined;
      flash.external.ExternalInterface.call("Request","PostEventComplete");
      com.ea.common.Generic.Utils.TriggerTransition("Exit");
   }
   function PostRace(screen)
   {
      this._movie = screen;
      _global.RootClass = this;
      gfx.events.EventDispatcher.initialize(this);
      this.mBusy = 0;
      Stage.addListener(this);
   }
   function set state(value)
   {
      this._state = value;
      if(this._state.label != "")
      {
         this._movie.gotoAndPlay(this._state.label);
      }
      if(this._state.swfFile != "")
      {
         this.mSubPageLoader.LoadPage(this._state.swfFile);
         flash.external.ExternalInterface.call("Request","Debug_NotifyState",this._state.swfFile);
      }
      this.enableNextButton();
   }
   function onIntroComplete()
   {
      com.ea.gameapi.command.Command.GetEventMode();
      com.ea.gameapi.command.Command.PostEventStart();
      this.StoreWasJustInPostRace();
      if(this.DATA_SOURCE == "local")
      {
         _global.mEventMode = new Object();
         _global.mEventMode.mode = com.ea.gameapi.enum.GAME_MODE.CIRCUIT.ordinal;
      }
      this._gameModeId = Number(_global.mEventMode.mode);
      this.initialize();
      this.mPurchaseBox = this._movie.mRecommendation;
      this.InitSuggestSale(this._gameModeId);
      switch(this._gameModeId)
      {
         case com.ea.gameapi.enum.GAME_MODE.PURSUIT.ordinal:
            this._chat._visible = false;
            this.GoToPursuitIntro();
            break;
         case com.ea.gameapi.enum.GAME_MODE.TEAM_ESCAPE.ordinal:
            this._chat._visible = true;
            this._chat.start();
            this.GoToTeamEscape();
            break;
         case com.ea.gameapi.enum.GAME_MODE.PURSUIT_COOP.ordinal:
         case com.ea.gameapi.enum.GAME_MODE.MULTIPLAYER_PURSUIT.ordinal:
            this._chat._visible = true;
            this._chat.start();
            this.GoToPursuitIntro();
            break;
         default:
            this._chat._visible = true;
            this._chat.start();
            this.GoToShow();
      }
      this.mcDurabilityCallout = _level0.DurabilityCallout;
   }
   function onShow()
   {
      this.gotoNextState();
   }
   function GetNavButton()
   {
      return this._flowButton;
   }
   function GetChat()
   {
      return this._chat;
   }
   function GetTitle()
   {
      return this.mEventTitle;
   }
   function SetBackingColour(colour)
   {
      this._movie.mc_glowFrame.mc_glowFrameGroup.gotoAndPlay(colour);
   }
   function onResize()
   {
      this.handleResize();
   }
   function OnPush()
   {
      this.handleResize();
   }
   function StoreWasJustInPostRace()
   {
      com.ea.gameapi.command.Command.SetSessionValue("WasJustInPostRace","Global","true");
   }
   function handleResize()
   {
      var _loc2_ = Stage.height < com.ea.PostRace.PostRace.MINIMUM_HEIGHT_FOR_BACKGROUND;
      var _loc3_;
      if(_loc2_)
      {
         _loc3_ = 0.1;
         this._movie._x = this._movie._width * _loc3_ / 2;
         this._movie._y = this._movie._height * _loc3_ / 2;
         this._movie._xscale = (1 - _loc3_) * 100;
         this._movie._yscale = (1 - _loc3_) * 100;
      }
   }
   function initialize()
   {
      this.mBusy = 0;
      this._flowButton = this._movie.nextBtn;
      this.flowButtonChangeToNext();
      var self = this;
      this.delegates.EH_onNextClick = function()
      {
         self.gotoNextState();
      };
      this._flowButton.addEventListener("click",this.delegates.EH_onNextClick);
      this._flowButton.addEventListener("press",this.delegates.EH_onNextClick);
      this._flowButton.onRelease = function()
      {
         self.gotoNextState();
      };
      this.mEventTitle = this._movie.mTitle;
      if(this._gameModeId != com.ea.gameapi.enum.GAME_MODE.PURSUIT.ordinal)
      {
         this._chat = this._movie.chatMc;
      }
      this._movie.mcRenderTarget._visible = false;
      this.mSubPageLoader = this._movie.mSubPageHolder;
      this.mSubPageLoader.removeAllEventListeners();
      this.delegates.EH_onPageLoaded = mx.utils.Delegate.create(this,this.onPageLoaded);
      this.mSubPageLoader.addEventListener(com.ea.components.SubPageLoader.ON_SCREEN_INIT,this.delegates.EH_onPageLoaded);
      this.delegates.PageBusy = mx.utils.Delegate.create(this,this.onPageBusy);
      this.delegates.PageIdle = mx.utils.Delegate.create(this,this.onPageIdle);
      this.enableNextButton();
   }
   function onHide()
   {
      this.mPurchaseBox.ShutDown();
      this.mSubPageLoader.unloadMovie(this._state.swfFile);
      if(this.mPendingSkills)
      {
         this.mPendingSkills = false;
         this.ShowSkillsWindow();
         return undefined;
      }
      flash.external.ExternalInterface.call("Request","PostEventComplete");
      com.ea.common.Generic.Utils.TriggerTransition("Exit");
   }
   function enableNextButton()
   {
      this.mBusy = 0;
      if(this._flowButton != undefined)
      {
         this._flowButton.setAttract(true);
         this._flowButton.setEnable(true);
         this._flowButton.enabled = true;
         this._flowButton._visible = true;
         if(this._flowButton.gotoAndStop != undefined)
         {
            this._flowButton.gotoAndStop("up");
         }
      }
   }
   function gotoNextState()
   {
      var _loc3_;
      var _loc4_;
      var _loc5_;
      switch(this._state)
      {
         case this.STATE_SHOW:
            this.GoToResults();
            return undefined;
         case this.STATE_RESULTS:
            this.GoToRewards();
            return undefined;
         case this.STATE_PURSUIT_INTRO:
            this.GoToPursuitShow();
            return undefined;
         case this.STATE_PURSUIT_SHOW:
            switch(this._gameModeId)
            {
               case com.ea.gameapi.enum.GAME_MODE.PURSUIT.ordinal:
                  this.GoToPursuit();
                  return undefined;
               case com.ea.gameapi.enum.GAME_MODE.PURSUIT_COOP.ordinal:
                  this.GoToPursuitCoop();
                  return undefined;
               case com.ea.gameapi.enum.GAME_MODE.MULTIPLAYER_PURSUIT.ordinal:
               case com.ea.gameapi.enum.GAME_MODE.TEAM_ESCAPE.ordinal:
                  this.GoToTeamEscape();
                  return undefined;
               default:
                  this.GoToPursuit();
                  return undefined;
            }
            break;
         case this.STATE_PURSUIT:
         case this.STATE_RESULTS_PURSUIT_COOP:
            this.GoToRewards();
            return undefined;
         case this.STATE_TEAM_ESCAPE:
            try
            {
               _loc3_ = com.ea.PostPursuit.TeamEscape(this.mSubPageLoader.GetCurrentScreen());
            }
            catch(e)
            {
               _loc3_ = null;
            }
            this.GoToRewards();
            return undefined;
         case this.STATE_REWARDS:
            _loc4_ = com.ea.PostRace.components.RewardsView(this.mSubPageLoader.GetCurrentScreen());
            this.GoToLuckyBox();
            return undefined;
         case this.STATE_LUCKY_DRAW:
            _loc5_ = com.ea.PostRace.components.LuckyBox(this.mSubPageLoader.GetCurrentScreen());
            if(_loc5_ != undefined && (_loc5_.GetRewards().HasLeveledUp || _global.mLuckyBoxLevelUpReply.IsTrue))
            {
               this.GoToLevelUpFlasher();
               return undefined;
            }
            this._movie.backgroundMc._visible = true;
            this.GoToHide();
            return undefined;
            break;
         case this.STATE_UNLOCKS:
            this._movie.backgroundMc._visible = true;
            this.GoToLevelUpFlasher();
            return undefined;
         case this.STATE_GETSKILLS:
            this.GoToHide();
      }
      return undefined;
   }
   function GoToLevelUpFlasher()
   {
      this.LoadExternalLevelUp();
   }
   function LoadExternalLevelUp()
   {
      this.mSubPageLoader.removeEventListener(com.ea.components.SubPageLoader.ON_SCREEN_INIT,this.delegates.EH_onPageLoaded);
      this.delegates.EH_onLevelUpLoaded = mx.utils.Delegate.create(this,this.onLevelUpLoaded);
      this.mSubPageLoader.addEventListener(com.ea.components.SubPageLoader.ON_SCREEN_INIT,this.delegates.EH_onLevelUpLoaded);
      this.state = this.STATE_LEVEL_UP;
   }
   function onLevelUpLoaded()
   {
      var _loc2_ = this.mSubPageLoader.GetCurrentScreen();
      if(_loc2_ != undefined)
      {
         if(_loc2_.navButton != undefined)
         {
            _loc2_.navButton.enabled = false;
         }
      }
      this._flowButton._visible = false;
   }
   function onPageLoaded(evtObj)
   {
      var self = this;
      var _loc3_ = this.mSubPageLoader.GetCurrentScreen();
      if(_loc3_ != undefined)
      {
         _loc3_.OnCompleted = function()
         {
            self.enableNextButton();
         };
         if(_loc3_.EnableNavButton != undefined)
         {
            _loc3_.EnableNavButton(true);
         }
      }
      this.enableNextButton();
   }
   function GoToShow()
   {
      this._movie.backgroundMc._visible = false;
      this.state = this.STATE_SHOW;
   }
   function GoToResults()
   {
      this._movie.backgroundMc._visible = false;
      this.state = this.STATE_RESULTS;
      flash.external.ExternalInterface.call("Request","HandleTutorial",com.ea.gameapi.enum.FeatureTutorial.Results.value,com.ea.interop.enums.GameCore_TutorialSource.kTutorialSource_Race.Value);
      this.HideCallouts();
      this.RequestCallouts();
   }
   function GoToPursuitIntro()
   {
      this.state = this.STATE_PURSUIT_INTRO;
   }
   function GoToPursuitShow()
   {
      this.state = this.STATE_PURSUIT_SHOW;
   }
   function GoToPursuit()
   {
      this.state = this.STATE_PURSUIT;
   }
   function GoToPursuitCoop()
   {
      this.state = this.STATE_RESULTS_PURSUIT_COOP;
   }
   function GoToTeamEscape()
   {
      this.state = this.STATE_TEAM_ESCAPE;
   }
   function GoToRewards()
   {
      this._movie.backgroundMc._visible = true;
      flash.external.ExternalInterface.call("Request","HideTutorial","IntroPopup",0);
      if(this.mcDurabilityCallout != undefined)
      {
         this.mcDurabilityCallout._visible = false;
      }
      this.state = this.STATE_REWARDS;
   }
   function GoToLuckyBox()
   {
      this._movie.backgroundMc._visible = true;
      this._movie.titleFld.text = "TXT_TITLE_LUCKY_BOX";
      var _loc2_ = new com.ea.PostRace.components.PostRaceView(this._movie.titleAnimationMc);
      _loc2_.title = "POSTRACE_LUCKYBOX_TITLE";
      this.state = this.STATE_LUCKY_DRAW;
      flash.external.ExternalInterface.call("Request","HandleTutorial",com.ea.gameapi.enum.FeatureTutorial.LuckyDraw.value,com.ea.interop.enums.GameCore_TutorialSource.kTutorialSource_PostRace.Value);
   }
   function GoToUnlocks()
   {
      this._movie.backgroundMc._visible = true;
      this.state = this.STATE_UNLOCKS;
   }
   function OnSkillsGetAllFailedReceived()
   {
      this.dispatchEvent({type:"OnSkillsGetAllFailedReceived"});
   }
   function OnSkillsGetAllInvalidReceived()
   {
      this.dispatchEvent({type:"OnSkillsGetAllInvalidReceived"});
   }
   function OnSkillsGetAllSucceededReceived()
   {
      this.dispatchEvent({type:"OnSkillsGetAllSucceededReceived"});
   }
   function GoToHide()
   {
      if(this._state == this.STATE_LEVEL_UP)
      {
         this.mPendingSkills = true;
         this.mSubPageLoader.unloadMovie("UnlocksView.gfx");
      }
      this.state = this.STATE_HIDE;
      com.ea.util.SFX.PlaySound(this.GADGET_HIDE_SFX);
   }
   function SkillsReceived()
   {
      if(this._state == this.STATE_GETSKILLS)
      {
         this.GoToHide();
      }
   }
   function flowButtonChangeToNext()
   {
      this._flowButton.setLabel("CMN_NEXT");
   }
   function clickOnFlowButton()
   {
      this.gotoNextState();
   }
   function InitSuggestSale(gameMode)
   {
      switch(gameMode)
      {
         case com.ea.gameapi.enum.GAME_MODE.TEAM_ESCAPE.ordinal:
         case com.ea.gameapi.enum.GAME_MODE.MULTIPLAYER_PURSUIT.ordinal:
         case com.ea.gameapi.enum.GAME_MODE.PURSUIT.ordinal:
            this.mPurchaseBox.Init(com.ea.common.components.PurchaseBox.PurchaseBox.CONTEXT_POST_PURSUIT);
            break;
         default:
            this.mPurchaseBox.Init(com.ea.common.components.PurchaseBox.PurchaseBox.CONTEXT_POST_RACE);
      }
      this.mPurchaseBox.removeAllEventListeners();
      this.mPurchaseBox.addEventListener(com.ea.common.components.PurchaseBox.PurchaseBox.ON_REQUEST_PURCHASE,this.delegates.PageBusy);
      this.mPurchaseBox.addEventListener(com.ea.common.components.PurchaseBox.PurchaseBox.ON_RESULT_RECIEVED,this.delegates.PageIdle);
   }
   function onPageBusy()
   {
      this.SetBusy(false);
   }
   function onPageIdle()
   {
      this.SetBusy(false);
   }
   function IsBusy(Void)
   {
      return false;
   }
   function SetBusy(value)
   {
      this.mBusy = 0;
   }
   function OnDisplayTutorialReceived()
   {
      if(_global.mDisplayTutorial.value)
      {
         this.SetupCallouts();
         this.ShowCallouts();
      }
   }
   function SetupCallouts()
   {
      if(this.mcDurabilityCallout != undefined)
      {
         this.mcDurabilityCallout.titleMc.titleFld.text = "TTRL_DURABILITYLOSS_1_HDR";
         this.mcDurabilityCallout.contentMc.contentFld.text = "TTRL_DURABILITYLOSS_1";
         this.mcDurabilityCallout.gotoAndPlay("top");
      }
   }
   function ShowCallouts()
   {
      if(this.mcDurabilityCallout != undefined)
      {
         this.mcDurabilityCallout._alpha = 100;
      }
   }
   function HideCallouts()
   {
      if(this.mcDurabilityCallout != undefined)
      {
         this.mcDurabilityCallout._alpha = 0;
      }
   }
   function RequestCallouts()
   {
      flash.external.ExternalInterface.call("Request","HandleTutorial",com.ea.gameapi.enum.FeatureTutorial.DurabilityCallout.value,com.ea.interop.enums.GameCore_TutorialSource.kTutorialSource_PostRace.Value);
   }
   function OnPopupClosed()
   {
      var _loc3_ = arguments[0];
      var _loc4_;
      switch(_loc3_)
      {
         case "GetRewardsCANCEL":
            _loc4_ = this.mSubPageLoader.GetCurrentScreen();
            if(_loc4_ != undefined)
            {
               _loc4_.EnableNavButton(true);
            }
            this.SetBusy(false);
            return undefined;
         case "GetRewardsOK":
            this.GoToRewards();
      }
      return undefined;
   }
}
