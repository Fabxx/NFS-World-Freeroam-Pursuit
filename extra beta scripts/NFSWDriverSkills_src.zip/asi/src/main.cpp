// NFSWDriverSkills.asi - NFS World 2015 (offline)
//
// Brings back the July 2010 beta "Driver Skills": skill points earned per level,
// skills tied to the driver profile and applied to every car.
//
// How it works
//  * Flash side (Profile_Skills.gfx / ResultsScreen.gfx) owns the UI and the rules
//    (ranks, level and category requirements, points = driver level - 1).
//  * This ASI owns persistence and the gameplay effect:
//      - Request "NFSWSkillsLoad"  (personaId)        -> loads the ranks and hands them back
//        to Flash through the game's own SetSessionValue("NFSWSkills","Global",data).
//      - Request "NFSWSkillsSave"  (personaId, data)  -> saves the ranks and applies them.
//    data = "101:2,204:1,..." (skill id : rank)
//  * Gameplay: every skill rank maps to the effect of the equivalent vanilla N-star skill mod
//    (gpcore.bin "skillmods/effects/..."). The game evaluates skill mod effects through
//    0x717000 (sum of effects of a type) and 0x716EE0 (effect flags) on the car's
//    customization record (12 effect slots at +0x298). For the local human player's car the
//    ASI evaluates the profile effects instead (in batches of 12 through the game's own
//    function, so caps and units stay vanilla) and, by default, ignores the car's own mods.

#include <windows.h>
#include "SkillTable.h"

// ---------------------------------------------------------------- addresses (nfsw.exe 2015)
static const DWORD kBase              = 0x00400000;
static const DWORD kEffectQuery       = 0x00717000; // float __thiscall (rec, type, sub, float* cap, uint* key, bool any)
static const DWORD kEffectFlags       = 0x00716EE0; // bool  __thiscall (rec, type, bool* a, bool* b)
static const DWORD kQuerySites[]      = { 0x721524, 0x721565, 0x7215A4, 0x7215C5, 0x7215E4,
                                          0x721655, 0x7216B4, 0x721745, 0x7217D4, 0x721805 };
static const DWORD kFlagsSite         = 0x006F7E10;
static const DWORD kGetRecordSlot     = 0x00BC3CA4; // PVehicle skill interface vtable slot 0x104
static const DWORD kGetRecordOrig     = 0x009DBB60; // mov eax,[ecx+30h]; ret
static const DWORD kRegistryGlobal    = 0x00CEA7A4; // interop "Request" registry
static const DWORD kRegisterCmd       = 0x00524410; // void __thiscall (registry, const char*, handler)
static const DWORD kRegisterAllSite   = 0x00522B9F; // call RegisterAll(registry)
static const DWORD kRegisterAll       = 0x004C4C50; // void __cdecl (registry)
static const DWORD kSetSessionValue   = 0x004C2C00; // Request handler: (ctx, args, argc)
static const DWORD kScreenEISlot      = 0x00B729C4; // ExternalInterface::Callback of FE screens
static const DWORD kScreenEIOrig      = 0x004ABBB0;
static const DWORD kGadgetEISlot      = 0x00B2D030; // ExternalInterface::Callback of gadgets
static const DWORD kGadgetEIOrig      = 0x004867E0;
static const int   kMovieSetRetVal    = 0xB4;       // GFxMovieView vtable: SetExternalInterfaceRetVal
// persona level: the "current player persona" cache is not refreshed after a level up,
// the GamePersona sent to the HUD (GetPersonaInfo) is.
static const DWORD kGamePersonaSite   = 0x004D7185; // call GamePersonaToFlash(movie, persona*)
static const DWORD kGamePersonaFn     = 0x004D3E70; // cdecl; persona: +0x10 id (i64), +0x4C level, +0x68 isSelf
static const DWORD kCurPersonaSite    = 0x0051C9B0; // call FEPlayerPersonaToFlash (HandleRequest_Interop_GetCurrentPlayerPersona)
static const DWORD kCurPersonaFn      = 0x00492F70; // thiscall(info, a, b) ret 8; info: +0x18 id (i64), +0x2C Level

static const int   kSlots             = 12;         // effect slots of a customization record
static const int   kRecordEffects     = 0x298;
static const int   kIfaceDriverClass  = 0x94;       // iface(+0xC4) -> PVehicle+0x158
static const int   kMaxEffects        = 64;

// ---------------------------------------------------------------- GFx value
// layout used by the game: interface ptr (+0), type (+4), value (+8); 16 bytes
struct GVal { void* obj; unsigned type; union { double n; const char* s; const char** ms; unsigned char b; } v; };

typedef void (__cdecl *ReqHandler)(void* ctx, const GVal* args, unsigned argc);

// ---------------------------------------------------------------- state
static DWORD    g_delta;
static char     g_dir[MAX_PATH];
static char     g_save[MAX_PATH];
static char     g_log[MAX_PATH];
static bool     g_logOn = true;
static int      g_humanClass = 0;
static int      g_rank[kSkillCount];
static unsigned g_effects[kMaxEffects];
static int      g_effectCount;
static char     g_persona[32] = "default";
static int      g_liveId = -1;    // persona id / level last seen in a GamePersona for the local player
static int      g_liveLevel = 0;
static void*    g_playerRecord;
static void*    g_movie;          // movie view of the ExternalInterface call being processed
static __declspec(align(16)) unsigned char g_fake[0x300];

// ---------------------------------------------------------------- tiny libc
#ifdef NFSW_NOCRT   // build without the C runtime (build.sh); Visual Studio uses the CRT ones
extern "C" void* __cdecl memset(void* d, int c, size_t n) { unsigned char* p = (unsigned char*)d; while (n--) *p++ = (unsigned char)c; return d; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; while (n--) *a++ = *b++; return d; }
#if !defined(__clang__)
#pragma function(memset, memcpy)
#endif
#else
#include <string.h>
#endif
static int  StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); StrCpy(d + n, s, cap - n); }
static bool StrEq(const char* a, const char* b) { if (!a || !b) return false; while (*a && *a == *b) { ++a; ++b; } return *a == *b; }
static void IntToStr(int v, char* out) { char t[16]; int n = 0; bool neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (neg) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static int  ParseInt(const char*& p) { int v = 0; while (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); ++p; } return v; }

static void Log(const char* a, const char* b = 0, const char* c = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w; const char* parts[3] = { a, b, c };
    for (int i = 0; i < 3; ++i) if (parts[i]) WriteFile(h, parts[i], StrLen(parts[i]), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}
static void LogHex(const char* what, DWORD v)
{
    char buf[16]; const char* hx = "0123456789ABCDEF"; buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 8; ++i) buf[2 + i] = hx[(v >> (28 - 4 * i)) & 15];
    buf[10] = 0; Log(what, buf);
}

static inline DWORD A(DWORD va) { return va + g_delta; }
static bool Readable(const void* p, unsigned n) { return p && !IsBadReadPtr(p, n); }

// ---------------------------------------------------------------- patching
static bool PatchCall(DWORD site, DWORD expectTarget, void* fn)
{
    unsigned char* p = (unsigned char*)A(site);
    if (p[0] != 0xE8) return false;
    DWORD target = (DWORD)p + 5 + *(int*)(p + 1);
    if (target != A(expectTarget)) return false;
    DWORD old;
    if (!VirtualProtect(p + 1, 4, PAGE_EXECUTE_READWRITE, &old)) return false;
    *(int*)(p + 1) = (int)((DWORD)fn - ((DWORD)p + 5));
    VirtualProtect(p + 1, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    return true;
}
static bool PatchPtr(DWORD addr, DWORD expect, void* value)
{
    DWORD* p = (DWORD*)A(addr);
    if (*p != A(expect)) return false;
    DWORD old;
    if (!VirtualProtect(p, 4, PAGE_READWRITE, &old)) return false;
    *p = (DWORD)value;
    VirtualProtect(p, 4, old, &old);
    return true;
}

// ---------------------------------------------------------------- profile data
static int FindSkill(int id) { for (int i = 0; i < kSkillCount; ++i) if (kSkills[i].id == id) return i; return -1; }

static void ParseRanks(const char* data)
{
    for (int i = 0; i < kSkillCount; ++i) g_rank[i] = 0;
    const char* p = data;
    while (p && *p) {
        while (*p == ' ' || *p == ',' || *p == ';') ++p;
        if (*p < '0' || *p > '9') { if (*p) ++p; continue; }
        int id = ParseInt(p);
        int rank = 0;
        if (*p == ':') { ++p; rank = ParseInt(p); }
        int i = FindSkill(id);
        if (i >= 0) g_rank[i] = rank < 0 ? 0 : (rank > kSkills[i].maxRank ? kSkills[i].maxRank : rank);
    }
}

static void BuildRanks(char* out, int cap)
{
    out[0] = 0; char num[16];
    for (int i = 0; i < kSkillCount; ++i) {
        if (g_rank[i] <= 0) continue;
        if (out[0]) StrCat(out, ",", cap);
        IntToStr(kSkills[i].id, num); StrCat(out, num, cap); StrCat(out, ":", cap);
        IntToStr(g_rank[i], num); StrCat(out, num, cap);
    }
}

static void RebuildEffects()
{
    int n = 0;
    for (int i = 0; i < kSkillCount && n < kMaxEffects; ++i) {
        int r = g_rank[i];
        if (r <= 0) continue;
        char key[64]; char val[64];
        // optional ini override: [Effects] EXTENDED_NOS_3=0x12345678
        StrCpy(key, kSkills[i].code, 48); StrCat(key, "_", 64); IntToStr(r, val); StrCat(key, val, 64);
        unsigned eff = kSkills[i].effect[r - 1];
        char ini[MAX_PATH]; StrCpy(ini, g_dir, MAX_PATH); StrCat(ini, "NFSWDriverSkills.ini", MAX_PATH);
        if (GetPrivateProfileStringA("Effects", key, "", val, sizeof(val), ini) > 2 && val[0] == '0' && (val[1] == 'x' || val[1] == 'X')) {
            unsigned v = 0; for (const char* q = val + 2; *q; ++q) { char ch = *q; int d = ch >= '0' && ch <= '9' ? ch - '0' : ch >= 'a' && ch <= 'f' ? ch - 'a' + 10 : ch >= 'A' && ch <= 'F' ? ch - 'A' + 10 : -1; if (d < 0) break; v = v * 16 + d; }
            eff = v;
        }
        if (eff) g_effects[n++] = eff;
    }
    g_effectCount = n;
}

static void LoadPersona(const char* persona)
{
    StrCpy(g_persona, persona && *persona ? persona : "default", sizeof(g_persona));
    char sect[48]; StrCpy(sect, "Persona_", 48); StrCat(sect, g_persona, 48);
    char data[512];
    GetPrivateProfileStringA(sect, "Skills", "", data, sizeof(data), g_save);
    ParseRanks(data);
    RebuildEffects();
    WritePrivateProfileStringA("General", "LastPersona", g_persona, g_save);
}

static void SavePersona()
{
    char sect[48]; StrCpy(sect, "Persona_", 48); StrCat(sect, g_persona, 48);
    char data[512]; BuildRanks(data, sizeof(data));
    WritePrivateProfileStringA(sect, "Skills", data, g_save);
    WritePrivateProfileStringA("General", "LastPersona", g_persona, g_save);
}

// ---------------------------------------------------------------- GFx helpers
static const char* ArgString(const GVal* a, char* tmp, int cap)
{
    if (!a) return 0;
    unsigned t = a->type & 0x8F;
    if (t == 4) {
        const char* s = (a->type & 0x40) ? (a->v.ms ? *a->v.ms : 0) : a->v.s;
        StrCpy(tmp, s, cap); return tmp;
    }
    if (t == 3) { IntToStr((int)a->v.n, tmp); return tmp; }
    return 0;
}

static void PushSessionValue(void* ctx, const char* id, const char* value)
{
    GVal args[3];
    memset(args, 0, sizeof(args));
    args[0].type = 4; args[0].v.s = id;
    args[1].type = 4; args[1].v.s = "Global";
    args[2].type = 4; args[2].v.s = value;
    ((ReqHandler)A(kSetSessionValue))(ctx, args, 3);
}

static void SetReturnString(const char* value)
{
    void* movie = g_movie;
    if (!Readable(movie, 4)) return;
    void** vt = *(void***)movie;
    if (!Readable(vt + kMovieSetRetVal / 4, 4)) return;
    GVal v; memset(&v, 0, sizeof(v));
    v.type = 4; v.v.s = value;
    typedef void (__fastcall *SetRet)(void*, void*, const GVal*);
    ((SetRet)vt[kMovieSetRetVal / 4])(movie, 0, &v);
}

typedef void (__fastcall *EICallback)(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc);
static void __fastcall Hook_ScreenEI(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc)
{
    void* prev = g_movie; g_movie = movie;
    ((EICallback)A(kScreenEIOrig))(self, edx, movie, method, args, argc);
    g_movie = prev;
}
static void __fastcall Hook_GadgetEI(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc)
{
    void* prev = g_movie; g_movie = movie;
    ((EICallback)A(kGadgetEIOrig))(self, edx, movie, method, args, argc);
    g_movie = prev;
}

// ---------------------------------------------------------------- Request handlers
static void __cdecl Req_Load(void* ctx, const GVal* args, unsigned argc)
{
    char tmp[64];
    const char* persona = argc > 0 ? ArgString(&args[0], tmp, sizeof(tmp)) : 0;
    LoadPersona(persona);
    static char data[512];
    BuildRanks(data, sizeof(data));
    PushSessionValue(ctx, "NFSWSkills", data);
    SetReturnString(data);
    Log("[load] persona ", g_persona, data);
}

static void __cdecl Req_Save(void* ctx, const GVal* args, unsigned argc)
{
    char tmp[64]; static char data[512];
    const char* persona = argc > 0 ? ArgString(&args[0], tmp, sizeof(tmp)) : 0;
    const char* d = argc > 1 ? ArgString(&args[1], data, sizeof(data)) : 0;
    if (persona && *persona) StrCpy(g_persona, persona, sizeof(g_persona));
    ParseRanks(d ? d : "");
    RebuildEffects();
    SavePersona();
    static char back[512]; BuildRanks(back, sizeof(back));
    PushSessionValue(ctx, "NFSWSkills", back);
    SetReturnString(back);
    Log("[save] persona ", g_persona, back);
}

static void __cdecl Req_Log(void*, const GVal* args, unsigned argc)
{
    char tmp[256];
    if (argc > 0) Log("[flash] ", ArgString(&args[0], tmp, sizeof(tmp)));
}

static void RegisterCommands(void* registry)
{
    typedef void (__fastcall *RegFn)(void*, void*, const char*, void*);
    RegFn reg = (RegFn)A(kRegisterCmd);
    reg(registry, 0, "NFSWSkillsLoad", (void*)Req_Load);
    reg(registry, 0, "NFSWSkillsSave", (void*)Req_Save);
    reg(registry, 0, "NFSWSkillsLog",  (void*)Req_Log);
    LogHex("[init] commands registered in ", (DWORD)registry);
}

static void __cdecl Hook_RegisterAll(void* registry)
{
    ((void (__cdecl*)(void*))A(kRegisterAll))(registry);
    RegisterCommands(registry);
}


// ---------------------------------------------------------------- persona level
static int SavedLevel(int id)
{
    char sect[48], num[16]; IntToStr(id, num); StrCpy(sect, "Persona_", 48); StrCat(sect, num, 48);
    return (int)GetPrivateProfileIntA(sect, "Level", 0, g_save);
}
static int KnownLevel(int id)
{
    if (id == g_liveId && g_liveLevel > 0) return g_liveLevel;
    return SavedLevel(id);
}
static void __cdecl Hook_GamePersona(void* movie, unsigned char* p)
{
    if (Readable(p, 0x6C) && p[0x68]) {
        int id = *(int*)(p + 0x10), lvl = *(int*)(p + 0x4C);
        if (id > 0 && lvl > 0 && lvl < 1000 && (id != g_liveId || lvl != g_liveLevel)) {
            g_liveId = id; g_liveLevel = lvl;
            if (SavedLevel(id) != lvl) {
                char sect[48], num[16]; IntToStr(id, num); StrCpy(sect, "Persona_", 48); StrCat(sect, num, 48);
                IntToStr(lvl, num); WritePrivateProfileStringA(sect, "Level", num, g_save);
                Log("[level] ", sect, num);
            }
        }
    }
    ((void (__cdecl*)(void*, void*))A(kGamePersonaFn))(movie, p);
}
static void __fastcall Hook_CurPersona(unsigned char* info, void* edx, void* a, void* b)
{
    if (Readable(info, 0x30)) {
        int id = *(int*)(info + 0x18);
        int lvl = id > 0 ? KnownLevel(id) : 0;
        if (lvl > *(int*)(info + 0x2C)) *(int*)(info + 0x2C) = lvl;
    }
    ((void (__fastcall*)(void*, void*, void*, void*))A(kCurPersonaFn))(info, edx, a, b);
}

// ---------------------------------------------------------------- gameplay hooks
typedef float         (__fastcall *QueryFn)(void* rec, void* edx, int type, int sub, float* cap, unsigned* key, int any);
typedef unsigned char (__fastcall *FlagsFn)(void* rec, void* edx, int type, unsigned char* a, unsigned char* b);

static void* __fastcall Hook_GetRecord(void* iface, void*)
{
    void* rec = *(void**)((char*)iface + 0x30);
    int cls = -1;
    if (Readable((char*)iface + kIfaceDriverClass, 4)) cls = *(int*)((char*)iface + kIfaceDriverClass);
    if (cls == g_humanClass) g_playerRecord = rec;
    else if (rec == g_playerRecord) g_playerRecord = 0;
    return rec;
}

static void FillFake(int from)
{
    unsigned* slots = (unsigned*)(g_fake + kRecordEffects);
    for (int i = 0; i < kSlots; ++i) slots[i] = (from + i < g_effectCount) ? g_effects[from + i] : 0;
}

static float __fastcall Hook_Query(void* rec, void* edx, int type, int sub, float* cap, unsigned* key, int any)
{
    QueryFn orig = (QueryFn)A(kEffectQuery);
    if (!rec || rec != g_playerRecord) return orig(rec, edx, type, sub, cap, key, any);

    float total = 0.0f, capOut = 0.0f; unsigned keyOut = 0; bool found = false;
    float c; unsigned k; float r;
    for (int from = 0; from < g_effectCount && !(any && found); from += kSlots) {
        FillFake(from);
        c = 0; k = 0; r = orig(g_fake, 0, type, sub, &c, &k, any);
        if (!k) continue;
        if (!keyOut) { keyOut = k; capOut = c; }
        if (k != keyOut) continue;
        if (any && r > 0.0f) found = true;
        total += r;
    }
    if (cap) *cap = capOut;
    if (key) *key = keyOut;
    if (any) return found ? 1.0f : 0.0f;
    if (total > capOut) total = capOut;
    if (total < 0.0f) total = 0.0f;
    return total;
}

static unsigned char __fastcall Hook_Flags(void* rec, void* edx, int type, unsigned char* a, unsigned char* b)
{
    FlagsFn orig = (FlagsFn)A(kEffectFlags);
    if (!rec || rec != g_playerRecord) return orig(rec, edx, type, a, b);
    for (int from = 0; from < g_effectCount; from += kSlots) {
        FillFake(from);
        if (orig(g_fake, 0, type, a, b)) return 1;
    }
    return 0;
}

// ---------------------------------------------------------------- init
static void Init(HMODULE self)
{
    g_delta = (DWORD)GetModuleHandleA(0) - kBase;
    DWORD n = GetModuleFileNameA(self, g_dir, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    for (int i = (int)n - 1; i >= 0; --i) if (g_dir[i] == '\\' || g_dir[i] == '/') { g_dir[i + 1] = 0; break; }
    char ini[MAX_PATH]; StrCpy(ini, g_dir, MAX_PATH); StrCat(ini, "NFSWDriverSkills.ini", MAX_PATH);
    // the beta driver skills are always on: the vanilla skill-mod system (workshop) is no longer selectable
    g_logOn      = GetPrivateProfileIntA("DriverSkills", "Log", 1, ini) != 0;
    g_humanClass = (int)GetPrivateProfileIntA("DriverSkills", "PlayerDriverClass", 0, ini);
    StrCpy(g_save, g_dir, MAX_PATH); StrCat(g_save, "NFSWDriverSkills.sav", MAX_PATH);
    StrCpy(g_log, g_dir, MAX_PATH);  StrCat(g_log, "NFSWDriverSkills.log", MAX_PATH);
    if (g_logOn) DeleteFileA(g_log);

    // check that this is the expected exe before touching anything
    const unsigned char* q = (const unsigned char*)A(kEffectQuery);
    const unsigned char* f = (const unsigned char*)A(kEffectFlags);
    if (!(q[0] == 0x55 && q[1] == 0x8B && q[2] == 0xEC && f[0] == 0x55 && f[1] == 0x8B && f[2] == 0xEC)) { Log("[init] unknown nfsw.exe, disabled"); return; }

    char last[32];
    GetPrivateProfileStringA("General", "LastPersona", "default", last, sizeof(last), g_save);
    LoadPersona(last);

    int ok = 0;
    for (unsigned i = 0; i < sizeof(kQuerySites) / sizeof(kQuerySites[0]); ++i) ok += PatchCall(kQuerySites[i], kEffectQuery, (void*)Hook_Query);
    ok += PatchCall(kFlagsSite, kEffectFlags, (void*)Hook_Flags);
    ok += PatchPtr(kGetRecordSlot, kGetRecordOrig, (void*)Hook_GetRecord);
    ok += PatchCall(kRegisterAllSite, kRegisterAll, (void*)Hook_RegisterAll);
    ok += PatchPtr(kScreenEISlot, kScreenEIOrig, (void*)Hook_ScreenEI);
    ok += PatchPtr(kGadgetEISlot, kGadgetEIOrig, (void*)Hook_GadgetEI);
    ok += PatchCall(kGamePersonaSite, kGamePersonaFn, (void*)Hook_GamePersona);
    ok += PatchCall(kCurPersonaSite, kCurPersonaFn, (void*)Hook_CurPersona);
    char num[16]; IntToStr(ok, num); Log("[init] patches applied: ", num, " / 17");
    void* reg = *(void**)A(kRegistryGlobal);
    if (reg) RegisterCommands(reg);
    IntToStr(g_effectCount, num); Log("[init] persona ", g_persona, num);
}

extern "C" BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hinst);
        Init(hinst);
    }
    return TRUE;
}
