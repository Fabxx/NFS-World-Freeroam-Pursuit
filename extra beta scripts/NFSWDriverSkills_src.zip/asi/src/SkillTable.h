// Generated from gpcore.bin (skillmods/effects) - best vanilla effect per star tier
// id, max rank, effect collection key per rank (rank N -> vanilla N-star skill mod)
struct SkillDef { int id; const char* code; int maxRank; unsigned int effect[5]; };
static const SkillDef kSkills[] = {
    { 101, "EXTENDED_NOS", 5, { 0x74010CCA, 0x48104922, 0xC23168D6, 0x30C523F2, 0xDA8C1B4C } }, // nitrous_duration -> nitrous_duration_13, nitrous_duration_20, nitrous_duration_34, nitrous_duration_46, nitrous_duration_53
    { 102, "PERFECT_START", 5, { 0x63CC4858, 0x854A7D5F, 0x7682DA73, 0x8EBF93AC, 0x59B04DAE } }, // perfectstart_duration -> perfectstart_duration_015, perfectstart_duration_025, perfectstart_duration_04, perfectstart_duration_045, perfectstart_duration_05
    { 103, "CATCH_UP", 3, { 0xE81A0C8B, 0x114DDFD4, 0x0DE5D2F5, 0x00000000, 0x00000000 } }, // catchup -> catchup_04, catchup_06, catchup_11
    { 104, "DRAGSTER", 3, { 0x5D11C89A, 0x1088AB1B, 0xDA2B62F5, 0x00000000, 0x00000000 } }, // gearratio_enhancement -> gearratio_enhancement_20, gearratio_enhancement_30, gearratio_enhancement_45
    { 105, "NEED_FOR_SPEED", 3, { 0xBEDE66F5, 0xE1E43ABF, 0x9330F796, 0x00000000, 0x00000000 } }, // slingshot_power -> slingshot_power_06, slingshot_power_09, slingshot_power_17
    { 106, "NERVES_OF_STEEL", 3, { 0x8EC61505, 0xEEFBF18B, 0x05290BFA, 0x00000000, 0x00000000 } }, // launchgrip -> launchgrip_15, launchgrip_22, launchgrip_41
    { 107, "RAPID_FIRE", 3, { 0xADD9123B, 0xA9AB9621, 0x77E9A599, 0x00000000, 0x00000000 } }, // nitrous_cooldown -> nitrous_cooldown_10, nitrous_cooldown_15, nitrous_cooldown_28
    { 108, "STRONG_FINISHER", 2, { 0x75601860, 0x5594DBF7, 0x00000000, 0x00000000, 0x00000000 } }, // slingshot_duration -> slingshot_duration_07, slingshot_duration_10
    { 109, "SUPER_SHOT", 3, { 0x6C246D5C, 0x2638D436, 0x00A31CCE, 0x00000000, 0x00000000 } }, // nitrous_power -> nitrous_power_10, nitrous_power_15, nitrous_power_27
    { 110, "TRAFFIC_COP", 3, { 0xF8D2AA22, 0x3046D19B, 0xA640EE8D, 0x00000000, 0x00000000 } }, // trafficmagnet_cooldown -> trafficmagnet_cooldown_07, trafficmagnet_cooldown_14, trafficmagnet_cooldown_28
    { 111, "JUMPSTART", 2, { 0x005FAA44, 0x48BFC23D, 0x00000000, 0x00000000, 0x00000000 } }, // jumpstart -> jumpstart_02, jumpstart_03
    { 112, "ROLLING_FORTRESS", 3, { 0x9699BB2E, 0xEEF4758B, 0x9E23D551, 0x00000000, 0x00000000 } }, // shield_duration -> shield_duration_09, shield_duration_14, shield_duration_28
    { 201, "RADAR", 3, { 0x9D2B4608, 0x356EDB19, 0x58AD9823, 0x00000000, 0x00000000 } }, // radar -> radar_100, radar_150, radar_275
    { 202, "MOST_WANTED", 3, { 0xD7D3CB39, 0x3C9FFCDA, 0x29F9A546, 0x00000000, 0x00000000 } }, // cashreward_pursuit -> cashreward_pursuit_06, cashreward_pursuit_08, cashreward_pursuit_17
    { 203, "SOCIALITE", 2, { 0xA4469D65, 0x9844D3D2, 0x00000000, 0x00000000, 0x00000000 } }, // cashreward_explore -> cashreward_explore_10, cashreward_explore_15
    { 204, "TYCOON", 5, { 0xC9B4C428, 0x1D7A9907, 0x390ED502, 0xA6D20A7C, 0xFD71921E } }, // cashreward_race -> cashreward_race_06, cashreward_race_09, cashreward_race_17, cashreward_race_19, cashreward_race_23
    { 205, "LIGHTNING_REFLEX", 3, { 0xAAD91374, 0xFD671B7F, 0x8AE12A6E, 0x00000000, 0x00000000 } }, // ready_cooldown -> ready_cooldown_13, ready_cooldown_20, ready_cooldown_36
    { 301, "RAM", 5, { 0x47FAD4E0, 0x5C1A26CF, 0x3D0AAFEC, 0x825C8DB2, 0x8FA00F30 } }, // collisionmass -> collision_mass_10, collision_mass_15, collision_mass_28, collision_mass_34, collision_mass_40
    { 302, "COOLDOWN", 3, { 0x302394BD, 0xF49DCB0B, 0x02B8315E, 0x00000000, 0x00000000 } }, // cooldown_meter -> cooldown_meter_10, cooldown_meter_15, cooldown_meter_28
    { 303, "TERMINATOR", 3, { 0xC1BAE4B8, 0x6E34B731, 0x5125161D, 0x00000000, 0x00000000 } }, // juggernaut_cooldown -> juggernaut_cooldown_07, juggernaut_cooldown_10, juggernaut_cooldown_18
    { 304, "DEMOLITION_MAN", 3, { 0x115E4965, 0x2CFBF1CE, 0x43005E77, 0x00000000, 0x00000000 } }, // juggernaut_power -> juggernaut_power_05, juggernaut_power_08, juggernaut_power_14
    { 305, "EVASION", 3, { 0xD48B5B62, 0x3D4AC7CC, 0xDB050CDA, 0x00000000, 0x00000000 } }, // emergency_power -> emergency_power_10, emergency_power_15, emergency_power_28
    { 306, "UNTOUCHABLE", 5, { 0xB5D1A6AA, 0x40366D77, 0xAB5BD62C, 0xEC7EED11, 0xBFEC42E6 } }, // emergency_cooldown -> emergency_cooldown_15, emergency_cooldown_21, emergency_cooldown_41, emergency_cooldown_49, emergency_cooldown_60
    { 307, "RAMPAGE", 3, { 0xFC6065A1, 0x26B4D671, 0xAED12AA4, 0x00000000, 0x00000000 } }, // juggernaut_duration -> juggernaut_duration_10, juggernaut_duration_15, juggernaut_duration_28
};
static const int kSkillCount = sizeof(kSkills)/sizeof(kSkills[0]);
