#!/bin/sh
# Build without Visual Studio (Linux, LLVM 18): clang-cl + lld-link, no CRT
set -e
CC_CL=${CC_CL:-clang-cl}
mkdir -p build
llvm-dlltool -m i386 -k -d shim/kernel32.def -l build/kernel32.lib
$CC_CL --target=i686-pc-windows-msvc /O2 /GS- /Zl /EHs-c- /GR- -fno-builtin -DNFSW_NOCRT -Ishim /c src/main.cpp /Fobuild/main.obj
$CC_CL --target=i686-pc-windows-msvc /O2 /GS- /Zl -fno-builtin /c shim/fltused.c /Fobuild/fltused.obj
lld-link /dll /machine:x86 /nodefaultlib /entry:DllMain /subsystem:windows /safeseh:no /release \
  /out:build/NFSWDriverSkills.asi build/main.obj build/fltused.obj build/kernel32.lib
