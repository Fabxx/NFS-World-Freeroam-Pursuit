NFSWDriverSkills - Beta 2010 Driver Skills for NFS World 2015 (offline)
=======================================================================

What it does
 - 1 skill point per driver level (points = level - 1).
 - After every level up (results screen, after the level-up flasher) the skill selection page
   appears: spend the points right away or press NEXT to keep them for later.
 - Unspent points can be used later in the safehouse: Driver Profile > Skills.
 - Skills belong to the profile (saved per persona in Scripts\NFSWDriverSkills.sav) and are applied
   to every car you drive.
 - The Skill Mod workshop button in the customization menu is disabled.

Skills (24, July 2010 build; unlock levels/category points from the beta).
Every rank N applies the effect of the vanilla N-star skill mod of the same type (gpcore.bin values).
Beta skills that no longer exist use the closest vanilla skill mod:
  RACE     Extended Nitrous (nitrous duration), Perfect Start (perfect start duration),
           Catch Up (catch up), Dragster -> gear ratio enhancement, Need for Speed -> slingshot power,
           Nerves of Steel -> launch grip, Rapid Fire (nitrous cooldown),
           Strong Finisher -> slingshot duration, Super Shot (nitrous power),
           Traffic Cop (traffic magnet cooldown), Jumpstart (jumpstart), Rolling Fortress (shield duration)
  EXPLORE  Radar (cop radar), Most Wanted -> pursuit cash, Socialite -> explore cash,
           Tycoon (race cash), Lightning Reflex (ready cooldown)
  PURSUIT  Ram (collision mass), Cooldown (pursuit cooldown meter), Terminator -> juggernaut cooldown,
           Demolition Man -> juggernaut power, Evasion (emergency evade power),
           Untouchable -> emergency evade cooldown, Rampage (juggernaut duration)

Files
 - Scripts\NFSWDriverSkills.asi / .ini   (ASI: persistence + gameplay effects)
 - GFX\_SkillSelectionComponent.gfx      (skill page + skill data/rules, class SkillSelectionComponent;
                                         ListBoxGrid imported from _ListBoxBeta.swf)
 - GFX\_ListBoxBeta.gfx                  (2010 _ListBox with the skill list items, textures embedded)
 - GFX\Profile_Skills.gfx                (same class, kept in sync)
 - GFX\ResultsScreen.gfx / PostRace.gfx  (races / pursuits: after the level up the results window
                                         closes and a separate DRIVER SKILLS window opens)
 - GFX\VisualCustomization.gfx           (skill mod workshop button disabled)

How the ASI works (nfsw.exe 2015)
 - Interop "Request" commands NFSWSkillsLoad / NFSWSkillsSave / NFSWSkillsLog registered in the
   game's Request registry (0x524410, hooked at 0x522B9F). Data goes back to Flash as the
   ExternalInterface return value (movie captured in the screen/gadget Callback, vtables
   0xB729C4 / 0xB2D030) and as session value "NFSWSkills".
 - Skill mod effects: the vehicle skill interface (vtable 0xBC3BA0, slot 0x104) returns the car's
   customization record; for the human driver (PVehicle+0x158 == 0) the ASI evaluates the profile
   effect keys through the game's own 0x717000 / 0x716EE0 (12 slots per batch, vanilla caps).

Build
 - Visual Studio: NFSWDriverSkills.vcxproj (Release|Win32).
 - Linux/LLVM: ./build.sh (clang-cl + lld-link, no CRT; shim\ = minimal Windows headers).
 - tools\build_tbl.py regenerates the skill table from gpcore.bin (needs the VLT parser used here).
 - flash\*.as = ActionScript classes compiled into the GFX files (FFDec: edit class and save).

Finestra skill post-gara:
- GFX\SkillSelection.gfx = port della SkillSelection della beta luglio 2010 (texture incorporate,
  gameAPIGlobalComponent rimosso). Classe in flash/SkillSelection.as.
- ResultsScreen/PostRace caricano SkillSelection.swf dopo la chiusura di UnlocksView; alla chiusura
  la finestra chiama _global.DSOnSkillWindowClosed -> PostEventComplete + Exit.

Livello del pilota:
- La cache "current player persona" (HandleRequest_Interop_GetCurrentPlayerPersona) non viene aggiornata
  dopo un level up. L'ASI intercetta il GamePersona inviato all'HUD (0x4D7185 -> 0x4D3E70, campo +0x4C,
  isSelf +0x68), salva il livello in NFSWDriverSkills.sav ([Persona_<id>] Level=) e lo inserisce nella
  risposta di GetCurrentPlayerPersona (0x51C9B0 -> 0x492F70, campo +0x2C). Punti totali = (livello - 1) x 2 (DS_POINTS_PER_LEVEL).
