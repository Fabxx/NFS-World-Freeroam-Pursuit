import sys; sys.path.insert(0,'/tmp/cam')
import json,collections,struct
exec(open('/tmp/cam/gpc.py').read())
out=json.load(open('/tmp/sk/parts_effects.json'))
best={}
for o in out:
    if len(o)<4 or not o[3]: continue
    nm,star,hdr,vals=o
    if star is None: continue
    for (en,v,t) in vals:
        if v is None: continue
        t=t.split('/')[-1]; k=(t,star)
        if k not in best or v>best[k][0]: best[k]=(v,en,nm)
ekey={}
for c in cols:
    n=name(c['key'])
    if n.startswith('skillmods/effects/'): ekey[n.split('/')[-1]]=c['key']
S=[
 (101,0,'EXTENDED_NOS','EXTENDED NITROUS','SKILL_EXT_NOS','nitrous_duration',5,[(4,0),(12,0),(20,0),(28,0),(36,0)]),
 (102,0,'PERFECT_START','PERFECT START','SKILL_PERFECT_START','perfectstart_duration',5,[(3,0),(10,2),(17,4),(24,6),(31,8)]),
 (103,0,'CATCH_UP','CATCH UP','SKILL_CATCH_UP','catchup',3,[(3,0),(13,0),(23,0)]),
 (104,0,'DRAGSTER','DRAGSTER','SKILL_DRAGSTER','gearratio_enhancement',3,[(17,2),(27,4),(37,8)]),
 (105,0,'NEED_FOR_SPEED','NEED FOR SPEED','SKILL_NEED_FOR_SPEED','slingshot_power',3,[(20,2),(30,4),(40,8)]),
 (106,0,'NERVES_OF_STEEL','NERVES OF STEEL','SKILL_NERVES_OF_STEEL','launchgrip',3,[(15,2),(25,4),(35,8)]),
 (107,0,'RAPID_FIRE','RAPID FIRE','SKILL_RAPID_FIRE','nitrous_cooldown',3,[(2,0),(12,2),(22,4)]),
 (108,0,'STRONG_FINISHER','STRONG FINISHER','SKILL_STRONG_FINISHER','slingshot_duration',2,[(6,2),(16,4)]),
 (109,0,'SUPER_SHOT','SUPER SHOT','SKILL_SUPER_SHOT','nitrous_power',3,[(8,0),(21,4),(34,8)]),
 (110,0,'TRAFFIC_COP','TRAFFIC COP','SKILL_TRAFFIC_COP','trafficmagnet_cooldown',3,[(8,0),(14,0),(23,4)]),
 (111,0,'JUMPSTART','JUMPSTART','SKILL_JUMPSTART','jumpstart',2,[(5,0),(15,0)]),
 (112,0,'ROLLING_FORTRESS','ROLLING FORTRESS','SKILL_ROLLING_FORTRESS','shield_duration',3,[(4,0),(14,2),(24,4)]),
 (201,1,'RADAR','RADAR','SKILL_RADAR','radar',3,[(3,0),(11,0),(19,0)]),
 (202,1,'MOST_WANTED','MOST WANTED','SKILL_MOST_WANTED','cashreward_pursuit',3,[(9,0),(19,2),(29,4)]),
 (203,1,'SOCIALITE','SOCIALITE','SKILL_SOCIALITE','cashreward_explore',2,[(5,3),(15,5)]),
 (204,1,'TYCOON','TYCOON','SKILL_TYCOON','cashreward_race',5,[(2,0),(11,0),(20,0),(29,0),(38,0)]),
 (205,1,'LIGHTNING_REFLEX','LIGHTNING REFLEX','SKILL_LIGHTNING_REFLEX','ready_cooldown',3,[(5,0),(10,0),(15,4)]),
 (301,2,'RAM','RAM','SKILL_RAM','collisionmass',5,[(3,0),(12,2),(21,4),(30,6),(39,8)]),
 (302,2,'COOLDOWN','COOLDOWN','SKILL_COOLDOWN','cooldown_meter',3,[(4,0),(12,0),(20,0)]),
 (303,2,'TERMINATOR','TERMINATOR','SKILL_TERMINATOR','juggernaut_cooldown',3,[(10,2),(18,0),(26,0)]),
 (304,2,'DEMOLITION_MAN','DEMOLITION MAN','SKILL_DEMOLITION_MAN','juggernaut_power',3,[(5,2),(11,4),(17,0)]),
 (305,2,'EVASION','EVASION','SKILL_EVASION','emergency_power',3,[(4,0),(14,2),(27,4)]),
 (306,2,'UNTOUCHABLE','UNTOUCHABLE','SKILL_UNTOUCHABLE','emergency_cooldown',5,[(2,0),(10,0),(18,0),(26,0),(34,0)]),
 (307,2,'RAMPAGE','RAMPAGE','SKILL_RAMPAGE','juggernaut_duration',3,[(2,0),(17,0),(27,3)]),
]
tbl=[]
for (i,cat,code,nm,icon,typ,mx,reqs) in S:
    ranks=[]
    for r in range(1,mx+1):
        v,en,part=best[(typ,r)]
        ranks.append(dict(star=r,value=v,effect=en,key=ekey[en],part=part,lvl=reqs[r-1][0],pts=reqs[r-1][1]))
    tbl.append(dict(id=i,cat=cat,code=code,name=nm,icon=icon,type=typ,max=mx,ranks=ranks))
    print(i,code,typ,[(x['value'],hex(x['key'])) for x in ranks])
json.dump(tbl,open('/tmp/ds/skills.json','w'),indent=1)
