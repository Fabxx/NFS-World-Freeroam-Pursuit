#!/bin/sh
set -e
CC_CL=${CC_CL:-clang-cl}; NAME=${NAME:-NFSWBorderless}
mkdir -p build
llvm-dlltool -m i386 -k -d shim/kernel32.def -l build/kernel32.lib
llvm-dlltool -m i386 -k -d shim/user32.def -l build/user32.lib
$CC_CL --target=i686-pc-windows-msvc /O2 /GS- /Zl /EHs-c- /GR- -fno-builtin -Ishim /c src/main.cpp /Fobuild/main.obj
$CC_CL --target=i686-pc-windows-msvc /O2 /GS- /Zl -fno-builtin /c shim/fltused.c /Fobuild/fltused.obj
lld-link /dll /machine:x86 /nodefaultlib /entry:DllMain /subsystem:windows /safeseh:no /release \
  /out:build/$NAME.asi build/main.obj build/fltused.obj build/kernel32.lib build/user32.lib
