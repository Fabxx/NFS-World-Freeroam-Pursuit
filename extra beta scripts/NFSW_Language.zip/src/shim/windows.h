// Dichiarazioni Windows minime per compilare senza Windows SDK (clang-cl + lld-link, senza CRT)
#pragma once
typedef unsigned long DWORD; typedef int BOOL; typedef unsigned char BYTE; typedef unsigned short WORD; typedef unsigned int UINT; typedef int INT;
typedef void* LPVOID; typedef void* HANDLE; typedef struct HINSTANCE__* HINSTANCE; typedef HINSTANCE HMODULE;
typedef const char* LPCSTR; typedef char* LPSTR; typedef const unsigned short* LPCWSTR; typedef unsigned long SIZE_T; typedef unsigned int size_t;
typedef DWORD* PDWORD; typedef DWORD* LPDWORD; typedef const void* LPCVOID; typedef unsigned int UINT_PTR; typedef long LONG; typedef long LONG_PTR;
typedef UINT_PTR WPARAM; typedef LONG_PTR LPARAM; typedef LONG_PTR LRESULT; typedef long HRESULT;
typedef struct HWND__* HWND; typedef struct HMENU__* HMENU; typedef struct HMONITOR__* HMONITOR; typedef struct HDC__* HDC;
typedef struct tagPOINT { long x, y; } POINT; typedef struct tagRECT { long left, top, right, bottom; } RECT;
typedef struct tagMONITORINFO { DWORD cbSize; RECT rcMonitor; RECT rcWork; DWORD dwFlags; } MONITORINFO;
typedef LRESULT (__stdcall *WNDPROC)(HWND, UINT, WPARAM, LPARAM);
typedef BOOL (__stdcall *MONITORENUMPROC)(HMONITOR, HDC, RECT*, LPARAM);
#define WINAPI __stdcall
#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define DLL_PROCESS_ATTACH 1
#define PAGE_READWRITE 0x04
#define PAGE_EXECUTE_READWRITE 0x40
#define FILE_APPEND_DATA 0x0004
#define FILE_SHARE_READ 0x00000001
#define OPEN_ALWAYS 4
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
extern "C" {
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(LPCSTR);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HMODULE, LPSTR, DWORD);
__declspec(dllimport) UINT WINAPI GetPrivateProfileIntA(LPCSTR, LPCSTR, INT, LPCSTR);
__declspec(dllimport) DWORD WINAPI GetPrivateProfileStringA(LPCSTR, LPCSTR, LPCSTR, LPSTR, DWORD, LPCSTR);
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, SIZE_T, DWORD, PDWORD);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, LPCVOID, SIZE_T);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess(void);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
__declspec(dllimport) HANDLE WINAPI CreateFileA(LPCSTR, DWORD, DWORD, LPVOID, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE, LPCVOID, DWORD, LPDWORD, LPVOID);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI DeleteFileA(LPCSTR);
__declspec(dllimport) BOOL WINAPI IsBadReadPtr(const void*, UINT_PTR);
__declspec(dllimport) DWORD WINAPI GetFileAttributesA(LPCSTR);
__declspec(dllimport) HMODULE WINAPI LoadLibraryA(LPCSTR);
__declspec(dllimport) void* WINAPI GetProcAddress(HMODULE, LPCSTR);
}
