// Utilita' comuni per gli ASI di NFS World (senza CRT)
#pragma once
#include "windows.h"

static char g_ini[MAX_PATH], g_log[MAX_PATH], g_gameDir[MAX_PATH];
static bool g_logOn = true;
static DWORD g_base = 0x400000, g_delta = 0;

static int  StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); StrCpy(d + n, s, cap - n); }
static char Upper(char c) { return (c >= 'a' && c <= 'z') ? (char)(c - 32) : c; }
static bool StrIEq(const char* a, const char* b)
{
    if (!a || !b) return false;
    while (*a && *b) { if (Upper(*a) != Upper(*b)) return false; ++a; ++b; }
    return *a == 0 && *b == 0;
}
static bool WStrIEqA(const unsigned short* a, const char* b)
{
    if (!a || !b) return false;
    while (*a && *b) { if (*a > 127 || Upper((char)*a) != Upper(*b)) return false; ++a; ++b; }
    return *a == 0 && *b == 0;
}
static void IntToStr(int v, char* out) { char t[16]; int n = 0; bool neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (neg) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static void HexStr(DWORD v, char* buf) { const char* hx = "0123456789ABCDEF"; buf[0] = '0'; buf[1] = 'x'; for (int i = 0; i < 8; ++i) buf[2 + i] = hx[(v >> (28 - 4 * i)) & 15]; buf[10] = 0; }
static bool Readable(const void* p, unsigned n) { return p && (DWORD)p > 0x10000 && !IsBadReadPtr(p, n); }
static void Trim(char* s)
{
    int n = StrLen(s); while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r')) s[--n] = 0;
    int i = 0; while (s[i] == ' ' || s[i] == '\t') ++i; if (i) { int j = 0; while (s[i]) s[j++] = s[i++]; s[j] = 0; }
    for (int k = 0; s[k]; ++k) if (s[k] == ';') { s[k] = 0; Trim(s); break; }
}
static bool IsNumber(const char* s) { if (!s || !*s) return false; for (; *s; ++s) if (*s < '0' || *s > '9') return false; return true; }
static int  ToInt(const char* s) { int v = 0; while (*s >= '0' && *s <= '9') v = v * 10 + (*s++ - '0'); return v; }

static void Log(const char* a, const char* b = 0, const char* c = 0, const char* d = 0, const char* e = 0, const char* f = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w; const char* parts[6] = { a, b, c, d, e, f };
    for (int i = 0; i < 6; ++i) if (parts[i]) WriteFile(h, parts[i], StrLen(parts[i]), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}
static void LogInt(const char* a, int v, const char* b = 0) { char t[16]; IntToStr(v, t); Log(a, t, b); }

// percorsi: <asi>.ini, <asi>.log, cartella del gioco (quella di nfsw.exe)
static void InitPaths(HINSTANCE self)
{
    char path[MAX_PATH]; GetModuleFileNameA(self, path, MAX_PATH);
    int n = StrLen(path); while (n > 0 && path[n - 1] != '.' && path[n - 1] != '\\') --n;
    if (n > 0 && path[n - 1] == '.') path[n - 1] = 0;
    StrCpy(g_ini, path, MAX_PATH); StrCat(g_ini, ".ini", MAX_PATH);
    StrCpy(g_log, path, MAX_PATH); StrCat(g_log, ".log", MAX_PATH);
    GetModuleFileNameA(0, g_gameDir, MAX_PATH);
    n = StrLen(g_gameDir); while (n > 0 && g_gameDir[n - 1] != '\\') --n; g_gameDir[n] = 0;
    g_delta = (DWORD)GetModuleHandleA(0) - g_base;
}
static bool GameFileExists(const char* rel)
{
    char p[MAX_PATH]; StrCpy(p, g_gameDir, MAX_PATH); StrCat(p, rel, MAX_PATH);
    return GetFileAttributesA(p) != INVALID_FILE_ATTRIBUTES;
}

// scrive un puntatore in memoria protetta
static bool WritePtr(void* where, void* value, void** oldValue = 0)
{
    DWORD old;
    if (!Readable(where, 4) || !VirtualProtect(where, 4, PAGE_EXECUTE_READWRITE, &old)) return false;
    if (oldValue) *oldValue = *(void**)where;
    *(void**)where = value;
    VirtualProtect(where, 4, old, &old);
    return true;
}
static bool WriteBytes(void* where, const BYTE* src, int n)
{
    DWORD old;
    if (!Readable(where, n) || !VirtualProtect(where, n, PAGE_EXECUTE_READWRITE, &old)) return false;
    for (int i = 0; i < n; ++i) ((BYTE*)where)[i] = src[i];
    VirtualProtect(where, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), where, n);
    return true;
}

// hook nella Import Address Table di nfsw.exe, per nome di funzione
static bool HookIAT(const char* dll, const char* func, void* hook, void** orig)
{
    BYTE* base = (BYTE*)GetModuleHandleA(0);
    DWORD pe = *(DWORD*)(base + 0x3C);
    DWORD impRva = *(DWORD*)(base + pe + 0x80);
    if (!impRva) return false;
    for (DWORD* d = (DWORD*)(base + impRva); d[3]; d += 5) {
        if (!StrIEq((const char*)(base + d[3]), dll)) continue;
        DWORD* names = (DWORD*)(base + (d[0] ? d[0] : d[4]));
        DWORD* iat = (DWORD*)(base + d[4]);
        for (int i = 0; names[i]; ++i) {
            if (names[i] & 0x80000000) continue;
            const char* nm = (const char*)(base + names[i] + 2);
            if (StrIEq(nm, func)) return WritePtr(&iat[i], hook, orig);
        }
    }
    return false;
}
