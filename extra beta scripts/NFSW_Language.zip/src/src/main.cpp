// NFSWLanguage.asi - sceglie la lingua di testo e audio di Need for Speed World (build 2015)
//
// Testo: tutto il gioco legge la lingua con Settings::GetString("UI", "Language", "EN")
//        (vtable delle impostazioni 0xB2BCE0 slot 13 = 0x4714C0). L'ASI risponde con il codice dell'ini;
//        il gioco carica LANGUAGES\<Lingua>_Global.bin, i caratteri (TC/SC/TH) e le schermate GFX di quella lingua.
// Audio: il sistema audio (0x77D720) sceglie la collezione "audiosystem" (english, french, german, ...) da
//        cui prende i file del parlato (Sound\Speech\copspeech*_xx.big) chiedendo l'ID lingua a
//        gameplay.native.dll; l'ASI sostituisce quella chiamata (0x77D75E) con l'ID scelto nell'ini.
#include "common.h"

struct TextLang  { const char* code; const char* file; const char* name; };
struct AudioLang { const char* code; int id; const char* suffix; const char* name; };

// ID del testo (Text=0..10 oppure il codice)
static const TextLang kText[] = {
    { "EN", "English",      "English" },
    { "FR", "French",       "Francais" },
    { "DE", "German",       "Deutsch" },
    { "ES", "Spanish",      "Espanol" },
    { "RU", "Russian",      "Russkij" },
    { "PL", "Polish",       "Polski" },
    { "PT", "Portuguese",   "Portugues (BR)" },
    { "TR", "Turkish",      "Turkce" },
    { "TH", "Thai",         "Thai" },
    { "TC", "Chinese_Trad", "Cinese tradizionale" },
    { "SC", "Chinese_Simp", "Cinese semplificato" },
};
// ID dell'audio (Audio=0..5 oppure il codice); id = valore che il sistema audio si aspetta
static const AudioLang kAudio[] = {
    { "EN", 0,  "en", "english" },
    { "FR", 1,  "fr", "french" },
    { "DE", 2,  "de", "german" },
    { "ES", 4,  "es", "spanish" },
    { "RU", 16, "ru", "russian" },
    { "TW", 12, "tw", "cinese (tw)" },
};
static const int kTextN = sizeof(kText) / sizeof(kText[0]), kAudioN = sizeof(kAudio) / sizeof(kAudio[0]);

static const TextLang* g_text = 0;

// ---------------------------------------------------------------- testo
static const DWORD kVtSettings = 0x00B2BCE0, kGetString = 0x004714C0;
typedef const char* (__thiscall* GetString_t)(void*, const char*, const char*, const char*);
static GetString_t g_getString;
static int g_textHits = 0;
static const char* __fastcall HookGetString(void* self, void*, const char* sec, const char* key, const char* def)
{
    if (g_text && sec && key && Readable(sec, 1) && Readable(key, 1) && StrIEq(sec, "UI") && StrIEq(key, "Language")) {
        if (g_textHits < 1) { const char* real = g_getString(self, sec, key, def); Log("UI/Language richiesto: impostazioni = ", real ? real : "(null)", ", restituito = ", g_text->code); }
        ++g_textHits;
        return g_text->code;
    }
    return g_getString(self, sec, key, def);
}

static const TextLang* FindText(const char* v)
{
    if (IsNumber(v)) { int i = ToInt(v); return (i >= 0 && i < kTextN) ? &kText[i] : 0; }
    for (int i = 0; i < kTextN; ++i) if (StrIEq(v, kText[i].code) || StrIEq(v, kText[i].file)) return &kText[i];
    if (StrIEq(v, "ZH") || StrIEq(v, "ZH_TW")) return &kText[9];
    if (StrIEq(v, "ZH_CN")) return &kText[10];
    if (StrIEq(v, "BR")) return &kText[6];
    return 0;
}
static const AudioLang* FindAudio(const char* v)
{
    if (IsNumber(v)) { int i = ToInt(v); return (i >= 0 && i < kAudioN) ? &kAudio[i] : 0; }
    for (int i = 0; i < kAudioN; ++i) if (StrIEq(v, kAudio[i].code) || StrIEq(v, kAudio[i].suffix) || StrIEq(v, kAudio[i].name)) return &kAudio[i];
    if (StrIEq(v, "TC") || StrIEq(v, "SC") || StrIEq(v, "ZH")) return &kAudio[5];
    return 0;
}
static const AudioLang* AudioForText(const TextLang* t)
{
    if (!t) return 0;
    if (StrIEq(t->code, "TC") || StrIEq(t->code, "SC")) return &kAudio[5];
    for (int i = 0; i < kAudioN; ++i) if (StrIEq(t->code, kAudio[i].code)) return &kAudio[i];
    return &kAudio[0];
}
static bool AudioFilesPresent(const AudioLang* a)
{
    static const char* parts[4] = { "copspeechdat_", "copspeechhdr_", "copspeechsth_", "copspeech_" };
    static const char* exts[4] = { ".big", ".big", ".big", ".csi" };
    for (int i = 0; i < 4; ++i) {
        char rel[MAX_PATH]; StrCpy(rel, "Sound\\Speech\\", MAX_PATH); StrCat(rel, parts[i], MAX_PATH); StrCat(rel, a->suffix, MAX_PATH); StrCat(rel, exts[i], MAX_PATH);
        if (!GameFileExists(rel)) { Log("  file mancante: ", rel); return false; }
    }
    return true;
}

// ---------------------------------------------------------------- audio
// 0x77D75E: mov eax,[0xD10CE0] ; mov ecx,[eax] ; mov edx,[ecx+0x2C] ; push eax ; call edx   (13 byte)
//        -> mov eax, <id> ; nop x8
static bool PatchAudio(int id)
{
    BYTE* p = (BYTE*)(0x0077D75E + g_delta);
    static const BYTE expect[13] = { 0xA1, 0xE0, 0x0C, 0xD1, 0x00, 0x8B, 0x08, 0x8B, 0x51, 0x2C, 0x50, 0xFF, 0xD2 };
    if (!Readable(p, 13)) return false;
    bool ok = true;
    for (int i = 0; i < 13; ++i) if ((i < 1 || i > 4) && p[i] != expect[i]) ok = false;   // 1..4 = indirizzo
    if (!ok) return false;
    BYTE patch[13]; patch[0] = 0xB8; *(int*)(patch + 1) = id; for (int i = 5; i < 13; ++i) patch[i] = 0x90;
    return WriteBytes(p, patch, 13);
}

static void Init(HINSTANCE self)
{
    InitPaths(self);
    DeleteFileA(g_log);
    g_logOn = GetPrivateProfileIntA("General", "Log", 1, g_ini) != 0;
    Log("NFSWLanguage 1.0");
    if (GetPrivateProfileIntA("General", "Enabled", 1, g_ini) == 0) { Log("disattivato ([General] Enabled=0)"); return; }

    char tv[64], av[64];
    GetPrivateProfileStringA("Language", "Text", "", tv, sizeof(tv), g_ini); Trim(tv);
    GetPrivateProfileStringA("Language", "Audio", "AUTO", av, sizeof(av), g_ini); Trim(av);

    // ---- testo
    if (tv[0] && !StrIEq(tv, "GAME")) {
        const TextLang* t = FindText(tv);
        if (!t) Log("ATTENZIONE: lingua del testo sconosciuta: ", tv, " (il gioco usa la sua)");
        else {
            char rel[MAX_PATH]; StrCpy(rel, "LANGUAGES\\", MAX_PATH); StrCat(rel, t->file, MAX_PATH); StrCat(rel, "_Global.bin", MAX_PATH);
            if (!GameFileExists(rel)) Log("ATTENZIONE: manca ", rel, ", lingua del testo non cambiata");
            else g_text = t;
        }
    }
    if (g_text) {
        DWORD* slot = (DWORD*)(kVtSettings + 13 * 4 + g_delta);
        if (Readable(slot, 4) && *slot == kGetString + g_delta && WritePtr(slot, (void*)HookGetString, (void**)&g_getString))
            Log("testo: ", g_text->code, " - ", g_text->name);
        else { Log("ERRORE: vtable delle impostazioni non riconosciuta (nfsw.exe diverso?)"); g_text = 0; }
    } else Log("testo: lingua del gioco (nessuna modifica)");

    // ---- audio
    const AudioLang* a = 0;
    if (StrIEq(av, "AUTO") || !av[0]) { a = AudioForText(g_text); if (!a) Log("audio: AUTO senza lingua del testo -> lingua del gioco (nessuna modifica)"); }
    else if (StrIEq(av, "GAME")) Log("audio: lingua del gioco (nessuna modifica)");
    else { a = FindAudio(av); if (!a) Log("ATTENZIONE: lingua dell'audio sconosciuta: ", av, " (il gioco usa la sua)"); }
    if (a && !AudioFilesPresent(a)) {
        Log("ATTENZIONE: parlato '", a->suffix, "' non installato, uso l'inglese");
        a = &kAudio[0];
    }
    if (a) {
        if (PatchAudio(a->id)) { Log("audio: ", a->code, " - ", a->name); Log("  file: Sound\\Speech\\copspeech*_", a->suffix, ".*"); }
        else Log("ERRORE: codice del sistema audio non riconosciuto (nfsw.exe diverso?)");
    }
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); Init(h); }
    return TRUE;
}
