class com.ea.PostRace.components.UnlocksView extends MovieClip
{
   var _car;
   var _event;
   var _help;
   var _movie;
   var _title;
   var _unlocksList;
   var dispatchEvent;
   var helpButtonListener;
   var mHelpButton;
   var mOwner;
   var mUnlocksFallbackTimer;
   var mPendingLevelUpInfo;
   var mvcLevelUpFlasher;
   var navButton;
   var nextBtn;
   var nextListeners;
   var previousBtn;
   var previousListeners;
   var releaseListeners;
   var TYPE_CAR = {label:"unlockedCar"};
   var TYPE_EVENT = {label:"unlockedEvent"};
   var REWARD_UNLOCK_SFX = "REWARD_UNLOCK";
   var REWARD_SCREEN_TRANS_SFX = "REWARD_SCREEN_TRANS";
   var _unlockShowingIndex = 0;
   var delegates = new Object();
   var mLevelUpAnimComplete = false;
   var mLevelUpDataReceived = false;
   var UNLOCK_FEATURE = "UNLOCK_VIEW";
   var mLevelUpStarted = false;
   var mForceExiting = false;
   var HC_LevelUpListener = new Object();
   function UnlocksView()
   {
      super();
      this._movie = this;
      this._unlocksList = new Array();
      this.previousBtn._visible = false;
      this.nextBtn._visible = false;
   }
   function OnLevelUpFlasherStarted()
   {
      this.gotoAndPlay("LevelUp");
      this.delegates.EH_LevelUpFlasherComplete = mx.utils.Delegate.create(this,this.EH_LevelUpFlasherComplete);
      this.HC_LevelUpListener.LevelUpFlasherComplete = this.delegates.EH_LevelUpFlasherComplete;
      if(this.mvcLevelUpFlasher != undefined)
      {
         this.mvcLevelUpFlasher.addListener(this.HC_LevelUpListener);
      }
   }
   function EH_LevelUpFlasherComplete()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      this.mLevelUpAnimComplete = true;
      this.gotoAndPlay("Unlocks");
      this.navButton.setAttract(true);
      this.navButton.setEnable(true);
      if(!this.mLevelUpDataReceived && this.mPendingLevelUpInfo != undefined)
      {
         this.deliverPendingUnlocks();
         return undefined;
      }
      if(this.mLevelUpDataReceived && (!_global.mPostRaceLevelUpInfo.CarUnlocked && (!_global.mPostRaceLevelUpInfo.EventsUnlocked && !_global.mPostRaceLevelUpInfo.ItemsUnlocked)))
      {
         this.navButton.onRelease();
      }
   }
   function onLoad()
   {
      this.mOwner = _global.RootClass;
      this._parent._parent.onLoadInit(this);
      this._title = this._movie.titleAnimationMc;
      this._help = this._movie.unlockContainer.mHelp;
      this.navButton = this.mOwner.GetNavButton();
      this.InitButtons();
      this.OnShow();
      com.ea.gameapi.command.Command.FeatureCheckFirstClick(this.UNLOCK_FEATURE);
      if(!this.mLevelUpStarted)
      {
         this.mLevelUpStarted = true;
         this.gotoAndPlay("LevelUp");
      }
   }
   function InitButtons()
   {
      this.nextListeners = new Object();
      this.nextBtn = this._movie.unlockContainer.nextBtn;
      this.delegates.nextUnlock = mx.utils.Delegate.create(this,this.showNextUnlock);
      this.nextListeners.onRelease = this.delegates.nextUnlock;
      this.nextBtn.addListener(this.nextListeners);
      this.previousListeners = new Object();
      this.previousBtn = this._movie.unlockContainer.previousBtn;
      this.delegates.previousUnlock = mx.utils.Delegate.create(this,this.showPreviousUnlock);
      this.previousListeners.onRelease = this.delegates.previousUnlock;
      this.previousBtn.addListener(this.previousListeners);
   }
   function InitializeDelegates()
   {
      this.delegates.EH_OnPostRaceLevelUpInfoReceived = mx.utils.Delegate.create(this,this.EH_OnPostRaceLevelUpInfoReceived);
      this.mOwner.addEventListener("OnPostRaceLevelUpInfoReceived",this.delegates.EH_OnPostRaceLevelUpInfoReceived);
      this.mOwner.OnPostRaceLevelUpInfoReceived = function()
      {
         this.dispatchEvent({type:"OnPostRaceLevelUpInfoReceived"});
      };
      this.delegates.EH_OnCompleted = mx.utils.Delegate.create(this,this.EH_OnCompleted);
      this.releaseListeners = new Object();
      this.releaseListeners.onRelease = this.delegates.EH_OnCompleted;
      this.navButton.addListener(this.releaseListeners);
      this.delegates.EH_ForceExit = mx.utils.Delegate.create(this,this.ForceExit);
      this.navButton.onRelease = this.delegates.EH_ForceExit;
      this.delegates.EH_Debug_showNextUnlock = mx.utils.Delegate.create(this,this.EH_Debug_showNextUnlock);
      this.mOwner.addEventListener("Debug_showNextUnlock",this.delegates.EH_Debug_showNextUnlock);
      this.mOwner.Debug_showNextUnlock = function()
      {
         this.dispatchEvent({type:"Debug_showNextUnlock"});
      };
      this.delegates.EH_OnFeatureFirstClickReceived = mx.utils.Delegate.create(this,this.EH_OnFeatureFirstClickReceived);
      this.mOwner.addEventListener("OnFeatureFirstClickReceived",this.delegates.EH_OnFeatureFirstClickReceived);
      this.mOwner.OnFeatureFirstClickReceived = function()
      {
         this.dispatchEvent({type:"OnFeatureFirstClickReceived"});
      };
   }
   function OnShow()
   {
      this.navButton.setAttract(false);
      this.navButton.setEnable(false);
      this.InitializeDelegates();
      this.requestUnlocks();
      this.mHelpButton = this._movie.unlockContainer.mHelpButton;
      this.mHelpButton.setEnable(true);
      this.mHelpButton.setTooltip("TXT_TLTP_CMN_HELP");
      this.helpButtonListener = new Object();
      this.helpButtonListener.onRelease = mx.utils.Delegate.create(this,this.handleHelpButtonRelease);
      this.mHelpButton.addListener(this.helpButtonListener);
   }
   function ForceExit()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      this.mForceExiting = true;
      if(this.mOwner == undefined)
      {
         return undefined;
      }
      this.mOwner.SetBusy(true);
      if(this.mvcLevelUpFlasher != undefined)
      {
         this.mvcLevelUpFlasher.stop();
         if(this.HC_LevelUpListener != undefined)
         {
            this.mvcLevelUpFlasher.removeListener(this.HC_LevelUpListener);
         }
      }
      if(this.mUnlocksFallbackTimer != undefined)
      {
         clearTimeout(this.mUnlocksFallbackTimer);
         this.mUnlocksFallbackTimer = undefined;
      }
      this.stop();
      if(this._movie.unlockContainer != undefined)
      {
         this._movie.unlockContainer.stop();
      }
      this._movie.onEnterFrame = null;
      this.mOwner.GoToHide();
   }
   function EH_OnCompleted()
   {
      this.ForceExit();
   }
   function OnCompleted()
   {
      this.ForceExit();
   }
   function showUnlocks(unlocks)
   {
      this._unlocksList = new Array();
      this._unlockShowingIndex = 0;
      if(unlocks == undefined)
      {
         this.createDefaultUnlocks();
         return undefined;
      }
      var _loc4_;
      if(unlocks.CarUnlocked && unlocks.Cars != undefined && unlocks.Cars.length > 0)
      {
         _loc4_ = 0;
         while(_loc4_ < unlocks.Cars.length)
         {
            if(unlocks.Cars[_loc4_] != undefined)
            {
               this._unlocksList.push({type:this.TYPE_CAR,unlocked:unlocks.Cars[_loc4_],viewed:false});
            }
            _loc4_ += 1;
         }
      }
      else if(unlocks.CarUnlocked && unlocks.Car != undefined)
      {
         this._unlocksList.push({type:this.TYPE_CAR,unlocked:unlocks.Car,viewed:false});
      }
      var _loc3_;
      if(unlocks.EventsUnlocked && unlocks.Events != undefined)
      {
         _loc3_ = 0;
         while(_loc3_ < unlocks.Events.length)
         {
            if(unlocks.Events[_loc3_] != undefined)
            {
               this._unlocksList.push({type:this.TYPE_EVENT,unlocked:unlocks.Events[_loc3_],viewed:false});
            }
            _loc3_ += 1;
         }
      }
      if(this._unlocksList.length == 0)
      {
         this.createDefaultUnlocks();
         return undefined;
      }
      this.nextBtn._visible = this._unlocksList.length > 1;
      this.showUnlock(this._unlocksList[0]);
   }
   function showUnlock(unlock)
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      this._movie.unlockContainer.gotoAndPlay(unlock.type.label);
      this.showArrowsIfNeeded();
      com.ea.util.SFX.PlaySound(this.REWARD_UNLOCK_SFX);
      switch(unlock.type)
      {
         case this.TYPE_CAR:
            this.populateCarUnlocked(unlock.unlocked);
            break;
         case this.TYPE_EVENT:
            this.populateEventUnlocked(unlock.unlocked);
      }
      unlock.viewed = true;
      this.checkIfAllUnlocksWhereViewed();
   }
   function checkIfAllUnlocksWhereViewed()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      var _loc2_ = true;
      var _loc3_ = 0;
      while(_loc3_ < this._unlocksList.length)
      {
         if(this._unlocksList[_loc3_].viewed == false)
         {
            _loc2_ = false;
            break;
         }
         _loc3_ += 1;
      }
      if(_loc2_)
      {
         this.mOwner.SetBusy(false);
         this.previousBtn._visible = false;
         this.nextBtn._visible = false;
         this.navButton._visible = true;
         this.navButton.setAttract(true);
         this.navButton.setEnable(true);
      }
   }
   function showArrowsIfNeeded()
   {
      if(this._unlocksList.length == 1)
      {
         this.previousBtn._visible = false;
         this.nextBtn._visible = false;
      }
      else
      {
         this.previousBtn._visible = this._unlockShowingIndex != 0;
         this.nextBtn._visible = this._unlockShowingIndex != this._unlocksList.length - 1;
      }
   }
   function populateEventUnlocked(event)
   {
      this._event = event;
      this._title.title = "TXT_LEVLUP_EVENTUNLOCKED";
      var _loc3_ = this._movie.unlockContainer.unlockedEventContainer;
      _loc3_.gotoAndPlay("in");
      _loc3_.effectMc.gotoAndPlay("in");
      _loc3_.eventNameMc.eventNameFld.text = this._event.Name;
      this._movie.onEnterFrame = mx.utils.Delegate.create(this,this.loadEventIconImage);
   }
   function loadEventIconImage()
   {
      if(this.mForceExiting)
      {
         this._movie.onEnterFrame = null;
         return undefined;
      }
      this._movie.onEnterFrame = null;
      var _loc2_ = this._movie.unlockContainer.unlockedEventContainer;
      var _loc3_ = _loc2_.eventIcon;
      _loc3_.imagePath = com.ea.components.ImageLoader.PATH_GAME_MODES;
      _loc3_.loadImage(this._event.Icon);
   }
   function populateCarUnlocked(car)
   {
      this._car = car;
      this._title.title = "TXT_UNLOCKED_NEW_CAR";
      var _loc3_ = this._movie.unlockContainer.unlockedCarContainer;
      _loc3_.gotoAndPlay("in");
      _loc3_.effectMc.gotoAndPlay("in");
      _loc3_.carNameMc.carNameFld.text = this._car.Name;
      var _loc4_ = this._car.Tier;
      if(typeof _loc4_ == "string" && (_loc4_.length == 0 || isNaN(Number(_loc4_))))
      {
         _loc3_.tierMc.tierFld.text = _loc4_;
      }
      else
      {
         _loc3_.tierMc.tierFld.text = "TIER" + _loc4_;
      }
   }
   function EH_Debug_showNextUnlock()
   {
      if(!this.mForceExiting)
      {
         this.showNextUnlock();
      }
   }
   function showNextUnlock()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      this._unlockShowingIndex += 1;
      if(this._unlockShowingIndex <= this._unlocksList.length - 1)
      {
         this.showUnlock(this._unlocksList[this._unlockShowingIndex]);
      }
      else
      {
         this._unlockShowingIndex = this._unlocksList.length - 1;
      }
   }
   function showPreviousUnlock()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      this._unlockShowingIndex -= 1;
      if(this._unlockShowingIndex >= 0)
      {
         this.showUnlock(this._unlocksList[this._unlockShowingIndex]);
      }
      else
      {
         this._unlockShowingIndex = 0;
      }
   }
   function createDefaultUnlocks()
   {
      var _loc3_ = new com.ea.gameapi.data.PostRaceLevelUpInfo();
      var _loc4_ = new com.ea.gameapi.data.PostRaceLevelUpCar();
      _loc4_.Icon = "CAYMANS_02";
      _loc4_.Name = "PORSCHE CAYMANS";
      _loc4_.Tier = 3;
      _loc3_.Car = _loc4_;
      _loc3_.CarUnlocked = true;
      var _loc5_ = new com.ea.gameapi.data.PostRaceLevelUpEvent();
      _loc5_.EventId = "c.c121";
      _loc5_.Icon = "GameModeIcon_Sprint_Large";
      _loc5_.Name = "ALL SPRINTS";
      var _loc6_ = new com.ea.gameapi.data.PostRaceLevelUpEvent();
      _loc6_.EventId = "c.c122";
      _loc6_.Icon = "GameModeIcon_Circuit_Large";
      _loc6_.Name = "ALL CIRCUITS";
      var _loc7_ = new com.ea.gameapi.data.PostRaceLevelUpEvent();
      _loc7_.EventId = "c.c123";
      _loc7_.Icon = "GameModeIcon_Pursuit_Mp_Large";
      _loc7_.Name = "ALL TEAM ESCAPES";
      var _loc8_ = new com.ea.gameapi.data.PostRaceLevelUpEvent();
      _loc8_.EventId = "c.c124";
      _loc8_.Icon = "GameModeIcon_Pursuit_Sp_Large";
      _loc8_.Name = "ALL PURSUITS";
      var _loc9_ = new com.ea.gameapi.data.PostRaceLevelUpEvent();
      _loc9_.EventId = "c.c125";
      _loc9_.Icon = "GameModeIcon_Drag_Large";
      _loc9_.Name = "ALL DRAGS";
      _loc3_.Events = [_loc5_,_loc6_,_loc7_,_loc8_,_loc9_];
      _loc3_.EventsUnlocked = true;
      _global.mPostRaceLevelUpInfo = _loc3_;
      this.mLevelUpDataReceived = true;
      this.showUnlocks(_loc3_);
   }
   function requestUnlocks()
   {
      var _loc3_;
      var _loc4_;
      var _loc5_;
      var _loc6_;
      var _loc7_;
      if((_loc3_ = _global.RootClass.DATA_SOURCE) !== "local")
      {
         this.mUnlocksFallbackTimer = setTimeout(mx.utils.Delegate.create(this,this.onUnlocksFallbackTimeout),2000);
         this.mPendingLevelUpInfo = this.parseLevelUpInfo(flash.external.ExternalInterface.call("Request","PostRaceGetLevelUpInfo"));
         if(this.mPendingLevelUpInfo != undefined && this.mLevelUpAnimComplete)
         {
            this.deliverPendingUnlocks();
         }
      }
      else
      {
         this.createDefaultUnlocks();
      }
   }
   function onUnlocksFallbackTimeout()
   {
      this.mUnlocksFallbackTimer = undefined;
      if(!this.mLevelUpDataReceived)
      {
         if(this.mPendingLevelUpInfo != undefined)
         {
            this.deliverPendingUnlocks();
         }
         else
         {
            this.createDefaultUnlocks();
         }
      }
   }
   function deliverPendingUnlocks()
   {
      var _loc2_ = this.mPendingLevelUpInfo;
      this.mPendingLevelUpInfo = undefined;
      if(_loc2_ == undefined || this.mForceExiting || this.mLevelUpDataReceived)
      {
         return undefined;
      }
      _global.mPostRaceLevelUpInfo = _loc2_;
      this.EH_OnPostRaceLevelUpInfoReceived();
   }
   function parseLevelUpInfo(data)
   {
      if(data == undefined || data == null)
      {
         return undefined;
      }
      var _loc12_ = String(data);
      if(_loc12_.length == 0)
      {
         return undefined;
      }
      var _loc4_ = new com.ea.gameapi.data.PostRaceLevelUpInfo();
      _loc4_.Cars = new Array();
      var _loc11_ = false;
      var _loc10_ = _loc12_.split("\r").join("").split("\n");
      var _loc3_;
      var _loc5_;
      var _loc6_;
      var _loc2_ = 0;
      while(_loc2_ < _loc10_.length)
      {
         _loc3_ = String(_loc10_[_loc2_]).split("|");
         if(_loc3_[0] == "L")
         {
            _loc11_ = true;
         }
         else if(_loc3_[0] == "C" && _loc3_.length >= 2 && _loc3_[1].length > 0)
         {
            _loc5_ = new com.ea.gameapi.data.PostRaceLevelUpCar();
            _loc5_.Name = _loc3_[1];
            _loc5_.Tier = _loc3_.length > 2 ? _loc3_[2] : "";
            _loc5_.Icon = _loc3_.length > 3 ? _loc3_[3] : "";
            _loc4_.Cars.push(_loc5_);
         }
         else if(_loc3_[0] == "E" && _loc3_.length >= 4)
         {
            _loc6_ = new com.ea.gameapi.data.PostRaceLevelUpEvent();
            _loc6_.EventId = _loc3_[1];
            _loc6_.Icon = _loc3_[2];
            _loc6_.Name = _loc3_.slice(3).join("|");
            _loc4_.Events.push(_loc6_);
         }
         _loc2_ += 1;
      }
      if(!_loc11_)
      {
         return undefined;
      }
      if(_loc4_.Cars.length > 0)
      {
         _loc4_.Car = _loc4_.Cars[0];
         _loc4_.CarUnlocked = true;
      }
      _loc4_.EventsUnlocked = _loc4_.Events.length > 0;
      return _loc4_;
   }
   function EH_OnPostRaceLevelUpInfoReceived()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      var _loc3_ = _global.mPostRaceLevelUpInfo;
      if(this.mUnlocksFallbackTimer != undefined)
      {
         clearTimeout(this.mUnlocksFallbackTimer);
         this.mUnlocksFallbackTimer = undefined;
      }
      if(_loc3_ == undefined)
      {
         this.createDefaultUnlocks();
         return undefined;
      }
      if(_loc3_.Events == undefined)
      {
         _loc3_.Events = new Array();
      }
      this.mLevelUpDataReceived = true;
      if(_loc3_.CarUnlocked || _loc3_.EventsUnlocked)
      {
         com.ea.util.SFX.PlaySound(this.REWARD_SCREEN_TRANS_SFX);
         this.showUnlocks(_loc3_);
      }
      else if(this.mLevelUpAnimComplete)
      {
         this.navButton.setAttract(true);
         this.navButton.setEnable(true);
         this.navButton.onRelease();
      }
   }
   function EH_OnFeatureFirstClickReceived()
   {
      if(this.mForceExiting)
      {
         return undefined;
      }
      var _loc3_ = _global.mFeatureFirstClick;
      var _loc4_ = _loc3_.gadgetName;
      if(_loc4_ == this.UNLOCK_FEATURE)
      {
         this.requestOpenIntroPopup();
      }
   }
   function requestOpenIntroPopup()
   {
      this._help._alpha = 100;
      this._help._visible = true;
   }
   function handleHelpButtonRelease()
   {
      this._help._alpha = 100;
      this._help._visible = !this._help._visible;
   }
}
