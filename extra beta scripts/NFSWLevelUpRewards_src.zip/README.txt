NFSWLevelUpRewards - premi del passaggio di livello (NFS World 2015 offline)
===========================================================================

Contenuto
  asi/src/main.cpp           sorgente dell'ASI (nessuna CRT; build.sh con clang-cl + lld-link)
  asi/shim/                  windows.h minimo, kernel32.def, _fltused
  asi/NFSWLevelUpRewards.ini configurazione
  gfx/UnlocksView.as         classe com.ea.PostRace.components.UnlocksView modificata
  gen/gen.py, gen/names.py   generatore della patch del server
  ServerPatch/data/...       file generati per il server offline (cartella patch del server)

Funzionamento
  1. UnlocksView.gfx chiede i premi con ExternalInterface.call("Request","PostRaceGetLevelUpInfo")
     e fa partire il timer di riserva di 2 s (pacchetto dummy se nessuno risponde).
  2. L'ASI registra quel comando nel registro "Request" del gioco (hook concatenato su RegisterAll 0x522B9F e
     sugli slot ExternalInterface 0xB729C4 / 0xB2D030, compatibile con NFSWDriverSkills.asi).
  3. Cartella del server: nessun nome fisso. Se ServerFolder nell'ini e' vuoto, viene cercata tra le
     sottocartelle della cartella del gioco (e di Data) quella con drivers\DefaultPersonaIdx.xml e data\;
     a parita' vince quella il cui config\config.json (nfswFilePath) punta a questo nfsw.exe.
  4. Livello: drivers\driver*\GetPersonaInfo.xml del server (pilota in uso = sub_43FDD0, altrimenti il file
     scritto per ultimo, cioe' quello appena aggiornato dall'arbitraggio della gara).
  5. Premi: data\events\LevelUpRewards.xml, voci <Car name tier icon/> e <Event id icon name/> per ogni livello.
  6. Risposta: "L|livello", "C|nome|tier|icona", "E|EventId|icona|nome" (una riga per voce).
     UnlocksView la converte in PostRaceLevelUpInfo (Car/Cars, Events) e la mostra quando termina l'animazione
     del livello, oppure allo scadere dei 2 s, come faceva il pacchetto dummy.

Patch del server (generata da gen.py dai file originali del server)
  data/events/availableatlevel.xml   MinLevel 1..60 per ogni evento (prima: tutti al livello 2)
     - eventi della classe E dal livello 2, D dal 3, C dal 10, B dal 20, A dal 30, S dal 42; classe libera 2..60
     - tutorial e meeting place restano al livello 1
  data/catalog/productsInCategory_NFSW_NA_EP_PRESET_RIDES_ALL_Category.xml
     - Level delle auto di serie (car_base) in vendita: classe D 2..18, C 10..30, B 20..42, A 30..52, S 44..60
     - auto iniziali, classe E ed edizioni speciali invariate
  data/DriverPersona/GetExpLevelPointsMap.xml   60 soglie = livello massimo 60
  data/events/LevelUpRewards.xml     premi per livello, coerenti con i due file sopra

Rigenerare:  python3 gen/gen.py "<cartella server originale>" "<cartella di uscita>"
Compilare:   cd asi && CC_CL=clang-cl ./build.sh
