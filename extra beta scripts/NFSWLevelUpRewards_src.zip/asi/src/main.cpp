// NFSWLevelUpRewards.asi - NFS World 2015 (offline)
//
// Premi del passaggio di livello per UnlocksView.gfx.
//
// UnlocksView chiede i premi con ExternalInterface.call("Request", "PostRaceGetLevelUpInfo"), ma nel client
// 2015 quel comando non ha piu' un gestore: la schermata restava vuota (o mostrava il pacchetto dummy del timer).
// Questo ASI registra il comando nel registro "Request" del gioco e risponde in modo sincrono (valore di ritorno
// di ExternalInterface.call) con i premi del livello appena raggiunto:
//   * il livello del pilota viene letto dai file del server offline (drivers\driver*\GetPersonaInfo.xml), che
//     il server aggiorna durante l'arbitraggio della gara, prima della schermata dei premi; il pilota e' quello
//     in uso nel gioco (sub_43FDD0), altrimenti quello il cui file e' stato scritto per ultimo;
//   * i premi vengono letti da LevelUpRewards.xml (generato insieme ad availableatlevel.xml e al catalogo delle
//     auto, quindi corrispondono agli eventi sbloccati sulla mappa e alle auto sbloccate nel concessionario);
//   * se il pilota ha guadagnato piu' livelli in una volta vengono uniti i premi di tutti i livelli raggiunti
//     (ultimo livello visto salvato in NFSWLevelUpRewards.sav).
//
// Risposta (una voce per riga, campi separati da '|'):
//   L|<livello>[|<livello di partenza>]
//   C|<nome auto>|<tier/classe>|<icona>
//   E|<EventId>|<icona GameModeIcon_*>|<nome evento>
// Se l'ASI non risponde, UnlocksView mantiene il timer di 2 s che mostra il pacchetto dummy.
//
// Cartella del server: nessun nome fisso, viene cercata tra le sottocartelle della cartella del gioco (struttura
// drivers\DefaultPersonaIdx.xml + data\, preferendo quella il cui config\config.json punta a questo nfsw.exe);
// ServerFolder nell'ini la imposta a mano.
//
// Convivenza con NFSWDriverSkills.asi: gli hook (RegisterAll e i due slot ExternalInterface) sono concatenati,
// cioe' viene chiamato il gestore che era installato prima (originale o di un altro ASI), mai sostituito.

#include <windows.h>

// ---------------------------------------------------------------- indirizzi (nfsw.exe 2015)
static const DWORD kBase              = 0x00400000;
static const DWORD kRegistryGlobal    = 0x00CEA7A4; // registro dei comandi "Request"
static const DWORD kRegisterCmd       = 0x00524410; // void __thiscall (registry, const char*, handler)
static const DWORD kRegisterAllSite   = 0x00522B9F; // call RegisterAll(registry)
static const DWORD kRegisterAll       = 0x004C4C50; // void __cdecl (registry)
static const DWORD kScreenEISlot      = 0x00B729C4; // ExternalInterface::Callback delle schermate FE
static const DWORD kScreenEIOrig      = 0x004ABBB0;
static const DWORD kGadgetEISlot      = 0x00B2D030; // ExternalInterface::Callback dei gadget
static const DWORD kGadgetEIOrig      = 0x004867E0;
static const DWORD kCurrentPersonaId  = 0x0043FDD0; // unsigned __int64 __cdecl (), id della persona in uso
static const int   kMovieSetRetVal    = 0xB4;       // GFxMovieView vtable: SetExternalInterfaceRetVal

// ---------------------------------------------------------------- valore GFx
struct GVal { void* obj; unsigned type; union { double n; const char* s; const char** ms; unsigned char b; } v; };
typedef void (__cdecl *ReqHandler)(void* ctx, const GVal* args, unsigned argc);
typedef void (__fastcall *EICallback)(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc);

// ---------------------------------------------------------------- stato
static DWORD g_delta;
static char  g_dir[MAX_PATH];        // cartella dell'ASI (Data\Scripts\)
static char  g_ini[MAX_PATH];
static char  g_sav[MAX_PATH];
static char  g_log[MAX_PATH];
static char  g_server[MAX_PATH];     // cartella del server offline
static char  g_rewards[MAX_PATH];    // LevelUpRewards.xml
static bool  g_logOn = true;
static int   g_maxMerge = 5;         // livelli massimi uniti in una sola schermata
static DWORD g_prevRegisterAll, g_prevScreenEI, g_prevGadgetEI;
static void* g_movie;                // movie della chiamata ExternalInterface in corso
static bool  g_registered;

static char  g_xml[512 * 1024];      // LevelUpRewards.xml
static char  g_out[32 * 1024];       // risposta per Flash

// ---------------------------------------------------------------- mini libc
extern "C" void* __cdecl memset(void* d, int c, size_t n) { unsigned char* p = (unsigned char*)d; while (n--) *p++ = (unsigned char)c; return d; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; while (n--) *a++ = *b++; return d; }
static int  StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); if (n < cap) StrCpy(d + n, s, cap - n); }
static bool StartsWith(const char* s, const char* p) { while (*p) if (*s++ != *p++) return false; return true; }
static void IntToStr(int v, char* out) { char t[16]; int n = 0; bool neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (neg) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static void UIntToStr(unsigned u, char* out) { char t[16]; int n = 0; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; while (n) out[i++] = t[--n]; out[i] = 0; }
static int  ParseInt(const char* p) { while (*p == ' ' || *p == '\t') ++p; bool neg = *p == '-'; if (neg) ++p; int v = 0; while (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); ++p; } return neg ? -v : v; }
static const char* Find(const char* s, const char* end, const char* what)
{
    int n = StrLen(what);
    for (; s + n <= end; ++s) { int i = 0; while (i < n && s[i] == what[i]) ++i; if (i == n) return s; }
    return 0;
}

static void Log(const char* a, const char* b = 0, const char* c = 0, const char* d = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME t; GetLocalTime(&t);
    char ts[16]; ts[0] = '[';
    int v[3] = { t.wHour, t.wMinute, t.wSecond };
    for (int i = 0; i < 3; ++i) { ts[1 + i * 3] = (char)('0' + v[i] / 10); ts[2 + i * 3] = (char)('0' + v[i] % 10); ts[3 + i * 3] = i < 2 ? ':' : ']'; }
    ts[10] = ' '; ts[11] = 0;
    DWORD w; const char* parts[5] = { ts, a, b, c, d };
    for (int i = 0; i < 5; ++i) if (parts[i]) WriteFile(h, parts[i], StrLen(parts[i]), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}
static void LogHex(const char* what, DWORD v)
{
    char buf[16]; const char* hx = "0123456789ABCDEF"; buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 8; ++i) buf[2 + i] = hx[(v >> (28 - 4 * i)) & 15];
    buf[10] = 0; Log(what, buf);
}

static inline DWORD A(DWORD va) { return va + g_delta; }
static bool Readable(const void* p, unsigned n) { return p && !IsBadReadPtr(p, n); }

// ---------------------------------------------------------------- patch concatenate
// Sostituisce la destinazione di una call rel32 e restituisce quella precedente (originale o hook di un altro ASI).
static bool ChainCall(DWORD site, DWORD* prev, void* fn, DWORD orig, const char* what)
{
    unsigned char* p = (unsigned char*)A(site);
    if (!Readable(p, 5) || p[0] != 0xE8) { Log("[init] ", what, ": istruzione inattesa, hook non installato"); return false; }
    DWORD target = (DWORD)p + 5 + *(int*)(p + 1);
    if (target == (DWORD)fn) return true;
    DWORD old;
    if (!VirtualProtect(p + 1, 4, PAGE_EXECUTE_READWRITE, &old)) return false;
    *prev = target;
    *(int*)(p + 1) = (int)((DWORD)fn - ((DWORD)p + 5));
    VirtualProtect(p + 1, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    Log("[init] ", what, target == A(orig) ? ": hook installato" : ": hook concatenato a quello di un altro ASI");
    return true;
}
static bool ChainPtr(DWORD addr, DWORD* prev, void* fn, DWORD orig, const char* what)
{
    DWORD* p = (DWORD*)A(addr);
    if (!Readable(p, 4) || !*p) { Log("[init] ", what, ": slot non valido, hook non installato"); return false; }
    if (*p == (DWORD)fn) return true;
    DWORD old;
    if (!VirtualProtect(p, 4, PAGE_READWRITE, &old)) return false;
    *prev = *p;
    *p = (DWORD)fn;
    VirtualProtect(p, 4, old, &old);
    Log("[init] ", what, *prev == A(orig) ? ": hook installato" : ": hook concatenato a quello di un altro ASI");
    return true;
}

// ---------------------------------------------------------------- file
static int ReadWholeFile(const char* path, char* buf, int cap, FILETIME* mtime)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return -1;
    if (mtime) { mtime->dwLowDateTime = mtime->dwHighDateTime = 0; GetFileTime(h, 0, 0, mtime); }
    DWORD size = GetFileSize(h, 0), got = 0;
    if (size == 0xFFFFFFFF || (int)size >= cap) { CloseHandle(h); return -1; }
    BOOL ok = ReadFile(h, buf, size, &got, 0);
    CloseHandle(h);
    if (!ok) return -1;
    buf[got] = 0;
    return (int)got;
}
static bool Newer(const FILETIME& a, const FILETIME& b)
{
    return a.dwHighDateTime != b.dwHighDateTime ? a.dwHighDateTime > b.dwHighDateTime : a.dwLowDateTime > b.dwLowDateTime;
}
// percorso relativo alla cartella dell'ASI, oppure assoluto
static void ResolvePath(char* out, const char* p)
{
    if (p[0] && (p[1] == ':' || (p[0] == '\\' && p[1] == '\\'))) { StrCpy(out, p, MAX_PATH); return; }
    StrCpy(out, g_dir, MAX_PATH); StrCat(out, p, MAX_PATH);
}

// ---------------------------------------------------------------- ricerca della cartella del server
// Nessun nome fisso: viene cercata, tra le sottocartelle della cartella del gioco (quella che contiene Data)
// e della cartella dell'eseguibile, quella che ha la struttura del server offline (drivers\DefaultPersonaIdx.xml
// e data\). Se piu' cartelle sono valide vince quella il cui config\config.json punta a questo nfsw.exe.
static bool FileExists(const char* path)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return false;
    CloseHandle(h);
    return true;
}
static bool DirExists(const char* path)
{
    WIN32_FIND_DATAA fd; char m[MAX_PATH]; StrCpy(m, path, MAX_PATH); StrCat(m, "*", MAX_PATH);
    HANDLE f = FindFirstFileA(m, &fd);
    if (f == INVALID_HANDLE_VALUE) return false;
    FindClose(f);
    return true;
}
static char LowerSlash(char c) { if (c == '/') return '\\'; return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
// config\config.json del server: "nfswFilePath" coincide con l'eseguibile in uso?
static bool ConfigPointsToExe(const char* server, const char* exe)
{
    static char buf[8 * 1024];
    char path[MAX_PATH]; StrCpy(path, server, MAX_PATH); StrCat(path, "config\\config.json", MAX_PATH);
    int n = ReadWholeFile(path, buf, sizeof(buf), 0);
    if (n <= 0) return false;
    const char* p = Find(buf, buf + n, "\"nfswFilePath\"");
    if (!p) return false;
    p = Find(p + 14, buf + n, "\"");
    if (!p) return false;
    ++p;
    const char* e = exe;
    while (p < buf + n && *p != '"') {
        char c = *p++;
        if (c == '\\' && p < buf + n && (*p == '\\' || *p == '/')) c = *p++;
        if (!*e || LowerSlash(c) != LowerSlash(*e)) return false;
        ++e;
    }
    return *e == 0;
}
static int ScanForServer(const char* root, const char* exe, char* best, int bestScore)
{
    char mask[MAX_PATH]; StrCpy(mask, root, MAX_PATH); StrCat(mask, "*", MAX_PATH);
    WIN32_FIND_DATAA fd;
    HANDLE f = FindFirstFileA(mask, &fd);
    if (f == INVALID_HANDLE_VALUE) return bestScore;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == '.') continue;
        char dir[MAX_PATH]; StrCpy(dir, root, MAX_PATH); StrCat(dir, fd.cFileName, MAX_PATH); StrCat(dir, "\\", MAX_PATH);
        char t[MAX_PATH]; StrCpy(t, dir, MAX_PATH); StrCat(t, "drivers\\DefaultPersonaIdx.xml", MAX_PATH);
        if (!FileExists(t)) continue;
        StrCpy(t, dir, MAX_PATH); StrCat(t, "data\\", MAX_PATH);
        if (!DirExists(t)) continue;
        int score = 1;
        StrCpy(t, dir, MAX_PATH); StrCat(t, "data\\events\\LevelUpRewards.xml", MAX_PATH);
        if (FileExists(t)) score += 1;
        if (ConfigPointsToExe(dir, exe)) score += 2;
        Log("[server] trovato: ", dir, score >= 3 ? " (configurato per questo nfsw.exe)" : "");
        if (score > bestScore) { bestScore = score; StrCpy(best, dir, MAX_PATH); }
    } while (FindNextFileA(f, &fd));
    FindClose(f);
    return bestScore;
}
static bool FindServerFolder(char* out)
{
    char exe[MAX_PATH], exeDir[MAX_PATH], root[MAX_PATH];
    DWORD n = GetModuleFileNameA(0, exe, MAX_PATH);
    if (!n || n >= MAX_PATH) return false;
    StrCpy(exeDir, exe, MAX_PATH);
    int cut = -1;
    for (int i = (int)n - 1; i >= 0; --i) if (exeDir[i] == '\\' || exeDir[i] == '/') { cut = i; break; }
    if (cut < 0) return false;
    exeDir[cut + 1] = 0;                                   // ...\Data\  .
    StrCpy(root, exeDir, MAX_PATH); root[cut] = 0;
    int up = -1;
    for (int i = cut - 1; i >= 0; --i) if (root[i] == '\\' || root[i] == '/') { up = i; break; }
    root[up + 1] = 0;                                      // cartella del gioco
    int score = 0;
    if (up >= 0) score = ScanForServer(root, exe, out, score);
    score = ScanForServer(exeDir, exe, out, score);
    return score > 0;
}
static void ResolveServer()
{
    char tmp[MAX_PATH];
    GetPrivateProfileStringA("LevelUpRewards", "ServerFolder", "", tmp, MAX_PATH, g_ini);
    if (tmp[0]) ResolvePath(g_server, tmp);
    else if (!FindServerFolder(g_server)) { g_server[0] = 0; Log("[server] cartella del server offline non trovata (indicarla con ServerFolder nell'ini)"); }
    int n = StrLen(g_server);
    if (n && g_server[n - 1] != '\\' && g_server[n - 1] != '/') StrCat(g_server, "\\", MAX_PATH);
    GetPrivateProfileStringA("LevelUpRewards", "RewardsFile", "", tmp, MAX_PATH, g_ini);
    if (tmp[0]) ResolvePath(g_rewards, tmp);
    else if (g_server[0]) { StrCpy(g_rewards, g_server, MAX_PATH); StrCat(g_rewards, "data\\events\\LevelUpRewards.xml", MAX_PATH); }
    else { StrCpy(g_rewards, g_dir, MAX_PATH); StrCat(g_rewards, "LevelUpRewards.xml", MAX_PATH); }
    Log("[init] server: ", g_server[0] ? g_server : "(non trovato)");
    Log("[init] premi: ", g_rewards);
}

// ---------------------------------------------------------------- livello del pilota (file del server)
static int TagInt(const char* xml, const char* tag)
{
    const char* end = xml + StrLen(xml);
    const char* p = Find(xml, end, tag);
    if (!p) return -1;
    return ParseInt(p + StrLen(tag));
}

static unsigned CurrentPersonaId()
{
    const unsigned char* f = (const unsigned char*)A(kCurrentPersonaId);
    if (!Readable(f, 5) || f[0] != 0xB8) return 0;
    unsigned long long id = ((unsigned long long (__cdecl*)())f)();
    if (id == 0 || id > 0x7FFFFFFFULL) return 0;
    return (unsigned)id;
}

// Restituisce il livello del pilota (0 se non trovato); *outId = PersonaId del file usato.
static int ReadPersonaLevel(unsigned wantId, unsigned* outId)
{
    if (!g_server[0]) return 0;
    char mask[MAX_PATH]; StrCpy(mask, g_server, MAX_PATH); StrCat(mask, "drivers\\driver*", MAX_PATH);
    WIN32_FIND_DATAA fd;
    HANDLE f = FindFirstFileA(mask, &fd);
    if (f == INVALID_HANDLE_VALUE) { Log("[livello] cartella drivers non trovata: ", mask); return 0; }
    int bestLevel = 0, matchLevel = 0; unsigned bestId = 0;
    FILETIME bestTime = { 0, 0 };
    static char buf[16 * 1024];
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        char path[MAX_PATH]; StrCpy(path, g_server, MAX_PATH); StrCat(path, "drivers\\", MAX_PATH);
        StrCat(path, fd.cFileName, MAX_PATH); StrCat(path, "\\GetPersonaInfo.xml", MAX_PATH);
        FILETIME t;
        if (ReadWholeFile(path, buf, sizeof(buf), &t) <= 0) continue;
        int id = TagInt(buf, "<PersonaId>"), lv = TagInt(buf, "<Level>");
        if (id <= 0 || lv <= 0) continue;
        if (wantId && (unsigned)id == wantId) { matchLevel = lv; }
        if (!bestId || Newer(t, bestTime)) { bestTime = t; bestLevel = lv; bestId = (unsigned)id; }
    } while (FindNextFileA(f, &fd));
    FindClose(f);
    if (matchLevel) { *outId = wantId; return matchLevel; }
    *outId = bestId;
    return bestLevel;
}

// ---------------------------------------------------------------- LevelUpRewards.xml
static bool g_full;
static void Out(const char* s)
{
    int n = StrLen(g_out), m = StrLen(s);
    if (n + m >= (int)sizeof(g_out) - 1) { g_full = true; return; }
    memcpy(g_out + n, s, m + 1);
}
// valore di un attributo (entita' XML decodificate, niente '|' o a capo); false se assente
static bool Attr(const char* tag, const char* tagEnd, const char* name, char* out, int cap)
{
    char key[32]; StrCpy(key, " ", 32); StrCat(key, name, 32); StrCat(key, "=", 32);
    const char* p = Find(tag, tagEnd, key);
    if (!p) return false;
    p += StrLen(key);
    char q = *p;
    if (q != '"' && q != '\'') return false;
    ++p;
    int n = 0;
    while (p < tagEnd && *p != q && n < cap - 1) {
        char c = *p;
        if (c == '&') {
            if (StartsWith(p, "&amp;")) { c = '&'; p += 5; }
            else if (StartsWith(p, "&lt;")) { c = '<'; p += 4; }
            else if (StartsWith(p, "&gt;")) { c = '>'; p += 4; }
            else if (StartsWith(p, "&quot;")) { c = '"'; p += 6; }
            else if (StartsWith(p, "&apos;")) { c = '\''; p += 6; }
            else ++p;
        } else ++p;
        if (c == '|' ) c = '/';
        if (c == '\r' || c == '\n' || c == '\t') c = ' ';
        out[n++] = c;
    }
    out[n] = 0;
    return true;
}

static int g_lastCars, g_lastEvents;
// Aggiunge alla risposta i premi del livello indicato.
static bool AppendLevel(const char* xml, int level)
{
    const char* end = xml + StrLen(xml);
    for (const char* p = xml; (p = Find(p, end, "<Level ")) != 0; ++p) {
        const char* gt = Find(p, end, ">");
        if (!gt) return false;
        char val[16];
        if (!Attr(p, gt, "value", val, sizeof(val)) || ParseInt(val) != level) continue;
        if (gt[-1] == '/') return true;                        // <Level value="n" />: nessun premio
        const char* blockEnd = Find(gt, end, "</Level>");
        if (!blockEnd) blockEnd = end;
        for (const char* t = gt; t < blockEnd; ++t) {
            if (*t != '<') continue;
            bool car = StartsWith(t, "<Car "), ev = StartsWith(t, "<Event ");
            if (!car && !ev) continue;
            const char* te = Find(t, blockEnd, ">");
            if (!te) break;
            char a[128], b[64], c[128];
            if (car) {
                if (!Attr(t, te, "name", a, sizeof(a))) continue;
                if (!Attr(t, te, "tier", b, sizeof(b))) b[0] = 0;
                if (!Attr(t, te, "icon", c, sizeof(c))) c[0] = 0;
                Out("C|"); Out(a); Out("|"); Out(b); Out("|"); Out(c); Out("\n");
                ++g_lastCars;
            } else {
                if (!Attr(t, te, "id", b, sizeof(b))) b[0] = 0;
                if (!Attr(t, te, "icon", c, sizeof(c))) StrCpy(c, "GameModeIcon_Sprint_Large", sizeof(c));
                if (!Attr(t, te, "name", a, sizeof(a))) continue;
                Out("E|"); Out(b); Out("|"); Out(c); Out("|"); Out(a); Out("\n");
                ++g_lastEvents;
            }
            t = te;
        }
        return true;
    }
    return false;
}

static bool LoadRewards()
{
    int n = ReadWholeFile(g_rewards, g_xml, sizeof(g_xml), 0);
    if (n <= 0) {
        char alt[MAX_PATH]; StrCpy(alt, g_dir, MAX_PATH); StrCat(alt, "LevelUpRewards.xml", MAX_PATH);
        n = ReadWholeFile(alt, g_xml, sizeof(g_xml), 0);
        if (n <= 0) { Log("[premi] file dei premi non trovato: ", g_rewards); return false; }
        Log("[premi] uso il file di riserva ", alt);
    }
    // i commenti non vanno interpretati
    for (char* p = g_xml; (p = (char*)Find(p, g_xml + n, "<!--")) != 0; ) {
        char* e = (char*)Find(p, g_xml + n, "-->");
        char* stop = e ? e + 3 : g_xml + n;
        while (p < stop) *p++ = ' ';
    }
    return true;
}

// ---------------------------------------------------------------- risposta a Flash
static void SetReturnString(const char* value)
{
    void* movie = g_movie;
    if (!Readable(movie, 4)) { Log("[flash] movie non disponibile, nessun valore di ritorno"); return; }
    void** vt = *(void***)movie;
    if (!Readable(vt + kMovieSetRetVal / 4, 4)) return;
    GVal v; memset(&v, 0, sizeof(v));
    v.type = 4; v.v.s = value;
    typedef void (__fastcall *SetRet)(void*, void*, const GVal*);
    ((SetRet)vt[kMovieSetRetVal / 4])(movie, 0, &v);
}

static int ArgInt(const GVal* a)
{
    if (!a) return 0;
    unsigned t = a->type & 0x8F;
    if (t == 3) return (int)a->v.n;
    if (t == 4) { const char* s = (a->type & 0x40) ? (a->v.ms ? *a->v.ms : 0) : a->v.s; return s ? ParseInt(s) : 0; }
    return 0;
}

static void __cdecl Req_LevelUpInfo(void*, const GVal* args, unsigned argc)
{
    g_out[0] = 0; g_full = false; g_lastCars = g_lastEvents = 0;
    if (!g_server[0]) ResolveServer();                         // il server potrebbe essere stato aggiunto dopo l'avvio
    unsigned want = CurrentPersonaId(), id = 0;
    int level = argc > 0 ? ArgInt(&args[0]) : 0;               // Flash puo' indicare il livello (opzionale)
    if (level <= 0) level = ReadPersonaLevel(want, &id);
    else id = want;
    char num[16], num2[16], sect[32];
    UIntToStr(want, num); IntToStr(level, num2);
    Log("[richiesta] PostRaceGetLevelUpInfo: persona in gioco ", num, ", livello ", num2);
    if (level <= 0) { Log("[richiesta] livello non disponibile: UnlocksView usera' il pacchetto di riserva"); return; }

    // livelli raggiunti dall'ultima schermata dei premi
    UIntToStr(id, num); StrCpy(sect, "Persona_", sizeof(sect)); StrCat(sect, num, sizeof(sect));
    int last = (int)GetPrivateProfileIntA(sect, "Level", 0, g_sav);
    int from = level;
    if (last > 0 && last < level) from = level - last > g_maxMerge ? level - g_maxMerge + 1 : last + 1;
    if (!LoadRewards()) return;

    Out("L|"); IntToStr(level, num2); Out(num2);
    if (from != level) { Out("|"); IntToStr(from, num2); Out(num2); }
    Out("\n");
    bool any = false;
    for (int lv = from; lv <= level; ++lv) any |= AppendLevel(g_xml, lv);
    if (!any) Log("[premi] nessuna voce <Level> per questo livello");
    IntToStr(level, num2); WritePrivateProfileStringA(sect, "Level", num2, g_sav);

    SetReturnString(g_out);
    char c1[16], c2[16], c3[16]; IntToStr(from, c1); IntToStr(g_lastCars, c2); IntToStr(g_lastEvents, c3);
    Log("[premi] livelli ", c1, "..", num2);
    Log("[premi] auto: ", c2, ", eventi: ", c3);
    if (g_full) Log("[premi] risposta troncata (troppe voci)");
}

// ---------------------------------------------------------------- hook
static void __fastcall Hook_ScreenEI(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc)
{
    void* prev = g_movie; g_movie = movie;
    ((EICallback)g_prevScreenEI)(self, edx, movie, method, args, argc);
    g_movie = prev;
}
static void __fastcall Hook_GadgetEI(void* self, void* edx, void* movie, const char* method, const GVal* args, unsigned argc)
{
    void* prev = g_movie; g_movie = movie;
    ((EICallback)g_prevGadgetEI)(self, edx, movie, method, args, argc);
    g_movie = prev;
}

static void RegisterCommands(void* registry)
{
    if (!registry) return;
    typedef void (__fastcall *RegFn)(void*, void*, const char*, void*);
    ((RegFn)A(kRegisterCmd))(registry, 0, "PostRaceGetLevelUpInfo", (void*)Req_LevelUpInfo);
    g_registered = true;
    LogHex("[init] comando PostRaceGetLevelUpInfo registrato in ", (DWORD)registry);
}
static void __cdecl Hook_RegisterAll(void* registry)
{
    ((void (__cdecl*)(void*))g_prevRegisterAll)(registry);
    RegisterCommands(registry);
}

// ---------------------------------------------------------------- init
static void Init(HMODULE self)
{
    g_delta = (DWORD)GetModuleHandleA(0) - kBase;
    DWORD n = GetModuleFileNameA(self, g_dir, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    for (int i = (int)n - 1; i >= 0; --i) if (g_dir[i] == '\\' || g_dir[i] == '/') { g_dir[i + 1] = 0; break; }
    StrCpy(g_ini, g_dir, MAX_PATH); StrCat(g_ini, "NFSWLevelUpRewards.ini", MAX_PATH);
    StrCpy(g_sav, g_dir, MAX_PATH); StrCat(g_sav, "NFSWLevelUpRewards.sav", MAX_PATH);
    StrCpy(g_log, g_dir, MAX_PATH); StrCat(g_log, "NFSWLevelUpRewards.log", MAX_PATH);
    if (!GetPrivateProfileIntA("LevelUpRewards", "Enabled", 1, g_ini)) return;
    g_logOn = GetPrivateProfileIntA("LevelUpRewards", "Log", 1, g_ini) != 0;
    g_maxMerge = (int)GetPrivateProfileIntA("LevelUpRewards", "MaxMergedLevels", 5, g_ini);
    if (g_maxMerge < 1) g_maxMerge = 1;
    if (g_logOn) DeleteFileA(g_log);

    ResolveServer();

    // controllo dell'eseguibile
    const unsigned char* site = (const unsigned char*)A(kRegisterAllSite);
    const unsigned char* pid = (const unsigned char*)A(kCurrentPersonaId);
    if (!Readable(site, 5) || site[0] != 0xE8 || !Readable(pid, 5) || pid[0] != 0xB8) { Log("[init] nfsw.exe sconosciuto, ASI disattivato"); return; }

    ChainCall(kRegisterAllSite, &g_prevRegisterAll, (void*)Hook_RegisterAll, kRegisterAll, "RegisterAll");
    ChainPtr(kScreenEISlot, &g_prevScreenEI, (void*)Hook_ScreenEI, kScreenEIOrig, "ExternalInterface schermate");
    ChainPtr(kGadgetEISlot, &g_prevGadgetEI, (void*)Hook_GadgetEI, kGadgetEIOrig, "ExternalInterface gadget");
    void* reg = Readable((void*)A(kRegistryGlobal), 4) ? *(void**)A(kRegistryGlobal) : 0;
    if (reg) RegisterCommands(reg);
}

extern "C" BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hinst);
        Init(hinst);
    }
    return TRUE;
}
