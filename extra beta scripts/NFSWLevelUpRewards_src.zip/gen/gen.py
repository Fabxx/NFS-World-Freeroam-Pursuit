#!/usr/bin/env python3
# Genera la patch del server per i premi di livello:
#  data/events/availableatlevel.xml   (MinLevel per livello, 1..60)
#  data/catalog/productsInCategory_NFSW_NA_EP_PRESET_RIDES_ALL_Category.xml (Level delle auto di serie)
#  data/DriverPersona/GetExpLevelPointsMap.xml (60 livelli)
#  data/events/LevelUpRewards.xml     (premi per livello letti da NFSWLevelUpRewards.asi)
import json, re, sys, os, collections
from xml.sax.saxutils import escape, quoteattr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from names import NAMES

SRV, OUT = sys.argv[1], sys.argv[2]
MAXLV = 60
CLS = {872416321:'E', 415909161:'D', 1866825865:'C', -406473455:'B', -405837480:'A', -2142411446:'S', 607077938:'O'}
MODE = {4:'Circuit', 9:'Sprint', 12:'Pursuit', 19:'Drag', 22:'Meet', 24:'TeamEsc'}
ICON = {'Sprint':'GameModeIcon_Sprint_Large', 'Circuit':'GameModeIcon_Circuit_Large', 'Drag':'GameModeIcon_Drag_Large',
        'Pursuit':'GameModeIcon_Pursuit_Sp_Large', 'TeamEsc':'GameModeIcon_Pursuit_Mp_Large'}
MODENAME = {'Sprint':'SPRINT', 'Circuit':'CIRCUIT', 'Drag':'DRAG', 'Pursuit':'PURSUIT', 'TeamEsc':'TEAM ESCAPE'}
# fasce di livello (inclusive) in cui si sbloccano eventi e auto di serie di ogni classe
EV_BAND = {'E':(2,12), 'D':(3,20), 'C':(10,32), 'B':(20,42), 'A':(30,54), 'S':(42,60), 'O':(2,60)}
CAR_BAND = {'D':(2,18), 'C':(10,30), 'B':(20,42), 'A':(30,52), 'S':(44,60)}
TUTORIAL = 48

def spread(items, a, b):
    n = len(items)
    if n == 0: return {}
    if n == 1: return {items[0]: a}
    return {it: a + round(i * (b - a) / (n - 1)) for i, it in enumerate(items)}

def roundrobin(groups, order):
    q = {k: list(groups.get(k, [])) for k in order}
    out = []
    while any(q.values()):
        for k in order:
            if q[k]: out.append(q[k].pop(0))
    return out

def evname(name, mode):
    n = re.sub(r'\s*\([^()]*\)\s*$', '', name.strip()).strip()
    if not n or set(n) <= set('?'): n = MODENAME.get(mode, 'EVENT')
    return n.upper().replace('|', '/')

# ---------------------------------------------------------------- eventi
events = {e['ID']: e for e in json.load(open(os.path.join(SRV, 'config/Assets/events.json'), encoding='utf-8'))}
aal_path = os.path.join(SRV, 'data/events/availableatlevel.xml')
aal = open(aal_path, encoding='utf-8', newline='').read()
ids = [int(i) for i in re.findall(r'<EventId>(\d+)</EventId>', aal)]
lv_event = {}
by_cls = collections.defaultdict(lambda: collections.defaultdict(list))
for i in sorted(ids):
    e = events[i]; c = CLS.get(e['carClassHash'], 'O'); m = MODE.get(e['eventModeId'], 'Sprint')
    if i == TUTORIAL or m == 'Meet': lv_event[i] = 1; continue
    by_cls[c][m].append(i)
for c, (a, b) in EV_BAND.items():
    order = ['Sprint', 'Circuit', 'Drag', 'Pursuit', 'TeamEsc']
    lv_event.update(spread(roundrobin(by_cls[c], order), a, b))
assert set(lv_event) == set(ids)

def set_min(m):
    body = m.group(0)
    i = int(re.search(r'<EventId>(\d+)</EventId>', body).group(1))
    return re.sub(r'<MinLevel>\d+</MinLevel>', '<MinLevel>%d</MinLevel>' % lv_event[i], body)
aal_new = re.sub(r'<EventDefinition>.*?</EventDefinition>', set_min, aal, flags=re.S)

# ---------------------------------------------------------------- auto
products = [p for p in json.load(open(os.path.join(SRV, 'config/Assets/products.json'), encoding='utf-8')) if p['productType'] == 'PRESETCAR']
cat_name = 'productsInCategory_NFSW_NA_EP_PRESET_RIDES_ALL_Category.xml'
cat = open(os.path.join(SRV, 'data/catalog', cat_name), encoding='utf-8', newline='').read()
price = {int(re.search(r'<Hash>(-?\d+)</Hash>', s).group(1)): float(re.search(r'<Price>([\d.]+)</Price>', s).group(1))
         for s in re.findall(r'<ProductTrans>.*?</ProductTrans>', cat, re.S)}
models = collections.defaultdict(list)   # (classe, modello) -> prodotti di serie
for p in products:
    if p['hash'] not in price or p['subType'] != 'car_base': continue
    pre, _, model = (p['longDescription'] or '').partition('_')
    if pre not in CAR_BAND or price[p['hash']] <= 0: continue
    models[(pre, model)].append(p)
lv_model = {}
for c, (a, b) in CAR_BAND.items():
    ms = sorted([k for k in models if k[0] == c], key=lambda k: (min(price[p['hash']] for p in models[k]), k[1]))
    lv_model.update(spread(ms, a, b))
lv_hash = {p['hash']: lv_model[k] for k, ps in models.items() for p in ps}
missing = [k[1] for k in models if k[1] not in NAMES]
assert not missing, missing

def set_level(m):
    body = m.group(0)
    h = int(re.search(r'<Hash>(-?\d+)</Hash>', body).group(1))
    if h not in lv_hash: return body
    return re.sub(r'<Level>\d+</Level>', '<Level>%d</Level>' % lv_hash[h], body)
cat_new = re.sub(r'<ProductTrans>.*?</ProductTrans>', set_level, cat, flags=re.S)

# ---------------------------------------------------------------- premi per livello
per = collections.defaultdict(lambda: {'cars': [], 'events': []})
for k, lv in sorted(lv_model.items(), key=lambda kv: (kv[1], NAMES[kv[0][1]])):
    p = models[k][0]
    per[lv]['cars'].append((NAMES[k[1]], 'CLASS ' + k[0], p['entitlementTag']))
for i, lv in sorted(lv_event.items(), key=lambda kv: (kv[1], kv[0])):
    if lv < 2: continue
    e = events[i]; m = MODE[e['eventModeId']]
    per[lv]['events'].append((i, ICON[m], evname(e['name'], m)))

x = ['<?xml version="1.0" encoding="utf-8"?>',
     '<!-- Premi mostrati da UnlocksView.gfx al passaggio di livello (letti da NFSWLevelUpRewards.asi).',
     '     Generato insieme a availableatlevel.xml (MinLevel degli eventi) e al catalogo PRESET_RIDES (Level delle auto),',
     '     quindi ogni voce corrisponde a un evento sbloccato sulla mappa o a un\'auto sbloccata nel concessionario.',
     '     Car: name, tier (testo sotto il nome), icon.  Event: id (EventId), icon (GameModeIcon_*), name. -->',
     '<LevelUpRewards maxLevel="%d">' % MAXLV]
for lv in range(2, MAXLV + 1):
    r = per[lv]
    x.append('  <Level value="%d">' % lv)
    for n, t, ic in r['cars']: x.append('    <Car name=%s tier=%s icon=%s />' % (quoteattr(n), quoteattr(t), quoteattr(ic)))
    for i, ic, n in r['events']: x.append('    <Event id="%d" icon=%s name=%s />' % (i, quoteattr(ic), quoteattr(n)))
    x.append('  </Level>')
x.append('</LevelUpRewards>')

xp = open(os.path.join(SRV, 'data/DriverPersona/GetExpLevelPointsMap.xml'), encoding='utf-8', newline='').read()
xps = re.findall(r'<int>(\d+)</int>', xp)
assert len(xps) >= MAXLV - 0
xp_new = '<!-- Soglie di esperienza NFS World 2015: %d livelli = livello massimo %d -->\n<ArrayOfInt>\n%s</ArrayOfInt>\n' % (
    MAXLV, MAXLV, ''.join('\t<int>%s</int>\n' % v for v in xps[:MAXLV]))

def w(rel, s):
    p = os.path.join(OUT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    if '\r\n' not in s: s = s.replace('\n', '\r\n')
    open(p, 'w', encoding='utf-8', newline='').write(s)
w('data/events/availableatlevel.xml', aal_new)
w('data/catalog/' + cat_name, cat_new)
w('data/DriverPersona/GetExpLevelPointsMap.xml', xp_new)
w('data/events/LevelUpRewards.xml', '\n'.join(x) + '\n')

cnt = [(lv, len(per[lv]['cars']), len(per[lv]['events'])) for lv in range(2, MAXLV + 1)]
print('livelli senza premi:', [c[0] for c in cnt if c[1] + c[2] == 0])
print('max voci per livello:', max(c[1] + c[2] for c in cnt), 'media %.1f' % (sum(c[1] + c[2] for c in cnt) / len(cnt)))
print(' '.join('%d:%d+%d' % c for c in cnt))
