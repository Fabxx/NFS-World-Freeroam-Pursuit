// NFSWBetaCameraFX - 2009/2010 beta-style driving camera effects.
//
// Effects:
//   - Native beta shake
//   - Surface shake
//   - Gear-shift shake
//   - Impact shake
//   - Near-miss roll
//   - Hard braking: the camera dives toward the car and pitches down
//
// NearMiss:
//   No lateral camera translation.
//   Only camera roll is applied, with smooth acceleration and return.

#include <windows.h>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <cstdlib>

namespace {

    constexpr uintptr_t RVA_CALL_SITE = 0x3DAE17;
    constexpr uintptr_t RVA_BUILDLOOKAT = 0x235D50;

    using BuildLookAt_t =
        void(__cdecl*)(float* out,
            const float* eye,
            const float* target,
            const float* up);

    BuildLookAt_t g_buildLookAt = nullptr;


    // ============================================================================
    // ATTRIBUTE HASH
    // ============================================================================

    uint32_t AttribHash(const char* str)
    {
        const uint8_t* k = (const uint8_t*)str;

        uint32_t len = (uint32_t)strlen(str);
        uint32_t a = 0x9E3779B9;
        uint32_t b = 0x9E3779B9;
        uint32_t c = 0xABCDEF00;
        uint32_t n = len;

        auto mix = [&]()
            {
                a -= b; a -= c; a ^= (c >> 13);
                b -= c; b -= a; b ^= (a << 8);
                c -= a; c -= b; c ^= (b >> 13);

                a -= b; a -= c; a ^= (c >> 12);
                b -= c; b -= a; b ^= (a << 16);
                c -= a; c -= b; c ^= (b >> 5);

                a -= b; a -= c; a ^= (c >> 3);
                b -= c; b -= a; b ^= (a << 10);
                c -= a; c -= b; c ^= (b >> 15);
            };

        while (n >= 12)
        {
            a += k[0] |
                (k[1] << 8) |
                (k[2] << 16) |
                ((uint32_t)k[3] << 24);

            b += k[4] |
                (k[5] << 8) |
                (k[6] << 16) |
                ((uint32_t)k[7] << 24);

            c += k[8] |
                (k[9] << 8) |
                (k[10] << 16) |
                ((uint32_t)k[11] << 24);

            mix();

            k += 12;
            n -= 12;
        }

        c += len;

        switch (n)
        {
        case 11: c += (uint32_t)k[10] << 24; [[fallthrough]];
        case 10: c += (uint32_t)k[9] << 16; [[fallthrough]];
        case 9:  c += (uint32_t)k[8] << 8; [[fallthrough]];
        case 8:  b += (uint32_t)k[7] << 24; [[fallthrough]];
        case 7:  b += (uint32_t)k[6] << 16; [[fallthrough]];
        case 6:  b += (uint32_t)k[5] << 8; [[fallthrough]];
        case 5:  b += k[4]; [[fallthrough]];
        case 4:  a += (uint32_t)k[3] << 24; [[fallthrough]];
        case 3:  a += (uint32_t)k[2] << 16; [[fallthrough]];
        case 2:  a += (uint32_t)k[1] << 8; [[fallthrough]];
        case 1:  a += k[0];
        }

        mix();

        return c;
    }


    // ============================================================================
    // SETTINGS
    // ============================================================================

    struct Settings
    {
        bool  enabled = true;

        // Native beta shake
        bool  native = true;
        float nativeScale = 1.0f;

        // Braking
        float brakeAmp = 0.10f;
        float brakeFreq = 1.0f;

        // Camera modes:
        // bumper, hood, close, far
        bool modes[4] = {
            false,
            false,
            true,
            true
        };

        float shakeFreq = 9.0f;


        // ------------------------------------------------------------------------
        // Surface
        // ------------------------------------------------------------------------

        bool  surfEnabled = false;

        uint32_t surf[32] = {};
        int surfCount = 0;

        float surfMinSpeed = 4.0f;
        float surfFullSpeed = 30.0f;

        float surfAmp = 0.035f;
        float surfRollDeg = 0.6f;


        // ------------------------------------------------------------------------
        // Gear shift
        // ------------------------------------------------------------------------

        bool  gearEnabled = false;

        float gearMinRpm = 0.0f;

        float gearAmp = 0.07f;
        float gearRollDeg = 1.2f;
        float gearDecay = 6.0f;


        // ------------------------------------------------------------------------
        // Impacts
        // ------------------------------------------------------------------------

        bool impactEnabled = true;

        float impactThresh = 250.0f;
        float impactScale = 800.0f;
        float impactAmp = 0.12f;
        float impactRollDeg = 2.0f;
        float impactDecay = 4.0f;
        float impactCollision = 0.8f;


        // ------------------------------------------------------------------------
        // NearMiss
        //
        // No lateral camera movement.
        // Roll only.
        // ------------------------------------------------------------------------

        bool nmEnabled = true;

        // Maximum lateral distance.
        float nmLateral = 3.2f;

        // Minimum relative passing speed.
        float nmMinRelSpeed = 12.0f;

        // Roll-in time.
        float nmImpulseRise = 0.15f;

        // Return time.
        float nmImpulseReturn = 0.55f;

        // Near-miss roll angle.
        float nmRollDeg = 3.0f;

        // Roll interpolation speed.
        float nmRollSmooth = 10.0f;

        // Steering roll multiplier.
        // 0.0 = no increase, 1.0 = up to 2x base roll.
        float nmSteerGain = 1.0f;

        // Angular speed for full steering contribution.
        float nmSteerFullRate = 1.2f;

        // Steering interpolation speed.
        float nmSteerSmooth = 10.0f;

        // Legacy INI compatibility.
        // No longer used for camera translation.
        float nmImpulse = 0.0f;
        float nmLagGain = 0.0f;
        float nmLagMax = 0.0f;
        float nmLagSmooth = 0.0f;
        float nmHold = 0.0f;
        float nmFade = 0.0f;
        float nmSwayTarget = 0.0f;
        float nmSwaySmooth = 0.0f;

        // Additional near-miss shake.
        float nmShake = 0.0f;


        // ------------------------------------------------------------------------
        // Hard braking
        //
        // When the car decelerates hard, the camera moves toward the car,
        // drops a little and pitches down (nose dive), then springs back.
        // ------------------------------------------------------------------------

        bool hbEnabled = true;

        // Minimum forward speed (m/s).
        float hbMinSpeed = 8.0f;

        // Deceleration (m/s^2) where the effect starts / reaches 100%.
        float hbThreshold = 6.0f;
        float hbFull = 22.0f;

        // Camera movement at 100%.
        float hbForward = 0.9f;
        float hbDrop = 0.18f;
        float hbPitchDeg = 3.0f;

        // Response speed while braking and when releasing the brake.
        float hbRise = 6.0f;
        float hbReturn = 2.5f;


        bool log = false;
    };

    Settings S;

    char g_dir[MAX_PATH];
    FILE* g_log = nullptr;


    // ============================================================================
    // LOG
    // ============================================================================

    void Log(const char* fmt, ...)
    {
        if (!g_log)
            return;

        va_list a;
        va_start(a, fmt);

        vfprintf(g_log, fmt, a);

        va_end(a);

        fputc('\n', g_log);
        fflush(g_log);
    }


    // ============================================================================
    // INI
    // ============================================================================

    float IniF(
        const char* sec,
        const char* key,
        float def,
        const char* ini)
    {
        char buf[64];
        char d[64];

        sprintf_s(d, "%g", def);

        GetPrivateProfileStringA(
            sec,
            key,
            d,
            buf,
            sizeof(buf),
            ini);

        return (float)atof(buf);
    }


    void LoadSettings()
    {
        char ini[MAX_PATH];

        sprintf_s(
            ini,
            "%s\\NFSWBetaCameraFX.ini",
            g_dir);


        // ------------------------------------------------------------------------
        // General
        // ------------------------------------------------------------------------

        S.enabled =
            IniF("General", "Enabled", 1, ini) != 0;

        S.log =
            IniF("General", "Log", 0, ini) != 0;

        S.modes[0] =
            IniF("General", "Bumper", 0, ini) != 0;

        S.modes[1] =
            IniF("General", "Hood", 0, ini) != 0;

        S.modes[2] =
            IniF("General", "Close", 1, ini) != 0;

        S.modes[3] =
            IniF("General", "Far", 1, ini) != 0;

        S.shakeFreq =
            IniF(
                "General",
                "ShakeFrequency",
                S.shakeFreq,
                ini);

        S.native =
            IniF(
                "General",
                "NativeShake",
                1,
                ini) != 0;

        S.nativeScale =
            IniF(
                "General",
                "NativeScale",
                1.0f,
                ini);


        // ------------------------------------------------------------------------
        // Brake
        // ------------------------------------------------------------------------

        S.brakeAmp =
            IniF(
                "Brake",
                "Amplitude",
                S.brakeAmp,
                ini);

        S.brakeFreq =
            IniF(
                "Brake",
                "FrequencyScale",
                S.brakeFreq,
                ini);


        // ------------------------------------------------------------------------
        // Surface
        // ------------------------------------------------------------------------

        S.surfEnabled =
            IniF(
                "Surface",
                "Enabled",
                0,
                ini) != 0;

        S.surfMinSpeed =
            IniF(
                "Surface",
                "MinSpeed",
                S.surfMinSpeed,
                ini);

        S.surfFullSpeed =
            IniF(
                "Surface",
                "FullSpeed",
                S.surfFullSpeed,
                ini);

        S.surfAmp =
            IniF(
                "Surface",
                "Amplitude",
                S.surfAmp,
                ini);

        S.surfRollDeg =
            IniF(
                "Surface",
                "RollDeg",
                S.surfRollDeg,
                ini);


        char list[512];

        GetPrivateProfileStringA(
            "Surface",
            "Names",
            "dirt,mud,dirt_shoulder,grass,grass_shoulder,gravel,sand",
            list,
            sizeof(list),
            ini);

        S.surfCount = 0;

        char* ctx = nullptr;

        for (
            char* t = strtok_s(list, ", ", &ctx);
            t && S.surfCount < 32;
            t = strtok_s(nullptr, ", ", &ctx))
        {
            S.surf[S.surfCount++] =
                (t[0] == '0' &&
                    (t[1] == 'x' || t[1] == 'X'))
                ? strtoul(t, nullptr, 16)
                : AttribHash(t);
        }


        // ------------------------------------------------------------------------
        // Gear
        // ------------------------------------------------------------------------

        S.gearEnabled =
            IniF(
                "GearShift",
                "Enabled",
                0,
                ini) != 0;

        S.gearMinRpm =
            IniF(
                "GearShift",
                "MinRpm",
                S.gearMinRpm,
                ini);

        S.gearAmp =
            IniF(
                "GearShift",
                "Amplitude",
                S.gearAmp,
                ini);

        S.gearRollDeg =
            IniF(
                "GearShift",
                "RollDeg",
                S.gearRollDeg,
                ini);

        S.gearDecay =
            IniF(
                "GearShift",
                "Decay",
                S.gearDecay,
                ini);


        // ------------------------------------------------------------------------
        // Impact
        // ------------------------------------------------------------------------

        S.impactEnabled =
            IniF(
                "Impact",
                "Enabled",
                1,
                ini) != 0;

        S.impactThresh =
            IniF(
                "Impact",
                "Threshold",
                S.impactThresh,
                ini);

        S.impactScale =
            IniF(
                "Impact",
                "Scale",
                S.impactScale,
                ini);

        S.impactAmp =
            IniF(
                "Impact",
                "Amplitude",
                S.impactAmp,
                ini);

        S.impactRollDeg =
            IniF(
                "Impact",
                "RollDeg",
                S.impactRollDeg,
                ini);

        S.impactDecay =
            IniF(
                "Impact",
                "Decay",
                S.impactDecay,
                ini);

        S.impactCollision =
            IniF(
                "Impact",
                "CollisionIntensity",
                S.impactCollision,
                ini);


        // ------------------------------------------------------------------------
        // NearMiss
        // ------------------------------------------------------------------------

        S.nmEnabled =
            IniF(
                "NearMiss",
                "Enabled",
                1,
                ini) != 0;

        S.nmLateral =
            IniF(
                "NearMiss",
                "Lateral",
                S.nmLateral,
                ini);

        S.nmMinRelSpeed =
            IniF(
                "NearMiss",
                "MinRelSpeed",
                S.nmMinRelSpeed,
                ini);

        S.nmImpulseRise =
            IniF(
                "NearMiss",
                "ImpulseRise",
                S.nmImpulseRise,
                ini);

        S.nmImpulseReturn =
            IniF(
                "NearMiss",
                "ImpulseReturn",
                S.nmImpulseReturn,
                ini);

        S.nmRollDeg =
            IniF(
                "NearMiss",
                "RollDeg",
                S.nmRollDeg,
                ini);

        S.nmRollSmooth =
            IniF(
                "NearMiss",
                "RollSmooth",
                S.nmRollSmooth,
                ini);

        S.nmSteerGain =
            IniF(
                "NearMiss",
                "SteerGain",
                S.nmSteerGain,
                ini);

        S.nmSteerFullRate =
            IniF(
                "NearMiss",
                "SteerFullRate",
                S.nmSteerFullRate,
                ini);

        S.nmSteerSmooth =
            IniF(
                "NearMiss",
                "SteerSmooth",
                S.nmSteerSmooth,
                ini);

        S.nmShake =
            IniF(
                "NearMiss",
                "Shake",
                S.nmShake,
                ini);


        // ------------------------------------------------------------------------
        // Hard braking
        // ------------------------------------------------------------------------

        S.hbEnabled =
            IniF("HardBrake", "Enabled", 1, ini) != 0;

        S.hbMinSpeed =
            IniF("HardBrake", "MinSpeed", S.hbMinSpeed, ini);

        S.hbThreshold =
            IniF("HardBrake", "Threshold", S.hbThreshold, ini);

        S.hbFull =
            IniF("HardBrake", "Full", S.hbFull, ini);

        S.hbForward =
            IniF("HardBrake", "Forward", S.hbForward, ini);

        S.hbDrop =
            IniF("HardBrake", "Drop", S.hbDrop, ini);

        S.hbPitchDeg =
            IniF("HardBrake", "PitchDeg", S.hbPitchDeg, ini);

        S.hbRise =
            IniF("HardBrake", "Rise", S.hbRise, ini);

        S.hbReturn =
            IniF("HardBrake", "Return", S.hbReturn, ini);
    }


    // ============================================================================
    // MATH
    // ============================================================================

    struct V3
    {
        float x;
        float y;
        float z;
    };

    inline V3 operator+(V3 a, V3 b)
    {
        return {
            a.x + b.x,
            a.y + b.y,
            a.z + b.z
        };
    }

    inline V3 operator-(V3 a, V3 b)
    {
        return {
            a.x - b.x,
            a.y - b.y,
            a.z - b.z
        };
    }

    inline V3 operator*(V3 a, float s)
    {
        return {
            a.x * s,
            a.y * s,
            a.z * s
        };
    }

    inline float Dot(V3 a, V3 b)
    {
        return
            a.x * b.x +
            a.y * b.y +
            a.z * b.z;
    }

    inline V3 Cross(V3 a, V3 b)
    {
        return {
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x
        };
    }

    inline float Len(V3 a)
    {
        return sqrtf(Dot(a, a));
    }

    inline V3 Norm(V3 a)
    {
        float l = Len(a);

        return l > 1e-6f
            ? a * (1.0f / l)
            : V3{ 0, 0, 0 };
    }

    inline float Clamp(
        float v,
        float lo,
        float hi)
    {
        return
            v < lo
            ? lo
            : (v > hi ? hi : v);
    }

    inline float Approach(
        float cur,
        float tgt,
        float rate,
        float dt)
    {
        return cur +
            (tgt - cur) *
            (1.0f - expf(-rate * dt));
    }


    // Rodrigues rotation.
    inline V3 Rotate(
        V3 v,
        V3 k,
        float ang)
    {
        float c = cosf(ang);
        float s = sinf(ang);

        return
            v * c +
            Cross(k, v) * s +
            k * (Dot(k, v) * (1.0f - c));
    }

    constexpr float DEG = 0.01745329252f;


    bool Readable(
        const void* p,
        size_t n)
    {
        MEMORY_BASIC_INFORMATION mbi;

        if (!p ||
            !VirtualQuery(
                p,
                &mbi,
                sizeof(mbi)))
            return false;

        if (mbi.State != MEM_COMMIT ||
            (mbi.Protect &
                (PAGE_NOACCESS | PAGE_GUARD)))
            return false;

        return
            (uintptr_t)p + n <=
            (uintptr_t)mbi.BaseAddress +
            mbi.RegionSize;
    }


    // ============================================================================
    // NEARBY VEHICLES
    // ============================================================================

    uintptr_t g_base = 0;

    inline uintptr_t VA(uint32_t ida)
    {
        return g_base + (ida - 0x400000);
    }

    using QI_t =
        void* (__thiscall*)(void* table, void* key);

    using VPtr_t =
        void* (__thiscall*)(void*);


    struct Track
    {
        uintptr_t obj;

        float lon;
        float lat;

        int seen;
    };

    Track g_track[64];

    int g_frame = 0;


    struct ScanStats
    {
        int listCount;
        int notVehicle;
        int noSim;
        int valid;
        int nearCount;

        float nearestDist;
        float nearestLon;
        float nearestLat;
        float minAny;
    };

    ScanStats g_stats;


    bool VehiclePos(
        uintptr_t obj,
        V3& pos)
    {
        __try
        {
            void* table =
                *(void**)(obj + 4);

            if (!table)
            {
                ++g_stats.noSim;
                return false;
            }

            QI_t qi =
                (QI_t)VA(0x7536B0);

            if (!qi(
                table,
                (void*)VA(0x64F4E0)))
            {
                ++g_stats.notVehicle;
                return false;
            }

            void* sim =
                qi(
                    table,
                    (void*)VA(0x684170));

            if (!sim)
                sim = (void*)obj;

            void* rb =
                ((VPtr_t)(*(void***)sim)[84 / 4])(sim);

            if (!rb)
                return false;

            const float* p =
                (const float*)
                ((VPtr_t)(*(void***)rb)[32 / 4])(rb);

            if (!p)
                return false;

            // Simulation -> rendering.
            pos = {
                p[2],
                -p[0],
                p[1]
            };

            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }


    // Returns:
    //   side     +1 = right
    //           -1 = left
    //
    // strength = near-miss intensity.
    bool ScanNearMiss(
        V3 me,
        V3 fwd,
        V3 right,
        float dt,
        float& side,
        float& strength)
    {
        ++g_frame;

        g_stats = ScanStats{};

        g_stats.nearestDist = 1e9f;
        g_stats.minAny = 1e9f;


        uintptr_t list = 0;
        int count = 0;

        __try
        {
            list =
                *(uintptr_t*)VA(0xC8E934);

            count =
                *(int*)VA(0xC8E93C);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }

        g_stats.listCount = count;

        if (!list ||
            count <= 0 ||
            count > 4096)
            return false;


        bool hit = false;
        float best = 0;


        for (int i = 0; i < count; ++i)
        {
            uintptr_t obj = 0;

            __try
            {
                obj =
                    ((uintptr_t*)list)[
                        2 * i + 1];
            }
            __except (EXCEPTION_EXECUTE_HANDLER)
            {
                break;
            }

            if (!obj)
                continue;


            V3 p;

            if (!VehiclePos(obj, p))
                continue;

            V3 d = p - me;

            ++g_stats.valid;


            float dist2 = Dot(d, d);

            if (dist2 >= 1.0f &&
                Len(d) < g_stats.minAny)
            {
                g_stats.minAny = Len(d);
            }


            if (dist2 < 1.0f ||
                dist2 > 30.0f * 30.0f)
                continue;


            float lon = Dot(d, fwd);
            float lat = Dot(d, right);

            ++g_stats.nearCount;


            if (Len(d) < g_stats.nearestDist)
            {
                g_stats.nearestDist = Len(d);
                g_stats.nearestLon = lon;
                g_stats.nearestLat = lat;
            }


            int slot = -1;
            int freeSlot = -1;


            for (int k = 0; k < 64; ++k)
            {
                if (g_track[k].obj == obj)
                {
                    slot = k;
                    break;
                }

                if (freeSlot < 0 &&
                    (g_track[k].obj == 0 ||
                        g_frame - g_track[k].seen > 30))
                {
                    freeSlot = k;
                }
            }


            if (slot >= 0)
            {
                Track& t = g_track[slot];

                float rel =
                    (t.lon - lon) / dt;


                if (t.lon > 0.0f &&
                    lon <= 0.0f &&
                    fabsf(lat) < S.nmLateral &&
                    rel > S.nmMinRelSpeed)
                {
                    float k =
                        Clamp(
                            rel / 40.0f,
                            0.4f,
                            1.0f) *
                        Clamp(
                            1.5f -
                            fabsf(lat) /
                            S.nmLateral,
                            0.5f,
                            1.0f);


                    if (k > best)
                    {
                        best = k;

                        side =
                            lat >= 0
                            ? 1.0f
                            : -1.0f;

                        hit = true;
                    }
                }


                t.lon = lon;
                t.lat = lat;
                t.seen = g_frame;
            }
            else if (freeSlot >= 0)
            {
                g_track[freeSlot] = {
                    obj,
                    lon,
                    lat,
                    g_frame
                };
            }
        }


        strength = best;

        return hit;
    }


    // ============================================================================
    // SURFACE
    // ============================================================================

    uint32_t OffroadSurface(
        const char* anchor,
        uint32_t& rawKey)
    {
        rawKey = 0;

        __try
        {
            const char* coll =
                *(const char* const*)
                (anchor + 0xB4);


            for (
                int depth = 0;
                coll && depth < 8;
                ++depth)
            {
                uint32_t key =
                    *(const uint32_t*)
                    (coll + 0x20);


                if (depth == 0)
                    rawKey = key;


                for (
                    int i = 0;
                    i < S.surfCount;
                    ++i)
                {
                    if (S.surf[i] == key)
                        return key;
                }


                coll =
                    *(const char* const*)
                    (coll + 0x10);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
        }

        return 0;
    }


    // ============================================================================
    // STATE
    // ============================================================================

    struct State
    {
        bool valid = false;

        int mode = -1;

        V3 prevVel{};

        float time = 0;

        float impact = 0;
        float gear = 0;
        float surfK = 0;

        float prevCol = 0;

        float statTime = 0;

        V3 aSmooth{};
        bool aInit = false;

        float prevRpm = 0;
        float overRevTime = 100;

        uint32_t lastSurf = 0xFFFFFFFF;

        float phase[6]{};


        // ------------------------------------------------------------------------
        // NearMiss
        // ------------------------------------------------------------------------

        float nmTime = 100.0f;

        float nmSide = 0.0f;
        float nmK = 0.0f;

        // Filtered steering intensity.
        float nmSteer = 0.0f;

        // Previous vehicle direction for turn-rate estimation.
        V3 prevFwd{};
        bool fwdInit = false;

        // Persistent near-miss roll.
        float nmRoll = 0.0f;


        // ------------------------------------------------------------------------
        // Hard braking
        // ------------------------------------------------------------------------

        // Filtered longitudinal deceleration (m/s^2, positive = braking).
        float hbDecel = 0.0f;

        // Effect intensity 0..1.
        float hbK = 0.0f;

        // Log helper.
        bool hbLogged = false;
    };

    State F;


    float Noise(
        float t,
        int axis)
    {
        const float f =
            S.shakeFreq *
            6.2831853f;

        return
            0.55f *
            sinf(
                f * t +
                F.phase[axis]) +

            0.30f *
            sinf(
                f * 1.37f * t +
                F.phase[(axis + 2) % 6]) +

            0.15f *
            sinf(
                f * 2.11f * t +
                F.phase[(axis + 4) % 6]);
    }


    // ============================================================================
    // BUILD LOOK AT
    // ============================================================================

    void __cdecl BuildLookAtFX(
        float* out,
        const float* eyeIn,
        const float* targetIn,
        const float* upIn,
        const char* mover,
        float dt)
    {
        if (!S.enabled ||
            !mover ||
            !Readable(mover, 0xB0))
        {
            g_buildLookAt(
                out,
                eyeIn,
                targetIn,
                upIn);

            return;
        }


        int mode =
            *(const int*)
            (mover + 0xA8);

        const char* car =
            *(const char* const*)
            (mover + 0x90);


        if (mode < 0 ||
            mode > 3 ||
            !S.modes[mode] ||
            !Readable(car, 0x100))
        {
            F.valid = false;

            g_buildLookAt(
                out,
                eyeIn,
                targetIn,
                upIn);

            return;
        }


        if (!(dt > 0.0f &&
            dt < 0.2f))
        {
            dt = 1.0f / 60.0f;
        }


        const float* m =
            (const float*)
            (car + 0x30);


        V3 fwd =
            Norm({
                m[0],
                m[1],
                m[2]
                });


        V3 rgt =
            Norm({
                m[4],
                m[5],
                m[6]
                });


        V3 vel =
            *(const V3*)
            (car + 0x80);


        float speed =
            fabsf(
                *(const float*)
                (car + 0xA0));


        float rpm =
            *(const float*)
            (car + 0xA8);


        bool onGround =
            *(const uint8_t*)
            (car + 0xB0) != 0;


        bool overRev =
            *(const uint8_t*)
            (car + 0xF1) != 0;


        bool gearChanged =
            *(const uint8_t*)
            (car + 0xF3) != 0;


        // ------------------------------------------------------------------------
        // Reset state on camera change.
        // ------------------------------------------------------------------------

        if (!F.valid ||
            F.mode != mode)
        {
            F = State{};

            F.valid = true;
            F.mode = mode;

            F.prevVel = vel;
            F.prevRpm = rpm;
            F.prevFwd = fwd;
            F.fwdInit = true;


            for (int i = 0; i < 6; ++i)
            {
                F.phase[i] =
                    (float)(
                        GetTickCount() %
                        (97 * (i + 3)))
                    * 0.137f;
            }
        }


        F.time += dt;


        // ========================================================================
        // STEERING / TURN RATE
        //
        // Estimate steering from the actual vehicle heading change.
        // ========================================================================

        float steerAmount = 0.0f;

        if (F.fwdInit)
        {
            float forwardDot =
                Clamp(
                    Dot(F.prevFwd, fwd),
                    -1.0f,
                    1.0f);

            float turnRate =
                acosf(forwardDot) /
                fmaxf(dt, 0.001f);

            steerAmount =
                Clamp(
                    turnRate /
                    fmaxf(S.nmSteerFullRate, 0.001f),
                    0.0f,
                    1.0f);
        }

        F.prevFwd = fwd;

        F.nmSteer =
            Approach(
                F.nmSteer,
                steerAmount,
                fmaxf(S.nmSteerSmooth, 0.001f),
                dt);


        // ========================================================================
        // 1. SURFACE
        // ========================================================================

        float surfTgt = 0.0f;


        if (S.surfEnabled &&
            onGround)
        {
            uint32_t raw = 0;

            uint32_t hit =
                OffroadSurface(
                    car,
                    raw);


            if (raw != F.lastSurf)
            {
                Log(
                    "surface 0x%08X%s",
                    raw,
                    hit
                    ? " (offroad)"
                    : "");

                F.lastSurf = raw;
            }


            if (hit &&
                speed > S.surfMinSpeed)
            {
                surfTgt =
                    Clamp(
                        (speed -
                            S.surfMinSpeed) /
                        (S.surfFullSpeed -
                            S.surfMinSpeed +
                            1e-3f),
                        0.0f,
                        1.0f);
            }
        }


        F.surfK =
            Approach(
                F.surfK,
                surfTgt,
                6.0f,
                dt);


        // ========================================================================
        // 2. GEAR SHIFT
        // ========================================================================

        if (overRev)
            F.overRevTime = 0;
        else
            F.overRevTime += dt;


        if (S.gearEnabled &&
            gearChanged)
        {
            bool high =
                S.gearMinRpm > 0
                ? F.prevRpm >= S.gearMinRpm
                : F.overRevTime < 0.3f;


            Log(
                "gear shift: previous RPM %.0f, "
                "limiter %s -> %s",
                F.prevRpm,
                F.overRevTime < 0.3f
                ? "yes"
                : "no",
                high
                ? "shake"
                : "none");


            if (high)
                F.gear = 1.0f;
        }


        F.gear *=
            expf(
                -S.gearDecay *
                dt);


        F.prevRpm = rpm;


        // ========================================================================
        // 3. IMPACT
        // ========================================================================

        V3 a =
            (vel - F.prevVel) *
            (1.0f / dt);

        F.prevVel = vel;


        float jerk =
            F.aInit
            ? Len(a - F.aSmooth)
            : 0.0f;


        F.aSmooth =
            F.aInit
            ? F.aSmooth +
            (a - F.aSmooth) *
            (1.0f -
                expf(-8.0f * dt))
            : a;


        F.aInit = true;


        float col = 0.0f;


        for (int i = 0; i < 3; ++i)
        {
            float c =
                *(const float*)
                (car + 0xD8 + 4 * i);

            if (c > col)
                col = c;
        }


        bool colEdge =
            col >
            F.prevCol + 0.3f;


        F.prevCol = col;


        if (S.impactEnabled &&
            (jerk > S.impactThresh ||
                colEdge))
        {
            float k =
                Clamp(
                    (jerk -
                        S.impactThresh * 0.5f) /
                    (S.impactScale -
                        S.impactThresh * 0.5f +
                        1e-3f),
                    0.0f,
                    1.0f);


            if (colEdge &&
                k <
                S.impactCollision * 0.4f)
            {
                k =
                    S.impactCollision *
                    0.4f;
            }


            if (k > F.impact + 0.05f)
            {
                Log(
                    "impact: jerk %.0f m/s^2, "
                    "collision %s -> intensity %.2f",
                    jerk,
                    colEdge
                    ? "yes"
                    : "no",
                    k);
            }


            if (k > F.impact)
                F.impact = k;
        }


        F.impact *=
            expf(
                -S.impactDecay *
                dt);


        // ========================================================================
        // 3b. HARD BRAKING
        //
        // Longitudinal deceleration from the filtered acceleration.
        // Collisions are excluded (their spikes belong to the impact effect).
        // ========================================================================

        {
            float fwdSpeed =
                Dot(vel, fwd);

            float decel =
                -Dot(F.aSmooth, fwd);


            if (col > 0.0f ||
                jerk > S.impactThresh ||
                !onGround ||
                fwdSpeed < S.hbMinSpeed)
            {
                decel = 0.0f;
            }


            F.hbDecel =
                Approach(
                    F.hbDecel,
                    Clamp(decel, 0.0f, S.hbFull * 1.5f),
                    10.0f,
                    dt);


            float hbTgt = 0.0f;


            if (S.hbEnabled)
            {
                hbTgt =
                    Clamp(
                        (F.hbDecel - S.hbThreshold) /
                        fmaxf(S.hbFull - S.hbThreshold, 0.001f),
                        0.0f,
                        1.0f);

                // Smooth start.
                hbTgt =
                    hbTgt * hbTgt *
                    (3.0f - 2.0f * hbTgt);
            }


            F.hbK =
                Approach(
                    F.hbK,
                    hbTgt,
                    fmaxf(
                        hbTgt > F.hbK
                        ? S.hbRise
                        : S.hbReturn,
                        0.001f),
                    dt);


            if (hbTgt > 0.5f && !F.hbLogged)
            {
                Log(
                    "hard brake: deceleration %.1f m/s^2 "
                    "at %.1f m/s",
                    F.hbDecel,
                    fwdSpeed);

                F.hbLogged = true;
            }
            else if (hbTgt <= 0.0f)
            {
                F.hbLogged = false;
            }
        }


        // ========================================================================
        // 4. NEAR MISS
        //
        // ROLL ONLY.
        // No eye/target translation.
        // ========================================================================

        if (S.nmEnabled)
        {
            V3 me =
                *(const V3*)
                (car + 0x20);


            F.statTime += dt;


            if (F.statTime > 2.0f)
            {
                F.statTime = 0;


                Log(
                    "vehicles: list %d, valid %d, "
                    "within 30m %d, non-vehicle %d, "
                    "no ISimable %d; nearest %.1fm "
                    "(forward %.1f, lateral %.1f), "
                    "nearest overall %.1fm",
                    g_stats.listCount,
                    g_stats.valid,
                    g_stats.nearCount,
                    g_stats.notVehicle,
                    g_stats.noSim,
                    g_stats.nearestDist < 1e8f
                    ? g_stats.nearestDist
                    : -1.0f,
                    g_stats.nearestLon,
                    g_stats.nearestLat,
                    g_stats.minAny < 1e8f
                    ? g_stats.minAny
                    : -1.0f);
            }


            float side = 0.0f;
            float k = 0.0f;


            if (ScanNearMiss(
                me,
                fwd,
                rgt,
                dt,
                side,
                k))
            {
                // New near miss.
                // Store only side and intensity.
                if (F.nmTime > 0.4f ||
                    k > F.nmK)
                {
                    F.nmTime = 0.0f;

                    F.nmSide = side;
                    F.nmK = k;


                    Log(
                        "near miss: side %+.0f "
                        "intensity %.2f "
                        "speed %.1f m/s",
                        side,
                        k,
                        speed);
                }
            }
        }


        F.nmTime += dt;


        // ------------------------------------------------------------------------
        // Roll timing.
        // ------------------------------------------------------------------------

        float rollShape = 0.0f;


        const float riseTime =
            fmaxf(
                S.nmImpulseRise,
                0.001f);


        const float returnTime =
            fmaxf(
                S.nmImpulseReturn,
                0.001f);


        const float endTime =
            riseTime +
            returnTime;


        if (F.nmTime < endTime)
        {
            float t = F.nmTime;


            if (t < riseTime)
            {
                float u =
                    Clamp(
                        t / riseTime,
                        0.0f,
                        1.0f);


                // 0 -> 1
                rollShape =
                    u * u *
                    (3.0f - 2.0f * u);
            }
            else
            {
                float u =
                    Clamp(
                        (t - riseTime) /
                        returnTime,
                        0.0f,
                        1.0f);


                // 1 -> 0.
                rollShape =
                    0.5f +
                    0.5f *
                    cosf(
                        u *
                        3.14159265f);
            }
        }


        // ------------------------------------------------------------------------
        // Near-miss intensity.
        // ------------------------------------------------------------------------

        float nmStrength =
            Clamp(
                0.6f +
                0.4f * F.nmK,
                0.0f,
                1.0f);


        // ------------------------------------------------------------------------
        // ROLL TARGET
        // ------------------------------------------------------------------------

        float steerMultiplier =
            1.0f +
            Clamp(
                S.nmSteerGain,
                0.0f,
                3.0f) *
            F.nmSteer;

        float desiredNmRoll =
            F.nmSide *
            S.nmRollDeg *
            nmStrength *
            rollShape *
            steerMultiplier;


        // ------------------------------------------------------------------------
        // Smooth roll interpolation.
        // ------------------------------------------------------------------------

        const float rollRate =
            fmaxf(
                S.nmRollSmooth,
                0.001f);


        F.nmRoll =
            Approach(
                F.nmRoll,
                desiredNmRoll,
                rollRate,
                dt);


        // ========================================================================
        // EFFECT COMPOSITION
        // ========================================================================

        float amp =
            S.surfAmp * F.surfK +
            S.gearAmp * F.gear +
            S.impactAmp * F.impact +
            S.nmShake * rollShape;


        float rollShake =
            S.surfRollDeg * F.surfK +
            S.gearRollDeg * F.gear +
            S.impactRollDeg * F.impact;


        // No active effect.
        if (amp < 1e-4f &&
            rollShake < 1e-3f &&
            fabsf(F.nmRoll) < 1e-3f &&
            F.hbK < 1e-3f)
        {
            g_buildLookAt(
                out,
                eyeIn,
                targetIn,
                upIn);

            return;
        }


        // ========================================================================
        // BASE CAMERA
        // ========================================================================

        V3 eye =
            *(const V3*)eyeIn;

        V3 target =
            *(const V3*)targetIn;

        V3 up =
            *(const V3*)upIn;


        V3 look =
            Norm(
                target - eye);


        V3 right =
            Norm(
                Cross(
                    look,
                    up));


        if (Len(right) < 0.5f)
        {
            g_buildLookAt(
                out,
                eyeIn,
                targetIn,
                upIn);

            return;
        }


        V3 camUp =
            Norm(
                Cross(
                    right,
                    look));


        // ========================================================================
        // SHAKE
        // ========================================================================

        V3 shake =
            right *
            (amp *
                Noise(
                    F.time,
                    0)) +

            camUp *
            (amp *
                0.8f *
                Noise(
                    F.time,
                    1));


        V3 shakeT =
            right *
            (amp *
                0.5f *
                Noise(
                    F.time,
                    2)) +

            camUp *
            (amp *
                0.5f *
                Noise(
                    F.time,
                    3));


        // ========================================================================
        // NEAR MISS DOES NOT TRANSLATE THE CAMERA.
        // Only F.nmRoll is applied.
        // ========================================================================

        V3 eye2 =
            eye + shake;


        V3 target2 =
            target + shakeT;


        // ========================================================================
        // HARD BRAKING
        //
        // Camera dives toward the car, drops and pitches down.
        // ========================================================================

        if (F.hbK > 1e-3f)
        {
            V3 dive =
                look *
                (S.hbForward * F.hbK) -
                camUp *
                (S.hbDrop * F.hbK);

            eye2 = eye2 + dive;
            target2 = target2 + dive;


            // Nose-down pitch around the camera right axis.
            V3 dir =
                target2 - eye2;

            dir =
                Rotate(
                    dir,
                    right,
                    -S.hbPitchDeg *
                    F.hbK *
                    DEG);

            target2 =
                eye2 + dir;
        }


        V3 look2 =
            Norm(
                target2 - eye2);


        // ========================================================================
        // ROLL
        // ========================================================================

        float rollDeg =
            rollShake *
            Noise(
                F.time,
                4) +

            F.nmRoll;


        V3 up2 =
            Rotate(
                up,
                look2,
                rollDeg * DEG);


        g_buildLookAt(
            out,
            &eye2.x,
            &target2.x,
            &up2.x);
    }


    // ============================================================================
    // THUNK
    // ============================================================================

    __declspec(naked) void Thunk()
    {
        __asm
        {
            push dword ptr[ebx + 8]
            push esi

            push dword ptr[esp + 0x18]
            push dword ptr[esp + 0x18]
            push dword ptr[esp + 0x18]
            push dword ptr[esp + 0x18]

            call BuildLookAtFX

            add esp, 0x18

            ret
        }
    }


    // ============================================================================
    // NATIVE SHAKE
    // ============================================================================

    float g_nativeScale = 1.0f;


    bool InstallNative(uintptr_t base)
    {
        uint8_t* p =
            (uint8_t*)
            (base +
                (0x7D86BB - 0x400000));


        if (!Readable(p, 17))
            return false;


        static const uint8_t pre[] = {
            0x80,
            0x3D
        };


        bool ok =
            memcmp(
                p,
                pre,
                2) == 0 &&

            p[6] == 0x00 &&
            p[7] == 0x74 &&
            p[8] == 0x0A &&

            p[9] == 0xF3 &&
            p[10] == 0x0F &&
            p[11] == 0x10 &&
            p[12] == 0x05;


        if (!ok)
        {
            Log(
                "native shake: unexpected code "
                "at 0x%08X, unchanged",
                (unsigned)(uintptr_t)p);

            return false;
        }


        g_nativeScale =
            S.nativeScale;


        DWORD old;


        if (!VirtualProtect(
            p,
            17,
            PAGE_EXECUTE_READWRITE,
            &old))
            return false;


        p[7] = 0x90;
        p[8] = 0x90;


        *(uint32_t*)(p + 13) =
            (uint32_t)
            (uintptr_t)
            &g_nativeScale;


        VirtualProtect(
            p,
            17,
            old,
            &old);


        FlushInstructionCache(
            GetCurrentProcess(),
            p,
            17);


        return true;
    }


    // ============================================================================
    // BRAKE
    // ============================================================================

    float g_brakeAmp = 0.1f;
    float g_brakeFreq = 1.0f;

    uintptr_t g_brakeRet = 0;


    __declspec(naked) void BrakeCave()
    {
        __asm
        {
            movss xmm0, dword ptr[g_brakeAmp]

            movss dword ptr[ebp - 4], xmm0


            movss xmm0, dword ptr[g_brakeFreq]

            mulss xmm0, xmm7

            movss dword ptr[ebp - 8], xmm0


            jmp dword ptr[g_brakeRet]
        }
    }


    bool InstallBrake(uintptr_t base)
    {
        uint8_t* p =
            (uint8_t*)
            (base +
                (0x7D84FB - 0x400000));


        static const uint8_t expect[10] = {
            0xF3, 0x0F, 0x11, 0x45, 0xFC,
            0xF3, 0x0F, 0x11, 0x7D, 0xF8
        };


        if (!Readable(p, 10) ||
            memcmp(
                p,
                expect,
                10) != 0)
        {
            Log(
                "brake: unexpected code, unchanged");

            return false;
        }


        g_brakeAmp =
            S.brakeAmp;

        g_brakeFreq =
            S.brakeFreq;


        g_brakeRet =
            base +
            (0x7D8505 - 0x400000);


        DWORD old;


        if (!VirtualProtect(
            p,
            10,
            PAGE_EXECUTE_READWRITE,
            &old))
            return false;


        p[0] = 0xE9;


        *(int32_t*)(p + 1) =
            (int32_t)(
                (uintptr_t)&BrakeCave -
                (uintptr_t)(p + 5));


        memset(
            p + 5,
            0x90,
            5);


        VirtualProtect(
            p,
            10,
            old,
            &old);


        FlushInstructionCache(
            GetCurrentProcess(),
            p,
            10);


        return true;
    }


    // ============================================================================
    // INSTALL
    // ============================================================================

    bool Install(uintptr_t base)
    {
        uint8_t* site =
            (uint8_t*)
            (base +
                RVA_CALL_SITE);


        uintptr_t expected =
            base +
            RVA_BUILDLOOKAT;


        if (!Readable(site, 5) ||
            site[0] != 0xE8)
        {
            Log(
                "call site not found (byte %02X)",
                site
                ? site[0]
                : 0);

            return false;
        }


        uintptr_t dest =
            (uintptr_t)(site + 5) +
            *(int32_t*)(site + 1);


        if (dest != expected)
        {
            Log(
                "call site points to 0x%08X "
                "instead of 0x%08X: "
                "different or modified executable",
                (unsigned)dest,
                (unsigned)expected);

            return false;
        }


        g_buildLookAt =
            (BuildLookAt_t)
            expected;


        DWORD old;


        if (!VirtualProtect(
            site,
            5,
            PAGE_EXECUTE_READWRITE,
            &old))
            return false;


        *(int32_t*)(site + 1) =
            (int32_t)(
                (uintptr_t)&Thunk -
                (uintptr_t)(site + 5));


        VirtualProtect(
            site,
            5,
            old,
            &old);


        FlushInstructionCache(
            GetCurrentProcess(),
            site,
            5);


        return true;
    }


    // ============================================================================
    // INIT
    // ============================================================================

    DWORD WINAPI Init(LPVOID)
    {
        uintptr_t base =
            (uintptr_t)
            GetModuleHandleA(nullptr);


        g_base = base;


        LoadSettings();


        if (S.log)
        {
            char path[MAX_PATH];


            sprintf_s(
                path,
                "%s\\NFSWBetaCameraFX.log",
                g_dir);


            fopen_s(
                &g_log,
                path,
                "w");
        }


        Log(
            "NFSWBetaCameraFX - base 0x%08X",
            (unsigned)base);


        if (S.enabled &&
            S.native)
        {
            bool n =
                InstallNative(base);


            Log(
                n
                ? "native beta shake enabled (scale %.2f)"
                : "native beta shake disabled",
                S.nativeScale);


            if (n)
            {
                Log(
                    InstallBrake(base)
                    ? "brake shake: amplitude %.2f (beta 0.30)"
                    : "brake shake unchanged",
                    S.brakeAmp);
            }
        }


        if (S.enabled &&
            (S.surfEnabled ||
                S.gearEnabled ||
                S.impactEnabled ||
                S.nmEnabled ||
                S.hbEnabled))
        {
            bool ok =
                Install(base);


            Log(
                ok
                ? "additional effects: hook installed "
                "(call site 0x%08X)"
                : "additional effects: hook not installed",
                (unsigned)
                (base +
                    RVA_CALL_SITE));
        }


        return 0;
    }


} // namespace


// ============================================================================
// DLLMAIN
// ============================================================================

BOOL APIENTRY DllMain(
    HMODULE mod,
    DWORD reason,
    LPVOID)
{
    if (reason ==
        DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(mod);


        GetModuleFileNameA(
            mod,
            g_dir,
            MAX_PATH);


        char* slash =
            strrchr(
                g_dir,
                '\\');


        if (slash)
            *slash = 0;


        Init(nullptr);
    }


    return TRUE;
}