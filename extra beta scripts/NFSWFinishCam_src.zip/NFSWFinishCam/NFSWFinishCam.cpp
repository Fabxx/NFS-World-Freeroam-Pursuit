#if __has_include(<windows.h>)
#include <windows.h>
#else
typedef int BOOL; typedef unsigned long DWORD; typedef void* HANDLE; typedef void* HMODULE; typedef void* LPVOID;
#define WINAPI __stdcall
#define DLL_PROCESS_ATTACH 1
#define PAGE_READWRITE 0x04
#define PAGE_EXECUTE_READWRITE 0x40
#define GENERIC_WRITE 0x40000000
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
#define MAX_PATH 260
extern "C" {
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, unsigned long, DWORD, DWORD*);
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(const char*);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, const void*, unsigned long);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess();
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HMODULE, char*, DWORD);
__declspec(dllimport) DWORD WINAPI GetPrivateProfileStringA(const char*, const char*, const char*, char*, DWORD, const char*);
__declspec(dllimport) HANDLE WINAPI CreateFileA(const char*, DWORD, DWORD, void*, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE, const void*, DWORD, DWORD*, void*);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
__declspec(dllimport) DWORD WINAPI GetTickCount();
__declspec(selectany) int _fltused = 0;
}
#endif

extern "C" {
unsigned g_flashCont = 0, g_camWriteOrig = 0;
void __cdecl OnFlashEvent(const char* name);
int __cdecl OnCamWrite(unsigned char* cam);
void TrampFlash();
void TrampCamWrite();
}

namespace {

// Render views (0x70 bytes each, camera at +0x30); view 1 is the player's view. Only that camera is
// frozen, so the other views (results screen car preview, reflections) keep updating.
const unsigned kViewsVA = 0xDC0B40;
const unsigned kViewsRefVA = 0x7CE921;
const unsigned kViewStride = 0x70;
const unsigned kViewCameraOffset = 0x30;
const unsigned kPlayerView = 1;

// Camera::SetMatrix (thiscall, ret 8), called at the end of every camera mover. For the frozen camera
// the call is skipped, the per-second deltas (+0x220..+0x2C7) that extrapolate the rendered camera are
// cleared and the lens fields written directly by the movers (+0xC0..+0xE7) are restored.
const unsigned kCamWriteVA = 0x7CDE40;
const unsigned kCamWriteCalls[] = { 0x63FE25, 0x64C1B1, 0x7B1D19, 0x7D1470, 0x7D2206, 0x7D2C77, 0x7D2C88,
                                    0x7D674F, 0x7D7500, 0x7D75ED, 0x7DAF10, 0x7DC096, 0x7DCF82, 0x7DEB7D };
const unsigned kCamDeltaBegin = 0x220;
const unsigned kCamDeltaEnd = 0x2C8;
const unsigned kCamLensBegin = 0xC0;
const unsigned kCamLensEnd = 0xE8;

// Native -> Flash UI events (cdecl int(void* ui, const char* name, ...)). The results screen at the
// finish line starts with screen.OnDisableWalletAutoUpdateReceived, the return to freeroam ends with
// screen.OnEnableWalletAutoUpdateReceived.
const unsigned kFlashSendVA = 0x9A7560;
const unsigned char kFlashSendPrologue[8] = { 0x83, 0xEC, 0x24, 0x56, 0x8B, 0x74, 0x24, 0x2C };

// IRacer "race closed" slot of the human vehicle AI, called when the race session ends: fallback unfreeze.
const unsigned kRacerVtbls[] = { 0xBD6228, 0xBD6650 };
const unsigned kRacerClosedVA = 0x7F7880;

unsigned g_base = 0x400000;
unsigned VA(unsigned a) { return a - 0x400000 + g_base; }

bool g_enabled = true;
float g_maxHold = 0.0f;
char g_freezeEvent[96] = "screen.OnDisableWalletAutoUpdateReceived";
char g_unfreezeEvent[96] = "screen.OnEnableWalletAutoUpdateReceived";

unsigned char* g_frozenCam = 0;
unsigned char g_lens[kCamLensEnd - kCamLensBegin];
bool g_frozen = false;
DWORD g_freezeTick = 0;

#ifdef _DEBUG
HANDLE g_log = INVALID_HANDLE_VALUE;
void LogOpen() { g_log = CreateFileA("NFSWFinishCam.log", GENERIC_WRITE, 1, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0); }
void Log(const char* s) {
    if (g_log == INVALID_HANDLE_VALUE) return;
    DWORD n = 0, len = 0; while (s[len]) ++len;
    WriteFile(g_log, s, len, &n, 0);
}
void LogHex(unsigned v) {
    char b[11] = "0x00000000";
    for (int i = 0; i < 8; ++i) { unsigned d = (v >> (28 - 4 * i)) & 15; b[2 + i] = (char)(d < 10 ? '0' + d : 'A' + d - 10); }
    Log(b);
}
void LogUInt(unsigned v) {
    char t[12]; int n = 0; do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    char b[12]; int p = 0; while (n) b[p++] = t[--n]; b[p] = 0; Log(b);
}
void LogEvent(const char* s) { Log("["); LogUInt(GetTickCount()); Log("] "); Log(s); Log("\r\n"); }
#else
inline void LogOpen() {}
inline void Log(const char*) {}
inline void LogHex(unsigned) {}
inline void LogEvent(const char*) {}
#endif

void Freeze(bool on) {
    if (g_frozen == on) return;
    if (on) {
        g_frozenCam = *(unsigned char**)(unsigned long)(VA(kViewsVA) + kPlayerView * kViewStride + kViewCameraOffset);
        if (!g_frozenCam) return;
        for (unsigned i = 0; i < sizeof(g_lens); ++i) g_lens[i] = g_frozenCam[kCamLensBegin + i];
    }
    g_frozen = on;
    g_freezeTick = GetTickCount();
    LogEvent(on ? "camera bloccata" : "camera sbloccata");
}

void CheckTimeout() {
    if (g_frozen && g_maxHold > 0.0f && (float)(GetTickCount() - g_freezeTick) * 0.001f >= g_maxHold) {
        LogEvent("tempo massimo raggiunto");
        Freeze(false);
    }
}

bool StrEq(const char* a, const char* b) {
    while (*a && *a == *b) { ++a; ++b; }
    return *a == *b;
}

typedef void(__thiscall* RacerClosedFn)(void*);
RacerClosedFn g_racerClosed[2] = { 0, 0 };

template <int I>
void __fastcall RacerClosedHook(void* self, void*) {
    g_racerClosed[I](self);
    Freeze(false);
}

float ParseFloat(const char* s, float def) {
    while (*s == ' ' || *s == '\t') ++s;
    bool neg = false;
    if (*s == '-') { neg = true; ++s; } else if (*s == '+') ++s;
    bool any = false; float v = 0.0f;
    while (*s >= '0' && *s <= '9') { v = v * 10.0f + (float)(*s - '0'); ++s; any = true; }
    if (*s == '.' || *s == ',') {
        ++s; float f = 0.1f;
        while (*s >= '0' && *s <= '9') { v += f * (float)(*s - '0'); f *= 0.1f; ++s; any = true; }
    }
    if (!any) return def;
    return neg ? -v : v;
}

void LoadIni(HMODULE self) {
    char path[MAX_PATH];
    DWORD n = GetModuleFileNameA(self, path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH - 4) return;
    int dot = -1;
    for (int i = (int)n - 1; i >= 0; --i) { if (path[i] == '.') { dot = i; break; } if (path[i] == '\\' || path[i] == '/') break; }
    if (dot < 0) dot = (int)n;
    path[dot] = '.'; path[dot + 1] = 'i'; path[dot + 2] = 'n'; path[dot + 3] = 'i'; path[dot + 4] = 0;
    char buf[64];
    if (GetPrivateProfileStringA("FinishCam", "Enabled", "", buf, sizeof(buf), path)) g_enabled = ParseFloat(buf, 1.0f) != 0.0f;
    GetPrivateProfileStringA("FinishCam", "FreezeEvent", g_freezeEvent, g_freezeEvent, sizeof(g_freezeEvent), path);
    GetPrivateProfileStringA("FinishCam", "UnfreezeEvent", g_unfreezeEvent, g_unfreezeEvent, sizeof(g_unfreezeEvent), path);
    if (GetPrivateProfileStringA("FinishCam", "MaxHoldSeconds", "", buf, sizeof(buf), path)) g_maxHold = ParseFloat(buf, g_maxHold);
    if (g_maxHold < 0.0f) g_maxHold = 0.0f;
}

bool CallTargets(unsigned callVA, unsigned expectedVA) {
    const unsigned char* c = (const unsigned char*)(unsigned long)VA(callVA);
    if (c[0] != 0xE8) return false;
    int rel = c[1] | (c[2] << 8) | (c[3] << 16) | (c[4] << 24);
    return VA(callVA) + 5 + rel == VA(expectedVA);
}

void WriteRel32(unsigned atVA, unsigned char opcode, void* fn, unsigned size) {
    unsigned char* p = (unsigned char*)(unsigned long)VA(atVA);
    DWORD old = 0;
    if (!VirtualProtect(p, size, PAGE_EXECUTE_READWRITE, &old)) return;
    int rel = (int)((unsigned)(unsigned long)fn - (VA(atVA) + 5));
    p[0] = opcode; p[1] = (unsigned char)rel; p[2] = (unsigned char)(rel >> 8); p[3] = (unsigned char)(rel >> 16); p[4] = (unsigned char)(rel >> 24);
    for (unsigned i = 5; i < size; ++i) p[i] = 0x90;
    VirtualProtect(p, size, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, size);
}

unsigned* Slot(unsigned vtbl) { return (unsigned*)(unsigned long)VA(vtbl); }

void* PatchSlot(unsigned* slot, void* fn) {
    DWORD old = 0;
    if (!VirtualProtect(slot, 4, PAGE_READWRITE, &old)) return 0;
    void* orig = (void*)(unsigned long)*slot;
    *slot = (unsigned)(unsigned long)fn;
    VirtualProtect(slot, 4, old, &old);
    return orig;
}

bool RefersTo(unsigned codeVA, unsigned dataVA) {
    const unsigned char* c = (const unsigned char*)(unsigned long)VA(codeVA);
    unsigned target = c[0] | (c[1] << 8) | (c[2] << 16) | ((unsigned)c[3] << 24);
    return target == VA(dataVA);
}

void Apply(HMODULE self) {
    g_base = (unsigned)(unsigned long)GetModuleHandleA(0);
    Log("NFSWFinishCam: base exe "); LogHex(g_base); Log("\r\n");
    LoadIni(self);
    if (!g_enabled) { Log("disattivato da ini\r\n"); return; }

    bool ok = RefersTo(kViewsRefVA, kViewsVA);
    const unsigned char* fp = (const unsigned char*)(unsigned long)VA(kFlashSendVA);
    for (int i = 0; ok && i < 8; ++i) ok = fp[i] == kFlashSendPrologue[i];
    for (unsigned i = 0; ok && i < sizeof(kCamWriteCalls) / sizeof(kCamWriteCalls[0]); ++i)
        ok = CallTargets(kCamWriteCalls[i], kCamWriteVA);
    for (int v = 0; ok && v < 2; ++v) ok = *Slot(kRacerVtbls[v]) == VA(kRacerClosedVA);
    if (!ok) { Log("codice inatteso - versione exe diversa, nessuna modifica\r\n"); return; }

    g_camWriteOrig = VA(kCamWriteVA);
    for (unsigned i = 0; i < sizeof(kCamWriteCalls) / sizeof(kCamWriteCalls[0]); ++i)
        WriteRel32(kCamWriteCalls[i], 0xE8, (void*)&TrampCamWrite, 5);

    g_racerClosed[0] = (RacerClosedFn)PatchSlot(Slot(kRacerVtbls[0]), (void*)&RacerClosedHook<0>);
    g_racerClosed[1] = (RacerClosedFn)PatchSlot(Slot(kRacerVtbls[1]), (void*)&RacerClosedHook<1>);

    g_flashCont = VA(kFlashSendVA) + 8;
    WriteRel32(kFlashSendVA, 0xE9, (void*)&TrampFlash, 8);

    Log("hook installati\r\n");
}

}

extern "C" {

int __cdecl OnCamWrite(unsigned char* cam) {
    CheckTimeout();
    if (!g_frozen || !cam || cam != g_frozenCam) return 0;
    for (unsigned i = kCamDeltaBegin; i < kCamDeltaEnd; ++i) cam[i] = 0;
    for (unsigned i = 0; i < sizeof(g_lens); ++i) cam[kCamLensBegin + i] = g_lens[i];
    return 1;
}

void __cdecl OnFlashEvent(const char* name) {
    if (!name) return;
    if (g_freezeEvent[0] && StrEq(name, g_freezeEvent)) Freeze(true);
    else if (g_unfreezeEvent[0] && StrEq(name, g_unfreezeEvent)) Freeze(false);
}

#if defined(_MSC_VER) && !defined(__clang__)
__declspec(naked) void TrampFlash() {
    __asm {
        pushad
        push dword ptr [esp + 40]
        call OnFlashEvent
        add esp, 4
        popad
        sub esp, 0x24
        push esi
        mov esi, dword ptr [esp + 0x2C]
        jmp dword ptr [g_flashCont]
    }
}

__declspec(naked) void TrampCamWrite() {
    __asm {
        pushad
        push ecx
        call OnCamWrite
        add esp, 4
        test eax, eax
        popad
        jnz skip
        jmp dword ptr [g_camWriteOrig]
    skip:
        ret 8
    }
}
#else
__attribute__((naked)) void TrampFlash() {
    asm volatile("pushal\n\t"
                 "pushl 40(%esp)\n\t"
                 "call _OnFlashEvent\n\t"
                 "addl $4, %esp\n\t"
                 "popal\n\t"
                 "subl $0x24, %esp\n\t"
                 "pushl %esi\n\t"
                 "movl 0x2c(%esp), %esi\n\t"
                 "jmp *_g_flashCont");
}

__attribute__((naked)) void TrampCamWrite() {
    asm volatile("pushal\n\t"
                 "pushl %ecx\n\t"
                 "call _OnCamWrite\n\t"
                 "addl $4, %esp\n\t"
                 "testl %eax, %eax\n\t"
                 "popal\n\t"
                 "jnz 1f\n\t"
                 "jmp *_g_camWriteOrig\n"
                 "1:\n\t"
                 "ret $8");
}
#endif

}

extern "C" BOOL WINAPI DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        LogOpen();
        Apply(h);
    }
    return 1;
}
