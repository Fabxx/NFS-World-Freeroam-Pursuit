#!/bin/sh
CFG=Release; DEF=""
[ "$1" = "debug" ] && CFG=Debug && DEF="-D_DEBUG"
mkdir -p "$CFG"
llvm-dlltool -m i386 -k -d kernel32.def -l "$CFG/kernel32.lib"
clang --target=i686-pc-windows-msvc -O2 $DEF -fno-exceptions -fno-rtti -ffreestanding -fno-builtin -fno-stack-protector -c NFSWSpeedStreaks.cpp -o "$CFG/NFSWSpeedStreaks.obj"
lld-link /dll /nodefaultlib /entry:DllMain /machine:x86 /safeseh:no /out:"$CFG/NFSWSpeedStreaks.asi" "$CFG/NFSWSpeedStreaks.obj" "$CFG/kernel32.lib"
