#if __has_include(<windows.h>)
#include <windows.h>
#else
typedef int BOOL; typedef unsigned long DWORD; typedef void* HANDLE; typedef void* HMODULE; typedef void* LPVOID;
#define WINAPI __stdcall
#define DLL_PROCESS_ATTACH 1
#define PAGE_READWRITE 0x04
#define PAGE_EXECUTE_READWRITE 0x40
#define GENERIC_WRITE 0x40000000
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
#define MAX_PATH 260
extern "C" {
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, unsigned long, DWORD, DWORD*);
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(const char*);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, const void*, unsigned long);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess();
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HMODULE, char*, DWORD);
__declspec(dllimport) DWORD WINAPI GetPrivateProfileStringA(const char*, const char*, const char*, char*, DWORD, const char*);
__declspec(dllimport) HANDLE WINAPI CreateFileA(const char*, DWORD, DWORD, void*, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE, const void*, DWORD, DWORD*, void*);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
__declspec(selectany) int _fltused = 0;
}
#endif

namespace {

const unsigned kMinSpeedVA = 0xBD1294;
const unsigned kSpeedAlphaVA = 0xBD1298;
const unsigned kRefMinSpeedVA = 0x7A6CDB;
const unsigned kRefSpeedAlphaVA = 0x7A6CE5;
const unsigned kAlphaUpdateVA = 0x7A6CB0;
const unsigned kAlphaUpdateCallVA = 0x71012A;
const unsigned kLevelConfigsVA = 0xDA2770;
const unsigned kRenderVA = 0x7A6D30;
const unsigned kRenderCallVA = 0x710F54;

unsigned g_base = 0x400000;
unsigned VA(unsigned a) { return a - 0x400000 + g_base; }

float g_speedAlpha = 0.15f;
float g_minSpeedKmh = 144.0f;
bool g_whiteWithoutNos = true;
bool g_hideNosStreaks = true;
int g_lineCopies = 3;
float g_lineSpacing = 0.3f;
float g_whiteIntensity = 1.0f;

struct alignas(16) StreakConfig {
    float color[4];
    int texture;
    float scroll;
    float nosAlpha;
    unsigned char pad[0x40 - 0x1C];
};
StreakConfig g_white = { { 1.0f, 1.0f, 1.0f, 0.0f }, 0, 0.0f, 1.0f, {} };

typedef void(__thiscall* AlphaUpdateFn)(void*, float, int, int, float);
AlphaUpdateFn g_alphaUpdate = 0;

typedef void(__thiscall* RenderFn)(void*, void*, float*, int);
RenderFn g_render = 0;
alignas(16) float g_mats[16 * 16];

void __fastcall RenderHook(void* self, void*, void* view, float* mats, int n) {
    g_render(self, view, mats, n);
    if (g_lineCopies <= 1 || n != 16) return;
    for (int c = 1; c < g_lineCopies; ++c) {
        float k = (float)((c + 1) / 2) * g_lineSpacing;
        if ((c & 1) == 0) k = -k;
        for (int i = 0; i < 16 * 16; ++i) g_mats[i] = mats[i];
        for (int m = 0; m < 16; ++m) {
            float* d = g_mats + m * 16;
            d[12] += d[4] * k; d[13] += d[5] * k; d[14] += d[6] * k;
        }
        g_render(self, view, g_mats, n);
    }
}

void __fastcall AlphaUpdateHook(void* self, void*, float dt, int nos, int level, float speed) {
    unsigned char* p = (unsigned char*)self;
    if (!g_hideNosStreaks) {
        g_alphaUpdate(self, dt, nos, level, speed);
        if (g_whiteWithoutNos && p[0x11] == 0) *(StreakConfig**)(p + 0x14) = &g_white;
        return;
    }
    p[0x11] = (unsigned char)nos;
    *(void**)(p + 0x14) = g_whiteWithoutNos ? (void*)&g_white : (void*)(unsigned long)(VA(kLevelConfigsVA) + ((unsigned)level << 6));
    float target = speed >= g_minSpeedKmh / 3.6f ? g_speedAlpha : 0.0f;
    float* alpha = (float*)(p + 0x0C);
    float a = *alpha, step = dt * 2.0f;
    if (target > a) { a += step; if (a > target) a = target; }
    else { a -= step; if (a < target) a = target; }
    *alpha = a;
}


#ifdef _DEBUG
HANDLE g_log = INVALID_HANDLE_VALUE;
void LogOpen() { g_log = CreateFileA("NFSWSpeedStreaks.log", GENERIC_WRITE, 1, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0); }
void LogClose() { if (g_log != INVALID_HANDLE_VALUE) { CloseHandle(g_log); g_log = INVALID_HANDLE_VALUE; } }
void Log(const char* s) {
    if (g_log == INVALID_HANDLE_VALUE) return;
    DWORD n = 0, len = 0; while (s[len]) ++len;
    WriteFile(g_log, s, len, &n, 0);
}
void LogHex(unsigned v) {
    char b[11] = "0x00000000";
    for (int i = 0; i < 8; ++i) { unsigned d = (v >> (28 - 4 * i)) & 15; b[2 + i] = (char)(d < 10 ? '0' + d : 'A' + d - 10); }
    Log(b);
}
void LogFloat(float f) {
    char b[32]; int p = 0;
    if (f < 0) { b[p++] = '-'; f = -f; }
    unsigned ip = (unsigned)f; unsigned fp = (unsigned)((f - (float)ip) * 1000.0f + 0.5f);
    if (fp >= 1000) { ++ip; fp -= 1000; }
    char t[12]; int n = 0; do { t[n++] = (char)('0' + ip % 10); ip /= 10; } while (ip);
    while (n) b[p++] = t[--n];
    b[p++] = '.'; b[p++] = (char)('0' + fp / 100); b[p++] = (char)('0' + fp / 10 % 10); b[p++] = (char)('0' + fp % 10); b[p] = 0;
    Log(b);
}
#else
inline void LogOpen() {}
inline void LogClose() {}
inline void Log(const char*) {}
inline void LogHex(unsigned) {}
inline void LogFloat(float) {}
#endif

float ParseFloat(const char* s, float def) {
    while (*s == ' ' || *s == '\t') ++s;
    bool neg = false;
    if (*s == '-') { neg = true; ++s; } else if (*s == '+') ++s;
    bool any = false; float v = 0.0f;
    while (*s >= '0' && *s <= '9') { v = v * 10.0f + (float)(*s - '0'); ++s; any = true; }
    if (*s == '.' || *s == ',') {
        ++s; float f = 0.1f;
        while (*s >= '0' && *s <= '9') { v += f * (float)(*s - '0'); f *= 0.1f; ++s; any = true; }
    }
    if (!any) return def;
    return neg ? -v : v;
}

void LoadIni(HMODULE self) {
    char path[MAX_PATH];
    DWORD n = GetModuleFileNameA(self, path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH - 4) return;
    int dot = -1;
    for (int i = (int)n - 1; i >= 0; --i) { if (path[i] == '.') { dot = i; break; } if (path[i] == '\\' || path[i] == '/') break; }
    if (dot < 0) dot = (int)n;
    path[dot] = '.'; path[dot + 1] = 'i'; path[dot + 2] = 'n'; path[dot + 3] = 'i'; path[dot + 4] = 0;
    char buf[64];
    if (GetPrivateProfileStringA("SpeedStreaks", "SpeedAlpha", "", buf, sizeof(buf), path)) g_speedAlpha = ParseFloat(buf, g_speedAlpha);
    if (GetPrivateProfileStringA("SpeedStreaks", "MinSpeedKmh", "", buf, sizeof(buf), path)) g_minSpeedKmh = ParseFloat(buf, g_minSpeedKmh);
    if (GetPrivateProfileStringA("SpeedStreaks", "WhiteWithoutNOS", "", buf, sizeof(buf), path)) g_whiteWithoutNos = ParseFloat(buf, 1.0f) != 0.0f;
    if (GetPrivateProfileStringA("SpeedStreaks", "HideNOSStreaks", "", buf, sizeof(buf), path)) g_hideNosStreaks = ParseFloat(buf, 1.0f) != 0.0f;
    if (GetPrivateProfileStringA("SpeedStreaks", "LineCopies", "", buf, sizeof(buf), path)) g_lineCopies = (int)ParseFloat(buf, (float)g_lineCopies);
    if (GetPrivateProfileStringA("SpeedStreaks", "LineSpacing", "", buf, sizeof(buf), path)) g_lineSpacing = ParseFloat(buf, g_lineSpacing);
    if (g_lineCopies < 1) g_lineCopies = 1;
    if (g_lineCopies > 9) g_lineCopies = 9;
    if (GetPrivateProfileStringA("SpeedStreaks", "WhiteIntensity", "", buf, sizeof(buf), path)) g_whiteIntensity = ParseFloat(buf, g_whiteIntensity);
    if (g_whiteIntensity < 0.0f) g_whiteIntensity = 0.0f;
    if (g_speedAlpha < 0.0f) g_speedAlpha = 0.0f;
    if (g_speedAlpha > 1.0f) g_speedAlpha = 1.0f;
    if (g_minSpeedKmh < 0.0f) g_minSpeedKmh = 0.0f;
}

bool WriteFloat(unsigned va, float v) {
    float* p = (float*)(unsigned long)VA(va);
    DWORD old = 0;
    if (!VirtualProtect(p, 4, PAGE_READWRITE, &old)) return false;
    *p = v;
    VirtualProtect(p, 4, old, &old);
    return true;
}

bool HookCall(unsigned callVA, unsigned expectedVA, void* fn, void** original) {
    unsigned char* c = (unsigned char*)(unsigned long)VA(callVA);
    if (c[0] != 0xE8) return false;
    int rel = c[1] | (c[2] << 8) | (c[3] << 16) | (c[4] << 24);
    unsigned target = VA(callVA) + 5 + rel;
    if (target != VA(expectedVA)) return false;
    DWORD old = 0;
    if (!VirtualProtect(c + 1, 4, PAGE_EXECUTE_READWRITE, &old)) return false;
    *original = (void*)(unsigned long)target;
    int nrel = (int)((unsigned)(unsigned long)fn - (VA(callVA) + 5));
    c[1] = (unsigned char)nrel; c[2] = (unsigned char)(nrel >> 8); c[3] = (unsigned char)(nrel >> 16); c[4] = (unsigned char)(nrel >> 24);
    VirtualProtect(c + 1, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), c, 5);
    return true;
}

bool RefersTo(unsigned codeVA, unsigned dataVA) {
    const unsigned char* c = (const unsigned char*)(unsigned long)VA(codeVA);
    unsigned target = c[0] | (c[1] << 8) | (c[2] << 16) | ((unsigned)c[3] << 24);
    return target == VA(dataVA);
}

void Apply(HMODULE self) {
    g_base = (unsigned)(unsigned long)GetModuleHandleA(0);
    Log("NFSWSpeedStreaks: base exe "); LogHex(g_base); Log("\r\n");
    LoadIni(self);
    Log("SpeedAlpha "); LogFloat(g_speedAlpha); Log(", MinSpeedKmh "); LogFloat(g_minSpeedKmh); Log("\r\n");

    const float* minSpeed = (const float*)(unsigned long)VA(kMinSpeedVA);
    const float* speedAlpha = (const float*)(unsigned long)VA(kSpeedAlphaVA);
    if (!RefersTo(kRefMinSpeedVA, kMinSpeedVA) || !RefersTo(kRefSpeedAlphaVA, kSpeedAlphaVA)) {
        Log("codice inatteso - versione exe diversa, nessuna modifica\r\n");
        return;
    }
    if (*minSpeed != 40.0f || !(*speedAlpha > 0.0999f && *speedAlpha < 0.1001f)) {
        Log("valori originali inattesi: "); LogFloat(*minSpeed); Log(" "); LogFloat(*speedAlpha); Log(" - nessuna modifica\r\n");
        return;
    }
    bool ok = WriteFloat(kMinSpeedVA, g_minSpeedKmh / 3.6f) && WriteFloat(kSpeedAlphaVA, g_speedAlpha);
    Log(ok ? "scie velocita' aggiornate\r\n" : "VirtualProtect fallita\r\n");
    if (g_whiteWithoutNos || g_hideNosStreaks) {
        g_white.color[0] = g_white.color[1] = g_white.color[2] = g_whiteIntensity;
        void* orig = 0;
        if (HookCall(kAlphaUpdateCallVA, kAlphaUpdateVA, (void*)&AlphaUpdateHook, &orig)) {
            g_alphaUpdate = (AlphaUpdateFn)orig;
            Log(g_hideNosStreaks ? "solo linee del vento, scie NOS disattivate\r\n" : "scie bianche senza NOS attive\r\n");
        } else {
            Log("hook colore non applicato - codice inatteso\r\n");
        }
    }
    if (g_lineCopies > 1) {
        void* orig = 0;
        if (HookCall(kRenderCallVA, kRenderVA, (void*)&RenderHook, &orig)) {
            g_render = (RenderFn)orig;
            Log("righe moltiplicate\r\n");
        } else {
            Log("hook righe non applicato - codice inatteso\r\n");
        }
    }
}

}

extern "C" BOOL WINAPI DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        LogOpen();
        Apply(h);
        LogClose();
    }
    return 1;
}
