NFS World 2015 - closed beta powerup console mode selector
==========================================================

Adds the closed beta page selector to the powerup console: left/right arrows next to the
side slots and 4 page dots (freeroam, sprint, pursuit, team escape). Mouse clicks also work
when the console is upscaled by NFSWUIScale.

Install (copy into the game's gamedata folder, back up the originals first):
  gamedata\GFX\powerup.gfx                  modified console (arrows, dots, page calls)
  gamedata\Scripts\NFSWPowerupPages.asi     handles PowerupPageLeft/Right (page change + refresh)
  gamedata\Scripts\NFSWUIScale.asi          UI scale v1.8 (scaled hit area for FixMouseMovies)
  gamedata\Scripts\NFSWUIScale.ini          FixMouseMovies=powerup, Log=0

Requires an ASI loader. NFSWPowerupPages works without NFSWUIScale (console at original size).

Source:
  source\powerup.gfx\Powerup.as   AS2 class __Packages/com/ea/HUD/powerups/Powerup
                                  (BigArrowButtonLeft/Right imported from _Buttons.swf)
  source\NFSWPowerupPages\        ASI source + build.sh (clang-cl + lld-link, no CRT)
  source\NFSWUIScale\             ASI source + build.sh
