// NFSWPowerupPages - closed beta powerup console mode selector for NFS World 2015 (offline)
// Handles the "PowerupPageLeft/Right" calls of powerup.gfx that the 2015 exe no longer processes
// (same logic as the 2010 beta: change the powerup page, refresh the console, play the page animation).
#include <windows.h>

extern "C" void* __cdecl memset(void* d, int c, size_t n) { unsigned char* p = (unsigned char*)d; while (n--) *p++ = (unsigned char)c; return d; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; while (n--) *a++ = *b++; return d; }
#pragma function(memset, memcpy)

static DWORD g_base;
static DWORD A(DWORD va) { return va - 0x400000 + g_base; }

static bool StrEq(const char* a, const char* b) { if (!a) return false; while (*a && *a == *b) { ++a; ++b; } return *a == *b; }

// 2015 addresses
static const DWORD kVtblExt   = 0x00B2D2D8; // powerup HUD ExternalInterface handler slot (0x485A80)
static const DWORD kMgrPtr    = 0x00CE62A8; // powerup manager singleton
static const DWORD kInvoke    = 0x009A7560; // movie->Invoke(method, fmt)
static const DWORD kRefresh   = 0x0048A3B0; // powerup HUD refresh (data + SetPowerupPage)
static const DWORD kEmptyFmt  = 0x00B1F804; // ""
static const int   kPageOff   = 0xA8;       // manager: current page
static const int   kPages     = 4;          // freeroam, sprint, pursuit, team escape

typedef void (__fastcall* Ext_t)(DWORD self, void* edx, int a2, const char* name, int args, int n);
typedef int  (__cdecl*    Invoke_t)(DWORD movie, const char* method, const char* fmt);
typedef void (__fastcall* Refresh_t)(DWORD hud, void* edx);
static Ext_t g_orig;

static void __fastcall ExtHook(DWORD self, void* edx, int a2, const char* name, int args, int n)
{
    bool left = StrEq(name, "PowerupPageLeft"), right = StrEq(name, "PowerupPageRight");
    if (!left && !right) { g_orig(self, edx, a2, name, args, n); return; }
    DWORD hud = self - 0x20;                       // handler sub-object is at HUD + 0x20
    DWORD mgr = *(DWORD*)A(kMgrPtr);
    DWORD movie = *(DWORD*)(hud + 0x2C);
    if (!mgr || !movie) return;
    Invoke_t inv = (Invoke_t)A(kInvoke); const char* e = (const char*)A(kEmptyFmt);
    inv(movie, left ? "powerupMarkerSlots.SetupPageUp" : "powerupMarkerSlots.SetupPageDown", e);
    int p = *(int*)(mgr + kPageOff);
    if (p < 0 || p >= kPages) p = 0;
    p = left ? (p == 0 ? kPages - 1 : p - 1) : (p == kPages - 1 ? 0 : p + 1);
    *(int*)(mgr + kPageOff) = p;
    ((Refresh_t)A(kRefresh))(hud, 0);
    inv(movie, left ? "powerupMarkerSlots.TriggerPageUp" : "powerupMarkerSlots.TriggerPageDown", e);
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason != DLL_PROCESS_ATTACH) return TRUE;
    DisableThreadLibraryCalls(h);
    g_base = (DWORD)GetModuleHandleA(0);
    DWORD* slot = (DWORD*)A(kVtblExt);
    if (*slot != A(0x00485A80)) return TRUE;       // unknown exe: do nothing
    DWORD old;
    if (!VirtualProtect(slot, 4, 0x04, &old)) return TRUE;
    g_orig = (Ext_t)*slot;
    *slot = (DWORD)ExtHook;
    VirtualProtect(slot, 4, old, &old);
    return TRUE;
}
