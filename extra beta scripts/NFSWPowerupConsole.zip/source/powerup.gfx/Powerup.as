class com.ea.HUD.powerups.Powerup extends MovieClip
{
   var powerUpElements;
   var tempPowerUpElements;
   var mPowerupButtonListeners;
   var main;
   var temp;
   var arrowLeft;
   var arrowRight;
   var pageIndicator;
   var kMAX_ELEMENTS = 4;
   var kMAX_PAGES = 4;
   var HC_powerupClipListener = new Object();
   var delegates = new Object();
   var pageIndex = 0;
   function Powerup()
   {
      super();
      this.powerUpElements = new Array();
      this.tempPowerUpElements = new Array();
      this.mPowerupButtonListeners = new Object();
      var _loc3_ = 0;
      var _loc4_;
      while(_loc3_ < this.kMAX_ELEMENTS)
      {
         _loc4_ = this.main["powerup_" + _loc3_];
         this.powerUpElements[_loc3_] = _loc4_;
         _loc4_.slot = _loc3_;
         this.powerUpElements[_loc3_] = _loc4_;
         this.tempPowerUpElements[_loc3_] = this.temp["powerup_" + _loc3_];
         _loc3_ = _loc3_ + 1;
      }
   }
   function onLoad()
   {
      if(this.arrowLeft == undefined)
      {
         this.CreatePageControls();
      }
      this.arrowLeft.onRollOver = function()
      {
         com.ea.util.SFX.PlaySound(com.ea.util.SFX.MOUSE_OVER_SFX);
         this.gotoAndStop("_over");
      };
      this.arrowLeft.onRollOut = function()
      {
         this.gotoAndStop("_up");
      };
      this.arrowLeft.onPress = function()
      {
         this.gotoAndStop("_down");
      };
      this.arrowLeft.onRelease = function()
      {
         this.gotoAndStop("_up");
         com.ea.util.SFX.PlaySound("PREVIOUS_BUTTON");
         this._parent.FirePageLeft();
      };
      this.arrowRight.onRollOver = function()
      {
         com.ea.util.SFX.PlaySound(com.ea.util.SFX.MOUSE_OVER_SFX);
         this.gotoAndStop("_over");
      };
      this.arrowRight.onRollOut = function()
      {
         this.gotoAndStop("_up");
      };
      this.arrowRight.onPress = function()
      {
         this.gotoAndStop("_down");
      };
      this.arrowRight.onRelease = function()
      {
         this.gotoAndStop("_up");
         com.ea.util.SFX.PlaySound("NEXT_BUTTON");
         this._parent.FirePageRight();
      };
   }
   function CreatePageControls()
   {
      // beta mode selector (arrows + 4 page dots), drawn at runtime: the 2015 file has no artwork for it
      // slot centres in this clip: top (0,-45), left (-42,-3), right (42,-3), bottom (0,39)
      var _loc6_ = this.getNextHighestDepth();
      // arrows: standard car selector arrows (BigArrowButtonLeft/Right imported from _Buttons), beside the left/right powerup slots (closed beta layout)
      this.arrowLeft = this.CreateArrow("arrowLeft",_loc6_,-1);
      this.arrowLeft._x = -82;
      this.arrowLeft._y = -3;
      this.arrowRight = this.CreateArrow("arrowRight",_loc6_ + 1,1);
      this.arrowRight._x = 82;
      this.arrowRight._y = -3;
      var _loc3_ = this.createEmptyMovieClip("pageIndicator",_loc6_ + 2);
      var _loc7_ = 0;
      var _loc8_;
      while(_loc7_ < this.kMAX_PAGES)
      {
         _loc8_ = _loc3_.createEmptyMovieClip("dot" + _loc7_,_loc7_);
         this.DrawCircle(_loc8_,0,0,4,16777215);
         _loc8_._x = (_loc7_ - (this.kMAX_PAGES - 1) / 2) * 16;
         _loc7_ = _loc7_ + 1;
      }
      _loc3_._x = 0;
      _loc3_._y = 70;
      _loc3_.owner = this;
      _loc3_.gotoAndPlay = function(lbl)
      {
         var _loc3_ = Number(String(lbl).substr(4));
         var _loc2_ = 0;
         while(_loc2_ < this.owner.kMAX_PAGES)
         {
            this["dot" + _loc2_]._alpha = _loc2_ != _loc3_ ? 35 : 100;
            _loc2_ = _loc2_ + 1;
         }
      };
      _loc3_.gotoAndStop = _loc3_.gotoAndPlay;
      _loc3_.gotoAndPlay("page" + this.pageIndex);
   }
   function CreateArrow(name, depth, dir)
   {
      var _loc2_ = this.createEmptyMovieClip(name,depth);
      var _loc3_ = _loc2_.attachMovie(dir >= 0 ? "BigArrowButtonRight" : "BigArrowButtonLeft","btn",1);
      if(_loc3_ != undefined && _loc3_._height > 0)
      {
         // standard car selector arrow (imported from _Buttons), 24 px high, centred on the container
         var _loc4_ = 24 / _loc3_._height * 100;
         _loc3_._xscale = _loc4_;
         _loc3_._yscale = _loc4_;
         var _loc5_ = _loc3_.getBounds(_loc2_);
         _loc3_._x = - (_loc5_.xMin + _loc5_.xMax) / 2;
         _loc3_._y = - (_loc5_.yMin + _loc5_.yMax) / 2;
         _loc3_.gotoAndStop(1);
         _loc2_.gotoAndStop = function(f)
         {
            this.btn.gotoAndStop(f != "_over" ? (f != "_down" ? 1 : 3) : 2);
         };
         return _loc2_;
      }
      // fallback: drawn arrow
      _loc2_.beginFill(16777215,100);
      _loc2_.moveTo(-5 * dir,-9);
      _loc2_.lineTo(6 * dir,0);
      _loc2_.lineTo(-5 * dir,9);
      _loc2_.lineTo(-5 * dir,-9);
      _loc2_.endFill();
      _loc2_._alpha = 75;
      _loc2_.gotoAndStop = function(f)
      {
         this._alpha = f != "_over" ? (f != "_down" ? 75 : 55) : 100;
      };
      return _loc2_;
   }
   function DrawCircle(mc, x, y, r, col)
   {
      var _loc3_ = 0.41421356 * r;
      var _loc2_ = 0.70710678 * r;
      mc.beginFill(col,100);
      mc.moveTo(x + r,y);
      mc.curveTo(x + r,y + _loc3_,x + _loc2_,y + _loc2_);
      mc.curveTo(x + _loc3_,y + r,x,y + r);
      mc.curveTo(x - _loc3_,y + r,x - _loc2_,y + _loc2_);
      mc.curveTo(x - r,y + _loc3_,x - r,y);
      mc.curveTo(x - r,y - _loc3_,x - _loc2_,y - _loc2_);
      mc.curveTo(x - _loc3_,y - r,x,y - r);
      mc.curveTo(x + _loc3_,y - r,x + _loc2_,y - _loc2_);
      mc.curveTo(x + r,y - _loc3_,x + r,y);
      mc.endFill();
   }
   function onKeyDown()
   {
      var _loc2_ = Key.getCode();
   }
   function ResetPowerupData()
   {
      var _loc2_ = 0;
      while(_loc2_ < this.kMAX_ELEMENTS)
      {
         this.powerUpElements[_loc2_].setPowerupEffectMode(com.ea.HUD.powerups.PowerupElement.EFFECT_MODE_EMPTY,0);
         _loc2_ = _loc2_ + 1;
      }
   }
   function SetPowerupPage(page)
   {
      this.pageIndex = page;
      this.pageIndicator.gotoAndPlay("page" + this.pageIndex);
   }
   function SetPowerupData(slotID, typeID, quantity, imageID)
   {
      var _loc6_ = new com.ea.HUD.powerups.PowerupData(slotID,typeID,quantity,imageID);
      var _loc7_ = this.powerUpElements[slotID];
      _loc7_.setListener(this.HC_powerupClipListener);
      _loc7_.SetPowerupData(_loc6_);
   }
   function SetTempPage()
   {
      var _loc2_ = 0;
      var _loc3_;
      while(_loc2_ < this.kMAX_ELEMENTS)
      {
         _loc3_ = this.powerUpElements[_loc2_].getData();
         if(_loc3_ != undefined)
         {
            this.tempPowerUpElements[_loc2_].SetPowerupData(_loc3_);
            this.tempPowerUpElements[_loc2_].setPowerupEffectMode(_loc3_.modeID);
            this.tempPowerUpElements[_loc2_].UpdateTimerProgress(_loc3_.rechargeProgress);
         }
         _loc2_ = _loc2_ + 1;
      }
   }
   function SetPowerupEffectMode(slotID, modeID)
   {
      var _loc4_ = this.powerUpElements[slotID];
      _loc4_.setPowerupEffectMode(modeID);
   }
   function UpdateTimer(slotID, progressInPercent)
   {
      var _loc4_ = this.powerUpElements[slotID];
      _loc4_.UpdateTimerProgress(progressInPercent);
   }
   function FirePageLeft()
   {
      flash.external.ExternalInterface.call("PowerupPageLeft");
   }
   function FirePageRight(r)
   {
      flash.external.ExternalInterface.call("PowerupPageRight");
   }
   function SetupPageUp()
   {
      this.gotoAndPlay("startPageLeft");
      this.SetTempPage();
      this.pageIndex = this.pageIndex - 1;
      if(this.pageIndex < 0)
      {
         this.pageIndex = this.kMAX_PAGES - 1;
      }
   }
   function TriggerPageUp()
   {
      this.gotoAndPlay("animatePageLeft");
      this.pageIndicator.gotoAndPlay("page" + this.pageIndex);
   }
   function SetupPageDown()
   {
      this.gotoAndPlay("startPageRight");
      this.SetTempPage();
      this.pageIndex = this.pageIndex + 1;
      if(this.pageIndex >= this.kMAX_PAGES)
      {
         this.pageIndex = 0;
      }
   }
   function TriggerPageDown()
   {
      this.gotoAndPlay("animatePageRight");
      this.pageIndicator.gotoAndPlay("page" + this.pageIndex);
   }
   function getWidth()
   {
      return Stage.width;
   }
   function getHeight()
   {
      return Stage.height;
   }
}
