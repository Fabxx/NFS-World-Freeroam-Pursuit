// dichiarazioni Windows minime (build senza Windows SDK: clang-cl + lld-link)
#pragma once
typedef unsigned long DWORD; typedef int BOOL; typedef unsigned char BYTE; typedef unsigned short WORD; typedef unsigned int UINT;
typedef int INT; typedef long LONG; typedef void* LPVOID; typedef void* HANDLE; typedef struct HINSTANCE__* HINSTANCE;
typedef HINSTANCE HMODULE; typedef const char* LPCSTR; typedef char* LPSTR; typedef unsigned long SIZE_T; typedef unsigned int size_t;
typedef DWORD* PDWORD; typedef DWORD* LPDWORD; typedef const void* LPCVOID; typedef unsigned int UINT_PTR;
#define WINAPI __stdcall
#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define DLL_PROCESS_ATTACH 1
#define GENERIC_READ 0x80000000
#define FILE_SHARE_READ 1
#define OPEN_EXISTING 3
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
#define MEM_COMMIT 0x1000
#define MEM_RESERVE 0x2000
#define PAGE_READWRITE 0x04
#define MEM_FREE 0x10000
#define MEM_RELEASE 0x8000
struct SYSTEMTIME { WORD wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds; };
struct MEMORY_BASIC_INFORMATION { LPVOID BaseAddress; LPVOID AllocationBase; DWORD AllocationProtect; SIZE_T RegionSize; DWORD State; DWORD Protect; DWORD Type; };
struct CRITICAL_SECTION { void* DebugInfo; LONG LockCount; LONG RecursionCount; HANDLE OwningThread; HANDLE LockSemaphore; UINT_PTR SpinCount; };
typedef DWORD (WINAPI* LPTHREAD_START_ROUTINE)(LPVOID);
#pragma pack(push, 1)
struct WAVEFORMATEX { WORD wFormatTag; WORD nChannels; DWORD nSamplesPerSec; DWORD nAvgBytesPerSec; WORD nBlockAlign; WORD wBitsPerSample; WORD cbSize; };
#pragma pack(pop)
struct WAVEHDR { LPSTR lpData; DWORD dwBufferLength; DWORD dwBytesRecorded; UINT_PTR dwUser; DWORD dwFlags; DWORD dwLoops; WAVEHDR* lpNext; UINT_PTR reserved; };
typedef void* HWAVEOUT;
extern "C" {
__declspec(dllimport) UINT WINAPI waveOutOpen(HWAVEOUT*, UINT, const WAVEFORMATEX*, UINT_PTR, UINT_PTR, DWORD);
__declspec(dllimport) UINT WINAPI waveOutPrepareHeader(HWAVEOUT, WAVEHDR*, UINT);
__declspec(dllimport) UINT WINAPI waveOutWrite(HWAVEOUT, WAVEHDR*, UINT);
__declspec(dllimport) UINT WINAPI waveOutClose(HWAVEOUT);
__declspec(dllimport) UINT WINAPI waveOutReset(HWAVEOUT);
}
extern "C" {
__declspec(dllimport) HMODULE WINAPI GetModuleHandleA(LPCSTR);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HMODULE, LPSTR, DWORD);
__declspec(dllimport) UINT WINAPI GetPrivateProfileIntA(LPCSTR, LPCSTR, INT, LPCSTR);
__declspec(dllimport) DWORD WINAPI GetPrivateProfileStringA(LPCSTR, LPCSTR, LPCSTR, LPSTR, DWORD, LPCSTR);
__declspec(dllimport) HANDLE WINAPI CreateFileA(LPCSTR, DWORD, DWORD, LPVOID, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE, LPCVOID, DWORD, LPDWORD, LPVOID);
__declspec(dllimport) BOOL WINAPI ReadFile(HANDLE, LPVOID, DWORD, LPDWORD, LPVOID);
__declspec(dllimport) DWORD WINAPI GetFileSize(HANDLE, LPDWORD);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) DWORD WINAPI GetTickCount(void);
__declspec(dllimport) BOOL WINAPI QueryPerformanceCounter(long long*);
__declspec(dllimport) BOOL WINAPI QueryPerformanceFrequency(long long*);
__declspec(dllimport) HANDLE WINAPI GetCurrentProcess(void);
__declspec(dllimport) DWORD WINAPI GetCurrentThreadId(void);
__declspec(dllimport) BOOL WINAPI VirtualProtect(LPVOID, SIZE_T, DWORD, PDWORD);
__declspec(dllimport) LPVOID WINAPI VirtualAlloc(LPVOID, SIZE_T, DWORD, DWORD);
__declspec(dllimport) SIZE_T WINAPI VirtualQuery(LPCVOID, MEMORY_BASIC_INFORMATION*, SIZE_T);
__declspec(dllimport) HANDLE WINAPI CreateThread(LPVOID, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD);
__declspec(dllimport) void WINAPI Sleep(DWORD);
__declspec(dllimport) BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
__declspec(dllimport) void WINAPI GetLocalTime(SYSTEMTIME*);
__declspec(dllimport) BOOL WINAPI FlushInstructionCache(HANDLE, LPCVOID, SIZE_T);
__declspec(dllimport) BOOL WINAPI WritePrivateProfileStringA(LPCSTR, LPCSTR, LPCSTR, LPCSTR);
__declspec(dllimport) short WINAPI GetAsyncKeyState(int);
__declspec(dllimport) void* WINAPI GetForegroundWindow(void);
__declspec(dllimport) DWORD WINAPI GetWindowThreadProcessId(void*, DWORD*);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) BOOL WINAPI VirtualFree(LPVOID, SIZE_T, DWORD);
__declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE, DWORD);
__declspec(dllimport) BOOL WINAPI ReleaseMutex(HANDLE);
__declspec(dllimport) void WINAPI InitializeCriticalSection(CRITICAL_SECTION*);
__declspec(dllimport) void WINAPI EnterCriticalSection(CRITICAL_SECTION*);
__declspec(dllimport) void WINAPI LeaveCriticalSection(CRITICAL_SECTION*);
__declspec(dllimport) BOOL WINAPI TryEnterCriticalSection(CRITICAL_SECTION*);
__declspec(dllimport) DWORD WINAPI SetFilePointer(HANDLE, LONG, LONG*, DWORD);
__declspec(dllimport) BOOL WINAPI CreateDirectoryA(LPCSTR, LPVOID);
struct GUID { DWORD a; unsigned short b, c; unsigned char d[8]; };
__declspec(dllimport) long WINAPI CoInitializeEx(LPVOID, DWORD);
__declspec(dllimport) long WINAPI CoCreateInstance(const GUID&, LPVOID, DWORD, const GUID&, LPVOID*);
__declspec(dllimport) void WINAPI CoTaskMemFree(LPVOID);
}
