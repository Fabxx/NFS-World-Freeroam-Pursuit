// NFSWBetaEngineAudio - NFS Carbon / Asian beta AEMS engine audio for NFS World 2015 (offline)
// Build: clang-cl + lld-link, no CRT (see build.sh). Addresses are NFS World 2015 VAs (ASLR-relocated via A()).
#include <windows.h>

static const DWORD kBase = 0x00400000;

static const DWORD kAemsTaskInt   = 0x00947090;
static const DWORD kAemsSetRate   = 0x00946000;
static const DWORD kAemsRunInt    = 0x009460E0;
static const DWORD kImpNew        = 0x00CDB3B0;
static const DWORD kGRate = 0x00E02CEC, kGCntReload = 0x00E02CF0, kGCnt = 0x00E02CF4, kGListInt = 0x00E02D44, kGListEmb = 0x00E02D48;
static const DWORD kLoadBank      = 0x00947D50;
static const DWORD kUnloadBank    = 0x00946F10;
static const DWORD kCsisAddLib    = 0x008BA230;
static const DWORD kCsisRegister  = 0x008BAED0;
static const DWORD kCsisCreate    = 0x008BAFF0;
static const DWORD kCsisUpdate    = 0x008BAB40;
static const DWORD kCsisRelease   = 0x008BAB10;

static const DWORD kEngVtbl       = 0x00BD95D8;
static const DWORD kEngDtor       = 0x00838970;
static const DWORD kEngUpdate     = 0x008317C0;
static const unsigned char kTaskBytes[] = { 0xD9, 0x44, 0x24, 0x08, 0xD9, 0xC0, 0xD9, 0x05, 0xEC, 0x2C, 0xE0, 0x00 };

static DWORD g_delta;

// ---- utilities
static DWORD A(DWORD va) { return va + g_delta; }

static int StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); if (n < cap) StrCpy(d + n, s, cap - n); }
static char Low(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static bool StrIEq(const char* a, const char* b) { while (*a && *b) { if (Low(*a) != Low(*b)) return false; ++a; ++b; } return *a == *b; }
static void MemSet(void* p, int v, int n) { unsigned char* q = (unsigned char*)p; for (int i = 0; i < n; ++i) q[i] = (unsigned char)v; }
static void MemCpy(void* d, const void* s, int n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; for (int i = 0; i < n; ++i) a[i] = b[i]; }
extern "C" void* __cdecl memset(void* p, int v, size_t n) { MemSet(p, v, (int)n); return p; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { MemCpy(d, s, (int)n); return d; }
static void IToStr(int v, char* out) { char t[16]; int n = 0; unsigned u = v < 0 ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (v < 0) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static void HexStr(DWORD v, char* out) { const char* h = "0123456789ABCDEF"; for (int i = 0; i < 8; ++i) out[i] = h[(v >> (28 - 4 * i)) & 15]; out[8] = 0; }
static float ParseF(const char* s, float def)
{
    if (!s || !*s) return def;
    float sign = 1, v = 0, f = 0.1f; int i = 0; bool any = false;
    if (s[i] == '-') { sign = -1; ++i; }
    for (; s[i] >= '0' && s[i] <= '9'; ++i) { v = v * 10 + (s[i] - '0'); any = true; }
    if (s[i] == '.' || s[i] == ',') for (++i; s[i] >= '0' && s[i] <= '9'; ++i) { v += (s[i] - '0') * f; f *= 0.1f; any = true; }
    return any ? sign * v : def;
}
static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static char g_dir[MAX_PATH], g_gameDir[MAX_PATH], g_log[MAX_PATH], g_bankDir[MAX_PATH];
static bool g_logOn = true;
static CRITICAL_SECTION g_logCs;
static void Log(const char* a, const char* b = 0, const char* c = 0, const char* d = 0)
{
    if (!g_logOn) return;
    EnterCriticalSection(&g_logCs);
    HANDLE h = CreateFileA(g_log, 0x0004 , FILE_SHARE_READ, 0, 4 , FILE_ATTRIBUTE_NORMAL, 0);
    if (h != INVALID_HANDLE_VALUE) {
        SYSTEMTIME t; GetLocalTime(&t);
        char ts[32] = "[", n[12];
        IToStr(t.wHour, n); if (t.wHour < 10) StrCat(ts, "0", 32); StrCat(ts, n, 32); StrCat(ts, ":", 32);
        IToStr(t.wMinute, n); if (t.wMinute < 10) StrCat(ts, "0", 32); StrCat(ts, n, 32); StrCat(ts, ":", 32);
        IToStr(t.wSecond, n); if (t.wSecond < 10) StrCat(ts, "0", 32); StrCat(ts, n, 32); StrCat(ts, "] ", 32);
        DWORD w; WriteFile(h, ts, StrLen(ts), &w, 0);
        const char* p[4] = { a, b, c, d };
        for (int i = 0; i < 4; ++i) if (p[i]) WriteFile(h, p[i], StrLen(p[i]), &w, 0);
        WriteFile(h, "\r\n", 2, &w, 0);
        CloseHandle(h);
    }
    LeaveCriticalSection(&g_logCs);
}
static void LogI(const char* a, int v, const char* b = 0) { char n[16]; IToStr(v, n); Log(a, n, b); }
static void LogH(const char* a, DWORD v, const char* b = 0) { char n[16]; HexStr(v, n); Log(a, n, b); }

static bool Readable(const void* p, int n)
{
    if ((DWORD)p < 0x10000) return false;
    MEMORY_BASIC_INFORMATION mi;
    if (!VirtualQuery(p, &mi, sizeof(mi))) return false;
    if (mi.State != MEM_COMMIT) return false;
    DWORD pr = mi.Protect & 0xFF;
    if ((mi.Protect & 0x100) || pr == 0x01 || pr == 0) return false;
    DWORD end = (DWORD)mi.BaseAddress + mi.RegionSize;
    return (DWORD)p + (DWORD)n <= end;
}

static void* ReadWholeFile(const char* path, DWORD* size, DWORD extra)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD n = GetFileSize(h, 0);
    void* buf = VirtualAlloc(0, n + extra + 64, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    DWORD r = 0;
    if (!buf || !ReadFile(h, buf, n, &r, 0) || r != n) { CloseHandle(h); return 0; }
    CloseHandle(h);
    *size = n;
    return buf;
}

#pragma pack(push, 1)

struct HybPar { int aemsVol, decAemsVol, ginAccVol, ginDecVol;
                float aMixS, aMixL, dAMixS, dAMixL, gMixS, gMixL, dGMixS, dGMixL, gNegS, gNegL, accThr, decThr;
                int decMin, decMax; float fadeIn, fadeOut; int has; };
struct ColData { char name[32]; char bank[48]; int carId; float minRpm, maxRpm; int cf[19]; int rs[8]; int lv[8]; int volShift; int tranny; HybPar h; };
struct CarData { DWORD key; int exh, eng; DWORD parent; int src; int gears; char name[32]; };
#pragma pack(pop)
#pragma pack(push, 1)
struct ShiftData { DWORD key; char bank[24]; DWORD hashCB; int volB; };
#pragma pack(pop)
static ShiftData* g_shifts; static int g_nShifts = 0;
static ColData* g_cols; static int g_nCols;
static CarData* g_cars; static int g_nCars;
static int FindCar(DWORD key) { for (int i = 0; i < g_nCars; ++i) if (g_cars[i].key == key) return i; return -1; }
static char g_ini[MAX_PATH];

// ---- NFSWBetaEngineAudio.dat (car -> Carbon collections, shift banks)
static bool LoadData()
{
    char p[MAX_PATH]; StrCpy(p, g_dir, MAX_PATH); StrCat(p, "NFSWBetaEngineAudio.dat", MAX_PATH);
    DWORD n = 0; unsigned char* d = (unsigned char*)ReadWholeFile(p, &n, 0);
    if (!d || n < 12 || d[0] != 'B' || d[1] != 'E' || d[2] != 'A' || d[3] != '6') return false;
    g_nCols = *(int*)(d + 4); g_nCars = *(int*)(d + 8);
    if (12 + g_nCols * (int)sizeof(ColData) + g_nCars * (int)sizeof(CarData) > (int)n) return false;
    g_cols = (ColData*)(d + 12); g_cars = (CarData*)(d + 12 + g_nCols * sizeof(ColData));
    DWORD t = 12 + g_nCols * sizeof(ColData) + g_nCars * sizeof(CarData);
    if (t + 8 <= n && d[t] == 'S' && d[t + 1] == 'H' && d[t + 2] == 'F' && d[t + 3] == 'T') { int c = *(int*)(d + t + 4); if (t + 8 + c * (int)sizeof(ShiftData) <= n) { g_nShifts = c; g_shifts = (ShiftData*)(d + t + 8); } }
    return true;
}

static int FindCol(const char* n) { for (int i = 0; i < g_nCols; ++i) if (StrIEq(g_cols[i].name, n)) return i; return -1; }

// [Cars] ini overrides
static void ApplyOverrides()
{
    static char keys[4096]; DWORD n = GetPrivateProfileStringA("Cars", 0, "", keys, sizeof(keys), g_ini);
    for (char* k = keys; n && *k; k += StrLen(k) + 1) {
        char v[128]; GetPrivateProfileStringA("Cars", k, "", v, sizeof(v), g_ini);
        char a[64] = "", b[64] = ""; int i = 0, j = 0;
        while (v[i] && v[i] != ',' && j < 63) { if (v[i] != ' ') a[j++] = v[i]; ++i; } a[j] = 0;
        if (v[i] == ',') { ++i; j = 0; while (v[i] && j < 63) { if (v[i] != ' ') b[j++] = v[i]; ++i; } b[j] = 0; }
        int ix = a[0] ? FindCol(a) : -1, ie = b[0] ? FindCol(b) : -1;
        int c = -1; for (int q = 0; q < g_nCars; ++q) if (StrIEq(g_cars[q].name, k)) c = q;
        if (c < 0 && k[0] == '0' && (k[1] == 'x' || k[1] == 'X')) {   // caraudio key as hex (upgrade-level collections have no name)
            DWORD hk = 0; for (const char* q = k + 2; *q; ++q) { char ch = Low(*q); hk = hk * 16 + (DWORD)(ch >= 'a' ? ch - 'a' + 10 : ch - '0'); }
            c = FindCar(hk);
        }
        if (c < 0 || (a[0] && ix < 0) || (b[0] && ie < 0)) { Log("[ini] invalid [Cars] entry: ", k, "=", v); continue; }
        g_cars[c].exh = ix; g_cars[c].eng = ie; g_cars[c].src = 1;
        Log("[ini] ", k, " -> ", v);
    }
}

static int g_allCars = 1, g_muteHub = 1;
static int g_p20 = -1, g_trP28 = 0;
static float g_trVol = 0.25f, g_whVol = 0.0f, g_trSpeedScale = 3.6f, g_whTop = 280.0f, g_whRpmMix = 0.2f;
static int g_trBySpeed = 0, g_trOwn = 1, g_trShiftMs = 350, g_whOwn = 1;
static DWORD now32() { return GetTickCount(); }
static float g_ngVol = 1.0f, g_sweetVol = 1.0f, g_sweetThr = 0.667f;
static volatile int g_layerOn = 1;
static int CountList(DWORD head) { int n = 0; for (DWORD v = *(DWORD*)A(head); v && n < 1000; v = *(DWORD*)v) { if (!Readable((void*)v, 4)) break; ++n; } return n; }
static int g_enable = 1, g_tickOld = 1, g_playerOnly = 1, g_telemetry = 1, g_useGameMix = 1, g_swap = 0;
static float g_exhVol = 1.0f, g_engVol = 1.0f;
static int g_pan = 0, g_mix64 = 0, g_mix116 = 0, g_p72 = 0, g_filter = 25000, g_vol2 = 0;

// ---- options
static float GetF(const char* sec, const char* key, float def) { char b[32]; GetPrivateProfileStringA(sec, key, "", b, 32, g_ini); return ParseF(b, def); }

typedef void (__cdecl* SetRate_t)(float);
typedef void (__cdecl* RunInt_t)(DWORD, DWORD, DWORD);
typedef void (__cdecl* EmbFn_t)(DWORD);
static volatile LONG g_embTicks = 0;
static void __cdecl AemsTask(int, float rate)
{
    if (*(float*)A(kGRate) != rate) ((SetRate_t)A(kAemsSetRate))(rate);
    int* cnt = (int*)A(kGCnt);
    if (--*cnt != 0) return;
    *cnt = *(int*)A(kGCntReload);
    for (DWORD v = *(DWORD*)A(kGListInt); v; ) { DWORD nx = *(DWORD*)v; ((RunInt_t)A(kAemsRunInt))(*(DWORD*)(v + 16), *(DWORD*)(v + 24), A(kImpNew)); v = nx; }
    if (g_tickOld) {
        for (DWORD v = *(DWORD*)A(kGListEmb); v; ) { DWORD nx = *(DWORD*)v; ((EmbFn_t)(*(DWORD*)(v + 8)))(*(DWORD*)(v + 12)); v = nx; ++g_embTicks; }
    }
}

typedef int (__cdecl* LoadBank_t)(void*, const char*, int, void*);
typedef int (__cdecl* UnloadBank_t)(int);
typedef int (__cdecl* AddLib_t)(void*);
typedef int (__fastcall* Register_t)(DWORD* desc, void*, void* entry);
typedef int (__cdecl* Create_t)(DWORD* desc, int* params, DWORD* handle);
typedef int (__fastcall* Update_t)(DWORD handle, void*, int* params);
typedef int (__fastcall* Release_t)(DWORD handle, void*);

struct CsisEntry { const char* name; DWORD id; };
static CsisEntry g_entCar = { "CAR", 0x0DD6311C }, g_entEng = { "CAR_ENG", 0x76EF311C }, g_entSw = { "CAR_SWTN", 0x7859311C }, g_entTr = { "CAR_TRANNY", 0x6F12311C }, g_entWh = { "CAR_WHINE", 0x603F311C };
static DWORD g_descCar[2], g_descEng[2], g_descSw[2], g_descTr[2], g_descWh[2], g_descFx[2];

static CsisEntry g_entFx = { "FX_SHIFTING_01", 0x79377C75 };
static int g_fxOn = 1, g_fxBank = -1; static float g_fxVol = 1.0f; static bool g_fxLibTried = false, g_fxLibOk = false;
static int g_curShift = -1;
static bool g_libOk = false, g_libTried = false;

static DWORD g_bankAllocSize;
static void* __cdecl BankAlloc(void* src, int size, int)
{
    if ((DWORD)size <= g_bankAllocSize) return src;
    void* p = VirtualAlloc(0, size + 64, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    return p;
}

struct Bank { char file[48]; int id; void* mem; };
struct Pending { void* mem; DWORD t; };
static Pending g_pend[16];
static void FreeLater(void* p) { if (!p) return; for (int i = 0; i < 16; ++i) if (!g_pend[i].mem) { g_pend[i].t = GetTickCount(); g_pend[i].mem = p; return; } }
static void FreePending()
{
    DWORD now = GetTickCount();
    for (int i = 0; i < 16; ++i) if (g_pend[i].mem && now - g_pend[i].t > 15000) { void* p = g_pend[i].mem; g_pend[i].mem = 0; VirtualFree(p, 0, MEM_RELEASE); }
}
static Bank g_banks[8]; static int g_nBanks = 0;

// ---- Csis libraries and banks
static bool EnsureLib()
{
    if (g_libTried) return g_libOk;
    g_libTried = true;
    char p[MAX_PATH]; StrCpy(p, g_bankDir, MAX_PATH); StrCat(p, "engines_aems2_ng.csi", MAX_PATH);
    DWORD n = 0; void* lib = ReadWholeFile(p, &n, 64);
    if (!lib || n < 40 || *(DWORD*)lib != 0x52494F4D ) { Log("[csi] beta engines_aems2_ng.csi missing or invalid: ", p); return false; }
    int r = ((AddLib_t)A(kCsisAddLib))(lib);
    g_libOk = (r == 0);
    LogI("[csi] beta class library (CAR, CAR_ENG...) registered, result ", r);
    return g_libOk;
}

static void UnloadBanks()
{
    for (int i = 0; i < g_nBanks; ++i) {
        if (g_banks[i].id > 0) {
            int r = ((UnloadBank_t)A(kUnloadBank))(g_banks[i].id);
            Log("[bank] unloaded ", g_banks[i].file, r == 0 ? "" : " (errore)");
            if (r == 0) FreeLater(g_banks[i].mem);
        }

    }
    g_nBanks = 0;
    g_descCar[0] = g_descCar[1] = g_descEng[0] = g_descEng[1] = g_descSw[0] = g_descSw[1] = g_descTr[0] = g_descTr[1] = g_descWh[0] = g_descWh[1] = 0;
    g_descFx[0] = g_descFx[1] = 0;
}

// beta main_aems csi (FX_SHIFTING_01)
static bool EnsureFxLib()
{
    if (g_fxLibTried) return g_fxLibOk;
    g_fxLibTried = true;
    char p[MAX_PATH]; StrCpy(p, g_bankDir, MAX_PATH); StrCat(p, "main_aems_beta.csi", MAX_PATH);
    DWORD n = 0; void* lib = ReadWholeFile(p, &n, 64);
    if (!lib || n < 40 || *(DWORD*)lib != 0x52494F4D) { Log("[shift] main_aems_beta.csi missing: Carbon shift sound disabled"); return false; }
    int r = ((AddLib_t)A(kCsisAddLib))(lib);
    g_fxLibOk = (r == 0);
    LogI("[shift] beta class library (FX_SHIFTING_01) registered, result ", r);
    return g_fxLibOk;
}
static int LoadBank(const char* file)
{
    for (int i = 0; i < g_nBanks; ++i) if (StrIEq(g_banks[i].file, file)) return g_banks[i].id;
    if (g_nBanks >= 8 || !file[0]) return -1;
    char p[MAX_PATH]; StrCpy(p, g_bankDir, MAX_PATH); StrCat(p, file, MAX_PATH);
    DWORD n = 0; unsigned char* b = (unsigned char*)ReadWholeFile(p, &n, 0);
    if (!b) { Log("[bank] missing file: ", p); return -1; }
    if (n < 0x60 || b[0] != 'A' || b[1] != 'B' || b[2] != 'K' || b[3] != 'C') { Log("[bank] not an ABKC file: ", p); return -1; }
    g_bankAllocSize = n;
    int id = ((LoadBank_t)A(kLoadBank))(b, 0, 0, (void*)BankAlloc);
    Bank& k = g_banks[g_nBanks++]; StrCpy(k.file, file, 48); k.id = id; k.mem = b;
    LogI("[bank] loaded ", id, file[0] ? "" : "");
    Log("        file ", file);
    return id;
}

struct Obj { DWORD obj; DWORD last; int car; int tries; int type; DWORD scanT; float mn, range; };
static Obj g_objs[32];
static CRITICAL_SECTION g_cs;

struct Inst {
    DWORD obj; int car;
    DWORD hExh, hEng;
    int pExh[100], pEng[100];
    DWORD hTr, hWh; int pTr[9], pWh[9];
    DWORD lastUpd; bool muted;
    volatile LONG busy;
};
static Inst g_in;
static int g_curCar = -1;
static volatile int g_atQuiet = 1, g_atEnabled = 0; static volatile float g_atRpm = 0, g_atThr = 0;   // published by UpdateInst for the auto test
static volatile int g_dbgMuteX = 0, g_dbgMuteE = 0, g_dbgMuteNG = 0; static int g_dbgKeys = 0, g_ownRange = 1;

static int& P(int* blk, int off) { return blk[(off - 4) / 4]; }

static void BuildParams(int* blk, const ColData& X, const ColData& Y, bool forEng)
{
    MemSet(blk, 0, 100 * 4);
    P(blk, 4) = Clamp(forEng ? Y.carId : X.carId, 0, 99);
    P(blk, 52) = 1;
    for (int i = 0; i < 19; ++i) { P(blk, 124 + 4 * i) = Clamp(Y.cf[i], 0, 10000); P(blk, 200 + 4 * i) = Clamp(X.cf[i], 0, 10000); }
    for (int i = 0; i < 8; ++i) { P(blk, 276 + 4 * i) = Clamp(Y.lv[i], 0, 0x7FFF); P(blk, 308 + 4 * i) = Clamp(X.lv[i], 0, 0x7FFF); }
    P(blk, 340) = Clamp(X.rs[0], 0, 0x7FFF);
    for (int i = 1; i < 8; ++i) P(blk, 340 + 4 * i) = Clamp(Y.rs[i], 0, 0x7FFF);
    for (int i = 0; i < 8; ++i) P(blk, 372 + 4 * i) = Clamp(X.rs[i], 0, 0x7FFF);
    P(blk, 56) = -16384; P(blk, 60) = 0x3FFF; P(blk, 108) = -16384; P(blk, 112) = 0x3FFF;
    P(blk, 88) = g_filter; P(blk, 120) = g_filter;
}

static void ReleaseSweets(bool all);
static void ReleaseFx(bool all);
static void ResetHyb();
static void ReleaseInst()
{
    EnterCriticalSection(&g_cs);
    DWORD hx = g_in.hExh, he = g_in.hEng, ht = g_in.hTr, hw = g_in.hWh;
    g_in.hExh = g_in.hEng = g_in.hTr = g_in.hWh = 0; g_in.obj = 0;
    LeaveCriticalSection(&g_cs);

    while (g_in.busy) Sleep(0);
    if (hx) ((Release_t)A(kCsisRelease))(hx, 0);
    if (he) ((Release_t)A(kCsisRelease))(he, 0);
    if (ht) ((Release_t)A(kCsisRelease))(ht, 0);
    if (hw) ((Release_t)A(kCsisRelease))(hw, 0);
    ReleaseSweets(true);
    ReleaseFx(true);
    ResetHyb();
    if (hx || he) Log("[instance] beta engine sound stopped");
}

static const ColData* ColX(int car) { int i = g_swap ? g_cars[car].eng : g_cars[car].exh; return i >= 0 ? &g_cols[i] : 0; }
static const ColData* ColY(int car) { int i = g_swap ? g_cars[car].exh : g_cars[car].eng; return i >= 0 ? &g_cols[i] : 0; }

// create CAR / CAR_ENG (and optional CAR_TRANNY / CAR_WHINE) instances for the player car
static bool StartInst(DWORD obj, int car)
{
    if (!EnsureLib()) return false;
    const ColData* X = ColX(car); const ColData* Y = ColY(car);
    if (!X && !Y) return false;
    if (!X) X = Y; if (!Y) Y = X;
    if (g_curCar != car) {
        UnloadBanks();
        LoadBank(X->bank);
        if (!StrIEq(X->bank, Y->bank)) LoadBank(Y->bank);
        if (g_sweetVol > 0) {
            char sw[48] = "SWTN_CAR_", t[16]; int id = Clamp(X->carId, 0, 99);
            if (id < 10) StrCat(sw, "0", 48); IToStr(id, t); StrCat(sw, t, 48); StrCat(sw, "_MB.abk", 48);
            LoadBank(sw);
        }
        if (g_cars[car].gears && g_trVol > 0 && !g_trOwn) LoadBank("car_tranny.abk");
        if (g_cars[car].gears && g_whVol > 0 && !g_whOwn) LoadBank("car_whine_00.abk");
        g_dbgMuteX = g_dbgMuteE = g_dbgMuteNG = 0;   // debug keys: back to normal on every car change
        g_fxBank = -1; g_curShift = -1;
        if (g_fxOn && EnsureFxLib()) {
            for (int i = 0; i < g_nShifts; ++i) if (g_shifts[i].key == g_cars[car].key) { g_curShift = i; break; }
            // cars without their own shift bank (e.g. [Cars] overrides such as the Aventador): use the shift bank of a
            // car with the same engine/exhaust collections, otherwise the generic GEAR_SML_Base, so every gear
            // change has its shift sound (the 2015 shift sound is disabled for these cars)
            if (g_curShift < 0) {
                for (int c = 0; c < g_nCars && g_curShift < 0; ++c) {
                    if (c == car || g_cars[c].exh != g_cars[car].exh || g_cars[c].eng != g_cars[car].eng) continue;
                    for (int i = 0; i < g_nShifts; ++i) if (g_shifts[i].key == g_cars[c].key) { g_curShift = i; break; }
                }
                for (int i = 0; i < g_nShifts && g_curShift < 0; ++i) if (StrIEq(g_shifts[i].bank, "GEAR_SML_Base.abk")) g_curShift = i;
                if (g_curShift < 0 && g_nShifts > 0) g_curShift = 0;
                if (g_curShift >= 0) Log("       no own shift bank: using ", g_shifts[g_curShift].bank);
            }
            if (g_curShift >= 0) { g_fxBank = LoadBank(g_shifts[g_curShift].bank); }
        }
        g_curCar = car;
        Log("[car] ", g_cars[car].name[0] ? g_cars[car].name : "(unnamed)", "  exhaust=", X->name);
        Log("       engine=", Y->name);
        if (g_curShift >= 0) Log("       shift=", g_shifts[g_curShift].bank, g_fxBank > 0 ? "" : " (bank NOT loaded)");
    }
    Inst& s = g_in;
    BuildParams(s.pExh, *X, *Y, false);
    BuildParams(s.pEng, *X, *Y, true);
    DWORD hx = 0, he = 0;
    int embBefore = CountList(kGListEmb), intBefore = CountList(kGListInt);
    if (!g_descCar[0]) { int r = ((Register_t)A(kCsisRegister))(g_descCar, 0, &g_entCar); if (r) { LogI("[csis] CAR class not found, result ", r); g_descCar[0] = 0; } }
    if (!g_descEng[0]) { int r = ((Register_t)A(kCsisRegister))(g_descEng, 0, &g_entEng); if (r) { g_descEng[0] = 0; } }
    if (g_descCar[0]) { int r = ((Create_t)A(kCsisCreate))(g_descCar, s.pExh, &hx); if (r) { LogI("[instance] CAR not created, result ", r); hx = 0; } }
    if (g_descEng[0]) { int r = ((Create_t)A(kCsisCreate))(g_descEng, s.pEng, &he); if (r) { he = 0; } }

    DWORD ht = 0, hw = 0;
    if (g_cars[car].gears && g_trVol > 0 && !g_trOwn) {
        if (!g_descTr[0] && ((Register_t)A(kCsisRegister))(g_descTr, 0, &g_entTr)) g_descTr[0] = 0;
        MemSet(s.pTr, 0, sizeof(s.pTr)); s.pTr[0] = Clamp(X->carId, 0, 60); s.pTr[5] = 25000; s.pTr[7] = 0x7FFF;
        if (g_descTr[0] && ((Create_t)A(kCsisCreate))(g_descTr, s.pTr, &ht)) ht = 0;
    }
    if (g_cars[car].gears && g_whVol > 0 && !g_whOwn) {
        if (!g_descWh[0] && ((Register_t)A(kCsisRegister))(g_descWh, 0, &g_entWh)) g_descWh[0] = 0;
        MemSet(s.pWh, 0, sizeof(s.pWh)); s.pWh[6] = 25000; s.pWh[8] = 0x7FFF;
        if (g_descWh[0] && ((Create_t)A(kCsisCreate))(g_descWh, s.pWh, &hw)) hw = 0;
    }
    Log("          CAR_TRANNY ", ht ? "OK" : "-", "   CAR_WHINE ", hw ? "OK" : "-");
    EnterCriticalSection(&g_cs);
    s.obj = obj; s.car = car; s.hExh = hx; s.hEng = he; s.hTr = ht; s.hWh = hw; s.lastUpd = GetTickCount(); s.muted = false;
    LeaveCriticalSection(&g_cs);
    { char b[160] = "[instance] old modules running: before ", t[16]; IToStr(embBefore, t); StrCat(b, t, 160); StrCat(b, " after ", 160); IToStr(CountList(kGListEmb), t); StrCat(b, t, 160);
      StrCat(b, "  (new modules: before ", 160); IToStr(intBefore, t); StrCat(b, t, 160); StrCat(b, " after ", 160); IToStr(CountList(kGListInt), t); StrCat(b, t, 160); StrCat(b, ")", 160); Log(b); }
    LogH("[instance] created for object ", obj, hx || he ? "" : "  (no module: no sound)");
    Log("          CAR (exhaust) ", hx ? "OK" : "-", "   CAR_ENG (engine) ", he ? "OK" : "-");
    return hx || he;
}

static int g_hits[32]; static int g_nHits;
static void AddHit(int c) { for (int i = 0; i < g_nHits; ++i) if (g_hits[i] == c) return; if (g_nHits < 32) g_hits[g_nHits++] = c; }
static void ScanKey(DWORD base, int bytes, int depth)
{
    if (!Readable((void*)base, bytes)) return;
    for (int o = 0; o < bytes; o += 4) { int c = FindCar(*(DWORD*)(base + o)); if (c >= 0) AddHit(c); }
    if (depth <= 0) return;
    for (int o = 0; o < bytes; o += 4) {
        DWORD w = *(DWORD*)(base + o);
        if (w < 0x10000 || (w & 3)) continue;
        ScanKey(w, depth == 2 ? 64 : 48, depth - 1);
    }
}

static int Depth(int c) { int d = 0; DWORD p = g_cars[c].parent; while (p && d < 16) { ++d; int i = FindCar(p); if (i < 0) break; p = g_cars[i].parent; } return d; }
static int Pick()
{
    int best = -1, bd = -1;
    for (int i = 0; i < g_nHits; ++i) if (g_cars[g_hits[i]].src == 3) return g_hits[i];
    for (int i = 0; i < g_nHits; ++i) { int d = Depth(g_hits[i]); if (d > bd) { bd = d; best = g_hits[i]; } }
    return best;
}

static int g_keyOff = -1;

// active caraudio collection key of an engine object
static DWORD ActiveKey(DWORD obj)
{
    DWORD o28 = *(DWORD*)(obj + 28);
    if (!o28 || !Readable((void*)(o28 + 148), 4)) return 0;
    DWORD inst = *(DWORD*)(o28 + 148);
    if (!inst || !Readable((void*)inst, 8)) return 0;
    DWORD coll = *(DWORD*)inst;
    if (!coll || !Readable((void*)coll, 64)) return 0;
    if (g_keyOff >= 0) { DWORD k = *(DWORD*)(coll + g_keyOff); return FindCar(k) >= 0 ? k : 0; }
    static const int offs[] = { 36, 32, 40, 28, 44, 24, 20, 16, 48 };
    for (int i = 0; i < 9; ++i) { DWORD k = *(DWORD*)(coll + offs[i]); if (FindCar(k) >= 0) { g_keyOff = offs[i]; LogI("[car] active caraudio key at offset ", offs[i], " of the collection"); return k; } }
    return 0;
}
// map the engine object to a car in the .dat
static int IdentifyCar(DWORD obj)
{
    { DWORD k = ActiveKey(obj); int c = k ? FindCar(k) : -1; if (c >= 0) return c; }
    DWORD car = *(DWORD*)(obj + 24);
    DWORD st = Readable((void*)(car + 52), 4) ? *(DWORD*)(car + 52) : 0;
    DWORD o28 = *(DWORD*)(obj + 28);
    g_nHits = 0;
    if (o28 && Readable((void*)(o28 + 148), 4)) ScanKey(*(DWORD*)(o28 + 148), 64, 2);
    if (!g_nHits && st) ScanKey(st + 640, 128, 2);
    if (!g_nHits && st) ScanKey(st, 0x300, 2);
    if (!g_nHits && o28) ScanKey(o28, 0x100, 2);
    if (!g_nHits && car) ScanKey(car, 0x100, 2);
    if (!g_nHits) ScanKey(obj, 0x470, 2);
    if (g_nHits > 1) {
        char b[256] = "[car] keys found:", t[16];
        for (int i = 0; i < g_nHits && i < 12; ++i) { StrCat(b, " ", 256); StrCat(b, g_cars[g_hits[i]].name[0] ? g_cars[g_hits[i]].name : "", 256); HexStr(g_cars[g_hits[i]].key, t); StrCat(b, "/", 256); StrCat(b, t, 256); }
        Log(b);
    }
    return Pick();
}

// ---- player engine state (rpm, throttle, rpm range)
static bool ReadEngine(DWORD obj, float* rpm, float* thr, float* mn, float* range)
{
    DWORD p = *(DWORD*)(obj + 60);
    if (!p || !Readable((void*)(p + 28), 4)) return false;
    float* q = *(float**)(p + 28);
    if (!q || !Readable(q, 20)) return false;
    *rpm = q[0]; *thr = q[2]; *mn = *(float*)(obj + 888); *range = *(float*)(obj + 892);
    return true;
}

static short* g_trS[2]; static int g_trLen[2];
static volatile float g_trTgtN = 0, g_trTgtVol = 0;
static volatile DWORD g_trUpd = 0;
static float g_trPMin = 0.4f, g_trPMax = 1.4f;
static bool LoadRaw(int i, const char* name)
{
    char p[MAX_PATH]; StrCpy(p, g_bankDir, MAX_PATH); StrCat(p, name, MAX_PATH);
    DWORD n = 0; short* d = (short*)ReadWholeFile(p, &n, 0);
    if (!d || n < 1000) { Log("[transmission] missing file: ", p); return false; }
    g_trS[i] = d; g_trLen[i] = (int)(n / 2); return true;
}

// ---- own transmission whine player (waveOut)
static DWORD WINAPI TrannyThread(LPVOID)
{
    if (!LoadRaw(0, "tranny_1.raw") || !LoadRaw(1, "tranny_2.raw")) return 0;
    WAVEFORMATEX wf = { 1, 1, 44100, 88200, 2, 16, 0 };
    HWAVEOUT wo = 0;
    if (waveOutOpen(&wo, 0xFFFFFFFF , &wf, 0, 0, 0)) { Log("[transmission] audio output not available"); return 0; }
    const int N = 882; static short buf[4][882]; static WAVEHDR hd[4];
    for (int i = 0; i < 4; ++i) { MemSet(&hd[i], 0, sizeof(WAVEHDR)); MemSet(buf[i], 0, sizeof(buf[i])); hd[i].lpData = (LPSTR)buf[i]; hd[i].dwBufferLength = N * 2; waveOutPrepareHeader(wo, &hd[i], sizeof(WAVEHDR)); hd[i].dwFlags |= 1 ; }
    Log("[transmission] own player started");
    float pos[2] = { 0, 0 }, n = 0, vol = 0;
    for (;;) {
        for (int b = 0; b < 4; ++b) {
            if (!(hd[b].dwFlags & 1)) continue;
            float tn = g_trTgtN, tv = g_trTgtVol;
            if (GetTickCount() - g_trUpd > 300) tv = 0;
            for (int i = 0; i < N; ++i) {
                n += (tn - n) * 0.004f; vol += (tv - vol) * 0.002f;
                float pitch = g_trPMin + (g_trPMax - g_trPMin) * n;
                float o = 0;
                for (int k = 0; k < 2; ++k) {
                    int len = g_trLen[k]; int ip = (int)pos[k]; float fr = pos[k] - ip; int ip2 = ip + 1 >= len ? 0 : ip + 1;
                    float smp = g_trS[k][ip] + (g_trS[k][ip2] - g_trS[k][ip]) * fr;
                    o += smp * (k == 0 ? 1.0f - n : n);
                    pos[k] += pitch; while (pos[k] >= len) pos[k] -= len;
                }
                o *= vol; if (o > 32767) o = 32767; if (o < -32768) o = -32768;
                buf[b][i] = (short)o;
            }
            hd[b].dwFlags &= ~1u;
            waveOutWrite(wo, &hd[b], sizeof(WAVEHDR));
        }
        Sleep(5);
    }
}

static short* g_whS[3]; static int g_whLen[3]; static float g_whRate[3];
static volatile float g_whKmh = 0, g_whTgtVol = 0; static volatile int g_whGear = 2; static volatile DWORD g_whUpd = 0, g_whCutUntil = 0;
static int g_whCutMs = 220, g_prevGear = -1; static float g_whL2 = 0.5f, g_whRev = 1.67f, g_whPScale = 1.0f, g_whTopP = 330.0f;

// ---- straight-cut gear whine player (WorldWhineGen style)
static bool LoadWav(int i, const char* name)
{
    char p[MAX_PATH]; StrCpy(p, g_bankDir, MAX_PATH); StrCat(p, "whine\\", MAX_PATH); StrCat(p, name, MAX_PATH);
    DWORD n = 0; unsigned char* d = (unsigned char*)ReadWholeFile(p, &n, 0);
    if (!d || n < 44 || *(DWORD*)d != 0x46464952) { Log("[gears] missing or invalid file: ", p); return false; }
    DWORD q = 12, rate = 0; int ch = 0, bits = 0;
    while (q + 8 <= n) {
        DWORD id = *(DWORD*)(d + q), sz = *(DWORD*)(d + q + 4);
        if (id == 0x20746D66) { ch = *(WORD*)(d + q + 10); rate = *(DWORD*)(d + q + 12); bits = *(WORD*)(d + q + 22); }
        if (id == 0x61746164) {
            if (ch != 1 || bits != 16 || !rate) { Log("[gears] unsupported format (16 bit mono PCM required): ", p); return false; }
            if (q + 8 + sz > n) sz = n - q - 8;
            g_whS[i] = (short*)(d + q + 8); g_whLen[i] = (int)(sz / 2); g_whRate[i] = (float)rate / 48000.0f; return g_whLen[i] > 100;
        }
        q += 8 + sz + (sz & 1);
    }
    Log("[gears] no audio data: ", p); return false;
}
static float SqrtF(float r) { if (r <= 0) return 0; float g = r > 1 ? r / 2 : 1; for (int i = 0; i < 14; ++i) g = 0.5f * (g + r / g); return g; }

// current gear (0 = reverse)
static int ReadGear()
{
    DWORD a = *(DWORD*)A(0x00DCF280); if (!a || !Readable((void*)(a + 0x3C), 4)) return -1;
    DWORD b = *(DWORD*)(a + 0x3C); if (!b || !Readable((void*)(b + 0x838), 4)) return -1;
    int g = *(int*)(b + 0x838); return (g >= 0 && g < 12) ? g : -1;
}

// pitch = 0.3 + 0.7*kmh/330 + min(0.6, 0.5*sqrt(kmh/70)); muted on upshift
static DWORD WINAPI WhineThread(LPVOID)
{
    if (!LoadWav(0, "car_whine.wav") || !LoadWav(1, "car_whine_2.wav")) return 0;
    bool rev = LoadWav(2, "car_whine_reverse.wav");
    WAVEFORMATEX wf = { 1, 1, 48000, 96000, 2, 16, 0 };
    HWAVEOUT wo = 0;
    if (waveOutOpen(&wo, 0xFFFFFFFF, &wf, 0, 0, 0)) { Log("[gears] audio output not available"); return 0; }
    const int N = 480; static short buf[4][480]; static WAVEHDR hd[4];
    for (int i = 0; i < 4; ++i) { MemSet(&hd[i], 0, sizeof(WAVEHDR)); MemSet(buf[i], 0, sizeof(buf[i])); hd[i].lpData = (LPSTR)buf[i]; hd[i].dwBufferLength = N * 2; waveOutPrepareHeader(wo, &hd[i], sizeof(WAVEHDR)); hd[i].dwFlags |= 1; }
    Log("[gears] own player started (car_whine)");
    float pos[3] = { 0, 0, 0 }, pitch = 0.3f, vol = 0, env = 1, gOff = 0, fwd = 1;
    for (;;) {
        for (int b = 0; b < 4; ++b) {
            if (!(hd[b].dwFlags & 1)) continue;
            DWORD now = GetTickCount();
            float kmh = g_whKmh, tv = g_whTgtVol; int gear = g_whGear;
            if (now - g_whUpd > 300) tv = 0;

            float tgo = gear > 1 ? (gear - 1) * 0.01f : 0.0f;
            float tp = 0.3f;
            if (kmh >= 1.0f) { float s2 = 0.5f * SqrtF(kmh / 70.0f); if (s2 > 0.6f) s2 = 0.6f; tp = 0.3f + 0.7f * kmh / g_whTopP + s2; }
            tp *= g_whPScale;
            float tf = gear == 0 ? 0.0f : 1.0f;
            float te = (now < g_whCutUntil) ? 0.0f : 1.0f;
            float l2 = g_whL2 * kmh / 140.0f; if (l2 > 2 * g_whL2) l2 = 2 * g_whL2;
            for (int i = 0; i < N; ++i) {
                gOff += (tgo - gOff) * 0.00005f;
                pitch += (tp + gOff - pitch) * 0.002f;
                vol += (tv - vol) * 0.0005f;
                fwd += (tf - fwd) * 0.001f;
                if (te < env) { env -= 1.0f / 4800.0f; if (env < 0) env = 0; }
                else if (te > env) { env += 1.0f / 1440.0f; if (env > 1) env = 1; }
                float o = 0;

                float st[3] = { pitch * g_whRate[0], g_whRate[1], pitch * g_whRate[2] };
                float gk[3] = { fwd, fwd * l2, (1.0f - fwd) * g_whRev };
                for (int k = 0; k < 3; ++k) {
                    if (k == 2 && !rev) continue;
                    int len = g_whLen[k]; int ip = (int)pos[k]; float fr = pos[k] - ip; int ip2 = ip + 1 >= len ? 0 : ip + 1;
                    if (gk[k] > 0.0001f) o += (g_whS[k][ip] + (g_whS[k][ip2] - g_whS[k][ip]) * fr) * gk[k];
                    pos[k] += st[k]; while (pos[k] >= len) pos[k] -= len;
                }
                o *= vol * env; if (o > 32767) o = 32767; if (o < -32768) o = -32768;
                buf[b][i] = (short)o;
            }
            hd[b].dwFlags &= ~1u;
            waveOutWrite(wo, &hd[b], sizeof(WAVEHDR));
        }
        Sleep(4);
    }
}

// ---- NFS MW tvr_cerb sweeteners for the BMW M3 (samples missing in Carbon)
static bool ParseWav(const char* p, short** s, int* len, float* rate)
{
    DWORD n = 0; unsigned char* d = (unsigned char*)ReadWholeFile(p, &n, 0);
    if (!d || n < 44 || *(DWORD*)d != 0x46464952) return false;
    DWORD q = 12, rt = 0; int ch = 0, bits = 0;
    while (q + 8 <= n) {
        DWORD id = *(DWORD*)(d + q), sz = *(DWORD*)(d + q + 4);
        if (id == 0x20746D66) { ch = *(WORD*)(d + q + 10); rt = *(DWORD*)(d + q + 12); bits = *(WORD*)(d + q + 22); }
        if (id == 0x61746164) {
            if (ch != 1 || bits != 16 || !rt) return false;
            if (q + 8 + sz > n) sz = n - q - 8;
            *s = (short*)(d + q + 8); *len = (int)(sz / 2); *rate = (float)rt / 48000.0f; return *len > 10;
        }
        q += 8 + sz + (sz & 1);
    }
    return false;
}
static short* g_mwS[13]; static int g_mwLen[13]; static float g_mwRate[13];
struct MwVoice { volatile int smp; float pos, vol; };
static MwVoice g_mwV[8];
static volatile int g_mwReady = 0; static int g_mwOn = 1;
static float g_mwVol = 1.2f; static DWORD g_mwEngageAt = 0;
static int g_mwShift[6] = { 2, 0 }, g_mwEngage[6] = { 1, 4, 0 }, g_mwLift[6] = { 8, 0 };
static DWORD g_mwSeed = 12345;
static void ParseList(const char* sec, const char* key, const char* def, int* out)
{
    char b[64]; GetPrivateProfileStringA(sec, key, def, b, 64, g_ini);
    int n = 0, v = 0, has = 0;
    for (int i = 0; ; ++i) {
        char c = b[i];
        if (c >= '0' && c <= '9') { v = v * 10 + (c - '0'); has = 1; }
        else { if (has && v >= 1 && v <= 12 && n < 5) out[n++] = v; v = 0; has = 0; if (!c) break; }
    }
    out[n] = 0;
}
static void PlayMw(const int* list, float vol)
{
    if (!g_mwReady || vol <= 0) return;
    int n = 0; while (list[n]) ++n; if (!n) return;
    g_mwSeed = g_mwSeed * 1103515245u + 12345u;
    int smp = list[(g_mwSeed >> 16) % (DWORD)n];
    if (!g_mwS[smp]) return;
    static int lg = 0; if (lg < 40) { ++lg; char t[16], b[64] = "[sweet MW] campione "; IToStr(smp, t); StrCat(b, t, 64); StrCat(b, " volume% ", 64); IToStr((int)(vol * 100), t); StrCat(b, t, 64); Log(b); }
    for (int i = 0; i < 8; ++i) if (!g_mwV[i].smp) { g_mwV[i].pos = 0; g_mwV[i].vol = vol; g_mwV[i].smp = smp; return; }
}

// one-shot sample mixer (waveOut)
static DWORD WINAPI MwSweetThread(LPVOID)
{
    int ok = 0;
    for (int i = 1; i <= 12; ++i) {
        char p[MAX_PATH], t[8]; StrCpy(p, g_bankDir, MAX_PATH); StrCat(p, "mw_m3\\swtn66_", MAX_PATH);
        if (i < 10) StrCat(p, "0", MAX_PATH); IToStr(i, t); StrCat(p, t, MAX_PATH); StrCat(p, ".wav", MAX_PATH);
        if (ParseWav(p, &g_mwS[i], &g_mwLen[i], &g_mwRate[i])) ++ok;
    }
    if (!ok) { Log("[sweet MW] samples missing in mw_m3\\ (Most Wanted sweeteners disabled)"); return 0; }
    WAVEFORMATEX wf = { 1, 1, 48000, 96000, 2, 16, 0 };
    HWAVEOUT wo = 0;
    if (waveOutOpen(&wo, 0xFFFFFFFF, &wf, 0, 0, 0)) { Log("[sweet MW] audio output not available"); return 0; }
    const int N = 480; static short buf[4][480]; static WAVEHDR hd[4];
    for (int i = 0; i < 4; ++i) { MemSet(&hd[i], 0, sizeof(WAVEHDR)); MemSet(buf[i], 0, sizeof(buf[i])); hd[i].lpData = (LPSTR)buf[i]; hd[i].dwBufferLength = N * 2; waveOutPrepareHeader(wo, &hd[i], sizeof(WAVEHDR)); hd[i].dwFlags |= 1; }
    g_mwReady = 1;
    { char t[8]; IToStr(ok, t); Log("[sweet MW] Most Wanted M3 sweeteners ready, samples: ", t); }
    for (;;) {
        for (int b = 0; b < 4; ++b) {
            if (!(hd[b].dwFlags & 1)) continue;
            for (int i = 0; i < N; ++i) {
                float o = 0;
                for (int v = 0; v < 8; ++v) {
                    int k = g_mwV[v].smp; if (!k) continue;
                    int ip = (int)g_mwV[v].pos;
                    if (ip + 1 >= g_mwLen[k]) { g_mwV[v].smp = 0; continue; }
                    float fr = g_mwV[v].pos - ip;
                    o += (g_mwS[k][ip] + (g_mwS[k][ip + 1] - g_mwS[k][ip]) * fr) * g_mwV[v].vol;
                    g_mwV[v].pos += g_mwRate[k];
                }
                if (o > 32767) o = 32767; if (o < -32768) o = -32768;
                buf[b][i] = (short)o;
            }
            hd[b].dwFlags &= ~1u;
            waveOutWrite(wo, &hd[b], sizeof(WAVEHDR));
        }
        Sleep(4);
    }
}

struct Sweet { DWORD h; DWORD t; int p[7]; };
static Sweet g_sw[6];
static float g_hist[16]; static DWORD g_histT[16]; static int g_histI = 0;
static float g_prevThr = 0; static DWORD g_lastSweet = 0;

static int g_shiftCut = 1; static DWORD g_cutMs = 90, g_cutUntil = 0; static float g_cutDuck = 0.55f, g_cutDrop = 0.025f;
static DWORD g_engageAt = 0; static float g_engageN = 0;
static int g_slideFrom = 0, g_prevGameRpm = 0, g_m3Slide = 1, g_rpmLogN = 0, g_rpmLogK = 0, g_rpmLogV[40]; static DWORD g_rpmLogT = 0; static float g_m3DropRatio = 0.87f; static int g_m3HoldMax = 1500;
static int g_m3EngageSw = 0; static float g_m3FxVol = 0.25f;
static DWORD g_resumeUntil = 0, g_m3CutMs = 180; static int g_m3ResumeMs = 600; static float g_m3CutDuck = 0.5f, g_m3Boost = 1.4f;
static float g_cH[16], g_cT2[16]; static DWORD g_cT[16]; static int g_cI = 0;
static float g_vzPrev = 0, g_azLast = 0, g_airAcc = 6.0f, g_bumpAcc = 15.0f; static long long g_vzT = 0; static DWORD g_fallT = 0, g_airUntil = 0, g_airHold = 700; static int g_upAxis = 2;
static void ReleaseSweets(bool all)
{
    DWORD now = GetTickCount();
    for (int i = 0; i < 6; ++i) if (g_sw[i].h && (all || now - g_sw[i].t > 6000)) { DWORD h = g_sw[i].h; g_sw[i].h = 0; ((Release_t)A(kCsisRelease))(h, 0); }
}
static bool g_mwLiftFlag = false;

// ---- beta CAR_SWTN sweeteners (Carbon CARSFX_Shift): [type, carId, rpm, vol, mix, 0, 0]
static void FireSweet(int type, int rpm, const ColData* X, float mix)
{
    if (g_sweetVol <= 0) return;
    if (g_mwOn && g_mwLiftFlag && g_curCar >= 0 && g_cars[g_curCar].gears) PlayMw(g_mwLift, g_mwVol * g_sweetVol * mix);
    g_mwLiftFlag = false;
    if (!g_descSw[0]) { int r = ((Register_t)A(kCsisRegister))(g_descSw, 0, &g_entSw); if (r) { g_descSw[0] = 0; Log("[sweet] CAR_SWTN class not found"); g_sweetVol = 0; return; } }
    Sweet* s = 0;
    for (int i = 0; i < 6; ++i) if (!g_sw[i].h) { s = &g_sw[i]; break; }
    if (!s) return;
    s->p[0] = type; s->p[1] = Clamp(X->carId, 0, 100); s->p[2] = Clamp(rpm, 0, 10000);
    s->p[3] = Clamp((int)(X->volShift * g_sweetVol * mix), 0, 32787); s->p[4] = g_mix64 > 0 ? Clamp(g_mix64, 0, 0x10000) : 0; s->p[5] = 0; s->p[6] = 0;
    DWORD h = 0;
    int r = ((Create_t)A(kCsisCreate))(g_descSw, s->p, &h);
    if (r == 0 && h) { s->h = h; s->t = GetTickCount(); }
    char b[96] = "[sweet] type ", t[16]; IToStr(type, t); StrCat(b, t, 96); StrCat(b, " rpm ", 96); IToStr(rpm, t); StrCat(b, t, 96);
    StrCat(b, r == 0 ? " OK" : " errore", 96); Log(b);
}
static volatile int g_shiftEvt = 0, g_shiftFlags = 0; static volatile DWORD g_rawShiftEvt = 0; static int g_fxGear = -1; static DWORD g_gearChangeAt = 0; static int g_fxType = -1; static DWORD g_lastShiftEvt = 0, g_liftAt = 0; static int g_liftRpm = 0, g_shiftEvents = 1;
struct FxInst { DWORD h; DWORD t; int p[6]; };
static FxInst g_fx[4];
static void ReleaseFx(bool all)
{
    DWORD now = GetTickCount();
    for (int i = 0; i < 4; ++i) if (g_fx[i].h && (all || now - g_fx[i].t > 1500)) { DWORD h = g_fx[i].h; g_fx[i].h = 0; ((Release_t)A(kCsisRelease))(h, 0); }
}

// Carbon FX_SHIFTING_01 shift sound: [type, vol, 4096, mix, 0, flag]
static void PlayShiftFx(float mix)
{
    if (!g_fxOn || g_fxBank <= 0 || g_curShift < 0 || mix <= 0) return;
    if (!g_descFx[0]) { int r = ((Register_t)A(kCsisRegister))(g_descFx, 0, &g_entFx); if (r) { g_descFx[0] = 0; LogI("[shift] FX_SHIFTING_01 class not found, result ", r); g_fxOn = 0; return; } }
    FxInst* f = 0; for (int i = 0; i < 4; ++i) if (!g_fx[i].h) { f = &g_fx[i]; break; }
    if (!f) { ReleaseFx(true); f = &g_fx[0]; }
    f->p[0] = g_fxType >= 0 ? g_fxType : (g_shiftFlags & 1); f->p[1] = Clamp((int)(g_shifts[g_curShift].volB * g_fxVol * mix), 0, 0x7FFF); f->p[2] = 4096; f->p[3] = 0x7FFF; f->p[4] = 0; f->p[5] = 1;
    DWORD h = 0; int r = ((Create_t)A(kCsisCreate))(g_descFx, f->p, &h);
    if (r == 0 && h) { f->h = h; f->t = GetTickCount(); }
    static int lg = 0; if (lg < 300) { ++lg; char t[16]; char b2[200] = ") type "; IToStr(f->p[0], t); StrCat(b2, t, 200);
        StrCat(b2, " flags ", 200); IToStr(g_shiftFlags, t); StrCat(b2, t, 200); StrCat(b2, " vol ", 200); IToStr(f->p[1], t); StrCat(b2, t, 200);
        StrCat(b2, " gear ", 200); IToStr(ReadGear(), t); StrCat(b2, t, 200); StrCat(b2, " slot ", 200); IToStr((int)(f - g_fx), t); StrCat(b2, t, 200);
        StrCat(b2, " result ", 200); IToStr(r, t); StrCat(b2, t, 200); StrCat(b2, r == 0 && h ? " OK" : " errore", 200); Log("[shift] Carbon FX_SHIFTING_01 (", g_shifts[g_curShift].bank, b2); }
}

// throttle-lift sweetener detection
static void CheckSweets(float n, float thr, int bRpmNow, const ColData* X, float mix)
{
    DWORD now = GetTickCount();
    g_hist[g_histI] = n; g_histT[g_histI] = now; g_histI = (g_histI + 1) & 15;
    float mx = n; for (int i = 0; i < 16; ++i) if (now - g_histT[i] < 120 && g_hist[i] > mx) mx = g_hist[i];
    static float thrH[16]; static DWORD thrT[16]; static int ti = 0; thrH[ti] = thr; thrT[ti] = now; ti = (ti + 1) & 15;
    float tmx = thr; for (int i = 0; i < 16; ++i) if (now - thrT[i] < 400 && thrH[i] > tmx) tmx = thrH[i];
    if (now - g_lastSweet > 500 && mix > 0) {
        float span = X->maxRpm - X->minRpm;
        if (!g_shiftEvents && mx - n > 0.03f && mx >= g_sweetThr && tmx > 0.5f) { FireSweet(0, (int)(mx * span + X->minRpm), X, mix); g_lastSweet = now; for (int i = 0; i < 16; ++i) g_hist[i] = 0; }
        else if (tmx > 0.7f && thr < 0.15f && n >= g_sweetThr) {
            if (g_shiftEvents) { if (!g_liftAt && now - g_lastShiftEvt > 400) { g_liftAt = now + 200; g_liftRpm = bRpmNow; } }
            else FireSweet(1, bRpmNow, X, mix);
            g_lastSweet = now;
        }
    }
    g_prevThr = thr;
    ReleaseSweets(false);
}

static int g_carbonMix = 1, g_p104 = 1, g_single = 1, g_ignoreW = 1;
static float g_ginScale = 1.0f, g_aemsScale = 1.0f, g_rpmTau = 0.06f, g_outTau = 0.05f, g_limN = 0.93f;
static int g_limHold = 1, g_fixColl = 1;
struct HybState { bool init; float prev, rs, dl[4]; int di; float m47, m48, m49; float v52, v56, v60, v112; float accF, decF, c, t; };
static HybState g_hx, g_he;
static volatile float g_gEng = 1.0f, g_gExh = 1.0f; static volatile int g_ginOn = 0, g_ginMute = 0;
static long long g_qf = 0, g_qPrev = 0;

// ---- Carbon SFXCTL_HybridNGEngine mix (disabled by default)
static float Curve(const HybPar& h, float x)
{
    float span = (float)(h.decMax - h.decMin);
    float px[5] = { 0.0f, (float)h.decMin, (float)h.decMin + span * h.fadeOut, (float)h.decMax - span * h.fadeIn, (float)h.decMax };
    float py[5] = { 0, 0, 1, 1, 0 };
    if (x <= px[0]) return py[0];
    if (x >= px[4]) return py[4];
    for (int i = 0; i < 4; ++i) if (x >= px[i] && x < px[i + 1]) {
        float w = px[i + 1] - px[i];
        if (w <= 1e-6f && w >= -1e-6f) return (py[i + 1] - py[i]) * 0.5f + py[i];
        return (py[i + 1] - py[i]) * ((x - px[i]) / w) + py[i];
    }
    return py[0];
}
static float Cl01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
static float Slew(float cur, float tgt, float step) { if (tgt > cur + step) return cur + step; if (tgt < cur - step) return cur - step; return tgt; }
static void HybUpdate(HybState& st, const ColData& C, float n, float thr, float fs)
{
    const HybPar& h = C.h;
    float rpm = n * (C.maxRpm - C.minRpm) + C.minRpm;
    if (!st.init) { MemSet(&st, 0, sizeof(st)); st.init = true; st.prev = rpm; st.rs = rpm; st.m47 = 1.0f; }

    float dt = fs / 60.0f, a1 = g_rpmTau > 0 ? dt / (g_rpmTau + dt) : 1.0f;
    st.rs += (rpm - st.rs) * a1;
    float d = (st.rs - st.prev) / (fs > 0.05f ? fs : 0.05f);
    st.prev = st.rs;
    if (g_limHold && thr > 0.8f && n > g_limN) d = 0;
    st.dl[st.di] = d; st.di = (st.di + 1) & 3;
    float sd = (st.dl[0] + st.dl[1] + st.dl[2] + st.dl[3]) * 0.25f;
    float a = sd + 10.0f; if (a < 0) a = -a;
    st.accF = h.accThr > 0 ? Cl01(1.0f - (h.accThr - a) / h.accThr) : 0;
    st.decF = h.decThr > 0 ? Cl01(1.0f - (h.decThr - a) / h.decThr) : 0;
    float v82 = (h.aMixL - h.aMixS) * st.accF + h.aMixS;
    float v83 = (h.gMixL - h.gMixS) * st.accF + h.gMixS;
    float v72 = (h.dAMixL - h.dAMixS) * st.decF + h.dAMixS;
    float v76 = (h.dGMixL - h.dGMixS) * st.decF + h.dGMixS;
    float v74 = (h.gNegL - h.gNegS) * st.decF + h.gNegS;
    st.c = Curve(h, rpm);
    float v73 = (1.0f - st.c) + st.c * v72, v77 = st.c * v76, v75 = st.c * v74;
    st.t = Cl01(thr * 100.0f / 35.0f);
    float m47 = (v82 - v73) * st.t + v73, m48 = (v83 - v75) * st.t + v75, m49 = -v77 * st.t + v77;
    float k = 0.2f * fs;
    st.m47 = Slew(st.m47, m47, k); st.m48 = Slew(st.m48, m48, k); st.m49 = Slew(st.m49, m49, k);
    float av = (float)h.decAemsVol + (float)(h.aemsVol - h.decAemsVol) * st.t;
    float kv = 7000.0f * fs;
    float ao = g_outTau > 0 ? dt / (g_outTau + dt) : 1.0f;
    st.v52 += (Slew(st.v52, av * st.m47, kv) - st.v52) * ao;
    st.v56 += (Slew(st.v56, (float)h.ginAccVol * st.m48, kv) - st.v56) * ao;
    st.v60 += (Slew(st.v60, (float)h.ginDecVol * st.m49, kv) - st.v60) * ao;
    st.v112 = (float)h.aemsVol;
}
static void ResetHyb() { g_ginOn = 0; g_hx.init = g_he.init = false; g_qPrev = 0; }

typedef int (__fastcall* Ng823130_t)(DWORD self, DWORD edx, float* eng, float* exh, float a5);

// 2015 Ginsu volume hook (0x823130)
static int __fastcall NgVolHook(DWORD self, DWORD edx, float* eng, float* exh, float a5)
{
    int r = ((Ng823130_t)A(0x00823130))(self, edx, eng, exh, a5);
    if ((g_ginMute || g_dbgMuteNG) && self == g_in.obj) { eng[0] = 0; exh[0] = 0; return r; }
    if (g_ginOn && self == g_in.obj) {
        if (g_ignoreW) {

            DWORD m = *(DWORD*)(self + 20), blk = (m && Readable((void*)(m + 12), 4)) ? *(DWORD*)(m + 12) : 0;
            DWORD o776 = *(DWORD*)(self + 776);
            if (blk && Readable((void*)blk, 12) && o776 && Readable((void*)(o776 + 88), 4)) {
                float k = *(float*)(o776 + 88) + 1.0f;
                float me = (float)(*(DWORD*)(blk + 4) & 0x7FFF) / 32767.0f * k, mx = (float)(*(DWORD*)(blk + 8) & 0x7FFF) / 32767.0f * k;
                if (me > 1) me = 1; if (mx > 1) mx = 1;
                eng[0] = me * g_gEng; exh[0] = mx * g_gExh;
                return r;
            }
        }
        eng[0] *= g_gEng; exh[0] *= g_gExh;
    }
    return r;
}

static int g_muteUnfocused = 1;
static bool GameFocused()
{
    void* fg = GetForegroundWindow(); if (!fg) return false;
    DWORD pid = 0; GetWindowThreadProcessId(fg, &pid);
    return pid == GetCurrentProcessId();
}
static DWORD g_telLast = 0;

// ---- per-frame update of the beta layer (params, shift cut, whine, sweeteners)
static void UpdateInst(DWORD obj)
{
    Inst& s = g_in;
    float rpm, thr, mn, range;
    if (!ReadEngine(obj, &rpm, &thr, &mn, &range)) return;
    float n = range > 1.0f ? (rpm - mn) / range : 0.0f;
    if (n < 0) n = 0; if (n > 1) n = 1;
    const ColData* X = ColX(s.car); const ColData* Y = ColY(s.car); if (!X) X = Y; if (!Y) Y = X;
    int bRpm = Clamp((int)(n * (X->maxRpm - X->minRpm) + X->minRpm), 0, 10000);
    int bRpmGame = bRpm;
    int bThr = Clamp((int)(thr * 1024.0f), 0, 1024);
    float mixE = 1.0f, mixX = 1.0f;
    DWORD w3 = 0, w4 = 0;
    BYTE enabled = *(BYTE*)(obj + 8);
    if (g_useGameMix) {

        DWORD m = *(DWORD*)(obj + 20);
        if (m && Readable((void*)(m + 12), 4)) {
            DWORD blk = *(DWORD*)(m + 12);
            if (blk && Readable((void*)blk, 24)) { w3 = *(DWORD*)(blk + 12); w4 = *(DWORD*)(blk + 16); mixE = (float)((w3 >> 16) & 0x7FFF) / 32767.0f; mixX = mixE;
                if (g_useGameMix == 2) { mixE = mixE > 0.03f ? 1.0f : 0.0f; mixX = mixX > 0.03f ? 1.0f : 0.0f; } }
        }
    }

    bool quiet = false;
    if (g_muteHub && !(*(DWORD*)A(0x00CE62F0) & 1)) quiet = true;
    if (g_muteHub && (*(DWORD*)A(0x00CE62F0) & 1)) {

        int idx = *(int*)A(0x00CE62CC);
        DWORD so = (idx >= 0 && idx < 64 && Readable((void*)A(0x00CE62D0 + 4 * idx), 4)) ? *(DWORD*)A(0x00CE62D0 + 4 * idx) : 0;
        DWORD vt = (so && Readable((void*)so, 4)) ? *(DWORD*)so : 0;
        if (!vt || !Readable((void*)(vt + 28), 4)) quiet = true;
        else {

            typedef bool (__cdecl* IsState_t)();
            bool drive = ((IsState_t)A(0x004A2AD0))() || ((IsState_t)A(0x004A2990))() || ((IsState_t)A(0x004A28A0))() || ((IsState_t)A(0x004A28F0))();
            if (!drive) quiet = true;
        }
    }
    if (g_muteUnfocused && !GameFocused()) quiet = true;
    g_atQuiet = quiet ? 1 : 0; g_atEnabled = enabled ? 1 : 0; g_atRpm = rpm; g_atThr = thr;
    if (!enabled || quiet) mixE = mixX = 0;
    {
        DWORD nw = GetTickCount(); bool m3 = g_cars[s.car].gears != 0;

        if (g_rpmLogN < 6 && g_rpmLogT && nw - g_rpmLogT < 900 && g_rpmLogK < 40) g_rpmLogV[g_rpmLogK++] = bRpm;
        else if (g_rpmLogT && (nw - g_rpmLogT >= 900 || g_rpmLogK >= 40)) {
            char b[400] = "[shift rpm] from ", t[16]; IToStr(g_slideFrom, t); StrCat(b, t, 400); StrCat(b, ":", 400);
            for (int i = 0; i < g_rpmLogK; ++i) { StrCat(b, " ", 400); IToStr(g_rpmLogV[i], t); StrCat(b, t, 400); }
            Log(b); g_rpmLogT = 0; g_rpmLogK = 0; ++g_rpmLogN;
        }
        if (g_shiftCut && nw < g_cutUntil) {
            bThr = 0; float d = m3 ? g_m3CutDuck : g_cutDuck; mixE *= d; mixX *= d;

            if (m3 && g_m3Slide && g_slideFrom > 0) {
                DWORD cm = g_m3CutMs ? g_m3CutMs : 1; float pr = (float)(nw - (g_cutUntil - cm)) / (float)cm; if (pr < 0) pr = 0; if (pr > 1) pr = 1;
                float sm = pr * pr * (3 - 2 * pr);
                int tgt = (int)(g_slideFrom * g_m3DropRatio);
                bRpm = Clamp((int)(g_slideFrom + (tgt - g_slideFrom) * sm), 0, 10000);
            }
        }
        else if (m3 && g_m3Slide && g_slideFrom > 0) {

            int tgt = (int)(g_slideFrom * g_m3DropRatio);
            if (bRpmGame >= tgt - 150 || nw - (g_cutUntil - g_m3CutMs) > (DWORD)g_m3HoldMax) g_slideFrom = 0;
            else bRpm = tgt;
        }
        else if (m3 && nw < g_resumeUntil && g_m3ResumeMs > 0) { float k = (float)(g_resumeUntil - nw) / (float)g_m3ResumeMs; float b = 1.0f + (g_m3Boost - 1.0f) * k; mixE *= b; mixX *= b; }
    }
    int vx = Clamp((int)(g_exhVol * mixX * 32767.0f) - 0x7FFF, -32767, 0);
    int ve = Clamp((int)(g_engVol * mixE * 32767.0f) - 0x7FFF, -32767, 0);
    int p104x = g_vol2, p104e = g_vol2;
    if (g_carbonMix) {
        long long q = 0; QueryPerformanceCounter(&q);
        float fs = 1.0f;
        if (g_qf > 0 && g_qPrev) { fs = (float)(q - g_qPrev) / (float)g_qf * 60.0f; if (fs < 0.1f) fs = 0.1f; if (fs > 6.0f) fs = 6.0f; }
        g_qPrev = q;
        float t1 = thr < 0 ? 0 : (thr > 1 ? 1 : thr);
        HybUpdate(g_hx, *X, n, t1, fs);
        HybUpdate(g_he, *Y, n, t1, fs);

        vx = Clamp((int)(g_hx.v52 * g_aemsScale * g_exhVol * mixX) - 0x7FFF, -32767, 0);
        ve = Clamp((int)(g_he.v52 * g_aemsScale * g_engVol * mixE) - 0x7FFF, -32767, 0);
        if (g_p104) { p104x = Clamp((int)(g_hx.v112 * mixX), 0, 0x7FFF); p104e = Clamp((int)(g_he.v112 * mixE), 0, 0x7FFF); }

        float ge = g_he.v56 * g_he.v56 + g_he.v60 * g_he.v60, gx = g_hx.v56 * g_hx.v56 + g_hx.v60 * g_hx.v60;
        float se = 0, sx = 0;
        if (ge > 0) { se = ge > 1 ? ge / 2 : 1; for (int i = 0; i < 20; ++i) se = 0.5f * (se + ge / se); }
        if (gx > 0) { sx = gx > 1 ? gx / 2 : 1; for (int i = 0; i < 20; ++i) sx = 0.5f * (sx + gx / sx); }
        g_gEng = se / 32767.0f * g_ginScale; g_gExh = sx / 32767.0f * g_ginScale;
        if (g_single && X == Y) g_gEng = 0.0f;
        g_ginOn = (enabled && !quiet) ? 1 : 0;
    } else g_ginOn = 0;

    P(s.pExh, 8) = bRpm; P(s.pExh, 16) = bThr; P(s.pExh, 24) = vx; P(s.pExh, 104) = p104x; P(s.pExh, 68) = g_pan;
    P(s.pExh, 116) = g_mix116; P(s.pExh, 120) = g_filter; P(s.pExh, 92) = 0; P(s.pExh, 100) = 0;

    int bRpmE = bRpm;
    if (g_ownRange && Y != X && X->maxRpm > X->minRpm + 1 && Y->maxRpm > Y->minRpm + 1) {
        // the engine collection has its own rpm range (Carbon maps each collection separately)
        float nx = (bRpm - X->minRpm) / (X->maxRpm - X->minRpm); if (nx < 0) nx = 0; if (nx > 1.05f) nx = 1.05f;
        bRpmE = Clamp((int)(Y->minRpm + nx * (Y->maxRpm - Y->minRpm)), 0, 10000);
    }
    if (g_dbgMuteX) vx = -32767;
    if (g_dbgMuteE) ve = -32767;
    P(s.pEng, 8) = bRpmE; P(s.pEng, 12) = bThr; P(s.pEng, 20) = ve; P(s.pEng, 104) = p104e; P(s.pEng, 68) = g_pan;
    P(s.pEng, 72) = g_p72; P(s.pEng, 64) = g_mix64; P(s.pEng, 88) = g_filter; P(s.pEng, 92) = 0; P(s.pEng, 100) = 0;
    if (s.hExh) ((Update_t)A(kCsisUpdate))(s.hExh, 0, s.pExh);
    if (s.hEng) ((Update_t)A(kCsisUpdate))(s.hEng, 0, s.pEng);
    {
        float mph = 0; DWORD car = *(DWORD*)(obj + 24);
        if (car && Readable((void*)(car + 52), 4)) { float* st = *(float**)(car + 52); if (st && Readable(st + 20, 12)) mph = st[20] * st[20] + st[21] * st[21] + st[22] * st[22]; }
        float ms = 0; if (mph > 0) { float r = mph; float g = r > 1 ? r / 2 : 1; for (int i = 0; i < 12; ++i) g = 0.5f * (g + r / g); ms = g; }
        float mixT = (!enabled || quiet) ? 0.0f : 1.0f;
        if (g_trOwn) { float t1 = thr > 1 ? 1 : thr; g_trTgtN = n; g_trTgtVol = g_cars[s.car].gears ? g_trVol * (n * n) * (0.5f + 0.5f * t1) * mixT : 0.0f; g_trUpd = GetTickCount(); }
        if (s.hTr) {
            int audioRpm = (int)(n * 9000.0f + 1000.0f);
            s.pTr[1] = Clamp(g_trBySpeed ? (int)(ms * 15.0f * g_trSpeedScale) : audioRpm, 0, 10000);
            s.pTr[2] = Clamp((int)(32767.0f * g_trVol * mixT), 0, 0x7FFF);
            s.pTr[3] = 0; s.pTr[4] = 0; s.pTr[5] = 25000; s.pTr[6] = g_trP28 > 0 ? g_trP28 : 0x7FFF; s.pTr[7] = 0x7FFF;
            s.pTr[8] = (g_lastShiftEvt && now32() - g_lastShiftEvt < (DWORD)g_trShiftMs) ? 1 : 0;
            ((Update_t)A(kCsisUpdate))(s.hTr, 0, s.pTr);
        }
        if (g_whOwn) {
            int gear = ReadGear();
            DWORD nw = now32();
            if (gear >= 0) { if (g_prevGear >= 2 && gear > g_prevGear) g_whCutUntil = nw + (DWORD)g_whCutMs; g_prevGear = gear; g_whGear = gear; }
            else if (g_lastShiftEvt && nw - g_lastShiftEvt < 30 && g_whCutUntil < g_lastShiftEvt) g_whCutUntil = g_lastShiftEvt + (DWORD)g_whCutMs;
            g_whKmh = ms * 3.6f;
            g_whTgtVol = g_cars[s.car].gears ? g_whVol * 0.15f * mixE * mixT : 0.0f;
            g_whUpd = nw;
        }
        if (s.hWh) {

            float sf = g_whTop > 1 ? (ms * 3.6f) / g_whTop : 0; if (sf > 1) sf = 1;
            int wr = (int)(1000.0f + 9000.0f * sf * (1.0f - g_whRpmMix + g_whRpmMix * n));
            s.pWh[1] = Clamp(wr, 0, 10000); s.pWh[2] = Clamp((int)((0.35f + 0.65f * sf) * 32767.0f * g_whVol * mixT), 0, 32787); s.pWh[3] = 0x7FFF;
            ((Update_t)A(kCsisUpdate))(s.hWh, 0, s.pWh);
        }
    }

    {
        DWORD car = *(DWORD*)(obj + 24); float vz = 0; bool ok = false;
        if (car && Readable((void*)(car + 52), 4)) { float* st = *(float**)(car + 52); if (st && Readable(st + 20, 12)) { vz = st[20 + g_upAxis]; ok = true; } }
        long long q = 0; QueryPerformanceCounter(&q); DWORD now = GetTickCount();
        if (ok && g_vzT && g_qf > 0 && vz != g_vzPrev) {
            float dt = (float)(q - g_vzT) / (float)g_qf;
            if (dt > 0.004f && dt < 0.5f) {
                float az = (vz - g_vzPrev) / dt;
                g_azLast = az;
                if (az < -g_airAcc) { if (!g_fallT) g_fallT = now; if (now - g_fallT >= 60) g_airUntil = now + g_airHold; }
                else g_fallT = 0;
                if (az > g_bumpAcc || az < -g_bumpAcc * 1.5f) g_airUntil = now + g_airHold;
            }
            g_vzPrev = vz; g_vzT = q;
        } else if (ok && !g_vzT) { g_vzPrev = vz; g_vzT = q; }

        // fallback: the game does not raise its shift event on every gear change (e.g. very quick shifts):
        // a gear change with no game event around it plays the shift sound too
        if (g_shiftEvents && g_fxOn && g_curShift >= 0) {
            int gnow = ReadGear();
            if (gnow >= 0) {
                if (g_fxGear >= 2 && gnow >= 2 && gnow != g_fxGear) g_gearChangeAt = now;
                g_fxGear = gnow;
            }
            if (g_gearChangeAt && now - g_gearChangeAt >= 150) {
                DWORD raw = g_rawShiftEvt;
                bool seen = raw && raw + 700 >= g_gearChangeAt && raw <= g_gearChangeAt + 150;
                if (!seen && !g_shiftEvt) { g_shiftEvt = 1; static int lg = 0; if (lg < 20) { ++lg; Log("[shift] gear change without game event: shift sound played anyway"); } }
                g_gearChangeAt = 0;
            }
        }
        if (g_shiftEvents && g_shiftEvt) {
            g_shiftEvt = 0; g_liftAt = 0;
            { static int lg2 = 0; if (lg2 < 300) { ++lg2; char b[160] = "[shift] event: gear ", t[16]; IToStr(ReadGear(), t); StrCat(b, t, 160);
                StrCat(b, enabled ? "" : " (disabled)", 160); StrCat(b, quiet ? " (quiet)" : "", 160); StrCat(b, now - g_lastShiftEvt > 150 ? "" : " (too soon)", 160);
                StrCat(b, " fxOn ", 160); IToStr(g_fxOn, t); StrCat(b, t, 160); StrCat(b, " bank ", 160); IToStr(g_fxBank, t); StrCat(b, t, 160); StrCat(b, " shift ", 160); IToStr(g_curShift, t); StrCat(b, t, 160); Log(b); } }
            if (enabled && !quiet && now - g_lastShiftEvt > 150) {
                g_lastShiftEvt = now;
                PlayShiftFx(g_cars[s.car].gears ? mixX * g_m3FxVol : mixX);
                if (g_mwOn && g_cars[s.car].gears && now >= g_airUntil) { PlayMw(g_mwShift, g_mwVol * g_sweetVol * mixX); g_mwEngageAt = now + g_cutMs; }
                if (g_shiftCut) { DWORD cm = g_cars[s.car].gears ? g_m3CutMs : g_cutMs; g_cutUntil = now + cm; g_resumeUntil = g_cutUntil + (DWORD)g_m3ResumeMs; }
                g_slideFrom = g_prevGameRpm > bRpmGame ? g_prevGameRpm : bRpmGame; if (g_rpmLogN < 6) { g_rpmLogT = now; g_rpmLogK = 0; }
                if (n >= g_sweetThr && g_sweetVol > 0 && now >= g_airUntil) { if (!(g_mwOn && g_mwReady && g_cars[s.car].gears && g_mwShift[0])) FireSweet(0, bRpm, X, mixX); g_engageAt = g_shiftCut ? g_cutUntil : now + g_cutMs; g_engageN = n; }
                g_lastSweet = now; for (int i = 0; i < 16; ++i) g_hist[i] = 0;
            }
        }

        if (g_mwEngageAt && now >= g_mwEngageAt) { g_mwEngageAt = 0; if (now >= g_airUntil) PlayMw(g_mwEngage, g_mwVol * g_sweetVol * mixX); }
        if (g_engageAt && now >= g_engageAt) { g_engageAt = 0; if (g_engageN >= g_sweetThr && g_sweetVol > 0 && (g_m3EngageSw || !g_cars[s.car].gears)) FireSweet(1, bRpm, X, mixX); }

        if (g_liftAt && now >= g_liftAt) { g_liftAt = 0; if (now - g_lastShiftEvt > 400 && now >= g_airUntil) { g_mwLiftFlag = true; FireSweet(1, g_liftRpm, X, mixX); } }
        ReleaseFx(false);
        if (now < g_airUntil) { for (int i = 0; i < 16; ++i) { g_hist[i] = 0; g_cH[i] = 0; } g_prevThr = thr; g_lastSweet = now; g_liftAt = 0; }
        else if (g_shiftCut && !g_shiftEvents) {
            g_cH[g_cI] = n; g_cT2[g_cI] = thr; g_cT[g_cI] = now; g_cI = (g_cI + 1) & 15;
            float mx = n, tm = thr; for (int i = 0; i < 16; ++i) { if (now - g_cT[i] < 120 && g_cH[i] > mx) mx = g_cH[i]; if (now - g_cT[i] < 400 && g_cT2[i] > tm) tm = g_cT2[i]; }
            if (mx - n > g_cutDrop && tm > 0.5f && mx > 0.3f && now > g_cutUntil + 300) { g_cutUntil = now + g_cutMs; g_engageAt = now + g_cutMs; g_engageN = mx; for (int i = 0; i < 16; ++i) g_cH[i] = 0; }
        }
        if (now < g_airUntil) {}
        else CheckSweets(n, thr, bRpm, X, mixX * (g_exhVol > 0 ? 1.0f : 0.0f));
    }
    g_prevGameRpm = bRpmGame;
    s.lastUpd = GetTickCount(); s.muted = false;
    if (g_telemetry && s.lastUpd - g_telLast > 2000) {
        g_telLast = s.lastUpd;
        char b[260] = "[tel] rpm2015=", t[16];
        IToStr((int)rpm, t); StrCat(b, t, 260); StrCat(b, " min=", 260); IToStr((int)mn, t); StrCat(b, t, 260);
        StrCat(b, " range=", 260); IToStr((int)range, t); StrCat(b, t, 260);
        StrCat(b, " thr%=", 260); IToStr((int)(thr * 100), t); StrCat(b, t, 260);
        StrCat(b, " -> rpmBeta=", 260); IToStr(bRpm, t); StrCat(b, t, 260);
        StrCat(b, " rpmEngine=", 260); IToStr(P(s.pEng, 8), t); StrCat(b, t, 260);
        StrCat(b, " thr=", 260); IToStr(bThr, t); StrCat(b, t, 260);
        StrCat(b, " enabled=", 260); IToStr(enabled, t); StrCat(b, t, 260);
        StrCat(b, " mix=", 260); HexStr(w3, t); StrCat(b, t, 260); StrCat(b, "/", 260); HexStr(w4, t); StrCat(b, t, 260);
        StrCat(b, " tickEmb=", 260); IToStr((int)g_embTicks, t); StrCat(b, t, 260);
        StrCat(b, " oldList=", 260); IToStr(CountList(kGListEmb), t); StrCat(b, t, 260);
        StrCat(b, " safehouse=", 260); StrCat(b, quiet ? "1" : "0", 260);
        StrCat(b, " layer=", 260); StrCat(b, g_layerOn ? "ON" : "OFF", 260);
        StrCat(b, " accVert=", 260); IToStr((int)g_azLast, t); StrCat(b, t, 260); StrCat(b, s.lastUpd < g_airUntil ? " (airborne: sweeteners paused)" : "", 260);
        if (g_carbonMix) {
            StrCat(b, " | carbon: aemsX=", 260); IToStr((int)g_hx.v52, t); StrCat(b, t, 260);
            StrCat(b, " aemsE=", 260); IToStr((int)g_he.v52, t); StrCat(b, t, 260);
            StrCat(b, " ginsuE%=", 260); IToStr((int)(g_gEng * 100), t); StrCat(b, t, 260);
            StrCat(b, " ginsuX%=", 260); IToStr((int)(g_gExh * 100), t); StrCat(b, t, 260);
            StrCat(b, " accF%=", 260); IToStr((int)(g_he.accF * 100), t); StrCat(b, t, 260);
            StrCat(b, " decWin%=", 260); IToStr((int)(g_he.c * 100), t); StrCat(b, t, 260);
        }
        Log(b);
    }
}

typedef void (__fastcall* Lock_t)(DWORD, void*);
typedef int (__fastcall* SetParam_t)(DWORD node, void*, int idx, float v);

// 2015 Ginsu level scaling
static void ScaleNG(DWORD self)
{
    if (g_ngVol >= 0.999f) return;
    DWORD m = *(DWORD*)(self + 20); if (!m || !Readable((void*)(m + 12), 4)) return;
    DWORD blk = *(DWORD*)(m + 12); if (!blk || !Readable((void*)blk, 24)) return;
    float lvl = (float)((*(DWORD*)(blk + 12) >> 16) & 0x7FFF) * g_ngVol;
    DWORD gp = *(DWORD*)A(0x00D77CC4); if (!gp || !Readable((void*)(gp + 132), 4)) return;
    DWORD g2 = *(DWORD*)(gp + 132); if (!g2 || !Readable((void*)(g2 + 4), 4)) return;
    DWORD lk = *(DWORD*)(g2 + 4); if (!lk) return;
    DWORD e = *(DWORD*)(self + 860), x = *(DWORD*)(self + 868);
    DWORD ne = (e && Readable((void*)(e + 16), 4)) ? *(DWORD*)(e + 16) : 0;
    DWORD nx = (x && Readable((void*)(x + 16), 4)) ? *(DWORD*)(x + 16) : 0;
    ((Lock_t)A(0x0092A9D0))(lk, 0);
    if (ne) ((SetParam_t)A(0x0092E9A0))(ne, 0, 0, lvl);
    if (nx) ((SetParam_t)A(0x0092E9A0))(nx, 0, 0, lvl);
    ((Lock_t)A(0x0092A9F0))(lk, 0);
}

typedef void (__fastcall* EngUpdate_t)(DWORD self, void*);
typedef DWORD (__fastcall* EngDtor_t)(DWORD self, void*, int flags);

static Obj* GetObj(DWORD obj)
{
    Obj* fr = 0;
    DWORD now = GetTickCount();
    for (int i = 0; i < 32; ++i) {
        if (g_objs[i].obj == obj) return &g_objs[i];
        if (!fr && (!g_objs[i].obj || now - g_objs[i].last > 10000)) fr = &g_objs[i];
    }
    if (fr) { fr->obj = obj; fr->car = -2; fr->tries = 0; fr->last = now; fr->scanT = 0; }
    return fr;
}

static void __fastcall EngUpdateHook(DWORD self, void* edx)
{
    // beta-layer car: the 2015 engine reads modified mixer values (volume, channel +16 low), restored right after
    DWORD blk = 0, s12 = 0, s16 = 0;
    float ngv = g_dbgMuteNG ? 0.0f : g_ngVol;
    if (g_in.obj == self && (ngv < 0.999f || g_p20 >= 0)) {
        DWORD m = *(DWORD*)(self + 20);
        if (m && Readable((void*)(m + 12), 4)) { blk = *(DWORD*)(m + 12); if (blk && !Readable((void*)blk, 24)) blk = 0; }
        if (blk) {
            s12 = *(DWORD*)(blk + 12); s16 = *(DWORD*)(blk + 16);
            if (ngv < 0.999f) { DWORD v = (DWORD)((float)((s12 >> 16) & 0x7FFF) * ngv); *(DWORD*)(blk + 12) = (s12 & 0x8000FFFF) | (v << 16); }
            if (g_p20 >= 0) *(DWORD*)(blk + 16) = (s16 & 0xFFFF8000) | (DWORD)(g_p20 & 0x7FFF);
        }
    }
    ((EngUpdate_t)A(kEngUpdate))(self, edx);
    if (blk) { *(DWORD*)(blk + 12) = s12; *(DWORD*)(blk + 16) = s16; }
    if (!g_enable || !g_nCars) return;
    Obj* o = GetObj(self);
    if (!o) return;
    DWORD now = GetTickCount();
    o->last = now;
    DWORD car = *(DWORD*)(self + 24);
    o->type = (car && Readable((void*)(car + 20), 4)) ? *(int*)(car + 20) : -1;
    {   // engine object reused on car change: re-identify when min/max rpm change
        float rpm, thr, mn, range;
        if (o->car >= 0 && ReadEngine(self, &rpm, &thr, &mn, &range) && (mn - o->mn > 1 || o->mn - mn > 1 || range - o->range > 1 || o->range - range > 1)) { o->car = -2; o->tries = 0; }
    }
    if (o->car >= 0 && now - o->scanT > 1000) {   // upgrade changed (same car, different caraudio collection)
        o->scanT = now; DWORD k = ActiveKey(self);
        if (k && k != g_cars[o->car].key) { o->car = -2; o->tries = 0; Log("[car] caraudio collection changed (upgrade): identifying again"); }
    }
    if (o->car == -2 || (o->car == -1 && o->tries < 20 && now - o->scanT > 1000)) {
        o->scanT = now;
        int c = IdentifyCar(self);
        ++o->tries;
        { float r1, t1; ReadEngine(self, &r1, &t1, &o->mn, &o->range); }
        if (c >= 0) {
            o->car = c;
            char t[16]; IToStr(o->type, t);
            Log("[car] identified ", g_cars[c].name[0] ? g_cars[c].name : "(unnamed key)", "  object type=", t);
            LogH("       caraudio key ", g_cars[c].key);
        } else {
            o->car = -1;
            if (o->tries == 1) { char t[16]; IToStr(o->type, t); LogH("[car] caraudio not found for object ", self, ""); Log("       type=", t); }
        }
    }
    bool isPlayer = (g_playerOnly ? (o->type == 1) : true) && g_layerOn;
    bool hasBeta = o->car >= 0 && (g_cars[o->car].src == 1 || g_cars[o->car].src == 3 || (g_allCars && g_cars[o->car].src == 2));
    if (!isPlayer || !hasBeta) {
        if (g_in.obj == self) ReleaseInst();
        return;
    }
    if (g_in.obj && g_in.obj != self) {
        // another object owns the instance: keep the most recently updated one
        if (now - g_in.lastUpd < 500) return;
        ReleaseInst();
    }
    if (!g_in.obj || g_in.car != o->car) { if (g_in.obj) ReleaseInst(); if (!StartInst(self, o->car)) { o->car = -3; Log("[instance] cannot start the beta sound for this car"); return; } }
    UpdateInst(self);
}

static DWORD __fastcall EngDtorHook(DWORD self, void* edx, int flags)
{
    if (g_in.obj == self) ReleaseInst();
    for (int i = 0; i < 32; ++i) if (g_objs[i].obj == self) g_objs[i].obj = 0;
    return ((EngDtor_t)A(kEngDtor))(self, edx, flags);
}


// frees banks, mutes the beta layer when the engine stops updating (pause/menus)
#include "autotest.inc"

static DWORD WINAPI Watchdog(LPVOID)
{
    short prev[3] = { 0, 0, 0 };
    for (;;) {
        Sleep(100);
        FreePending();
        AutoTestTick();
        if (g_dbgKeys && GameFocused()) {
            // F9 = beta sound only (2015 muted), F10 = 2015 sound only (beta muted), F11 = both (normal)
            static const int vk[3] = { 0x78, 0x79, 0x7A };
            for (int i = 0; i < 3; ++i) {
                short st = (short)GetAsyncKeyState(vk[i]);
                if ((st & 0x8000) && !(prev[i] & 0x8000)) {
                    g_dbgMuteNG = (i == 0); g_dbgMuteX = g_dbgMuteE = (i == 1);
                    Log("[debug] ", i == 0 ? "F9: beta sound only (2015 muted)" : (i == 1 ? "F10: 2015 sound only (beta muted)" : "F11: both layers (normal)"));
                    if (g_in.car >= 0) LogH("        key ", g_cars[g_in.car].key);
                }
                prev[i] = st;
            }
        }
        if (!g_in.obj || g_in.muted) continue;
        if (GetTickCount() - g_in.lastUpd < 400) continue;
        EnterCriticalSection(&g_cs);
        if (!g_in.obj || g_in.muted) { LeaveCriticalSection(&g_cs); continue; }
        g_in.busy = 1;
        DWORD hx = g_in.hExh, he = g_in.hEng;
        int px[100], pe[100];
        MemCpy(px, g_in.pExh, sizeof(px)); MemCpy(pe, g_in.pEng, sizeof(pe));
        g_in.muted = true;
        LeaveCriticalSection(&g_cs);
        P(px, 24) = -32767; P(pe, 20) = -32767;
        if (hx) ((Update_t)A(kCsisUpdate))(hx, 0, px);
        if (he) ((Update_t)A(kCsisUpdate))(he, 0, pe);
        g_in.busy = 0;
    }
}

// ---- code patches
static bool PatchJmp(DWORD va, const unsigned char* expect, int n, void* to)
{
    unsigned char* p = (unsigned char*)A(va);
    if (!Readable(p, n)) return false;
    for (int i = 0; i < n; ++i) if (p[i] != expect[i]) return false;
    DWORD old;
    if (!VirtualProtect(p, 5, 0x40, &old)) return false;
    p[0] = 0xE9; *(int*)(p + 1) = (int)((DWORD)to - ((DWORD)p + 5));
    VirtualProtect(p, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    return true;
}
static bool PatchPtr(DWORD va, DWORD expect, void* val)
{
    DWORD* p = (DWORD*)A(va);
    if (!Readable(p, 4) || *p != A(expect)) return false;
    DWORD old;
    if (!VirtualProtect(p, 4, 0x04, &old)) return false;
    *p = (DWORD)val;
    VirtualProtect(p, 4, old, &old);
    return true;
}

static bool PatchCall(DWORD va, DWORD expectTarget, void* to)
{
    unsigned char* p = (unsigned char*)A(va);
    if (!Readable(p, 5) || p[0] != 0xE8) return false;
    if ((DWORD)p + 5 + *(int*)(p + 1) != A(expectTarget)) return false;
    DWORD old;
    if (!VirtualProtect(p, 5, 0x40, &old)) return false;
    *(int*)(p + 1) = (int)((DWORD)to - ((DWORD)p + 5));
    VirtualProtect(p, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    return true;
}

static unsigned char g_dummyEntry[64];

// 0x82ED00 off-by-one fix (collision/landing sound crash)
static bool PatchCollision()
{
    static const unsigned char ex[] = { 0x3B, 0xC2, 0x0F, 0x4D, 0xC2, 0x3B, 0xC3, 0x0F, 0x4C, 0xC3 };
    unsigned char* p = (unsigned char*)A(0x0082ED51);
    if (!Readable(p, 10)) return false;
    for (int i = 0; i < 10; ++i) if (p[i] != ex[i]) return false;
    unsigned char* c = (unsigned char*)VirtualAlloc(0, 64, MEM_COMMIT | MEM_RESERVE, 0x40);
    if (!c) return false;
    int k = 0;
    c[k++] = 0x4A;
    c[k++] = 0x3B; c[k++] = 0xC2;
    c[k++] = 0x0F; c[k++] = 0x4F; c[k++] = 0xC2;
    c[k++] = 0x85; c[k++] = 0xD2;
    c[k++] = 0x79; c[k++] = 0x07;
    c[k++] = 0xB9; *(DWORD*)(c + k) = (DWORD)g_dummyEntry; k += 4;
    c[k++] = 0x33; c[k++] = 0xC0;
    c[k++] = 0x3B; c[k++] = 0xC3;
    c[k++] = 0x0F; c[k++] = 0x4C; c[k++] = 0xC3;
    c[k++] = 0xE9; *(int*)(c + k) = (int)(A(0x0082ED5B) - ((DWORD)c + k + 4)); k += 4;
    DWORD old;
    if (!VirtualProtect(p, 10, 0x40, &old)) return false;
    p[0] = 0xE9; *(int*)(p + 1) = (int)((DWORD)c - ((DWORD)p + 5));
    for (int i = 5; i < 10; ++i) p[i] = 0x90;
    VirtualProtect(p, 10, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, 10);
    return true;
}

static int g_noWorldShift = 1;
static bool SkipWorldShift(DWORD self)
{
    if (!g_noWorldShift || !g_in.obj || g_in.car < 0) return false;
    if (g_noWorldShift == 1 && !g_cars[g_in.car].gears) return false;
    DWORD a = Readable((void*)(self + 28), 4) ? *(DWORD*)(self + 28) : 0, b = *(DWORD*)(g_in.obj + 28);
    return a && a == b;
}
typedef int (__fastcall* Snd_t)(DWORD self, DWORD edx);
static int g_noWorldShiftFx = 0;
static int g_fxLog = 0;

// 0x82DA7E: game shift event -> our shift handling
static int __fastcall ShiftFxHook(DWORD self, DWORD edx)
{
    if (g_in.obj && Readable((void*)(self + 28), 4) && *(DWORD*)(self + 28) == *(DWORD*)(g_in.obj + 28)) {
        DWORD f72 = Readable((void*)(self + 72), 4) ? *(DWORD*)(self + 72) : 0;
        g_shiftFlags = (f72 && Readable((void*)(f72 + 44), 4)) ? *(int*)(f72 + 44) : 0;
        g_shiftEvt = 1; g_rawShiftEvt = GetTickCount();
        if (g_fxOn && g_curShift >= 0 && g_fxBank > 0) return 0;
    }
    if (g_noWorldShiftFx && SkipWorldShift(self)) return 0;
    int r = ((Snd_t)A(0x00825A50))(self, edx);
    if (g_fxLog < 20 && g_in.obj && Readable((void*)(self + 44), 4)) {
        DWORD a = *(DWORD*)(self + 28), b = *(DWORD*)(g_in.obj + 28);
        if (a == b) { ++g_fxLog; LogH("[shift] FX_SHIFTING_01 started for the player car, instance ", *(DWORD*)(self + 44), *(DWORD*)(self + 44) ? "" : "  (NO instance: sound not created)"); }
    }
    return r;
}

struct StrKey { DWORD hash; const char* name; };
static StrKey g_shiftBank = { 0xBB492972, "GEAR_MED_Lev3.abk" };
static int g_m3ShiftBank = 1, g_worldCbGear = 1;
static StrKey* g_cbKeys = 0;
typedef void* (__fastcall* AttrGet_t)(int* inst, DWORD edx, DWORD key, unsigned idx);
// shift_filename override (0x6C4700) -> per-car Carbon CB_GEAR bank
static void* __fastcall ShiftFileHook(int* inst, DWORD edx, DWORD key, unsigned idx)
{
    void* r = ((AttrGet_t)A(0x006C4700))(inst, edx, key, idx);

    if (g_fxOn && g_worldCbGear && inst && Readable(inst, 4) && g_nShifts) {
        DWORD coll = *(DWORD*)inst; int off = g_keyOff >= 0 ? g_keyOff : 20;
        if (coll && Readable((void*)(coll + off), 4)) {
            DWORD k = *(DWORD*)(coll + off);
            for (int i = 0; i < g_nShifts; ++i) if (g_shifts[i].key == k) {
                if (!g_cbKeys) { g_cbKeys = (StrKey*)VirtualAlloc(0, g_nShifts * (sizeof(StrKey) + 32), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); }
                if (!g_cbKeys) break;
                char* nm = (char*)(g_cbKeys + g_nShifts) + i * 32;
                if (!nm[0]) { StrCpy(nm, "CB_", 32); StrCat(nm, g_shifts[i].bank, 32); g_cbKeys[i].hash = g_shifts[i].hashCB; g_cbKeys[i].name = nm; }
                static DWORD lastK = 0; if (lastK != k) { lastK = k; Log("[shift] game shift bank: ", nm); }
                return &g_cbKeys[i];
            }
        }
    }
    if (g_m3ShiftBank && inst && Readable(inst, 4)) {
        DWORD coll = *(DWORD*)inst;
        int off = g_keyOff >= 0 ? g_keyOff : 20;
        if (coll && Readable((void*)(coll + off), 4)) { int c = FindCar(*(DWORD*)(coll + off)); if (c >= 0 && g_cars[c].gears) { Log("[shift] shift bank replaced with GEAR_MED_Lev3.abk for ", g_cars[c].name); return &g_shiftBank; } }
    }
    return r;
}
static int __fastcall SwtnFxHook(DWORD self, DWORD edx) { if (SkipWorldShift(self)) return 0; return ((Snd_t)A(0x00825F20))(self, edx); }

static int g_noLoadWobble = 1;

// 0x831B11: remove load wobble
static bool PatchLoadWobble()
{
    unsigned char* p = (unsigned char*)A(0x00831B11);
    if (!Readable(p, 13)) return false;
    if (p[0] != 0x83 || p[1] != 0x3D || *(DWORD*)(p + 2) != A(0x00D20384) || p[6] != 0x00 || p[7] != 0x0F || p[8] != 0x84) return false;
    DWORD tgt = (DWORD)(p + 13) + *(int*)(p + 9);
    if (tgt != A(0x00831C36)) return false;
    DWORD old; if (!VirtualProtect(p, 13, 0x40, &old)) return false;
    p[0] = 0xE9; *(int*)(p + 1) = (int)(tgt - ((DWORD)p + 5));
    for (int i = 5; i < 13; ++i) p[i] = 0x90;
    VirtualProtect(p, 13, old, &old); FlushInstructionCache(GetCurrentProcess(), p, 13);
    return true;
}

static int g_noRpmSmooth = 1;

// 0x8319E2: remove 2015 rpm smoothing
static bool PatchRpmSmooth()
{
    unsigned char* p = (unsigned char*)A(0x008319E2);
    if (!Readable(p, 2) || p[0] != 0x76 || p[1] != 0x74) return false;
    DWORD old; if (!VirtualProtect(p, 2, 0x40, &old)) return false;
    p[0] = 0xEB; VirtualProtect(p, 2, old, &old); FlushInstructionCache(GetCurrentProcess(), p, 2);
    return true;
}

static void LogBytes(const char* tag, DWORD va, int n)
{
    unsigned char* p = (unsigned char*)A(va);
    char b[128]; StrCpy(b, tag, 128);
    MEMORY_BASIC_INFORMATION mi; MemSet(&mi, 0, sizeof(mi)); VirtualQuery(p, &mi, sizeof(mi));
    char t[16]; HexStr(mi.Protect, t); StrCat(b, " prot=", 128); StrCat(b, t, 128); StrCat(b, " byte=", 128);
    const char* h = "0123456789ABCDEF";
    if (Readable(p, n)) for (int i = 0; i < n; ++i) { char x[4] = { h[p[i] >> 4], h[p[i] & 15], ' ', 0 }; StrCat(b, x, 128); }
    else StrCat(b, "(illeggibile)", 128);
    Log(b);
}

// applies patches/hooks once the game is ready
static DWORD WINAPI Patcher(LPVOID)
{
    bool task = !GetPrivateProfileIntA("General", "PatchAemsTask", 0, g_ini), upd = false, dtor = false, logged = false, ngv = !g_carbonMix, coll = !g_fixColl, wsh = !g_noWorldShift, wob = !g_noLoadWobble, sbk = !g_m3ShiftBank, rsm = !g_noRpmSmooth;
    for (int i = 0; i < 600 && !(task && upd && dtor && ngv && coll && wsh && wob && sbk && rsm); ++i) {
        if (!task) { unsigned char ex[12]; MemCpy(ex, kTaskBytes, 12); *(DWORD*)(ex + 8) = A(kGRate);
            task = PatchJmp(kAemsTaskInt, ex, 12, (void*)AemsTask); if (task) Log("[init] AEMS task extended to old (beta/Carbon) modules"); }
        if (task && i == 0) { DWORD* t = (DWORD*)A(0x00E02D50); int fi = -1, fe = -1; if (Readable(t, 64)) for (int k = 0; k < 16; ++k) { if (t[k] == A(kAemsTaskInt)) fi = k; if (t[k] == A(0x00946080)) fe = k; } LogI("[init] task registered: Int at index ", fi, ""); LogI("       Emb at index ", fe, ""); }
        if (!upd) { upd = PatchPtr(kEngVtbl + 10 * 4, kEngUpdate, (void*)EngUpdateHook); if (upd) Log("[init] SFXObj_Engine update hook OK"); }
        if (!dtor) { dtor = PatchPtr(kEngVtbl, kEngDtor, (void*)EngDtorHook); if (dtor) Log("[init] SFXObj_Engine destructor hook OK"); }
        if (!wsh && g_noWorldShift) { bool a1 = PatchCall(0x0082DA7E, 0x00825A50, (void*)ShiftFxHook), a2 = PatchCall(0x0082DAAE, 0x00825F20, (void*)SwtnFxHook); wsh = a1 && a2; if (wsh) Log("[init] 2015 shift sounds (FX_SHIFTING / CAR_SWTN NG) disabled for the selected cars"); }
        if (!sbk && g_m3ShiftBank) { bool b1 = PatchCall(0x0081E0C7, 0x006C4700, (void*)ShiftFileHook), b2 = PatchCall(0x0081E234, 0x006C4700, (void*)ShiftFileHook); sbk = b1 && b2; if (sbk) Log("[init] BMW M3 shift sound: GEAR_MED_Lev3.abk (as in Carbon/beta)"); }
        if (!rsm && g_noRpmSmooth) { rsm = PatchRpmSmooth(); if (rsm) Log("[init] 2015 rpm smoothing disabled (as in Carbon)"); }
        if (!wob && g_noLoadWobble) { wob = PatchLoadWobble(); if (wob) Log("[init] engine load from body roll disabled (as in Carbon)"); }
        if (!coll && g_fixColl) { coll = PatchCollision(); if (coll) Log("[init] collision/landing sound crash fix (0x82ED00) applied"); }
        if (!ngv && g_carbonMix) { ngv = PatchCall(0x008318E3, 0x00823130, (void*)NgVolHook); if (ngv) Log("[init] 2015 Ginsu volume hook (Carbon mix) OK"); }
        if (!logged && !(task && upd && dtor)) {
            logged = true;
            Log("[init] some patches not applicable yet, retrying for 60 seconds");
            LogBytes("       task 0x947090", kAemsTaskInt, 12);
            LogBytes("       vtable+0x28", kEngVtbl + 40, 4);
            LogBytes("       vtable+0x00", kEngVtbl, 4);
        }
        if (!(task && upd && dtor && ngv)) Sleep(100);
    }
    if (!(task && upd && dtor)) {
        Log("[init] patches NOT applied (different nfsw.exe or code already changed by another mod)");
        LogBytes("       task 0x947090", kAemsTaskInt, 12);
        LogBytes("       vtable+0x28", kEngVtbl + 40, 4);
        LogBytes("       vtable+0x00", kEngVtbl, 4);
    }
    return 0;
}

// ---- init
static void Init(HMODULE self)
{
    g_delta = (DWORD)GetModuleHandleA(0) - kBase;
    InitializeCriticalSection(&g_logCs); InitializeCriticalSection(&g_cs);
    DWORD n = GetModuleFileNameA(self, g_dir, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    for (int i = (int)n - 1; i >= 0; --i) if (g_dir[i] == '\\' || g_dir[i] == '/') { g_dir[i + 1] = 0; break; }
    StrCpy(g_ini, g_dir, MAX_PATH); StrCat(g_ini, "NFSWBetaEngineAudio.ini", MAX_PATH);
    StrCpy(g_log, g_dir, MAX_PATH); StrCat(g_log, "NFSWBetaEngineAudio.log", MAX_PATH);
    g_logOn = GetPrivateProfileIntA("General", "Log", 1, g_ini) != 0;
    if (g_logOn) { HANDLE h = CreateFileA(g_log, 0x40000000, FILE_SHARE_READ, 0, 2 , FILE_ATTRIBUTE_NORMAL, 0); if (h != INVALID_HANDLE_VALUE) CloseHandle(h); }
    g_enable = GetPrivateProfileIntA("General", "Enable", 1, g_ini);
    g_tickOld = GetPrivateProfileIntA("General", "RunOldModules", 1, g_ini);
    g_playerOnly = GetPrivateProfileIntA("General", "PlayerOnly", 1, g_ini);
    g_telemetry = GetPrivateProfileIntA("General", "Telemetry", 1, g_ini);
    g_swap = GetPrivateProfileIntA("Mix", "SwapEngineExhaust", 0, g_ini);
    g_useGameMix = GetPrivateProfileIntA("Mix", "UseGameMix", 1, g_ini);
    g_allCars = GetPrivateProfileIntA("General", "AllCars", 1, g_ini);
    g_muteHub = GetPrivateProfileIntA("General", "MuteInSafehouse", 1, g_ini);
    g_ngVol = GetF("Mix", "Volume2015", 1.0f);
    g_dbgKeys = GetPrivateProfileIntA("Debug", "MuteKeys", 0, g_ini);
    g_atOn = GetPrivateProfileIntA("AutoTest", "Enable", 0, g_ini);
    g_atPhaseMs = Clamp(GetPrivateProfileIntA("AutoTest", "PhaseSeconds", 7, g_ini), 2, 60) * 1000;
    g_atCycles = Clamp(GetPrivateProfileIntA("AutoTest", "Cycles", 2, g_ini), 1, 5);
    if (g_atOn) g_dbgKeys = 0;
    g_ownRange = GetPrivateProfileIntA("Mix", "EngineOwnRpmRange", 1, g_ini);
    g_p20 = GetPrivateProfileIntA("Mix", "Channel16Low", -1, g_ini);
    g_trVol = GetF("Gears", "TransmissionVolume", 0.25f); g_whVol = GetF("Gears", "GearWhineVolume", 0.0f);
    g_trBySpeed = GetPrivateProfileIntA("Gears", "TransmissionFollowsSpeed", 0, g_ini);
    g_whOwn = GetPrivateProfileIntA("Gears", "GearWhineOwnPlayer", 1, g_ini); g_whCutMs = GetPrivateProfileIntA("Gears", "GearWhineShiftCutMs", 220, g_ini);
    g_whL2 = GetF("Gears", "GearWhineLayer2", 0.5f); g_whRev = GetF("Gears", "GearWhineReverse", 1.67f); g_whPScale = GetF("Gears", "GearWhinePitchScale", 1.0f); g_whTopP = GetF("Gears", "GearWhinePitchTopKmh", 330.0f);
    g_whTop = GetF("Gears", "GearWhineTopSpeedKmh", 280.0f); g_whRpmMix = GetF("Gears", "GearWhineRpmInfluence", 0.2f);
    g_trOwn = GetPrivateProfileIntA("Gears", "TransmissionOwnPlayer", 1, g_ini); g_trShiftMs = GetPrivateProfileIntA("Gears", "TransmissionShiftMs", 350, g_ini); g_trPMin = GetF("Gears", "TransmissionPitchMin", 0.4f); g_trPMax = GetF("Gears", "TransmissionPitchMax", 1.4f); g_trSpeedScale = GetF("Gears", "TransmissionSpeedScale", 3.6f); g_trP28 = GetPrivateProfileIntA("Gears", "TransmissionParam28", 0, g_ini);
    g_airAcc = GetF("Sweeteners", "AirborneAccel", 6.0f); g_bumpAcc = GetF("Sweeteners", "LandingAccel", 15.0f);
    g_airHold = (DWORD)GetPrivateProfileIntA("Sweeteners", "AirborneHoldMs", 700, g_ini); g_upAxis = Clamp(GetPrivateProfileIntA("Sweeteners", "UpAxis", 2, g_ini), 0, 2);
    g_sweetVol = GetF("Sweeteners", "Volume", 1.0f);
    g_shiftCut = GetPrivateProfileIntA("Sweeteners", "ShiftCut", 1, g_ini); g_cutMs = (DWORD)GetPrivateProfileIntA("Sweeteners", "ShiftCutMs", 90, g_ini);
    g_m3CutMs = (DWORD)GetPrivateProfileIntA("Sweeteners", "M3ShiftCutMs", 180, g_ini); g_m3CutDuck = GetF("Sweeteners", "M3ShiftCutVolume", 0.5f);
    g_m3Slide = GetPrivateProfileIntA("Sweeteners", "M3ShiftRpmSlide", 1, g_ini); g_m3DropRatio = GetF("Sweeteners", "M3ShiftRpmDrop", 0.87f); g_m3HoldMax = GetPrivateProfileIntA("Sweeteners", "M3ShiftHoldMaxMs", 1500, g_ini);
    g_m3EngageSw = GetPrivateProfileIntA("Sweeteners", "M3EngageSweetener", 0, g_ini); g_m3FxVol = GetF("Sweeteners", "M3ShiftFxVolume", 0.25f);
    g_m3Boost = GetF("Sweeteners", "M3ResumeBoost", 1.4f); g_m3ResumeMs = GetPrivateProfileIntA("Sweeteners", "M3ResumeMs", 600, g_ini);
    g_cutDuck = GetF("Sweeteners", "ShiftCutVolume", 0.55f); g_cutDrop = GetF("Sweeteners", "ShiftCutRpmDrop", 0.025f); g_sweetThr = GetF("Sweeteners", "MinRpm", 0.667f);
    g_exhVol = GetF("Mix", "ExhaustVolume", 0.6f); g_engVol = GetF("Mix", "EngineVolume", 0.6f);
    g_pan = GetPrivateProfileIntA("Mix", "Pan", 0, g_ini);
    g_mix64 = GetPrivateProfileIntA("Mix", "EngParam64", 0, g_ini);
    g_mix116 = GetPrivateProfileIntA("Mix", "ExhParam116", 0, g_ini);
    g_p72 = GetPrivateProfileIntA("Mix", "EngParam72", 0, g_ini);
    g_filter = GetPrivateProfileIntA("Mix", "Filter", 25000, g_ini);
    g_vol2 = GetPrivateProfileIntA("Mix", "Param104", 0, g_ini);
    g_carbonMix = GetPrivateProfileIntA("Carbon", "CarbonMix", 1, g_ini);
    g_p104 = GetPrivateProfileIntA("Carbon", "AemsParam104", 1, g_ini);
    g_single = GetPrivateProfileIntA("Carbon", "SingleGinsu", 1, g_ini); g_ignoreW = GetPrivateProfileIntA("Carbon", "IgnoreWorldGinsuVolume", 1, g_ini);
    g_ginScale = GetF("Carbon", "GinsuScale", 1.0f);
    g_fixColl = GetPrivateProfileIntA("General", "FixCollisionCrash", 1, g_ini);
    g_fxOn = GetPrivateProfileIntA("Sweeteners", "CarbonShiftSound", 1, g_ini); g_fxVol = GetF("Sweeteners", "CarbonShiftVolume", 1.0f);
    {
        float mv = GetF("General", "MasterVolume", 1.0f); if (mv < 0) mv = 0; if (mv > 2) mv = 2;
        if (mv < 0.999f || mv > 1.001f) { g_exhVol *= mv; g_engVol *= mv; g_ngVol *= mv; if (g_ngVol > 1) g_ngVol = 1; g_sweetVol *= mv; g_fxVol *= mv; g_whVol *= mv; g_trVol *= mv; }
        char t[16]; IToStr((int)(mv * 100), t); Log("[ini] master vehicle volume % = ", t);
    }
    g_fxType = GetPrivateProfileIntA("Sweeteners", "CarbonShiftType", -1, g_ini);
    g_shiftEvents = GetPrivateProfileIntA("Sweeteners", "ShiftFromGame", 1, g_ini);
    g_worldCbGear = GetPrivateProfileIntA("Sweeteners", "GameLoadsCarbonGear", 1, g_ini);
    g_muteUnfocused = GetPrivateProfileIntA("General", "MuteWhenUnfocused", 1, g_ini);
    g_m3ShiftBank = GetPrivateProfileIntA("Sweeteners", "M3ShiftBankLev3", 1, g_ini);
    g_noWorldShiftFx = GetPrivateProfileIntA("Sweeteners", "DisableWorldShiftFx", 0, g_ini);
    g_noRpmSmooth = GetPrivateProfileIntA("Mix", "DisableRpmSmoothing2015", 1, g_ini);
    g_noLoadWobble = GetPrivateProfileIntA("Mix", "DisableLoadWobble", 1, g_ini);
    g_noWorldShift = Clamp(GetPrivateProfileIntA("Sweeteners", "DisableWorldShiftSounds", 1, g_ini), 0, 2);
    g_limHold = GetPrivateProfileIntA("Carbon", "LimiterHold", 1, g_ini); g_limN = GetF("Carbon", "LimiterRpm", 0.93f);
    g_rpmTau = GetF("Carbon", "RpmSmoothing", 0.06f); g_outTau = GetF("Carbon", "VolumeSmoothing", 0.05f); g_aemsScale = GetF("Carbon", "AemsScale", 1.0f);
    QueryPerformanceFrequency(&g_qf);
    char gd[MAX_PATH]; DWORD m = GetModuleFileNameA(0, gd, MAX_PATH);
    if (m && m < MAX_PATH) { for (int i = (int)m - 1; i >= 0; --i) if (gd[i] == '\\' || gd[i] == '/') { gd[i + 1] = 0; break; } StrCpy(g_gameDir, gd, MAX_PATH); }
    char bd[MAX_PATH]; GetPrivateProfileStringA("General", "BankFolder", "Sound\\BetaEngine\\", bd, MAX_PATH, g_ini);
    StrCpy(g_bankDir, g_gameDir, MAX_PATH); StrCat(g_bankDir, bd, MAX_PATH);
    Log("NFSWBetaEngineAudio 1.47 - bank folder: ", g_bankDir);
    if (!g_enable) { Log("disabled in the ini"); return; }
    if (!LoadData()) { Log("[init] NFSWBetaEngineAudio.dat missing or invalid: nothing changed"); return; }
    LogI("[init] cars in data: ", g_nCars);
    ApplyOverrides();
    CreateThread(0, 0, Patcher, 0, 0, 0);
    CreateThread(0, 0, Watchdog, 0, 0, 0);
    if (g_atOn) { Log("[test] automatic test ENABLED ([AutoTest] in the ini)"); CreateThread(0, 0, RecorderThread, 0, 0, 0); }
    if (g_trOwn && g_trVol > 0) CreateThread(0, 0, TrannyThread, 0, 0, 0);
    if (g_whOwn && g_whVol > 0) CreateThread(0, 0, WhineThread, 0, 0, 0);
    g_mwOn = GetPrivateProfileIntA("Sweeteners", "M3MostWantedSweeteners", 1, g_ini); g_mwVol = GetF("Sweeteners", "M3MostWantedVolume", 0.5f);
    ParseList("Sweeteners", "M3ShiftSamples", "1", g_mwShift); ParseList("Sweeteners", "M3EngageSamples", "", g_mwEngage); ParseList("Sweeteners", "M3LiftSamples", "", g_mwLift);
    if (g_mwOn && g_sweetVol > 0) CreateThread(0, 0, MwSweetThread, 0, 0, 0);
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); Init(h); }
    return TRUE;
}
