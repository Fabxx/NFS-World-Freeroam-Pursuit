NFSWBetaEngineAudio 1.45 - closed beta / Carbon engine audio for NFS World 2015 (offline)
=======================================================================================

Copy the "gamedata" folder over the game's gamedata folder (back up the originals first).
Requires an ASI loader (dinput8.dll). Works with the original and the Soapbox Race World nfsw.exe.

gamedata\Scripts\
  NFSWBetaEngineAudio.asi   the script
  NFSWBetaEngineAudio.ini   settings (defaults, see the comments inside)
  NFSWBetaEngineAudio.dat   per-car engine/exhaust data

gamedata\Sound\BetaEngine\  beta engine/exhaust/sweetener banks, gear banks, BMW whine (whine\),
                            BMW M3 Most Wanted sweeteners (mw_m3\), beta CSI libraries,
                            beta_car_list.txt (car -> beta collections, for the [Cars] section)
gamedata\Sound\Shifting\    CB_GEAR_*.abk  Carbon shift banks loaded by the game
gamedata\Sound\Engine\      modified 2015 engine/exhaust .tmx files (beta Ginsu), plus
                            car_066-exhaust-*.tmx (TVR Cerbera exhaust used by every BMW M3)
gamedata\GLOBAL\attributes.bin
                            car audio settings (BMW M3 audio, upgrade levels, Lamborghini fix).
                            NOTE: this is the complete attributes.bin of the modded game, so it
                            also carries the other attribute changes of the mod.

source\                     ASI source + build.sh (Linux: clang-cl + lld-link, no CRT)

Changes in 1.43 - 1.45
----------------------
- Engine collection mapped to its own rpm range (fixes the engine cutting out at high rpm,
  e.g. upgraded Nissan 240SX).
- car_109 / car_127 / car_142 exhaust .tmx reduced below the size the 2015 engine can load
  (upgraded Viper SRT10 was silent and broke the sound of the following cars; same risk for
  the DB9 and the Mustang GT / GT500 / Boss 302 / Cobra 427).
- Upgraded Lamborghini (Reventon, Murcielago 650-4 / 670-4 SV, Estoque, Aventador), Bentley
  Continental and Zonda Cinque: Gallardo engine instead of the Zonda exhaust used as engine
  (2015 layer, attributes.bin) and lam_gallardo_exh + lam_gallardo beta pair (ini [Cars]).
  Fixes the muffled engine and the loud whistle.
- [Cars] accepts caraudio keys in hex (upgrade levels have no name).
- Diagnostic tools, off by default: [Debug] MuteKeys (F9/F10/F11 layer solo) and [AutoTest]
  (automatic layer test with recording of the game output to Scripts\AudioTest\).
