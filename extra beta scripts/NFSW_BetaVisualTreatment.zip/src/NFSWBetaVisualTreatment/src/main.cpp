// NFSWBetaVisualTreatment - visual treatment in stile beta asiatica per NFS World 2015.
//
// Cosa cambia
//   Il passaggio finale della visual treatment (shader "composito" dentro IDI_VISUALTREATMENT_FX e
//   IDI_VISUALTREATMENT_FX_1X, risorse RCDATA di nfsw.exe) nella 2015 fa:
//       colore = LUT(scena) + bloom;  colore = lerp(colore, cvVignetteColour, vignetta);  colore *= luminosita'
//   La LUT (FILTER0..15, colour cube 32x32x32 in GlobalB.lzc) e la vignetta verso un colore sono il filtro
//   "slavato". Nella beta asiatica lo stesso shader non ha la vignetta a colore: moltiplica per una
//   maschera (scurisce i bordi) e il resto e' identico (bloom, luci, lens flare sono passaggi separati).
//   L'ASI ricostruisce solo il composito: LUT dosabile (0 = niente filtro 2015), bloom, saturazione,
//   contrasto, vignetta scura come la beta (o quella 2015 originale). Tutti gli altri passaggi della
//   visual treatment (bloom, motion blur, distorsione dello schermo, flare, luci) restano quelli del gioco.
//
// Come
//   Sostituisce nell'IAT di nfsw.exe D3DXCreateEffectFromResourceA: quando il gioco carica un effetto
//   dalle risorse, l'ASI ne fa una copia, cerca i 4 shader compositi conosciuti (confronto esatto delle
//   istruzioni), li sostituisce con quelli nuovi (stessa tabella costanti CTAB, valori dell'ini scritti
//   nelle costanti def c20..c23) e crea l'effetto con D3DXCreateEffect. Se qualcosa non torna usa
//   l'effetto originale. nfsw.exe e i file del gioco non vengono modificati.
#include <windows.h>
#include "Shaders.h"

extern "C" void* __cdecl memset(void* d, int c, size_t n) { unsigned char* p = (unsigned char*)d; while (n--) *p++ = (unsigned char)c; return d; }
extern "C" void* __cdecl memcpy(void* d, const void* s, size_t n) { unsigned char* a = (unsigned char*)d; const unsigned char* b = (const unsigned char*)s; while (n--) *a++ = *b++; return d; }
#pragma function(memset, memcpy)

typedef HRESULT(WINAPI* FromResource_t)(void* dev, HMODULE mod, LPCSTR res, const void* defines, void* include,
                                         DWORD flags, void* pool, void** effect, void** errors);
typedef HRESULT(WINAPI* CreateEffect_t)(void* dev, const void* data, UINT len, const void* defines, void* include,
                                         DWORD flags, void* pool, void** effect, void** errors);

static FromResource_t g_origFromResource;
static CreateEffect_t g_createEffect;
static char  g_ini[MAX_PATH];
static char  g_log[MAX_PATH];
static bool  g_logOn = true;
static bool  g_enabled = true;
static int   g_mode = 1;
static float g_c20[4], g_c21[4], g_c22[4], g_c23[4];

// ---------------------------------------------------------------- stringhe / log
static int  StrLen(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
static void StrCpy(char* d, const char* s, int cap) { int i = 0; if (s) for (; s[i] && i < cap - 1; ++i) d[i] = s[i]; d[i] = 0; }
static void StrCat(char* d, const char* s, int cap) { int n = StrLen(d); StrCpy(d + n, s, cap - n); }
static char Lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static bool StrIEq(const char* a, const char* b) { if (!a || !b) return false; while (*a && Lower(*a) == Lower(*b)) { ++a; ++b; } return Lower(*a) == Lower(*b); }
static void IntToStr(int v, char* out) { char t[16]; int n = 0; bool neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v; do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u); int i = 0; if (neg) out[i++] = '-'; while (n) out[i++] = t[--n]; out[i] = 0; }
static void FloatToStr(float f, char* out)
{
    int i = 0; if (f < 0) { out[i++] = '-'; f = -f; }
    int ip = (int)f; int fp = (int)((f - (float)ip) * 1000.0f + 0.5f); if (fp >= 1000) { ++ip; fp -= 1000; }
    IntToStr(ip, out + i); i = StrLen(out); out[i++] = '.';
    out[i++] = (char)('0' + fp / 100); out[i++] = (char)('0' + (fp / 10) % 10); out[i++] = (char)('0' + fp % 10); out[i] = 0;
}
static float ParseFloat(const char* p, float def)
{
    while (*p == ' ' || *p == '\t') ++p;
    bool neg = false; if (*p == '-' || *p == '+') { neg = *p == '-'; ++p; }
    if (!((*p >= '0' && *p <= '9') || *p == '.' || *p == ',')) return def;
    float v = 0; while (*p >= '0' && *p <= '9') { v = v * 10.0f + (float)(*p - '0'); ++p; }
    if (*p == '.' || *p == ',') { ++p; float s = 0.1f; while (*p >= '0' && *p <= '9') { v += s * (float)(*p - '0'); s *= 0.1f; ++p; } }
    return neg ? -v : v;
}
static void Log(const char* a, const char* b = 0, const char* c = 0, const char* d = 0)
{
    if (!g_logOn) return;
    HANDLE h = CreateFileA(g_log, FILE_APPEND_DATA, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w; const char* parts[4] = { a, b, c, d };
    for (int i = 0; i < 4; ++i) if (parts[i]) WriteFile(h, parts[i], StrLen(parts[i]), &w, 0);
    WriteFile(h, "\r\n", 2, &w, 0);
    CloseHandle(h);
}
static void LogHex(const char* what, DWORD v)
{
    char buf[16]; const char* hx = "0123456789ABCDEF"; buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 8; ++i) buf[2 + i] = hx[(v >> (28 - 4 * i)) & 15];
    buf[10] = 0; Log(what, buf);
}
static float IniFloat(const char* key, float def)
{
    char buf[64]; GetPrivateProfileStringA("VisualTreatment", key, "", buf, sizeof(buf), g_ini);
    return buf[0] ? ParseFloat(buf, def) : def;
}
static float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ---------------------------------------------------------------- parametri
static void LoadSettings()
{
    g_logOn   = GetPrivateProfileIntA("General", "Log", 1, g_ini) != 0;
    g_enabled = GetPrivateProfileIntA("General", "Enabled", 1, g_ini) != 0;
    float lut      = Clamp(IniFloat("ColourFilter", 0.0f), 0.0f, 1.0f);
    float bloom    = Clamp(IniFloat("Bloom", 1.0f), 0.0f, 4.0f);
    float sat      = Clamp(IniFloat("Saturation", 1.10f), 0.0f, 3.0f);
    float contrast = Clamp(IniFloat("Contrast", 1.10f), 0.2f, 3.0f);
    float pivot    = Clamp(IniFloat("ContrastPivot", 0.40f), 0.0f, 1.0f);
    float bright   = Clamp(IniFloat("Brightness", 0.0f), -0.5f, 0.5f);
    g_mode         = (int)GetPrivateProfileIntA("VisualTreatment", "VignetteMode", 1, g_ini);
    float vStart   = Clamp(IniFloat("VignetteStart", 0.55f), 0.0f, 1.35f);
    float vStr     = Clamp(IniFloat("VignetteStrength", 0.40f), 0.0f, 1.0f);
    if (g_mode < 0 || g_mode > 2) g_mode = 1;
    if (g_mode == 0) { g_mode = 1; vStr = 0.0f; }
    // c20 = (LUT, bloom, saturazione, -)   c21 = pesi luminanza   c23 = (contrasto, offset)
    // c22 = vignetta su d^2 (d = distanza dal centro, angoli d^2 = 2): v = sat((d^2 - start^2) * k)
    float s2 = vStart * vStart, k = 1.0f / (2.0f - s2 > 0.05f ? 2.0f - s2 : 0.05f);
    g_c20[0] = lut; g_c20[1] = bloom; g_c20[2] = sat; g_c20[3] = 0;
    g_c21[0] = 0.299f; g_c21[1] = 0.587f; g_c21[2] = 0.114f; g_c21[3] = 0;
    g_c22[0] = -s2 * k; g_c22[1] = k; g_c22[2] = -vStr; g_c22[3] = 1.0f;
    g_c23[0] = contrast; g_c23[1] = pivot * (1.0f - contrast) + bright; g_c23[2] = 0; g_c23[3] = 0;
    char a[16], b[16], c[16], d[16];
    FloatToStr(lut, a); FloatToStr(bloom, b); FloatToStr(sat, c); FloatToStr(contrast, d);
    Log("parametri: ColourFilter=", a, " Bloom=", b); Log("           Saturation=", c, " Contrast=", d);
    IntToStr(g_mode, a); FloatToStr(vStart, b); FloatToStr(vStr, c);
    Log("           VignetteMode=", a, " VignetteStart=", b); Log("           VignetteStrength=", c);
}

// ---------------------------------------------------------------- sostituzione degli shader
static const DWORD kEnd = 0x0000FFFF;

// istruzioni (senza commenti) di uno shader: true se coincidono con ref
static bool SameInstructions(const DWORD* t, int n, const u32* ref, int refLen)
{
    int i = 1, r = 0;
    while (i < n) {
        DWORD x = t[i];
        if ((x & 0xFFFF) == 0xFFFE) { i += 1 + (int)((x >> 16) & 0x7FFF); continue; }
        if (x == kEnd) return r == refLen;
        int len = 1 + (int)((x >> 24) & 0xF);
        if (i + len > n || r + len > refLen) return false;
        for (int k = 0; k < len; ++k) if (t[i + k] != ref[r + k]) return false;
        i += len; r += len;
    }
    return false;
}

// copia lo shader originale (versione + commenti CTAB/PRES) con le istruzioni nuove; ritorna i DWORD scritti
static int BuildShader(const DWORD* t, int n, const VTShader& s, DWORD* out)
{
    const u32* body = g_mode == 2 ? s.mode2 : s.mode1;
    int bodyLen = g_mode == 2 ? s.len2 : s.len1;
    int o = 0; out[o++] = t[0];
    for (int i = 1; i < n;) {
        DWORD x = t[i];
        if (x == kEnd) break;
        if ((x & 0xFFFF) == 0xFFFE) { int len = 1 + (int)((x >> 16) & 0x7FFF); for (int k = 0; k < len; ++k) out[o++] = t[i + k]; i += len; continue; }
        i += 1 + (int)((x >> 24) & 0xF);
    }
    int start = o;
    for (int k = 0; k < bodyLen; ++k) out[o++] = body[k];
    const float* vals[4] = { g_c20, g_c21, g_c22, g_c23 };
    for (int d = 0; d < 4; ++d) memcpy(&out[start + s.defs[d]], vals[d], 16);
    out[o++] = kEnd;
    return o;
}

// copia dell'effetto con gli shader compositi sostituiti; ritorna la dimensione (0 = nessuno trovato)
static DWORD PatchEffect(const unsigned char* src, DWORD size, unsigned char*& out, int& replaced)
{
    replaced = 0; out = 0;
    if (size < 16 || *(const DWORD*)src != 0xFEFF0901) return 0;
    const int nShaders = (int)(sizeof(kShaders) / sizeof(kShaders[0]));
    int maxGrow = 0;
    for (int s = 0; s < nShaders; ++s) { const VTShader& v = kShaders[s]; int g = (v.len2 > v.len1 ? v.len2 : v.len1) - v.origLen; if (g > maxGrow) maxGrow = g; }
    DWORD cap = size + (DWORD)(nShaders * 2) * (DWORD)(maxGrow + 8) * 4 + 64;
    out = (unsigned char*)HeapAlloc(GetProcessHeap(), 0, cap);
    if (!out) return 0;
    DWORD in = 0, o = 0;
    for (DWORD p = 8; p + 8 <= size; p += 4) {
        DWORD ver = *(const DWORD*)(src + p);
        if (ver != 0xFFFF0200) continue;
        DWORD bytes = *(const DWORD*)(src + p - 4);
        if (bytes < 16 || (bytes & 3) || p + bytes > size) continue;
        const DWORD* t = (const DWORD*)(src + p);
        int n = (int)(bytes / 4);
        for (int s = 0; s < nShaders; ++s) {
            if (!SameInstructions(t, n, kShaders[s].orig, kShaders[s].origLen)) continue;
            // copia fino alla dimensione (esclusa), poi dimensione nuova + shader nuovo
            DWORD upTo = p - 4;
            memcpy(out + o, src + in, upTo - in); o += upTo - in;
            DWORD* dst = (DWORD*)(out + o + 4);
            int words = BuildShader(t, n, kShaders[s], dst);
            *(DWORD*)(out + o) = (DWORD)words * 4;
            o += 4 + (DWORD)words * 4;
            in = p + bytes;
            ++replaced;
            Log("  composito sostituito: ", kShaders[s].name);
            p = in - 4;
            break;
        }
    }
    if (!replaced) { HeapFree(GetProcessHeap(), 0, out); out = 0; return 0; }
    memcpy(out + o, src + in, size - in); o += size - in;
    return o;
}

static void ReleaseCom(void* p) { if (p) { typedef unsigned long(WINAPI * Rel)(void*); (*(Rel**)p)[2](p); } }

static HRESULT WINAPI HookFromResource(void* dev, HMODULE mod, LPCSTR res, const void* defines, void* include,
                                       DWORD flags, void* pool, void** effect, void** errors)
{
    if (g_enabled && g_createEffect) {
        HRSRC r = FindResourceA(mod, res, (LPCSTR)10);
        HGLOBAL g = r ? LoadResource(mod, r) : 0;
        const unsigned char* data = g ? (const unsigned char*)LockResource(g) : 0;
        DWORD size = r ? SizeofResource(mod, r) : 0;
        if (data && size) {
            unsigned char* patched; int replaced;
            DWORD len = PatchEffect(data, size, patched, replaced);
            if (len) {
                char name[64];
                if (IS_INTRESOURCE(res)) IntToStr((int)(UINT_PTR)res, name); else StrCpy(name, res, sizeof(name));
                HRESULT hr = g_createEffect(dev, patched, len, defines, include, flags, pool, effect, errors);
                HeapFree(GetProcessHeap(), 0, patched);
                if (hr >= 0) { Log("effetto ", name, ": visual treatment beta attiva"); return hr; }
                LogHex("ERRORE: D3DXCreateEffect ha rifiutato l'effetto modificato, uso l'originale. hr=", (DWORD)hr);
                if (errors && *errors) {
                    typedef void*(WINAPI * GetPtr)(void*); const char* msg = (const char*)(*(GetPtr**)*errors)[3](*errors);
                    if (msg) Log("  ", msg);
                    ReleaseCom(*errors); *errors = 0;
                }
            }
        }
    }
    return g_origFromResource(dev, mod, res, defines, include, flags, pool, effect, errors);
}

// ---------------------------------------------------------------- IAT
static bool HookImport(const char* dll, const char* fn, void* hook, void** orig)
{
    unsigned char* base = (unsigned char*)GetModuleHandleA(0);
    HMODULE lib = GetModuleHandleA(dll);
    void* real = lib ? GetProcAddress(lib, fn) : 0;
    DWORD nt = *(DWORD*)(base + 0x3C);
    DWORD impRva = *(DWORD*)(base + nt + 24 + 104);
    if (!impRva) return false;
    for (DWORD* d = (DWORD*)(base + impRva); d[3]; d += 5) {
        if (!StrIEq((const char*)(base + d[3]), dll)) continue;
        DWORD* names = d[0] ? (DWORD*)(base + d[0]) : 0;
        DWORD* iat = (DWORD*)(base + d[4]);
        for (int i = 0; iat[i]; ++i) {
            bool hit = real && iat[i] == (DWORD)real;
            if (!hit && names && !(names[i] & 0x80000000)) hit = StrIEq((const char*)(base + names[i] + 2), fn);
            if (!hit) continue;
            DWORD old;
            if (!VirtualProtect(&iat[i], 4, PAGE_READWRITE, &old)) return false;
            *orig = (void*)iat[i];
            iat[i] = (DWORD)hook;
            VirtualProtect(&iat[i], 4, old, &old);
            return true;
        }
    }
    return false;
}

static void Init(HMODULE self)
{
    char path[MAX_PATH]; GetModuleFileNameA(self, path, MAX_PATH);
    int n = StrLen(path); while (n > 0 && path[n - 1] != '.' && path[n - 1] != '\\') --n;
    if (n > 0 && path[n - 1] == '.') path[n - 1] = 0;
    StrCpy(g_ini, path, MAX_PATH); StrCat(g_ini, ".ini", MAX_PATH);
    StrCpy(g_log, path, MAX_PATH); StrCat(g_log, ".log", MAX_PATH);
    DeleteFileA(g_log);
    LoadSettings();
    Log("NFSWBetaVisualTreatment 1.0");
    if (!g_enabled) { Log("disattivato ([General] Enabled=0)"); return; }
    HMODULE d3dx = LoadLibraryA("d3dx9_43.dll");
    g_createEffect = d3dx ? (CreateEffect_t)GetProcAddress(d3dx, "D3DXCreateEffect") : 0;
    if (!g_createEffect) { Log("ERRORE: D3DXCreateEffect non trovato in d3dx9_43.dll"); return; }
    if (HookImport("d3dx9_43.dll", "D3DXCreateEffectFromResourceA", (void*)HookFromResource, (void**)&g_origFromResource))
        Log("D3DXCreateEffectFromResourceA agganciato: in attesa del caricamento della visual treatment");
    else
        Log("ERRORE: import D3DXCreateEffectFromResourceA non trovato in nfsw.exe");
}

extern "C" BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); Init(h); }
    return TRUE;
}
