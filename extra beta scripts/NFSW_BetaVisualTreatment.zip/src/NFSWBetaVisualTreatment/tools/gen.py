import struct,sys
TYPES={'r':0,'v':1,'c':2,'t':3,'oC':8,'s':10}
OPC={'mov':1,'add':2,'mad':4,'mul':5,'rcp':6,'rsq':7,'dp3':8,'lrp':18,'dp2add':90,'def':81,'tex':66}
def regtok(r):
    import re
    m=re.match(r'^(-?)(oC|[rvcts])(\d+)(?:\.([xyzw]+))?$',r); assert m,r
    neg,t,n,sw=m.groups(); ty=TYPES[t]
    return neg,ty,int(n),sw
def dst(r,sat=False):
    neg,ty,n,sw=regtok(r); wm=0xF if not sw else sum(1<<'xyzw'.index(c) for c in sw)
    return 0x80000000|((ty&7)<<28)|((ty&0x18)<<8)|(wm<<16)|((1 if sat else 0)<<20)|n
def src(r):
    neg,ty,n,sw=regtok(r)
    if not sw: sw='xyzw'
    sw=(sw+sw[-1]*4)[:4]
    s=sum('xyzw'.index(c)<<(2*i) for i,c in enumerate(sw))
    return 0x80000000|((ty&7)<<28)|((ty&0x18)<<8)|(s<<16)|((1 if neg else 0)<<24)|n
def asm(lines):
    out=[]; defs={}
    for ln in lines:
        ln=ln.split(';')[0].strip()
        if not ln: continue
        op,rest=(ln.split(None,1)+[''])[:2]; args=[a.strip() for a in rest.split(',')]
        sat=op.endswith('_sat'); op=op.replace('_sat','')
        if op=='def':
            defs[args[0]]=len(out)+2
            out+= [OPC['def']|(5<<24), dst(args[0])]+list(struct.unpack('<4I',struct.pack('<4f',*map(float,args[1:]))))
            continue
        toks=[dst(args[0],sat)]+[src(a) for a in args[1:]]
        out+=[OPC[op]|(len(toks)<<24)]+toks
    return out,defs
def instrs(d,o):
    n=struct.unpack_from('<I',d,o-4)[0]; toks=list(struct.unpack_from('<%dI'%(n//4),d,o))
    i=1; ins=[]; comments=[]
    while i<len(toks):
        t=toks[i]
        if t&0xFFFF==0xFFFE: k=(t>>16)&0x7FFF; comments+=toks[i:i+1+k]; i+=1+k; continue
        if t==0xFFFF: break
        l=(t>>24)&0xF; ins.append(toks[i:i+1+l]); i+=1+l
    return toks[0],comments,ins
def tail(S,B,L,I,K,T1,T2,mode):
    a=[f'lrp {T1}.xyz, c20.x, {L}, {I}', f'mad {T2}.xyz, {B}, c20.y, {T1}', f'dp3 {T1}.x, {T2}, c21',
       f'lrp {L}.xyz, c20.z, {T2}, {T1}.x', f'mad {T2}.xyz, {L}, c23.x, c23.y',
       f'mad {T1}.xy, t0, {K}.x, {K}.y', f'dp2add {T1}.w, {T1}, {T1}, {K}.z']
    if mode==1:
        a+=[f'mad_sat {T1}.w, {T1}.w, c22.y, c22.x', f'mad {T1}.w, {T1}.w, c22.z, c22.w', f'mul {T2}.xyz, {T2}, {T1}.w', f'mul {S}.xyz, {T2}, c0.x']
    else:
        a+=[f'rsq {T1}.w, {T1}.w', f'rcp {T1}.w, {T1}.w', f'add {T1}.w, {T1}.w, -c0.z', f'mul_sat {T1}.w, {T1}.w, c0.w',
            f'lrp {L}.xyz, {T1}.w, c1, {T2}', f'mul {S}.xyz, {L}, c0.x']
    a+=[f'mov oC0, {S}']
    return a
DEFS=['def c20, 1, 1, 1, 0','def c21, 0.299, 0.587, 0.114, 0','def c22, 0, 1, 0, 1','def c23, 1, 0, 0, 0']
# variant: file, offset, number of prefix instrs to keep (after defs/dcls), register map, patch for tint
V=[('IDI_VISUALTREATMENT_FX_15.bin',0x41c0,dict(S='r0',B='r1',L='r2',I='r0',K='c2',T1='r3',T2='r4')),
   ('IDI_VISUALTREATMENT_FX_1X_15.bin',0x4670,dict(S='r0',B='r2',L='r1',I='r0',K='c2',T1='r3',T2='r4')),
   ('IDI_VISUALTREATMENT_FX_15.bin',0x37cc,dict(S='r0',B='r2',L='r1',I='r4',K='c9',T1='r3',T2='r5')),
   ('IDI_VISUALTREATMENT_FX_1X_15.bin',0x3ca4,dict(S='r0',B='r2',L='r1',I='r4',K='c9',T1='r3',T2='r5'))]
TEX=66; ADD=2
res=[]
for fn,off,m in V:
    d=open('/tmp/fx/'+fn,'rb').read(); ver,com,ins=instrs(d,off)
    orig=[t for x in ins for t in x]
    # keep everything up to the bloom tex (last tex instruction), drop the rest
    lastTex=max(i for i,x in enumerate(ins) if x[0]&0xFFFF==TEX)
    pre=[list(x) for x in ins[:lastTex+1]]
    if m['I']=='r4':
        # add rX.xyz, r0, c5 -> add r4, r0, c5 ; following volume tex uses r4
        ai=[i for i,x in enumerate(pre) if x[0]&0xFFFF==ADD and (x[3]&0x7FF)==5 and ((x[3]>>28)&7)==2][-1]
        pre[ai][1]=dst('r4'); 
        ti=[i for i,x in enumerate(pre) if i>ai and x[0]&0xFFFF==TEX and (x[3]&0x7FF)==3][0]
        pre[ti][2]=src('r4')
    # insert our defs after the original defs
    nd=sum(1 for x in pre if x[0]&0xFFFF==81)
    dtoks,dpos=asm(DEFS)
    out={}
    for mode in (1,2):
        tt,_=asm(tail(**m,mode=mode))
        head=[t for x in pre[:nd] for t in x]
        body=head+dtoks+[t for x in pre[nd:] for t in x]+tt
        dp={k:len(head)+v for k,v in dpos.items()}
        out[mode]=(body,dp)
    res.append((fn,off,ver,com,orig,out))
# write header
h=['// generato da gen.py - shader composito della visual treatment (2015) ricostruiti in stile beta','#pragma once','typedef unsigned int u32;']
for k,(fn,off,ver,com,orig,out) in enumerate(res):
    h.append(f'// {fn} @0x{off:x}')
    h.append(f'static const u32 kOrig{k}[{len(orig)}] = {{'+','.join('0x%X'%t for t in orig)+'};')
    for mode in (1,2):
        body,dp=out[mode]
        h.append(f'static const u32 kNew{k}_{mode}[{len(body)}] = {{'+','.join('0x%X'%t for t in body)+'};')
    h.append(f'static const int kDef{k}[4] = {{{out[1][1]["c20"]},{out[1][1]["c21"]},{out[1][1]["c22"]},{out[1][1]["c23"]}}};')
    assert out[1][1]==out[2][1]
h.append('struct VTShader { const u32* orig; int origLen; const u32* mode1; int len1; const u32* mode2; int len2; const int* defs; const char* name; };')
h.append('static const VTShader kShaders[] = {'+','.join(f'{{kOrig{k},{len(r[4])},kNew{k}_1,{len(r[5][1][0])},kNew{k}_2,{len(r[5][2][0])},kDef{k},"{r[0]}@0x{r[1]:x}"}}' for k,r in enumerate(res))+'};')
open('/tmp/vt/asi/src/Shaders.h','w').write('\n'.join(h)+'\n')
import pickle; pickle.dump(res,open('/tmp/vt/gen/res.pkl','wb'))
print('ok', [(r[0],r[1],len(r[4]),len(r[5][1][0]),len(r[5][2][0])) for r in res])
