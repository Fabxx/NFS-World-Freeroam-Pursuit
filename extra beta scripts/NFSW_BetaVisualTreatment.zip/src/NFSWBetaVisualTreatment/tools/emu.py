import struct,math,pickle,random,sys
sys.path.insert(0,'/tmp/vt/gen'); from gen import *
def run(toks,consts,inputs,tex):
    R={}; C=dict(consts); i=0
    def rd(t):
        ty=((t>>28)&7)|((t>>8)&0x18); n=t&0x7FF; key=(ty,n)
        if ty==10: return [0,0,0,0]
        v=C.get(n,[0,0,0,0]) if ty==2 else (inputs.get(key) if ty==3 else R.get(key))
        assert v is not None,('uninit',ty,n)
        sw=(t>>16)&0xFF; v=[v[(sw>>(2*k))&3] for k in range(4)]
        mod=(t>>24)&0xF
        if mod==1: v=[-x for x in v]
        elif mod==11: v=[abs(x) for x in v]
        return v
    def wr(t,v,cur=None):
        ty=((t>>28)&7)|((t>>8)&0x18); n=t&0x7FF; wm=(t>>16)&0xF; sat=(t>>20)&1
        old=R.get((ty,n),[0.0]*4)
        nv=[ (min(1,max(0,v[k])) if sat else v[k]) if wm>>k&1 else old[k] for k in range(4)]
        R[(ty,n)]=nv
    while i<len(toks):
        t=toks[i]; op=t&0xFFFF; l=(t>>24)&0xF; a=toks[i+1:i+1+l]; i+=1+l
        if op==81: C[a[0]&0x7FF]=list(struct.unpack('<4f',struct.pack('<4I',*a[1:5]))); continue
        if op==31: continue
        s=[rd(x) for x in a[1:]]
        if op==1: v=s[0]
        elif op==2: v=[x+y for x,y in zip(s[0],s[1])]
        elif op==4: v=[x*y+z for x,y,z in zip(*s)]
        elif op==5: v=[x*y for x,y in zip(s[0],s[1])]
        elif op==6: v=[1/s[0][0] if s[0][0] else float('inf')]*4
        elif op==7: v=[1/math.sqrt(s[0][0]) if s[0][0]>0 else float('inf')]*4
        elif op==8: v=[sum(s[0][k]*s[1][k] for k in range(3))]*4
        elif op==18: v=[f*x+(1-f)*y for f,x,y in zip(*s)]
        elif op==90: v=[s[0][0]*s[1][0]+s[0][1]*s[1][1]+s[2][0]]*4
        elif op==19: v=[x-math.floor(x) for x in s[0]]
        elif op==11: v=[max(x,y) for x,y in zip(s[0],s[1])]
        elif op==35: v=[abs(x) for x in s[0]]
        elif op==37: x=s[0][0]; v=[math.cos(x),math.sin(x),0,0]
        elif op==66: v=tex(a[2]&0x7FF,s[0])
        else: raise Exception('op %d'%op)
        if op==37:
            # sincos writes masked comps
            pass
        if (a[0]>>28)&7==0 and (a[0]>>8)&0x18==0x18 or (((a[0]>>28)&7)|((a[0]>>8)&0x18))==8: R['out']=v; continue
        wr(a[0],v)
    return R['out']
def mktex(seed):
    rnd=random.Random(seed)
    def tex(s,c):
        h=hash((s,round(c[0],5),round(c[1],5),round(c[2],5)))%1000003
        r=random.Random(h); return [r.random() for _ in range(4)]
    return tex
res=pickle.load(open('res.pkl','rb'))
ok=True
for fn,off,ver,com,orig,out in res:
    body,dp=out[2]
    for trial in range(30):
        rnd=random.Random(trial)
        consts={k:[rnd.uniform(-1,1) for _ in range(4)] for k in range(12)}
        consts[0][3]=abs(consts[0][3])
        inputs={(3,0):[rnd.random(),rnd.random(),0,1]}
        tex=mktex(trial)
        o=run(orig,consts,inputs,tex)
        nb=list(body)
        def setdef(name,vals):
            p=dp[name]; nb[p:p+4]=struct.unpack('<4I',struct.pack('<4f',*vals))
        setdef('c20',[1,1,1,0]); setdef('c23',[1,0,0,0])
        n=run(nb,consts,inputs,tex)
        if any(abs(x-y)>1e-4 for x,y in zip(o,n)): ok=False; print('MISMATCH',fn,hex(off),o,n); break
    # mode1 with strength 0 and identity equals original without vignette
print('all equal' if ok else 'fail')
